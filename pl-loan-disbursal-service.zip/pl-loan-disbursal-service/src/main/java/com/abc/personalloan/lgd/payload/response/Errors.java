package com.abc.personalloan.lgd.payload.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Errors {

	private String code;
	private String errorType;
	private String description;

}
