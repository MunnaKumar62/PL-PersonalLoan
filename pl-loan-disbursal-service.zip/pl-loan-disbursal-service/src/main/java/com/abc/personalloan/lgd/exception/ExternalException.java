package com.abc.personalloan.lgd.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExternalException extends RuntimeException {

	private static final long serialVersionUID = 4087930070289795747L;

	private String errorCode;
	private String errorMessage;
	private Integer code;
	private String reason;
	private String message;
	

	public ExternalException() {
		super();
	}

	public ExternalException(Throwable cause) {
		super(cause);
	}

	public ExternalException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public ExternalException(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public ExternalException(String errorCode, String errorMessage, Integer code, String reason) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.code = code;
		this.reason = reason;
	}

	public ExternalException(int code, String reason, String errorCode, String errorMessage,String message) {
		super();
		this.code = code;
		this.reason = reason;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.message = message;
				
		
	}
}