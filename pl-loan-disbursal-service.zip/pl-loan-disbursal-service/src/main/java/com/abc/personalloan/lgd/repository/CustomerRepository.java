package com.abc.personalloan.lgd.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.CustomerDetails;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerDetails, Long> {

	Optional<CustomerDetails> findByMobileNumber(String mobileNumber);

	Optional<CustomerDetails> findByAccountId(String accountId);
}
