package com.abc.personalloan.lgd.common.model.offer;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OfferResponse {

	
    @JsonProperty("Code") 
    public int code;
    @JsonProperty("Message") 
    public String message;
    @JsonProperty("Success") 
    public boolean success;
    @JsonProperty("Data") 
    public OfferData data;
    @JsonProperty("FailureReasons") 
    public FailureReason failureReasons;

}
