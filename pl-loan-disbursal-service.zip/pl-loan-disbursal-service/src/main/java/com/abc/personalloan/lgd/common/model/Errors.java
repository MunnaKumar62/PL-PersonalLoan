package com.abc.personalloan.lgd.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Errors {

	private String errorCode;
	private String fieldName;
	private String message;

}
