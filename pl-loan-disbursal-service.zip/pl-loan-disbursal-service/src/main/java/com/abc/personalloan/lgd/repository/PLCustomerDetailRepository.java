package com.abc.personalloan.lgd.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.PLCustomerDetail;

@Repository
public interface PLCustomerDetailRepository extends JpaRepository<PLCustomerDetail, Long> {

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndActive(String accountId, Boolean active);

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndLoanIdAndCustomerIdAndActive(String accountId, String loanId, Long customerId, Boolean active);
	
	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId)")
	Optional<PLCustomerDetail> findByAccountId(String accountId);
  
	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId)")
	Optional<PLCustomerDetail> findByAccountIdAndLoanIdAndCustomerId(String accountId, String loanId, Long customerId);
	
	@Query("SELECT c FROM PLCustomerDetail c WHERE c.customerId =:customerId and c.accountId =:accountId and c.loanId =:loanId  ORDER BY c.customerDetailId DESC LIMIT 1")
	PLCustomerDetail findTopByCustomerIdAndAccountIdAndLoanId(@Param("customerId") Long customerId,@Param("accountId") String accountId,@Param("loanId") String loanId);

}
