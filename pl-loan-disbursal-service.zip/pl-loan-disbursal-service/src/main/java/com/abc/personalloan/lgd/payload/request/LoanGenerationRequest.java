package com.abc.personalloan.lgd.payload.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class LoanGenerationRequest {

	private String accountId;

	@JsonProperty("loanAmount")
	private Integer loanAmount;

	@JsonProperty("disbursalAmount")
	private Integer disbursalAmount;

	@JsonProperty("tenure")
	private String tenure;

	@JsonProperty("bankDetails")
	private BankDetails bankDetails;

	@JsonProperty("charges")
	private List<Charges> charges;

	@JsonProperty("mandateDetails")
	private MandateDetails mandateDetails;

	@JsonProperty("uniqueId")
	private String uniqueId;

}
