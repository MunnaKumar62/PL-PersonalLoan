package com.abc.personalloan.lgd.constants;

public interface Constants {

	public static final String ALL = "*";

	public static final String API = "/api";

	public static final String VERSION = Constants.SLASH + "${pl.url.version}";

	public static final String PL_JOURNEY = "PL";

	public static final String PL_AUTH_TOKEN = "AUTH_TOKEN";

	public static final String PL = "PL";

	public static final String CHECK_API_STATUS = "/api-status";

	public static final String PERSONAL_LOAN = "/personal-loan";

	public static final String LOAN_DISBURSEMENT = "/loan-disbursement";

	public static final String DISBURSEMENT_STATUS = "/disbursement-status";
	
	public static final String DISBURSEMENT_STATUS_APICALL = "/disbursement-status-apicall";
	
	public static final String DISBURSEMENT_STATUS_JOB = "/disbursement-status-job";
	
	public static final String LOAN_DISBURSEMENT_DTLS = "/loandisbursedtls";

	public static final String DISBURSEMENT_CALLBACK = "/disbursement-callback";
	
	public static final String REGULATORY_DATA = "/regulatorydata";
	
	public static final String DISBURSAL ="/disbursal/{customerId}/{accountId}/{loanId}";

	public static final String LOAN_AGREEMENT_PDF = "/loan-agreement-pdf";

	public static final String SANCATION_LETTER_PDF = "/sanction-letter-pdf";

	public static final String REPAYMENTSSCHEDULE_KFS_PDF = "/repayment-schedule-kfs-pdf";

	public static final String PL_DISBURSEMENT_GENERATION = "DISBURSEMENT_GENERATION";

	public static final String PL_DISBURSEMENT_STATUS = "DISBURSEMENT_STATUS";
	
	public static final String PL_DISBURSEMENT_CALLBACK = "DISBURSEMENT_CALLBACK";

	public static final String PL_E_MANDATE_POLLING = "E_MANDATE_POLLING";
	
	public static final String PL_PAN_NAME_CHECK = "PAN_NAME_CHECK";
	
	public static final String PL_GET_OFFERS = "GET_OFFERS";
	
	public static final String PL_LEAD_UPDATE = "LEAD_UPDATE";
	
	public static final String PL_REGULATORY_DATA = "REGULATORY_DATA";

	/**
	 * ********** Common Constants **********
	 */
	public static final String EMPTY = "";
	
	public static final String YES = "Y";
	
	public static final String NO = "N";
	
	public static final String COMMA = ",";

	public static final String SLASH = "/";

	public static final String TILDA = "~";

	public static final String UNDER_SQUARE = "_";

	public static final String DATE_FORMAT = "yyyy-MM-dd";

	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy hh:mm:ss a";
	
	public static final String DATE_TIME_FORMAT_1 = "dd-MM-yyyy hh:mm:ss";
	
	public static final String DATE_TIME_FORMAT_2 = "yyyy-MM-dd'T'HH:mm:ss";
	
	public static final String DOB_FORMAT = "dd-MM-yyyy";

	public static final String BEGIN = " Begin";

	public static final String END = " End";

	public static final String EXCEPTION = "[EXCEPTION]";

	public static final String FINALLY_BLOCK = "[FINALLY_BLOCK]";

	public static final String SUCCESS = "success";

	public static final String ERROR = "error";
	
	public static final String DISBURSAL_ERROR = "DISBURSAL_ERROR";

	public static final String IN_PROGRESS = "in_progress";

	public static final String API_STATUS = "API_STATUS";

	public static final String API_RESPONSE = "API_RESPONSE";

	public static final String LOAN_IS_FULLY_DISBURSED = "LOAN_IS_FULLY_DISBURSED";
	
	public static final String LOAN_DISBURSEMENT_IN_PROGRESS = "LOAN_DISBURSEMENT_IN_PROGRESS";
	
	public static final String LOAN_DISBURSMENT_REJECTED = "LOAN_DISBURSMENT_REJECTED";

	public static final String DISBURSED = "DISBURSED";
	
	public static final String REJECTED = "REJECTED";
	
	public static final String PL_DECISION_ENGINE_CONFIG = "DECISION_ENGINE_CONFIG";
	
	public static final String PL_BRE_DETAILS = "BRE_DETAILS";

	public static final int STATUS_CODE_400 = 400;

	
	public static final String PROJECT_ID = "project_id";
	public static final String STRICT_REQUEST_PARAM = "strict";

	public static final String CLIENT_ID = "client_id";

	public static final String SCOPE = "scope";

	public static final String GRANT_TYPE = "grant_type";

	public static final String AUTH_TOKEN = "auth-token";
	
	public static final String X_API_KEY = "X-API-KEY";
	
	public static final String PAGE_INDEX = "pageIndex";
	
	public static final String PAGE_SIZE = "pageSize";
	
	public static final String CATEGORY = "category";

	public static final String CREATED_BY = "system";

	public static final String FILED_ACC_ID = "accountId";

	public static final String FILED_MOB = "mobileNumber";

	public static final String FILED_UNQ_ID = "uniqueId";

	public static final String FILED_EMPLOYER_NAME = "employerName";

	public static final String FILED_EMPLOYEE_NAME = "employeeName";

	public static final String FILED_MOBILE = "mobile";

	public static final String FILED_CONTACT = "contact";

	public static final String FILED_CUSTOMER_ID = "customer_id";

	public static final String FILED_CUSTOMERID = "customerId";

	public static final String FILED_PAYMENT_ID = "pymentId";

	public static final int RETRY_MAX_COUNT = 6;

	public static final int RETRY_INTERVAL = 5000;
	
	public static final String LOCALE_MESSAGE_COUNTRYCODE = "IN";

	public static final String LOCALE_MESSAGE_ENGLISH = "en";
	
	public static final String ERROR_TYPE_BUSINESS="Business Error";
	public static final String ERROR_TYPE_TECHNICAL="Technical Error";
	
	public final static String CLIENT="C";
	public final static String SERVER="S";
	public final static String ERROR_CODE_PREFIX_C="PL-EE-C" ;
	public final static String ERROR_CODE_PREFIX_S="PL-EE-S" ;
	public final static String COLON=": " ;
}
