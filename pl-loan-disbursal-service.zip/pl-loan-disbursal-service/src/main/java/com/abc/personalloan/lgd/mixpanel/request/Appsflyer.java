package com.abc.personalloan.lgd.mixpanel.request;

import lombok.Data;

@Data
public class Appsflyer{
    public Long customer_user_id;
    public String appsflyer_id;
    public String eventName;
//    public String advertising_id;
//    public String oaid;
//    public String amazon_aid;
    public String ip;
    public String bundleIdentifier;
    public String app_version_name;
    public String eventTime;
    public Propertiesvalue eventValue;
}
