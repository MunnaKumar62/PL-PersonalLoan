package com.abc.personalloan.lgd.service.impl;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.entity.BankAccountDetails;
import com.abc.personalloan.lgd.payload.request.PLBankDetailsRequest;
import com.abc.personalloan.lgd.repository.BankAccountDetailsRepository;
import com.abc.personalloan.lgd.service.PLBankAccountDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;

@Slf4j
@Service
public class PLBankAccountDetailsServiceImpl implements PLBankAccountDetailsService, Constants {

    private final String className = "[" + this.getClass().getSimpleName() + "]";

    @Autowired
    BankAccountDetailsRepository bankAccountDetailsRepository;

    @Override
    public BankAccountDetails saveOrUpdate(PLBankDetailsRequest bankDetailsRequest) {

        BankAccountDetails bankAccountDetails = null;
        if (null != bankDetailsRequest) {
            bankAccountDetails = mergeBankDetailsRequest(bankDetailsRequest, findByCustomerIdAndAccountIdAndLoanIdActive(bankDetailsRequest.getCustomerId(), bankDetailsRequest.getAccountId(), bankDetailsRequest.getLoanId(), Boolean.FALSE));
            if (null != bankAccountDetails) {
                bankAccountDetails = bankAccountDetailsRepository.save(bankAccountDetails);
                log.info(className + "[Address: " + bankAccountDetails.toString() + "]");
            }
        }
        return bankAccountDetails;
    }

    private BankAccountDetails mergeBankDetailsRequest(PLBankDetailsRequest source, BankAccountDetails dest) {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

        if (null != dest) {
            log.info(className + methodName + "[UPDATING ADDRESS DETAILS ... ...]");
            dest.setActive(null != source.getActive() ? source.getActive() : dest.isActive());
            dest.setModifiedBy(CREATED_BY);
            dest.setModifiedDate(new Timestamp(new Date().getTime()));
        } else {
            log.info(className + methodName + "[ADDRESS DETAILS NOT FOUND]");
        }
        return dest;
    }

    @Override
    public BankAccountDetails findByCustomerIdAndAccountIdAndLoanIdActive(Long customerId, String accountId, String loanId,  Boolean active) {

        BankAccountDetails bankAccountDetails = null;
        Optional<BankAccountDetails> details = bankAccountDetailsRepository.findByCustomerIdAndAccountIdAndLoanIdActive(customerId, accountId, loanId, active);
        if (details.isPresent()) {
            bankAccountDetails = details.get();
        }
        return bankAccountDetails;
    }
}