package com.abc.personalloan.lgd.payload.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LoanStatusResponse {

	public LoanStatusResponse(String responseStatus) {
		super();
		this.responseStatus = responseStatus;
	}
	
	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private StatusData data;

	@JsonInclude(value = Include.NON_NULL)
	private Error error;
}
