package com.abc.personalloan.lgd.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.entity.CustomerDetails;
import com.abc.personalloan.lgd.repository.CustomerRepository;
import com.abc.personalloan.lgd.service.CustomerDetailsService;
import com.abc.personalloan.lgd.service.biz.CommonBizService;

@Service
public class CustomerDetailsServiceImpl extends CommonBizService implements CustomerDetailsService, Constants {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public CustomerDetails findByCustomerId(Long id) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findById(id);
		if (details.isPresent()) {
			customerDetails = details.get();
		}
		return customerDetails;
	}

	@Override
	public CustomerDetails findByMobileNumber(String mobileNumber) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findByMobileNumber(mobileNumber);
		if (details.isPresent()) {
			customerDetails = details.get();
		}
		return customerDetails;
	}

	@Override
	public CustomerDetails findByAccountId(String accountId) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findByAccountId(accountId);
		if (details.isPresent()) {
			customerDetails = details.get();
		}
		return customerDetails;
	}

}
