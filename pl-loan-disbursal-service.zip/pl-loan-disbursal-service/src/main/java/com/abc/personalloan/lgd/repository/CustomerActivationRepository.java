package com.abc.personalloan.lgd.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.AppActivationn;

@Repository
public interface CustomerActivationRepository extends JpaRepository<AppActivationn, Long> {	

    @Query("SELECT a FROM AppActivationn a WHERE a.mdn = :mdn AND a.cleverTapId IS NOT NULL AND a.mixPanelId IS NOT NULL AND a.appsFlyerId IS NOT NULL ORDER BY a.customerActivationId DESC LIMIT 1")
    AppActivationn findLatestActivationByMdn(@Param("mdn") String mdn);
}