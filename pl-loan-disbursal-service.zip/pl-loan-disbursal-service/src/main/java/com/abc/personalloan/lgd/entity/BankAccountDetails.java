package com.abc.personalloan.lgd.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "t_pl_bank_account_details")
@EntityListeners(AuditingEntityListener.class)
public class BankAccountDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -2546793369822175436L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bank_account_id")
    private Long bankAccountId;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name ="ifsc_code")
    private String ifscCode;

    @Column(name = "account_holder_name")
    private String accountName;

    @Column(name = "card_no")
    private Long cardNumber;

    @Column(name = "account_no")
    private String accountNumber;

    @Column(name = "accountid")
    private String accountId;

    @Column(name = "loan_id")
    private String loanId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "active")
    private boolean active;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_date")
    @CreatedDate
    private Date createdDate;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "modified_date")
    @LastModifiedDate
    private Date modifiedDate;
}