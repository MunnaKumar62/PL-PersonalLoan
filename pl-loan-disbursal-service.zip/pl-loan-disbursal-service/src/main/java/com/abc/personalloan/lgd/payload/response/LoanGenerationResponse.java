package com.abc.personalloan.lgd.payload.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanGenerationResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private Data data;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;

}
