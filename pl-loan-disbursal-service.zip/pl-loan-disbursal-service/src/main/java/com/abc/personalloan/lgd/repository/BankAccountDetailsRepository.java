package com.abc.personalloan.lgd.repository;

import com.abc.personalloan.lgd.entity.BankAccountDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface BankAccountDetailsRepository extends JpaRepository<BankAccountDetails, Long> {

    @Query("SELECT a FROM BankAccountDetails a WHERE a.bankAccountId=(SELECT max(a.bankAccountId) FROM BankAccountDetails a WHERE a.customerId =:customerId and a.accountId =:accountId and a.loanId =:loanId and a.active =:active)")
    Optional<BankAccountDetails> findByCustomerIdAndAccountIdAndLoanIdActive(Long customerId, String accountId, String loanId, Boolean active);
}
