package com.abc.personalloan.lgd.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_customer")
public class CustomerDetails implements Serializable {

	private static final long serialVersionUID = 3944886206643636410L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	@NotNull(message = "{HL4101}")
	private Long customerId;

	@Column(name = "firstname", length = 60)
	@NotBlank(message = "{HL4102}")
	@Size(min = 2, message = "{HL4103}")
	// @Pattern(regexp = "([A-Z]{5}[0-9]{4}[A-Z]{1})", message = "{HL4109}")
	private String firstName;

	@Column(name = "lastname", length = 60)
	// @NotBlank(message = "{4102}")
	// @Size(min = 2, message = "{4108}")
	private String lastName;

	@Column(name = "dateofbirth")
	// @Past(message = "{4108}")
	@Temporal(TemporalType.DATE)
	private LocalDate dateOfBirth;

	@Column(name = "gender", length = 1)
	// @NotBlank(message = "{4103}")
	private String gender;

	@Column(name = "mobilenumber", length = 20)
	@NotBlank(message = "{HL4104}")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "{HL4105}")
	private String mobileNumber;

	@Column(name = "email", length = 60)
	@NotBlank(message = "{HL4106}")
	@Email(message = "{HL4107}")
	private String emailAddress;

	@Column(name = "pannumber", length = 20)
	@NotBlank(message = "{HL4108}")
	@Pattern(regexp = "([A-Z]{5}[0-9]{4}[A-Z]{1})", message = "{HL4109}")
	private String panNumber;

	@Column(name = "aadhaarnumber", length = 20)
	private String aadhaarNumber;

	// @Column(name = "loantype", length = 60)
	// private String loanType;

	@Column(name = "createdby", length = 60)
	private String createdBy;

	@Column(name = "createddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modifiedby", length = 60)
	private String modifiedBy;

	@Column(name = "modifieddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "accountid")
	private String accountId;

	// @Valid
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customerDetails", cascade = CascadeType.ALL)
	private List<AccountDetails> accountDetails;

	// @Valid
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customerDetails", cascade = CascadeType.ALL)
	private List<LoanOfferDetails> loanOfferDetails;

}
