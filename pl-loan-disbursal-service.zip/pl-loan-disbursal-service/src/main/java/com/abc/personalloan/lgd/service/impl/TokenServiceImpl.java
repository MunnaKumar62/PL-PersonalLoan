package com.abc.personalloan.lgd.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.payload.request.ApiCommonRequest;
import com.abc.personalloan.lgd.payload.response.TokenResponse;
import com.abc.personalloan.lgd.service.TokenService;
import com.abc.personalloan.lgd.service.biz.CommonBizService;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class TokenServiceImpl extends CommonBizService implements TokenService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Value("${abc.token.url}")
	private String tokenUrl;

	@Value("${abc.token.client-id}")
	private String clientId;

	@Value("${abc.token.scope}")
	private String inputScope;

	@Value("${abc.token.grant-type}")
	private String grantType;

	@Value("${abc.token.auth-token}")
	private String authToken;

	@Override
	public String getAccessToken() {

		ResponseEntity<Object> apiResponse = callTokenApi();
		String token = EMPTY;
		if (null != apiResponse && null != apiResponse.getBody()) {
			TokenResponse response = (TokenResponse) apiResponse.getBody();
			token = null != response && null != response.getAccessToken() ? response.getAccessToken() : token;
		}
		return token;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callTokenApi() {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;

		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam(CLIENT_ID, clientId)
					.queryParam(SCOPE, inputScope).queryParam(GRANT_TYPE, grantType).build();
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_AUTH_TOKEN)
					.requestHeaders(getTokenRequestHeaders(authToken)).url(builder.toUriString())
					.method(HttpMethod.POST).request(null).accountId(EMPTY).profileId(EMPTY).requestId(EMPTY)
					.transactionId(EMPTY).active(true).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, TokenResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new CustomException(ex.getMessage());

		}
		log.info(className + methodName + END);

		return apiResponse;
	}

}
