package com.abc.personalloan.lgd.service;

import java.util.Optional;

import com.abc.personalloan.lgd.entity.CustomerDetails;

public interface CustomerService {

	Optional<CustomerDetails> findByMobileNumber(String mobileNumber);

}
