package com.abc.personalloan.lgd.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.LMSLeadDrop;

@Repository
public interface LMSLeadDropRepository extends JpaRepository<LMSLeadDrop, Long> {

	Optional<LMSLeadDrop> findByLeadId(String leadId);
}
