package com.abc.personalloan.lgd.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.PLAddress;

@Repository
public interface PLAddressRepository extends JpaRepository<PLAddress, Long> {

	@Query("SELECT a FROM PLAddress a WHERE a.addressId=(SELECT max(a.addressId) FROM PLAddress a WHERE a.customerId =:customerId and a.accountId =:accountId and a.loanId =:loanId and a.active =:active)")
	Optional<PLAddress> findByCustomerIdAndAccountIdAndLoanIdActive(Long customerId, String accountId, String loanId, Boolean active);
}
