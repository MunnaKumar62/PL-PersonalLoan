package com.abc.personalloan.lgd.common.model;

import java.time.LocalDate;
import java.util.Date;

import com.abc.personalloan.lgd.constants.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PLCustomerDetailDto {

	private Long customerDetailId;

	private Date accntCreateDate;

	private String accountId;

	private String loanId;

	private Long customerId;

	private String cccId;

	private String mobilenumber;

	private String creditScore;

	private String loanPurpose;

	private String firstnameLastname;

	private String pannumber;

	@JsonFormat(pattern = Constants.DOB_FORMAT)
	private LocalDate dateOfBirth;

	private String gender;

	private String email;

	private Double breloanAmount;

	private Double breroi;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date breOffertime;

	private String breRejectReason;

	private String emandateStatus;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date emanDatetime;

	private String ckycStatus;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date ckyctime;
	
	private String digilockerConsent;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date digilockerConsentDatetime;

	private String digilockerStatus;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date digilockerTime;

	private String ukycStatus;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date ukycTime;

	private String currentScreen;

	private String appPlatform;

	private String basicConsent;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date basicConsentDatetime;

	private String bankConsent;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date bankConsentDatetime;

	private String kycAddressConsent;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date kycAddressConsentDatetime;
	
	private String ukycAddressConsent;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date ukycAddressConsentDatetime;
	
	private String bankaccountId;
	
	private String pennydropStatus;
	
	private String bankDetailValidation;

	private String digisignConsent;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date digisignConsentDatetime;

	private Boolean active;

	private String createdBy;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date createdDate;

	private String modifiedBy;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private Date modifiedDate;

	private String ukycInit;
	
	private String kycType;

	private Date ukycInitTime;
	
	private String transactionId;
	
}
