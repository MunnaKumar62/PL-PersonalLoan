package com.abc.personalloan.lgd.mixpanel.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MixPanelRequest {

	private Propertiesvalue properties;
	private String event;
}

