package com.abc.personalloan.lgd.service;

import java.util.List;
import java.util.Optional;

import com.abc.personalloan.lgd.entity.ApiStatus;
import com.abc.personalloan.lgd.payload.response.ApiStatusResponse;

public interface ApiStatusService {

	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName);

	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus);
	
	public List<ApiStatusResponse> getAllApiList(String accountId);
}
