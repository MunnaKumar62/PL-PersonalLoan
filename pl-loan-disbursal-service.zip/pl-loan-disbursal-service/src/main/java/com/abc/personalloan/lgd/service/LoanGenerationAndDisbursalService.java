package com.abc.personalloan.lgd.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.abc.personalloan.lgd.entity.LoanDisbursementDetails;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.exception.RetryException;
import com.abc.personalloan.lgd.payload.request.DisburementCallBackRequest;
import com.abc.personalloan.lgd.payload.request.LoanRequest;
import com.abc.personalloan.lgd.payload.request.RegulatoryDataRequest;
import com.abc.personalloan.lgd.payload.response.LoanDispursalDtlResponse;
import com.abc.personalloan.lgd.payload.response.LoanStatusResponse;

public interface LoanGenerationAndDisbursalService {

	public ResponseEntity<Object> loanGeneration(LoanRequest request);
	
	public ResponseEntity<Object> disbursementStatusWithRetry(LoanRequest createLoanRequest);
	
	public ResponseEntity<Object> disbursementStatus(LoanRequest statusRequest);
	
	public LoanStatusResponse callDisbursalPollingStatus(LoanRequest statusRequest, String status) throws RetryException, CustomException;

	public List<LoanDispursalDtlResponse> getLoanDisburseDts(long customerID);
	
	public List<LoanDisbursementDetails> findByCustomerId(long customerId);

	public LoanDisbursementDetails getLatestLODByAccountId(String accountId);

	public LoanDisbursementDetails findByUniqueIdAndCustomeridAndAccountIdAndLoanId(String uniqueId, long customerId, String accountId, String loanId);

	public LoanDisbursementDetails savOrUpdate(LoanDisbursementDetails details);

	public ResponseEntity<Object> disbursementcallback(DisburementCallBackRequest disburementCallBackRequest);
	
	ResponseEntity<Object> uploadRegulatoryData(RegulatoryDataRequest request);

	public ResponseEntity<Object> disbursalStatus(Long customerId, String accountId, String loanId);

	public ResponseEntity<Object> disbursementStatusJob();
}
