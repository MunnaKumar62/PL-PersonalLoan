package com.abc.personalloan.lgd.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.entity.ApiStatus;
import com.abc.personalloan.lgd.entity.AppActivationn;
import com.abc.personalloan.lgd.entity.CustomerDetails;
import com.abc.personalloan.lgd.entity.LoanDisbursementDetails;
import com.abc.personalloan.lgd.entity.PLCustomerDetail;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.exception.ExternalException;
import com.abc.personalloan.lgd.exception.InternalException;
import com.abc.personalloan.lgd.mixpanel.request.Appsflyer;
import com.abc.personalloan.lgd.mixpanel.request.MixPanelRequest;
import com.abc.personalloan.lgd.mixpanel.request.Propertiesvalue;
import com.abc.personalloan.lgd.mixpanel.response.MixPanelResponse;
import com.abc.personalloan.lgd.payload.response.TokenResponse;
import com.abc.personalloan.lgd.repository.APIStatusRepository;
import com.abc.personalloan.lgd.repository.CustomerActivationRepository;
import com.abc.personalloan.lgd.repository.CustomerRepository;
import com.abc.personalloan.lgd.repository.LoanDisbursementRepository;
import com.abc.personalloan.lgd.repository.PLCustomerDetailRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class MixPanelServiceImpl implements Constants {
	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Value("${mixpanel.events.push.url}")
	private String mixPanelEventPushURL;

	@Value("${mixpanel.url.request.param.strictid}")
	private String strictId;

	@Value("${mixpanel.url.request.param.projectid}")
	private String projectId;
	
	@Value("${appsflyer.Android.url}")
	private String appsflyerAndroidURL;
	
	@Value("${appsflyer.ios.url}")
	private String appsflyerIosURL;
	
	@Value("${abc.token.url}")
	private String tokenUrl;

	@Value("${abc.token.client-id}")
	private String clientId;

	@Value("${abc.token.scope}")
	private String scope;

	@Value("${abc.token.grant-type}")
	private String grantType;

	@Value("${abc.token.auth-token}")
	private String authToken;

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	ObjectMapper objectMapper;
	@Autowired
	APIStatusRepository apiStatusRepository;
	@Autowired
	LoanDisbursementRepository detailsRepository;
	@Autowired
	CustomerActivationRepository activationrepo;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	PLCustomerDetailRepository customerDetailRepository;

	public MixPanelResponse pushUpswingEventstoMixPanel(Long customerid,String accountId,String loanId) throws Exception {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		List<MixPanelRequest> mixpanelRequests = null;
		Optional<LoanDisbursementDetails> listValue = null;
		Appsflyer appsflyer=null;
		Long customerId = 0L;
		try {
			long pci = customerid;
			log.info("Start of pushUpswingEventstoMixPanel");

			listValue = detailsRepository.findTopByCustomeridAndAccountIdAndLoanIdAndDisburalStatusOrderByLoanOfferIdDesc(customerid,accountId,loanId, "DISBURSED");
			if (listValue.isEmpty()) {
				log.info("LoanOfferDetails not found for PCI: {}", pci);
				throw new InternalException("LoanOfferDetails not found for Customer");
			} else {

				log.info("LoanOfferDetails found: {}", listValue);
				if (listValue.isPresent()) {
					customerId = listValue.get().getCustomerid();
				}
				Optional<CustomerDetails> customerOpt = customerRepository.findById(listValue.get().getCustomerid());
				CustomerDetails customer = customerOpt
						.orElseThrow(() -> new InternalException("CustomerDetails not found for Customer ID: " + pci));

				log.info("CustomerDetails found: {}", customer);
				PLCustomerDetail plCustomer = customerDetailRepository.findTopByCustomerIdAndAccountIdAndLoanId(customer.getCustomerId(),accountId,loanId);
				if (plCustomer == null) {
					log.info("plCustomer not found for CustomerId: {}", pci);
				} else {
					log.info("plCustomer found: {}", plCustomer);
				}
				
				AppActivationn activationValue = activationrepo.findLatestActivationByMdn(customer.getMobileNumber());
				if (activationValue == null) {
					log.info("AppActivationn not found for mobile number: {}", customer.getMobileNumber());

				} else {

					log.info("AppActivationn found: {}", activationValue);
				}
				mixpanelRequests = buildMixPanelRequest(listValue, customer, activationValue, plCustomer);
				log.info("MixPanelRequest built: {}", mixpanelRequests);

				appsflyer = requestAppsflyerSet(listValue, customer, activationValue, plCustomer);
//              Appsfyper not for production 
				appsflyerPush(appsflyer, listValue, activationValue);

				return pushEvents(mixpanelRequests, listValue);
			}

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			log.error("Error occurred while consuming MixPanel API:", ex);
			throw new InternalException("Error occurred while consuming  MixPanel API: " + ex.getMessage());
		}
	}

	private List<MixPanelRequest> buildMixPanelRequest(Optional<LoanDisbursementDetails> listValue,
			CustomerDetails customer, AppActivationn activationValue, PLCustomerDetail plCustomer) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		String disStatus = null, loanNo = null, loanDisbursalDate = null, loanType = null;
		Double monthlyEmi = 0.0, loanAmount = 0.0, rateOfIntrest = 0.0;
		Integer tenure = 0;
		if (listValue.isPresent()) {
			disStatus = listValue.get().getDisburalStatus();
			monthlyEmi = listValue.get().getMonthlyEmi();
			tenure = listValue.get().getTenure();
			loanNo = listValue.get().getLoanNo();
			loanAmount = listValue.get().getLoanAmount();
			loanDisbursalDate = listValue.get().getLoanDisbursalDate().toString();
			loanType = listValue.get().getLoanType();
			rateOfIntrest = listValue.get().getRateOfInterest();
		}
		List<MixPanelRequest> events = new ArrayList<>();
		MixPanelRequest newMixPanelRequest = new MixPanelRequest();
		log.info("Here start to setting the request");
		newMixPanelRequest.setEvent("pl_disbursal_status_change");
		Propertiesvalue properties = new Propertiesvalue();
		if(Objects.nonNull(activationValue)){
			properties.setAppsflyerId(StringUtils.isNotEmpty(activationValue.getAppsFlyerId()) ? activationValue.getAppsFlyerId() :  "");
		}else{
			properties.setAppsflyerId("");
		}
		properties.setCleverTapUserId(activationValue.getCleverTapId());
		properties.setClientId(customer.getCustomerId()); // Replace with logic to get client ID
		properties.setDisbursalStatus(disStatus);
		properties.setEmiAmount(monthlyEmi);
		properties.setEmiTenureMonths(tenure);
		properties.setLoanID(plCustomer.getLoanId());
		properties.setAccountID(plCustomer.getAccountId());
		properties.setGoldenId(customer.getCustomerId());
		properties.setGuestId(customer.getCustomerId());
		properties.setJourneyType(plCustomer.getJourneyType()); // Replace with logic to determine journey type
		properties.setLoanAccNumber(loanNo); // Replace with logic to generate loan account number
		properties.setLoanAmount(loanAmount);
		properties.setLoanDisbursalDate(loanDisbursalDate); // disbursal status
		properties.setLoanType(getLoanTypeName(loanType));
		properties.setScreenName(" Personal Loan Loan Offer Disbursement Successful Screen");
		properties.setScreenType("personal_loan");
		properties.setPreviousScreen("Personal Loan Loan Disbursal Under Process Screen");
		properties.setUserAge(calculateAge(plCustomer.getDateOfBirth()));
		properties.setUserGender(customer.getGender());
		properties.setTime(System.currentTimeMillis());
		properties.setRateOfInterest(rateOfIntrest);
		properties.setDistinctId(customer.getCustomerId().toString());
		properties.setInsertId(generateInsertIdMILLIS());
		properties.setProductName(getLoanTypeName(loanType));
		newMixPanelRequest.setProperties(properties);
		events.add(newMixPanelRequest);

		log.info("newMixPanelRequest{}", newMixPanelRequest);
		return events;
	}

	private MixPanelResponse pushEvents(List<MixPanelRequest> mixPanelRequests,
			Optional<LoanDisbursementDetails> loandeatil) throws Exception {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		log.debug("In pushEvents method: " + mixPanelRequests);
		String request = objectMapper.writeValueAsString(mixPanelRequests);
		log.info("In pushEvents method: " + request);

		String response = null;
		Long customerId = 0L;
		String accountId = null;
		if (loandeatil.isPresent()) {
			customerId = loandeatil.get().getCustomerid();
			accountId = loandeatil.get().getAccountId();
		}
		try {
			HttpEntity<String> httpEntity = new HttpEntity<>(request, getHttpHeaders());
			log.info("httpEntity :" + httpEntity);
			String mixPanelURL = UriComponentsBuilder.fromUriString(mixPanelEventPushURL)
					.queryParam(Constants.STRICT_REQUEST_PARAM, strictId).queryParam(Constants.PROJECT_ID, projectId)
					.build().toString();

			ResponseEntity<MixPanelResponse> apiResponse = restTemplate.postForEntity(mixPanelURL, httpEntity,
					MixPanelResponse.class);
			response = new Gson().toJson(apiResponse.getBody());
			saveApiSuccessResponse("MIXPANEL_API", accountId, null, null, null, loandeatil.get().getCustomerid(),
					loandeatil.get().getLoanId(), mixPanelRequests, apiResponse.getBody());
			log.info(" Data share to mixPanel successfully");
			log.info(className + methodName + END);

			return apiResponse.getBody();

		} catch (HttpServerErrorException ex) {
			log.error("HttpServerErrorException in customerRecord {} : {}", ex.getStatusCode().value(),
					ex.getResponseBodyAsString());
			saveApiErrorResponse("MIXPANEL_API", accountId, null, null, null, customerId, loandeatil.get().getLoanId(), request,
					ex.getMessage());
			throw new ExternalException(ex.getStatusCode().value(), "HttpServerErrorException", "HTTP_SERVER_ERROR",
					"Internal Server Error", ex.getResponseBodyAsString());

		} catch (HttpClientErrorException ex) {
			log.error("HttpClientErrorException in customerRecord {} : {}", ex.getStatusCode().value(),
					ex.getResponseBodyAsString());
			saveApiErrorResponse("MIXPANEL_API", accountId, null, null, null, customerId, loandeatil.get().getLoanId(), request,
					ex.getMessage());
			throw new ExternalException(ex.getStatusCode().value(), "HttpClientErrorException", "HTTP_CLIENT_ERROR",
					"Client Error", ex.getResponseBodyAsString());
		} catch (Exception ex) {
			log.error("Exception in consuming Mixpanel API: ", ex);
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			saveApiErrorResponse("MIXPANEL_API", accountId, null, null, null, customerId, loandeatil.get().getLoanId(), request,
					ex.getMessage());
			throw new InternalException("Error Occurred while consuming Mixpanel API: " + ex.getMessage());
		}
	}

	public HttpHeaders getHttpHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.add("auth-token", generateToken());
		log.info("MIXPANEL httpHeaders  " + httpHeaders);
		return httpHeaders;

	}

	public String generateToken() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		TokenResponse tokenResp = null;
		try {
			log.info("Generate Token Start");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam("client_id", clientId)
					.queryParam("scope", scope).queryParam("grant_type", grantType).build();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			headers.add("Authorization", "Basic " + authToken);

			HttpEntity<Object> request = new HttpEntity<>(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					request, String.class);

			tokenResp = objectMapper.readValue(responseEntity.getBody(), TokenResponse.class);

			if (Objects.isNull(tokenResp) || Objects.isNull(tokenResp.getAccessToken())) {

				throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
						// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
						HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}

			log.info("Token " + tokenResp.getAccessToken());
			log.info("Generate Token End");

		} catch (Exception e) {
			log.error(className + methodName + EXCEPTION + "[" + e.getMessage() + "]");

			throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}

		return tokenResp.getAccessToken();
	}

	private static String generateInsertIdMILLIS() {
		String insertId = String.format("%s%d", "ABCD", System.currentTimeMillis());
		log.info("insertId: " + insertId);
		return insertId;
	}

	public static int calculateAge(LocalDate birthDate) {
		return Period.between(birthDate, LocalDate.now()).getYears();
	}

	public static int calculateAge1(LocalDate birthDate) {
		return Period.between(birthDate, LocalDate.now()).getYears();
	}

	public String getLoanTypeName(String listValue) {
		if (listValue == null || listValue.isEmpty()) {
			log.info("Invalid loan data"); // Handle empty or null list
		}

		String loanType = listValue;

		if (loanType != null) {
			loanType = loanType.trim(); // Remove leading/trailing whitespace

			if ("Personal Use".equalsIgnoreCase(loanType)) {
				return "personal_loans";
			} else if ("Wedding Loan".equalsIgnoreCase(loanType)) {
				return "wedding_loans";
			} else if ("Vacation Loan".equalsIgnoreCase(loanType)) {
				return "vacation_loans";
			} else if ("Purchase of consumer Durables".equalsIgnoreCase(loanType)) {
				return "consumer_durables_loans";
			} else if ("Medical Emergency".equalsIgnoreCase(loanType)) {
				return "medical_emergency_loans";
			} else {
				return "home_renovation_loans";
			}
		}
		return loanType;
	}

	public void saveApiSuccessResponse(String apiName, String acctId, String profileId, String transactionId,
			String requestId, Long customerId, String loanId, Object reqestObject, Object responseObject)
			throws Exception {
		String resquestJsonObject = objectMapper.writeValueAsString(reqestObject);
		String responseJsonObject = objectMapper.writeValueAsString(responseObject);
		ApiStatus successStatusObj = ApiStatus.builder().journey("PL").apiName(apiName).accountId(acctId).loanId(loanId)
				.customerId(customerId).profileId(profileId).transactionId(transactionId).requestId(requestId)
				.requestJson(resquestJsonObject).responseJson(responseJsonObject).status("DISBURSED")
				.active(Boolean.FALSE).build();
		apiStatusRepository.save(successStatusObj);

	}

	public void saveApiErrorResponse(String apiName, String acctId, String profileId, String transactionId,
			String requestId, Long customerId, String loanId, Object javaObject, String errorResponse)
			throws Exception {
		String responseJsonObject = objectMapper.writeValueAsString(javaObject);
		ApiStatus failureStatusObj = ApiStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.customerId(customerId).loanId(loanId).status("ERROR").requestJson(responseJsonObject)
				.responseJson(errorResponse).build();
		apiStatusRepository.save(failureStatusObj);
	}

	
	private String appsflyerPush(Appsflyer events, Optional<LoanDisbursementDetails> loandeatil,
			AppActivationn activationValue) throws Exception {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		log.debug("In appsflyerPush method: " + events);
		String request = objectMapper.writeValueAsString(events);
		log.info("In appsflyerPush method: " + request);
		String appsflyerPushURL1=null;

		String response = null;
		Long customerId = 0L;
		String accountId = null;
		if (loandeatil.isPresent()) {
			customerId = loandeatil.get().getCustomerid();
			accountId = loandeatil.get().getAccountId();
		}
		try {
			if (null != activationValue && null != activationValue.getOsName()
					&& activationValue.getOsName().equalsIgnoreCase("Android")) {
				appsflyerPushURL1 = appsflyerAndroidURL;
			} else if (null != activationValue && null != activationValue.getOsName()
					&& activationValue.getOsName().equalsIgnoreCase("iOS")) {
				appsflyerPushURL1 = appsflyerIosURL;
			}

			HttpEntity<String> httpEntity = new HttpEntity<>(request, getHttpHeaders());
			log.info("httpEntity :" + httpEntity);
			ResponseEntity<String> apiResponse = restTemplate.postForEntity(appsflyerPushURL1, httpEntity, String.class);
			saveApiSuccessResponse("APPSFLYER_API", accountId, null, null, null, loandeatil.get().getCustomerid(),
					loandeatil.get().getLoanId(), request, apiResponse.getBody().toString());
			log.info(" Data share to appsflyerPush successfully");
			log.info(className + methodName + END);

			return apiResponse.getBody();

		} catch (HttpServerErrorException ex) {
			log.error("HttpServerErrorException in customerRecord {} : {}", ex.getStatusCode().value(),
					ex.getResponseBodyAsString());
			saveApiErrorResponse("APPSFLYER_API", accountId, null, null, null, customerId, loandeatil.get().getLoanId(),
					request, ex.getMessage());
			throw new ExternalException(ex.getStatusCode().value(), "HttpServerErrorException", "HTTP_SERVER_ERROR",
					"Internal Server Error", ex.getResponseBodyAsString());

		} catch (HttpClientErrorException ex) {
			log.error("HttpClientErrorException in customerRecord {} : {}", ex.getStatusCode().value(),
					ex.getResponseBodyAsString());
			saveApiErrorResponse("APPSFLYER_API", accountId, null, null, null, customerId, loandeatil.get().getLoanId(),
					request, ex.getMessage());
			throw new ExternalException(ex.getStatusCode().value(), "HttpClientErrorException", "HTTP_CLIENT_ERROR",
					"Client Error", ex.getResponseBodyAsString());
		} catch (Exception ex) {
			log.error("Exception in consuming APPSFLYER_API API: ", ex);
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			saveApiErrorResponse("APPSFLYER_API", accountId, null, null, null, customerId, loandeatil.get().getLoanId(),
					request, ex.getMessage());

			throw new InternalException("Error Occurred while consuming Mixpanel API: " + ex.getMessage());
		}
	}
	
	public Appsflyer requestAppsflyerSet(Optional<LoanDisbursementDetails> listValue,
			CustomerDetails customer, AppActivationn activationValue, PLCustomerDetail plCustomer) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		String disStatus = null, loanNo = null, loanDisbursalDate = null, loanType = null;
		Double monthlyEmi = 0.0, loanAmount = 0.0, rateOfIntrest = 0.0;
		Integer tenure = 0;
		if (listValue.isPresent()) {
			disStatus = listValue.get().getDisburalStatus();
			monthlyEmi = listValue.get().getMonthlyEmi();
			tenure = listValue.get().getTenure();
			loanNo = listValue.get().getLoanNo();
			loanAmount = listValue.get().getLoanAmount();
			loanDisbursalDate = listValue.get().getLoanDisbursalDate().toString();
			loanType = listValue.get().getLoanType();
			rateOfIntrest = listValue.get().getRateOfInterest();
		}
		log.info("Here start to requestAppsflyerSet");
		Appsflyer appsflyer = new Appsflyer();

		appsflyer.setApp_version_name(activationValue.getCurrentAppVersionId());
		appsflyer.setAppsflyer_id(activationValue.getAppsFlyerId());
		appsflyer.setBundleIdentifier("com.oneApp");
		appsflyer.setCustomer_user_id(customer.getCustomerId());
		appsflyer.setEventName("pl_disbursal_status_change");
		appsflyer.setEventTime(currentdatetime());
		appsflyer.setIp(activationValue.getIpAddress());
		Propertiesvalue properties = new Propertiesvalue();
		properties.setAppsflyerId(activationValue.getAppsFlyerId());
		properties.setCleverTapUserId(activationValue.getCleverTapId());
		properties.setClientId(customer.getCustomerId());
		properties.setDisbursalStatus(disStatus);
		properties.setEmiAmount(monthlyEmi);
		properties.setEmiTenureMonths(tenure);
		properties.setLoanID(plCustomer.getLoanId());
		properties.setAccountID(plCustomer.getAccountId());
		properties.setGoldenId(customer.getCustomerId());
		properties.setGuestId(customer.getCustomerId());
		properties.setJourneyType(plCustomer.getJourneyType());
		properties.setLoanAccNumber(loanNo);
		properties.setLoanAmount(loanAmount);
		properties.setLoanDisbursalDate(loanDisbursalDate);
		properties.setLoanType(getLoanTypeName(loanType));
		properties.setScreenName(" Personal Loan Loan Offer Disbursement Successful Screen");
		properties.setScreenType("personal_loan");
		properties.setPreviousScreen("Personal Loan Loan Disbursal Under Process Screen");
		properties.setUserAge(calculateAge(plCustomer.getDateOfBirth()));
		properties.setUserGender(customer.getGender());
		properties.setTime(System.currentTimeMillis());
		properties.setRateOfInterest(rateOfIntrest);
		properties.setDistinctId(customer.getCustomerId().toString());
		properties.setInsertId(generateInsertIdMILLIS());
		properties.setProductName(getLoanTypeName(loanType));
		appsflyer.setEventValue(properties);

		log.info("appsflyer Request{}", appsflyer);
		return appsflyer;

	}
	
	public String currentdatetime() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSSSSS");

		LocalDateTime now = LocalDateTime.now();

		String currentTime = now.format(formatter);
		return currentTime;
	}
}
