package com.abc.personalloan.lgd.service.impl;

import java.sql.Timestamp;
import java.time.Clock;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.abc.personalloan.lgd.common.model.PLCustomerDetailDto;
import com.abc.personalloan.lgd.common.model.SuccessResponse;
import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.entity.PLCustomerDetail;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.payload.request.ApiCommonRequest;
import com.abc.personalloan.lgd.payload.request.LeadDropRequest;
import com.abc.personalloan.lgd.repository.PLCustomerDetailRepository;
import com.abc.personalloan.lgd.service.PLCustomerDetailService;
import com.abc.personalloan.lgd.service.TokenService;
import com.abc.personalloan.lgd.service.biz.CommonBizService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PLCustomerDetailServiceImpl extends CommonBizService implements PLCustomerDetailService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	PLCustomerDetailRepository detailRepository;

	@Autowired
	TokenService tokenService;

	@Autowired
	private ObjectMapper mapper;

	@Value("${abc.leaddrop.url}")
	private String leaddropUrl;

	@Override
	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto tmp) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		PLCustomerDetail detail = null;
		if (null != tmp) {
			/**
			 * Get Last updated record from t_pl_customer_detail table by accountId &
			 * active=false
			 */
			detail = findByAccountIdAndLoanIdAndCustomerIdAndActive(tmp.getAccountId(), tmp.getLoanId(), tmp.getCustomerId(), Boolean.FALSE);
			if (null != detail) {
				log.info(className + methodName + "[PLCustomerDetail: " + detail.toString() + "]");
				detail = mergeDetails(tmp, detail);
				savOrUpdateCustomerDetails(detail);
			}
		}
		return detail;
	}
	
	@Override
	public PLCustomerDetail auditCustomerDetailsError(PLCustomerDetailDto tmp) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		PLCustomerDetail detail = null;
		if (null != tmp) {
			/**
			 * Get Last updated record from t_pl_customer_detail table by accountId &
			 * active=false
			 */
			detail = findByAccountIdAndActive(tmp.getAccountId(), Boolean.FALSE);
			if (null != detail) {
				log.info(className + methodName + "[PLCustomerDetail: " + detail.toString() + "]");
				detail = mergeDetailsError(tmp, detail);
				savOrUpdateCustomerDetails(detail);
			}
		}
		return detail;
	}

	@Override
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail) {

		return detailRepository.save(plCustomerDetail);
	}

	@Override
	public PLCustomerDetail findByAccountIdAndActive(String accountId, Boolean active) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountIdAndActive(accountId, active);
		if (details.isPresent()) {
			customerDetail = details.get();
		}
		return customerDetail;
	}

	@Override
	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdAndActive(String accountId, String loanId, Long customerId, Boolean active) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountIdAndLoanIdAndCustomerIdAndActive(accountId, loanId, customerId, active);
		if (details.isPresent()) {
			customerDetail = details.get();
		}
		return customerDetail;
	}

	@Override
	public PLCustomerDetail findByAccountId(String accountId) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountId(accountId);
		if (details.isPresent()) {
			customerDetail = details.get();
		}
		return customerDetail;
	}

	@Override
	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerId(String accountId, String loanId, Long customerId) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountIdAndLoanIdAndCustomerId(accountId, loanId, customerId);
		if (details.isPresent()) {
			customerDetail = details.get();
		}
		return customerDetail;
	}

	private PLCustomerDetail mergeDetails(PLCustomerDetailDto tmp, PLCustomerDetail detail) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			detail.setCurrentScreen(
					!isEmptyOrNull(tmp.getCurrentScreen()) ? tmp.getCurrentScreen() : detail.getCurrentScreen());
			detail.setActive(null != tmp.getActive() ? tmp.getActive() : detail.getActive());
			detail.setModifiedBy(CREATED_BY);
			detail.setModifiedDate(new Timestamp(new Date().getTime()));

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return detail;
	}
	
	private PLCustomerDetail mergeDetailsError(PLCustomerDetailDto tmp, PLCustomerDetail detail) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			detail.setCurrentScreen(tmp.getTransactionId());
			detail.setUkycInit(tmp.getUkycInit());
			detail.setKycType(null);
			detail.setUkycInitTime(null);
			detail.setModifiedBy(CREATED_BY);
			detail.setModifiedDate(new Timestamp(new Date().getTime()));

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return detail;
	}

	@Override
	public void updateLeadMileStone(LeadDropRequest request, String accountId, String loanId, Long customerId) {
		/**
		 * Get Last updated record from t_pl_customer_detail table by accountId &
		 * active=false
		 */
		PLCustomerDetail detail = findByAccountIdAndLoanIdAndCustomerIdAndActive(accountId, loanId, customerId, Boolean.FALSE);
		if (null != detail && !isEmptyOrNull(detail.getLeadId())) {
			Clock clock = Clock.systemDefaultZone();
			long milliseconds = clock.millis();
			String uniqueId = accountId + "T" + milliseconds;
			request.setUNFYD_Session_ID__c(uniqueId);
			request.setCo_Browsing_Flag__c(false);
			request.setLead_id(detail.getLeadId());
			request.setLoB_Application_ID__c(detail.getApplicationId());
			request.setLoan_Amount_Required__c(detail.getLoanAmount() != null ? String.valueOf(detail.getLoanAmount()) : null);
			request.setSegment_Type__c(StringUtils.isNotEmpty(detail.getJourneyType()) && detail.getJourneyType().equals("pre_approved_flow") ? "Pre-approved": "");
			updateLead(request);
		} else {
			log.info(className + "[updateLeadMileStone] lead_id not available for " + accountId);
		}
	}

	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> updateLead(LeadDropRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;
		try {
			/**
			 * External API Call
			 */
			log.info(className + methodName + "REQUEST: " + mapper.writeValueAsString(request));
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_LEAD_UPDATE)
					.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).url(leaddropUrl)
					.method(HttpMethod.POST).request(request).accountId(EMPTY).profileId(EMPTY).requestId(EMPTY)
					.transactionId(EMPTY).active(false).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, SuccessResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new CustomException(ex.getMessage());
		}
		log.info(className + methodName + END);

		return apiResponse;
	}
}
