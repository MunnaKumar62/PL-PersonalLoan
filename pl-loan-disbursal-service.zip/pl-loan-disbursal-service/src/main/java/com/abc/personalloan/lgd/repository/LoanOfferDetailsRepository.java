package com.abc.personalloan.lgd.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.PLLoanOfferDetails;

@Repository
public interface LoanOfferDetailsRepository extends JpaRepository<PLLoanOfferDetails, Long> {

	@Query(value = "SELECT b.loan_id,b.loan_offer_id,b.loanamount,b.rateof_interest,b.customer_id,b.account_id,b.unique_id,"
			+ "b.disbursal_status,b.loan_disbursal_date,b.loan_disbursal_start,b.loan_disbursal_start_datetime "
			+ "FROM t_pl_customer_detail a, t_pl_loan_offer_details b " 
			+ "WHERE b.loan_disbursal_start='Y' "
			+ "AND b.disbursal_status in('INITIATED','IN_PROGRESS') " 
			+ "AND b.unique_id is not null "
			+ "AND a.active=false " 
			+ "AND a.accountid=b.account_id "
			+ "AND a.loan_id=b.loan_id "
			+ "AND a.customer_id=b.customer_id", nativeQuery = true)
	public List<PLLoanOfferDetails> getPendingDisbursals();

	
	//@Query(value = "SELECT loan_offer_id FROM t_pl_loan_offer_details WHERE customer_id = :customerId ORDER BY loan_offer_id DESC LIMIT 1 ", nativeQuery = true)
	@Query(value = "SELECT loan_offer_id FROM t_pl_loan_offer_details WHERE customer_id = :customerId AND account_id = :accountId AND loan_id = :loanId AND loan_disbursal_start='Y' "
			+ "AND disbursal_status in('INITIATED','IN_PROGRESS') AND unique_id is not null ORDER BY loan_offer_id DESC LIMIT 1 ", nativeQuery = true)
	public Long findLatestByCustomerId(@Param("customerId") long customerId, @Param("accountId") String accountId, @Param("loanId") String loanId);
	
//    Optional<PLLoanOfferDetails> findTopByCustomerIdAndDisburalStatusOrderByLoanOfferIdDesc(@Param("customerId") Long customerId, @Param("value") String disbursalStatus);
	
}
