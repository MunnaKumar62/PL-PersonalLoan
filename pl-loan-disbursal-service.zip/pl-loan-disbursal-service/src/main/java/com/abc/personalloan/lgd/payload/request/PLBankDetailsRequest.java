package com.abc.personalloan.lgd.payload.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PLBankDetailsRequest {

    @JsonProperty("accountNumber")
    private String accountNumber;

    @JsonProperty("IFSCCode")
    private String iFSCCode;

    @JsonProperty("customerId")
    private Long customerId;

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("loanId")
    private String loanId;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("active")
    private Boolean active;
}