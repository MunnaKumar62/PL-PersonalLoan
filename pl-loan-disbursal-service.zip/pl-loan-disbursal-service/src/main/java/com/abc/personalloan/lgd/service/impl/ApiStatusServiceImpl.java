package com.abc.personalloan.lgd.service.impl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.entity.ApiStatus;
import com.abc.personalloan.lgd.payload.response.ApiStatusResponse;
import com.abc.personalloan.lgd.repository.APIStatusRepository;
import com.abc.personalloan.lgd.service.ApiStatusService;
import com.abc.personalloan.lgd.service.biz.LoanBizService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ApiStatusServiceImpl implements ApiStatusService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";
	
	@Autowired
	APIStatusRepository apiStatusRepo;
	
	@Value("${abfl.regulatorydata.whitelist.services}")
	private String whiteListedServices;


	@Override
	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName) {

		return apiStatusRepo.findByAccountIdAndApiName(accountId, apiName);
	}

	@Override
	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus) {

		return apiStatusRepo.save(apiStatus);
	}

	@Override
	public List<ApiStatusResponse> getAllApiList(String accountId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		List<ApiStatusResponse> resultList = new ArrayList<>();
		LoanBizService customerBizService = new LoanBizService();
		List<String> apiNameList = customerBizService.apiNameList(whiteListedServices);
		log.info(className + methodName + "[WHITE_LISTED_SERVICES= " + apiNameList + "]");
		List<ApiStatus> list = apiStatusRepo.findByApiNameInAndAccountIdOrderByIdDesc(apiNameList, accountId);

		Set<String> set = new HashSet<>();
		for (ApiStatus apiStatus : list) {
			if (!set.contains(apiStatus.getApiName())) {
				resultList.add(ApiStatusResponse.builder().apiName(apiStatus.getApiName().toUpperCase())
						.responseJson(apiStatus.getResponseJson()).updatedDate(apiStatus.getModifiedDt()).build());
				set.add(apiStatus.getApiName().toUpperCase());
			}
		}
		log.info(className + methodName + END);

		return resultList;
	}
}
