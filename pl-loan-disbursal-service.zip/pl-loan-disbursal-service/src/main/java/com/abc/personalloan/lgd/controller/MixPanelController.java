package com.abc.personalloan.lgd.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


import com.abc.personalloan.lgd.mixpanel.response.MixPanelResponse;
import com.abc.personalloan.lgd.service.impl.MixPanelServiceImpl;

@RestController
public class MixPanelController {
	@Autowired
	MixPanelServiceImpl impl;

	@PostMapping("/mixPanelEvent/{pci}/{accountId}/{loanId}")

	public MixPanelResponse pushUpswingEventstoMixPanel( @PathVariable Long pci,@PathVariable String accountId,@PathVariable String loanId) throws Exception {
		return impl.pushUpswingEventstoMixPanel(pci,accountId,loanId);
	}

}