package com.abc.personalloan.lgd.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

import com.abc.personalloan.lgd.payload.request.*;
import com.abc.personalloan.lgd.repository.BankAccountDetailsRepository;
import com.abc.personalloan.lgd.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.personalloan.lgd.common.model.PLCustomerDetailDto;
import com.abc.personalloan.lgd.common.model.RetryConfg;
import com.abc.personalloan.lgd.common.model.offer.OfferPageDatum;
import com.abc.personalloan.lgd.common.model.offer.OfferResponse;
import com.abc.personalloan.lgd.common.util.CommonUtil;
import com.abc.personalloan.lgd.common.util.EnumLoanPurpose;
import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.constants.MessageConstants;
import com.abc.personalloan.lgd.entity.ApiStatus;
import com.abc.personalloan.lgd.entity.CustomerDetails;
import com.abc.personalloan.lgd.entity.LoanDisbursementDetails;
import com.abc.personalloan.lgd.entity.PLCustomerDetail;
import com.abc.personalloan.lgd.entity.PLLoanOfferDetails;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.exception.RetryException;
import com.abc.personalloan.lgd.payload.response.DisbursalStatusResponse;
import com.abc.personalloan.lgd.payload.response.LoanDispursalDtlResponse;
import com.abc.personalloan.lgd.payload.response.LoanGenerationResponse;
import com.abc.personalloan.lgd.payload.response.LoanStatusResponse;
import com.abc.personalloan.lgd.payload.response.RegulatoryDataResponse;
import com.abc.personalloan.lgd.payload.response.StatusData;
import com.abc.personalloan.lgd.repository.APIStatusRepository;
import com.abc.personalloan.lgd.repository.LoanDisbursementRepository;
import com.abc.personalloan.lgd.repository.LoanOfferDetailsRepository;
import com.abc.personalloan.lgd.service.biz.CommonBizService;
import com.abc.personalloan.lgd.service.biz.LoanBizService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class LoanGenerationAndDisbursalServiceImpl extends CommonBizService
		implements LoanGenerationAndDisbursalService, Constants, MessageConstants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;

	
	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	CustomerDetailsService customerDetailsService;

	@Value("${abc.loan-disbursement-generation.url}")
	private String generationUrl;

	@Value("${abc.loan-disbursement-status.url}")
	private String statusUrl;
	
	@Value("${pl.retry.disbursaldetails}")
	private String disbursalRetryConfig;

	@Autowired
	private CustomerDetailsService customerService;

	@Autowired
	APIStatusRepository apiStatusRespo;

	@Autowired
	BankAccountDetailsRepository bankAccountDetailsRepository;

	@Autowired
	private LoanDisbursementRepository disbursementRepository;
	
	@Autowired
	private LoanOfferDetailsRepository loanOfferDetailsRepository;
	
	@Autowired
	private PLCustomerDetailService plCustomerDetailService;
	
	@Autowired
	private PLAddressService plAddressService;

	@Autowired
	private PLBankAccountDetailsService plBankAccountDetailsService;
	
	@Autowired
	private TokenService tokenService;
	
	@Autowired
	MixPanelServiceImpl mixPanelServiceImpl;

	@Autowired
	ApiStatusService apiStatusService;
	
	@Value("${abfl.regulatorydata.url}")
	private String regDataUrl;
	
	@Value("${pl.disbursal.whitelist.services}")
	private String whiteListedServices;
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> loanGeneration(LoanRequest loanRequest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		LoanGenerationRequest request = null;
		final String code = "PL4201";
		LoanBizService loanBizService = new LoanBizService();
		ResponseEntity<Object> apiResponse = null;
		LoanGenerationResponse loanGenerationResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		ApiStatus existingApiStatus = null;
		String jsonResponse = EMPTY;
		/**
		 * Input request validation
		 */
		request = loanBizService.constructRequest(loanRequest, customerService, apiStatusRespo, bankAccountDetailsRepository);
					
		if (request != null) {
			/**
			 * External API Call
			 */

				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_DISBURSEMENT_GENERATION)
						.accountId(loanRequest.getAccountId()).profileId(EMPTY).requestId(request.getUniqueId()).customerId(loanRequest.getCustomerId()).loanId(loanRequest.getLoanId())
						.transactionId(request.getUniqueId()).url(generationUrl).requestHeaders(getRequestHeaders(tokenService.getAccessToken()))
						.method(HttpMethod.POST).request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

				map = callExternalApi(commonRequest, LoanGenerationResponse.class);
				CustomerDetails customerDetails = null;

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					// Success Response
					if (validateResponse(apiResponse)) {

						LoanGenerationResponse response = (LoanGenerationResponse) apiResponse.getBody();
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), response);

						customerDetails = customerService.findByAccountId(loanRequest.getAccountId());

						if (null != customerDetails && null != customerDetails.getCustomerId()) {
							LoanDisbursementDetails details = disbursementRepository
									.getLatestLODByCustIdAndAndAccountIdLoanId(customerDetails.getCustomerId(), loanRequest.getAccountId(), loanRequest.getLoanId());
							if (null != details) {
								log.info(className + methodName + "[LoanDisbursementDetails-LoanOfferId: "
										+ details.getLoanOfferId() + "]");
								details.setUniqueId(request.getUniqueId());
								details.setCustomerid(loanRequest.getCustomerId());
								details.setLoanId(loanRequest.getLoanId());
								details.setAccountId(loanRequest.getAccountId());
								details.setLoanDisbursalStart("Y");
								details.setLoanDisbursalStartDatetime(LocalDateTime.now());
								log.info(className + methodName + "[LoanDisbursementDetails: " + details.toString() + "]");
								savOrUpdate(details);
							}
						}
					} else {
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					updateApiStatus(customerDetails, apiStatus, loanRequest.getLoanId());
				}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> disbursementStatusWithRetry(LoanRequest createLoanRequest) {

		String code = "PL4202";
		Object obj = null;
		String responseJsonObject = null;
		LoanStatusResponse response = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		try {
			ApiStatus apiStatus = apiStatusRespo.findByAccountIdAndApiNameAndTransactionIdAndLoanId(
					createLoanRequest.getAccountId(), PL_DISBURSEMENT_STATUS, createLoanRequest.getUniqueId(), createLoanRequest.getLoanId());
			if (null != apiStatus) {
				responseJsonObject = apiStatus.getResponseJson();
				response = objectMapper.readValue(responseJsonObject, LoanStatusResponse.class);
				if (null != response && IN_PROGRESS.equalsIgnoreCase(response.getResponseStatus())) {
					apiResponse = disbursementStatus(createLoanRequest);
					response = (LoanStatusResponse) apiResponse.getBody();
				}
				obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), response);
			} else {
				apiResponse = disbursementStatus(createLoanRequest);
				if (validateResponse(apiResponse)) {
					response = (LoanStatusResponse) apiResponse.getBody();
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), response);
				} else {
					obj = apiResponse.getBody();
				}
				if (null != response && IN_PROGRESS.equalsIgnoreCase(response.getResponseStatus())) {
					log.info(className + "[disbursementStatus: " + response.getResponseStatus() + "]");
					new Thread(() -> {
						// Asynchronous call - with Retry
						try {
							callDisbursalPollingStatus(createLoanRequest, IN_PROGRESS);
						} catch (CustomException | RetryException ex) {
							log.error(className + "[disbursementStatusWithRetry]" + EXCEPTION + "[" + ex.getMessage()
									+ "]");
						}
					}).start();
				}
			}
		} catch (JsonProcessingException ex) {
			log.error(className + "[disbursementStatusWithRetry]" + EXCEPTION + "[" + ex.getMessage() + "]");
		}

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
	
	@Override
	public ResponseEntity<Object> disbursementStatus(LoanRequest createLoanRequest) {

		ResponseEntity<Object> apiResponse = disbursementStatusApiCall(createLoanRequest, tokenService.getAccessToken());
		if (validateResponse(apiResponse)) {
			CustomerDetails customerDetails = customerService.findByAccountId(createLoanRequest.getAccountId());
			LoanStatusResponse response = (LoanStatusResponse) apiResponse.getBody();
			updateLoanDetails(createLoanRequest, response, customerDetails);
		
		}
		return new ResponseEntity<>(apiResponse.getBody(), HttpStatus.OK);
	}
		
	@Override
	public LoanStatusResponse callDisbursalPollingStatus(LoanRequest request, String status) throws RetryException, CustomException {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		LoanStatusResponse response = null;
		CommonBizService bizService = new CommonBizService();
		List<RetryConfg> configList = bizService.getRetryConfig(disbursalRetryConfig);
		log.info(className + methodName + " Retry Configuration: " + disbursalRetryConfig);
		for (RetryConfg config : configList) {
			try {
				// External Api with Retry
				response = getDisbursalPollingStatusRetry(request, config.getMaxAttempts(), config.getDelay());
				// Stop processing
				if (null != response && !IN_PROGRESS.equalsIgnoreCase(response.getResponseStatus())) {
					break;
				}
			} catch (CustomException | RetryException ex) {
				log.error(className + "[recursiveLoop]" + EXCEPTION + "[" + ex.getMessage() + "]");
			}
		}
		return response;
	}

	public LoanStatusResponse getDisbursalPollingStatusRetry(LoanRequest request, int maxAttempts, long backOffPeriod)
			throws RetryException, CustomException {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		CommonBizService bizService = new CommonBizService();
		RetryTemplate retryTemplate = bizService.createRetryTemplate(maxAttempts, backOffPeriod);

		RetryCallback<LoanStatusResponse, RetryException> retryCallback = context -> {
			LoanStatusResponse response = null;
			// Call External Api
			ResponseEntity<Object> apiResponse = disbursementStatus(request);
			if (validateResponse(apiResponse)) {
				response = (LoanStatusResponse) apiResponse.getBody();
				log.info(className + methodName + " Count:: " + context.getRetryCount());

				if (null != response && IN_PROGRESS.equalsIgnoreCase(response.getResponseStatus())) {
					log.info(className + methodName + " ResponseStatus: " + response.getResponseStatus() + "]");
					throw new RetryException(response.getResponseStatus(), response.getData());
				} else {
					String status = (null != response && null != response.getResponseStatus())
							? response.getResponseStatus()
							: Constants.EMPTY;
					log.info(className + methodName + " ResponseStatus Changed To " + status);
				}
			}
			return response;
		};

		RecoveryCallback<LoanStatusResponse> recoveryCallback = context -> {
			log.info(className + methodName + " Recovery action taken");
			return new LoanStatusResponse(Constants.IN_PROGRESS);
		};

		return retryTemplate.execute(retryCallback, recoveryCallback);

	}

	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> disbursementStatusApiCall(LoanRequest loanRequest, String token) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		LoanStatusRequest request = null;
		LoanBizService loanBizService = new LoanBizService();
		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = loanBizService.getCreateLoanStatusRequest(loanRequest);
		if (request != null) {
			ApiStatus apiStatus = apiStatusRespo.findByAccountIdAndApiNameAndTransactionIdAndLoanId(loanRequest.getAccountId(),
					PL_DISBURSEMENT_STATUS, loanRequest.getUniqueId(), loanRequest.getLoanId());
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_DISBURSEMENT_STATUS)
					.accountId(loanRequest.getAccountId()).customerId(loanRequest.getCustomerId()).profileId(EMPTY).requestId(request.getUniqueId())
					.transactionId(request.getUniqueId()).url(statusUrl).requestHeaders(getRequestHeaders(token))
					.method(HttpMethod.POST).request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).apiStatus(apiStatus).build();

			map = callExternalApi(commonRequest, LoanStatusResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatusForDisStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerService.findByAccountId(loanRequest.getAccountId()), apiStatusForDisStatus, loanRequest.getLoanId());
			}
		}
		log.info(className + methodName + END);

		return apiResponse;
	}

	@Override
	public List<LoanDispursalDtlResponse> getLoanDisburseDts(long customerID) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		List<LoanDispursalDtlResponse> resList = new ArrayList<>();
		LoanBizService loanBizService = new LoanBizService();
		try {
			resList = loanBizService.getLoanDispursalDtlList(findByCustomerId(customerID));
			log.info(className + methodName + "LIST_SIZE: " + resList.size());

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new CustomException(ex.getMessage());

		}
		log.info(className + methodName + END);

		return resList;
	}

	@Override
	public List<LoanDisbursementDetails> findByCustomerId(long customerId) {

		return disbursementRepository.findByCustomerId(customerId);
	}

	@Override
	public LoanDisbursementDetails getLatestLODByAccountId(String accountId) {

		return disbursementRepository.getLatestLODByAccountId(accountId);
	}

	@Override
	public LoanDisbursementDetails findByUniqueIdAndCustomeridAndAccountIdAndLoanId(String uniqueId, long customerId, String accountId, String loanId) {

		return disbursementRepository.findByUniqueIdAndCustomeridAndAccountIdAndLoanId(uniqueId, customerId, accountId, loanId);
	}

	@Override
	public LoanDisbursementDetails savOrUpdate(LoanDisbursementDetails details) {

		return disbursementRepository.save(details);
	}
	
	@Override
	public ResponseEntity<Object> disbursementcallback(DisburementCallBackRequest request) {
		
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String requestJsonObject1 = null;
		String responseJsonObject = null;
		Object obj = null;
		final String code = "PL2206";
		try {
			if (null == request) {
				throw new CustomException(EMPTY_REQUEST);
			} else if (isEmptyOrNull(request.getAccountId())) {
				throw new CustomException(FILED_ACC_ID + TILDA + EMPTY_FIELD);
			} else {
				apiStatus = apiStatusRespo.findByLoanIdAndApiNameAndTransactionId(request.getAccountId(),
						PL_DISBURSEMENT_STATUS,request.getUniqueId());
				requestJsonObject1 = objectMapper
						.writeValueAsString(LoanStatusResponse
								.builder().responseStatus(request.getStatus()).data(new StatusData(request.getDealNo(),
										request.getLoanNo(), request.getDisbursalStatus(), request.getUtrNo()))
								.build());
				requestJsonObject = objectMapper.writeValueAsString(request);
				if (apiStatus == null) {
					throw new CustomException(DETAILS_NOT_FOUND);
				} else {
					apiStatus.setResponseJson(requestJsonObject1);
					apiStatusRespo.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), null);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_DISBURSEMENT_CALLBACK).accountId(apiStatus.getAccountId()).profileId(EMPTY)
							.loanId(request.getAccountId())
							.requestId(EMPTY)
							.transactionId(EMPTY).requestJson(requestJsonObject)
							.responseJson(responseJsonObject).status(SUCCESS).httpStatusCode(HttpStatus.OK.value())
							.active(Boolean.FALSE).build(), null);
				}
			}
			log.info(className + methodName + END);

		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
		
	}

	/**
	 * Freeze Loan details, Address details and all API success calls
	 * @param createLoanRequest
	 * @param response
	 */
	private void updateLoanDetails(LoanRequest createLoanRequest, LoanStatusResponse response, CustomerDetails customerDetails) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		try {
			if (null != response && null != response.getData()) {
				String accountId = createLoanRequest.getAccountId();
				if (null != customerDetails && null != customerDetails.getCustomerId()) {
					LoanDisbursementDetails details = findByUniqueIdAndCustomeridAndAccountIdAndLoanId(createLoanRequest.getUniqueId(), customerDetails.getCustomerId(), accountId, createLoanRequest.getLoanId());
					if (null != details) {
						log.info(className + methodName + details.toString());
						details.setUtrno(response.getData().getUtrNo());
						details.setLoanNo(response.getData().getLoanNo());
						String disStatus = response.getData().getDisbursalStatus();
						if (!isEmptyOrNull(disStatus) && (LOAN_DISBURSEMENT_IN_PROGRESS.equalsIgnoreCase(disStatus)
								|| LOAN_DISBURSMENT_REJECTED.equalsIgnoreCase(disStatus)
								|| LOAN_IS_FULLY_DISBURSED.equalsIgnoreCase(disStatus))) {
							boolean flag = Boolean.FALSE;
							// PL_LEAD_UPDATE
							new Thread(() -> {
								LeadDropRequest leadDropRequest = LeadDropRequest.builder()
										.abcd_app_status_code__c(response.getData().getDisbursalStatus())
										.lead_Milestone__c("Final Loan Screen Page")
										.customer_id(String.valueOf(customerDetails.getCustomerId())).build();
								plCustomerDetailService.updateLeadMileStone(leadDropRequest, accountId, createLoanRequest.getLoanId(), createLoanRequest.getCustomerId());
							}).start();

							if (LOAN_IS_FULLY_DISBURSED.equalsIgnoreCase(disStatus)) {
								disStatus = DISBURSED;
								flag = Boolean.TRUE;
								if (null == details.getLoanDisbursalDate()) {
									details.setLoanDisbursalDate(LocalDateTime.now());
								}
							} else if (LOAN_DISBURSMENT_REJECTED.equalsIgnoreCase(disStatus)) {
								disStatus = REJECTED;
							} else if (LOAN_DISBURSEMENT_IN_PROGRESS.equalsIgnoreCase(disStatus)) {
								disStatus = IN_PROGRESS.toUpperCase();
							}
							// PL_JOURNEY_AUDIT
							/**
							 * Freeze Customer Details, Address details and all API success calls status to disStatus
							 *
							 * Consider final status of the loan from t_pl_loan_offer_details.disbursal_status
							 */
							if (flag) {
								plCustomerDetailService.auditCustomerDetails(PLCustomerDetailDto.builder().accountId(accountId).loanId(createLoanRequest.getLoanId()).customerId(createLoanRequest.getCustomerId()).currentScreen("Success/Congratulations Page").active(Boolean.TRUE).build());
								plAddressService.saveOrUpdate(PLAddressRequest.builder().customerId(customerDetails.getCustomerId()).accountId(accountId).loanId(createLoanRequest.getLoanId()).active(Boolean.TRUE).build());
								plBankAccountDetailsService.saveOrUpdate(PLBankDetailsRequest.builder().customerId(customerDetails.getCustomerId()).accountId(accountId).loanId(createLoanRequest.getLoanId()).active(Boolean.TRUE).build());
								apiStatusRespo.updateStatus(Boolean.TRUE, accountId, createLoanRequest.getLoanId(), createLoanRequest.getCustomerId(), disStatus, new Timestamp(new Date().getTime()));
								log.info(className + methodName + "Loan " + disStatus + " And Details Freezed");
							}
						}
						details.setLoanId(createLoanRequest.getLoanId());
						details.setCustomerid(createLoanRequest.getCustomerId());
						details.setAccountId(accountId);
						details.setDisburalStatus(disStatus);
						savOrUpdate(details);
						if (LOAN_IS_FULLY_DISBURSED.equalsIgnoreCase(disStatus)
								|| DISBURSED.equalsIgnoreCase(disStatus)) {
							log.info("DISBURSED pushUpswingEventstoMixPanel CustomerId:{}",
									customerDetails.getCustomerId());
							mixPanelServiceImpl.pushUpswingEventstoMixPanel(customerDetails.getCustomerId(),accountId,createLoanRequest.getLoanId());
						} else {
							log.info("User Not DISBURSED CustomerId:{}", customerDetails.getCustomerId());
						}
					}
				}
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> uploadRegulatoryData(RegulatoryDataRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL2207";
		LoanBizService bizService = new LoanBizService();
		ResponseEntity<Object> apiResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateRegulatoryRequest(request, apiService);
		try {
			if (request != null) {
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_REGULATORY_DATA)
						.accountId(request.getAccountId()).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY)
						.url(regDataUrl).requestHeaders(getRequestHeaders(tokenService.getAccessToken()))
						.method(HttpMethod.POST).code(code).request(request).active(Boolean.TRUE).isAudit(Boolean.FALSE).build();
				map = callExternalApi(commonRequest, RegulatoryDataResponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					} else {
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> disbursalStatus(Long customerId, String accountId, String loanId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		try {
			LoanBizService loanBizService = new LoanBizService();
			customerId = loanBizService.accountIdRequest(customerId);

			CustomerDetails customerDetails = customerService.findByCustomerId(customerId);

			if (customerDetails != null) {
				log.info("Customer details found: " + customerDetails.getCustomerId());

				LoanDisbursementDetails status = disbursementRepository
						.findLatestByCustomerIdAndAccountIdAndLoanIdOrderByLoanOfferIdDesc(customerDetails.getCustomerId(), accountId, loanId);

				if (status != null) {
					log.info("Loan Offer details not found for status: " + status.getDisburalStatus());
					DisbursalStatusResponse response = new DisbursalStatusResponse();
					response.setDisbursalStatus(status.getDisburalStatus());
					return ResponseEntity.ok(response);
				} else {
					return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new DisbursalStatusResponse());
				}
			} else {
				log.info("Customer details not found for customerId: " + customerId);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new DisbursalStatusResponse());
			}
		} catch (Exception ex) {
			log.error(className + methodName + " Error: " + ex.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new DisbursalStatusResponse());
		} finally {
			log.info(className + methodName + END);
		}
	}

	@Override
	public ResponseEntity<Object> disbursementStatusJob() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		Object obj = null;
		String code = "PL2208";
		int count = 0;
		try {
			List<PLLoanOfferDetails> list = loanOfferDetailsRepository.getPendingDisbursals();
			for (PLLoanOfferDetails details : list) {
				Long loanOfferId = loanOfferDetailsRepository.findLatestByCustomerId(details.getCustomerId(), details.getAccountId(), details.getLoanId());
				if (null != loanOfferId && null != details.getLoanOfferId()
						&& Objects.equals(loanOfferId, details.getLoanOfferId())) {
					LoanRequest request = LoanRequest.builder().accountId(details.getAccountId())
							.uniqueId(details.getUniqueId())
							.loanId(details.getLoanId())
							.customerId(details.getCustomerId()).build();
					log.info(className + methodName + "[Count: " + count + "]" + request.toString());
					//External API Call
					disbursementStatus(request);
					count++;
				}
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), "Total Processed Count " + count);
		log.info(className + methodName + "Total Processed Count " + count);
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
}
