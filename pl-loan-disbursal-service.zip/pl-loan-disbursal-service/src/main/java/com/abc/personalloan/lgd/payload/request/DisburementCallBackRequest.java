package com.abc.personalloan.lgd.payload.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DisburementCallBackRequest {

	private String status;
	private String uniqueId;
	private String accountId;
	private String loanNo;
	private String disbursalStatus;
	private String utrNo;
	private String dealNo;

}
