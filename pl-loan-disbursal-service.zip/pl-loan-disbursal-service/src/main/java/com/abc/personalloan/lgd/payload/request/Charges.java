package com.abc.personalloan.lgd.payload.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class Charges {

	@JsonProperty("chargeType")
	private String chargeType;

	@JsonProperty("businessPartnerType")
	private String businessPartnerType;

	@JsonProperty("chargeAmount")
	private String chargeAmount;

	@JsonProperty("taxRate1")
	private String taxRate1;

	@JsonProperty("taxInclusive")
	private String taxInclusive;

	@JsonProperty("taxApplicable")
	private String taxApplicable;

	@JsonProperty("taxRate2")
	private String taxRate2;

	@JsonProperty("businessPartnerName")
	private String businessPartnerName;

	@JsonProperty("finalAmount")
	private String finalAmount;

	@JsonProperty("chargeCode")
	private String chargeCode;

	@JsonProperty("chargeMethod")
	private String chargeMethod;

	@JsonProperty("chargeCalculatedOn")
	private String chargeCalculatedOn;

}
