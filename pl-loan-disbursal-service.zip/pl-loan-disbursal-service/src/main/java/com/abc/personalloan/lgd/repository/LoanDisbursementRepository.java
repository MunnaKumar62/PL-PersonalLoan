package com.abc.personalloan.lgd.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.LoanDisbursementDetails;
import com.abc.personalloan.lgd.entity.PLLoanOfferDetails;
@Repository
public interface LoanDisbursementRepository extends JpaRepository<LoanDisbursementDetails, Double> {

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE customer_id = :customerId And disbursal_status='DISBURSED'", nativeQuery = true)
	public List<LoanDisbursementDetails> findByCustomerId(@Param("customerId") long customerId);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE created_date = (SELECT MAX(created_date) FROM t_pl_loan_offer_details WHERE account_id = :accountId)", nativeQuery = true)
	public LoanDisbursementDetails getLatestLODByAccountId(@Param("accountId") String accountId);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE unique_id = :uniqueId AND customer_id = :customerId AND account_id = :accountId AND loan_id = :loanId ORDER BY loan_offer_id DESC LIMIT 1", nativeQuery = true)
	public LoanDisbursementDetails findByUniqueIdAndCustomeridAndAccountIdAndLoanId(@Param("uniqueId") String uniqueId, @Param("customerId") long customerId, @Param("accountId") String accountId, @Param("loanId") String loanId);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE created_date = (SELECT MAX(created_date) FROM t_pl_loan_offer_details WHERE customer_id = :customerId)", nativeQuery = true)
	public LoanDisbursementDetails getLatestLODByCustId(@Param("customerId") long customerId);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE created_date = (SELECT MAX(created_date) FROM t_pl_loan_offer_details WHERE customer_id = :customerId and account_id = :accountId and loan_id = :loanId)", nativeQuery = true)
	public LoanDisbursementDetails getLatestLODByCustIdAndAndAccountIdLoanId(@Param("customerId") long customerId, @Param("accountId") String accountId, @Param("loanId") String loanId);
	
	@Query("SELECT a FROM LoanDisbursementDetails a WHERE a.loanOfferId > 0 AND a.customerid = :customerId AND a.accountId = :accountId AND a.loanId = :loanId ORDER BY a.loanOfferId DESC LIMIT 1 ")
	public LoanDisbursementDetails findLatestByCustomerIdAndAccountIdAndLoanIdOrderByLoanOfferIdDesc(long customerId, String accountId, String loanId);
	
	Optional<LoanDisbursementDetails> findTopByCustomeridAndAccountIdAndLoanIdAndDisburalStatusOrderByLoanOfferIdDesc(@Param("customerId") Long customerId, @Param("accountId")String accountId,@Param("loanId") String loanId, @Param("value") String disbursalStatus);

}
