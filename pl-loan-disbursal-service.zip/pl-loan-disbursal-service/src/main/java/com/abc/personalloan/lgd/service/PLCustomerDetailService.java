package com.abc.personalloan.lgd.service;

import com.abc.personalloan.lgd.common.model.PLCustomerDetailDto;
import com.abc.personalloan.lgd.entity.PLCustomerDetail;
import com.abc.personalloan.lgd.payload.request.LeadDropRequest;

public interface PLCustomerDetailService {

	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto plCustomerDetailDto);
	
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail);
	
	public PLCustomerDetail findByAccountIdAndActive(String accountId, Boolean active);

	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdAndActive(String accountId, String loanId, Long customerId, Boolean active);

	public PLCustomerDetail findByAccountId(String accountId);
	
	public void updateLeadMileStone(LeadDropRequest request, String accountId, String loanId, Long customerId);

	public PLCustomerDetail auditCustomerDetailsError(PLCustomerDetailDto plCustomerDetailDto);

	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerId(String accountId, String loanId, Long customerId);
}
