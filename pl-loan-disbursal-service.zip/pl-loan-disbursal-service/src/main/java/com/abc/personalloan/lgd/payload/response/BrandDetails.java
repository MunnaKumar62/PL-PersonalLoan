package com.abc.personalloan.lgd.payload.response;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BrandDetails {

	private String sku;

	private String shortDesc;

	private String imagePath;

	private String brandId;

	private String brandName;

}
