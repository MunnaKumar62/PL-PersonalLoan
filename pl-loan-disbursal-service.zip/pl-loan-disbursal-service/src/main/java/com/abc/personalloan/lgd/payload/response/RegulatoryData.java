package com.abc.personalloan.lgd.payload.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegulatoryData {

	@JsonProperty("message")
	private String message;

	@JsonProperty("accountId")
	private String accountId;
}
