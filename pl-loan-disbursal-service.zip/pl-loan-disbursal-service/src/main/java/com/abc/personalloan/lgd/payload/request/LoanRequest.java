package com.abc.personalloan.lgd.payload.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class LoanRequest {

	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("uniqueId")
	private String uniqueId;

	@JsonProperty("customerId")
	private Long customerId;

	@JsonProperty("mobileNumber")
	private String mobileNumber;

	@JsonProperty("panNumber")
	private String panNumber;
	
	@JsonProperty("loanId")
	private String loanId;

	

}
