package com.abc.personalloan.lgd.common.model.offer;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BrandDetails {

	
    @JsonProperty("Id") 
    public String id;
    @JsonProperty("Name") 
    public String name;
    @JsonProperty("SKU") 
    public String sKU;
    @JsonProperty("Images") 
    public ArrayList<Image> images;
    @JsonProperty("Description") 
    public Object description;
    @JsonProperty("URL") 
    public Object uRL;
    @JsonProperty("Message") 
    public Object message;
    @JsonProperty("IsInternal") 
    public boolean isInternal;
    @JsonProperty("Tnc") 
    public Object tnc;

}
