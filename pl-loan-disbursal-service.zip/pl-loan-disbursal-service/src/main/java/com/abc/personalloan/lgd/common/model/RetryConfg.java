package com.abc.personalloan.lgd.common.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
public class RetryConfg {

	private int maxAttempts;
	private long delay;

}
