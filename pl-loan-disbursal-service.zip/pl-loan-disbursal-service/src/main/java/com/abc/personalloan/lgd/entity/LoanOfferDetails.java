package com.abc.personalloan.lgd.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_pl_loan_offer_details")
public class LoanOfferDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -13671207720763931L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "loan_offer_id")
	private Double loanOfferId;

	@Column(name = "loanamount")
	private Double loanAmount;

	@Column(name = "loan_id")
	private String loanId;

	@Column(name = "account_id")
	private String accountId;

	@Column(name = "tenure")
	private Integer tenure;

	@Column(name = "rateof_interest")
	private Double rateOfInterest;

	@Column(name = "monthly_emi")
	private Double monthlyEmi;

	@Column(name = "credited_amount")
	private Double creditedAmount;

	@Column(name = "repayment_amount")
	private Double repaymentAmount;

	@Column(name = "emidate")
	private String emiDate;

	@Column(name = "offerdate")
	private LocalDateTime offerDate;

	@Column(name = "processing_fee")
	private Double processingFee;

	@Column(name = "stampduty_charges")
	private Double stampDutyCharges;

	@Column(name = "interest")
	private Double interest;
	

	@Column(name = "disbursal_status")
	private String disburalStatus;
	
	@Column(name = "loan_no")
	private String loanNo;
	
	@Column(name = "loan_type")
	private String loanType;

	@Column(name = "loan_disbursal_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime loanDisbursalDate;
	/*
	 * @ManyToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "bank_account_id") private AccountDetails bankAccountId;
	 */

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private CustomerDetails customerDetails;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "emiplan_id", unique = false)
//	private EmiPlan emiPlan;

	@Column(name = "active")
	private boolean status;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;
	
	@Column(name = "loan_disbursal_start")
	private String loanDisbursalStart;

	@Column(name = "loan_disbursal_start_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime loanDisbursalStartDatetime;

}
