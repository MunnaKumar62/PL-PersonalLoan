package com.abc.personalloan.lgd.payload.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PdfRequest {

	private String accountId;

	private String customerId;

	private String mobileNumber;

	private String panNumber;

	private String dateOfBirth;

}
