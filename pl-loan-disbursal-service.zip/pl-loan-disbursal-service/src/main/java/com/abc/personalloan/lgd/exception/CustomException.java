package com.abc.personalloan.lgd.exception;

import lombok.Data;

@Data
public class CustomException extends RuntimeException {
private static final long serialVersionUID = -6411588775873452678L;
	
	private String errorType;
	private String errorCode;
	private String discription;

	public CustomException() {
		super();
	}

	public CustomException(String message, Throwable cause) {
		super(message, cause);
	}

	public CustomException(String message) {
		super(message);
	}
	
	public CustomException(String errorCode,String discription, String errorType) {
		super(errorCode+discription+errorType);
		this.errorCode = errorCode;
		this.discription = discription;
		this.errorType = errorType;
	}
	
	public CustomException(String errorCode,String message) {
		super(errorCode+message);
	}

	public CustomException(Throwable cause) {
		super(cause);
	}

}
