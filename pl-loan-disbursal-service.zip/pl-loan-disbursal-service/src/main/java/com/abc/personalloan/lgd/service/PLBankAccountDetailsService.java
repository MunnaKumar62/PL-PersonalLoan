package com.abc.personalloan.lgd.service;


import com.abc.personalloan.lgd.entity.BankAccountDetails;
import com.abc.personalloan.lgd.payload.request.PLBankDetailsRequest;

public interface PLBankAccountDetailsService {

    public BankAccountDetails findByCustomerIdAndAccountIdAndLoanIdActive(Long customerId, String accountId, String loanId, Boolean active);

    public BankAccountDetails saveOrUpdate(PLBankDetailsRequest request);
}
