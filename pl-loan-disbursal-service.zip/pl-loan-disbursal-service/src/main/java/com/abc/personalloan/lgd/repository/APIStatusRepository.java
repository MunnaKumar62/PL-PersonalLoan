package com.abc.personalloan.lgd.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.personalloan.lgd.entity.ApiStatus;

import jakarta.transaction.Transactional;
@Repository
public interface APIStatusRepository extends JpaRepository<ApiStatus, Integer> {

	public ApiStatus findByApiName(String apiName);

	public ApiStatus findByApiNameAndCustomerIdAndAccountId(String apiName, int customerId, String accountId);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName);

	public ApiStatus findByApiNameAndCustomerId(String apiName, int customerId);
	
	@Query("SELECT a FROM ApiStatus a WHERE a.apiName IN (:apiNames) AND a.accountId = :accountId ORDER BY a.id DESC")
	List<ApiStatus> findByApiNameInAndAccountIdOrderByIdDesc(@Param ("apiNames")List<String> apiNames, String accountId);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("UPDATE ApiStatus a set a.active =:active,a.status =:status, a.modifiedDt =:modifiedDt WHERE (a.active = null OR a.active = false) AND a.accountId =:accountId AND a.loanId =:loanId AND a.customerId =:customerId AND a.status ='SUCCESS'")
	public void updateStatus(@Param("active") Boolean active, @Param("accountId") String accountId, @Param("loanId") String loanId, @Param("customerId") Long customerId, @Param("status") String status, @Param("modifiedDt") Date modifiedDt);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("UPDATE ApiStatus a set a.status =:status, a.modifiedDt =:modifiedDt WHERE a.active = false AND a.accountId =:accountId AND a.apiName IN (:list) AND a.status ='SUCCESS'")
	public void updateStatusError(@Param("list") List<String> list, @Param("accountId") String accountId, @Param("status") String status, @Param("modifiedDt") Date modifiedDt);
	
	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' and a.transactionId =:transactionId order by a.id desc limit 1")
	public ApiStatus findByAccountIdAndApiNameAndTransactionId(String accountId, String apiName, String transactionId);

	@Query("SELECT a FROM ApiStatus a WHERE a.loanId =:loanId and a.apiName= :apiName and a.status ='SUCCESS' and a.transactionId =:transactionId order by a.id desc limit 1")
	public ApiStatus findByLoanIdAndApiNameAndTransactionId(String loanId, String apiName, String transactionId);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' and a.transactionId =:transactionId and a.loanId= :loanId order by a.id desc limit 1")
	public ApiStatus findByAccountIdAndApiNameAndTransactionIdAndLoanId(String accountId, String apiName, String transactionId, String loanId);
}
