package com.abc.personalloan.lgd.payload.response;

import java.time.LocalDateTime;
import java.util.List;

import com.abc.personalloan.lgd.constants.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldErrorResponse {

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private LocalDateTime timestamp;

	private String status;

	private String path;

	private List<FieldError> errors;

}
