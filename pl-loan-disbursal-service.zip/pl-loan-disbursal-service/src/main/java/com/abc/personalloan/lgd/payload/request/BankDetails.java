package com.abc.personalloan.lgd.payload.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class BankDetails {

	@JsonProperty("accountNumber")
	private String accountNumber;

	@JsonProperty("IFSCCode")
	private String iFSCCode;
}
