package com.abc.personalloan.lgd.service.biz;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.abc.personalloan.lgd.entity.*;
import com.abc.personalloan.lgd.repository.BankAccountDetailsRepository;
import com.abc.personalloan.lgd.service.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abc.personalloan.lgd.common.util.CommonUtil;
import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.constants.MessageConstants;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.payload.request.BankDetails;
import com.abc.personalloan.lgd.payload.request.Charges;
import com.abc.personalloan.lgd.payload.request.LoanGenerationRequest;
import com.abc.personalloan.lgd.payload.request.LoanRequest;
import com.abc.personalloan.lgd.payload.request.LoanStatusRequest;
import com.abc.personalloan.lgd.payload.request.MandateDetails;
import com.abc.personalloan.lgd.payload.request.RegulatoryDataRequest;
import com.abc.personalloan.lgd.payload.response.ApiStatusResponse;
import com.abc.personalloan.lgd.payload.response.AvailCouponDetail;
import com.abc.personalloan.lgd.payload.response.BrandDetails;
import com.abc.personalloan.lgd.payload.response.LoanDispursalDtlResponse;
import com.abc.personalloan.lgd.repository.APIStatusRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LoanBizService implements Constants, MessageConstants {

	public LoanGenerationRequest constructRequest(LoanRequest createLoanRequest, CustomerDetailsService customerService,
			APIStatusRepository apiStatusRespo, BankAccountDetailsRepository bankAccountDetailsRepository) {

		LoanGenerationRequest request = null;
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != createLoanRequest) {
			String mobNo = createLoanRequest.getMobileNumber();
			if (CommonUtil.isNullorBlank(mobNo)) {
				msg = FILED_MOB + TILDA + EMPTY_FIELD;
			} else {
				CustomerDetails customerDetails = customerService.findByMobileNumber(mobNo);
				if (null != customerDetails) {
					request = getCreateLoanRequest(customerDetails, apiStatusRespo, createLoanRequest, bankAccountDetailsRepository);
					flag = Boolean.FALSE;
				} else {
					msg = FILED_MOB + TILDA + CUST_NOT_FOUND + mobNo;
				}
			}
		}
		if (flag) {
			throw new CustomException(msg);
		}
		return request;
	}

	public LoanGenerationRequest getCreateLoanRequest(CustomerDetails customerDetails,
			APIStatusRepository apiStatusRespo, LoanRequest createLoanRequest, BankAccountDetailsRepository bankAccountDetailsRepository) {

		Double loanAmount = 0.00;
		Integer tenure = 1;
		Double processingFee = 0.00;

		if (null != customerDetails) {
			String accountId = customerDetails.getAccountId();
			List<LoanOfferDetails> loanDetailsList = customerDetails.getLoanOfferDetails();
			if (!loanDetailsList.isEmpty()) {
				Comparator<LoanOfferDetails> loanComparator = (c1, c2) -> c1.getLoanOfferId().compareTo(c2.getLoanOfferId()); 
				loanDetailsList.sort(Collections.reverseOrder(loanComparator));
				Optional<LocalDateTime> maxDateOptional = loanDetailsList.stream().map(u -> u.getCreatedDate()).max(LocalDateTime::compareTo);
				if(maxDateOptional.isPresent() && maxDateOptional.get().equals(loanDetailsList.get(0).getCreatedDate())) {
					log.info("[getCreateLoanRequest] Fetching last inserted record based on max created date");
					loanAmount = loanDetailsList.get(0).getLoanAmount();
					tenure = loanDetailsList.get(0).getTenure();
					processingFee = loanDetailsList.get(0).getProcessingFee();
				}
			}
			loanAmount = null != loanAmount ? loanAmount : 0;
			tenure = null != tenure ? tenure : 0;
			processingFee = null != processingFee ? processingFee : 0.00;
			log.info("[getCreateLoanRequest]loanAmount: "+loanAmount+" tenure: "+tenure+" processingFee: "+processingFee);
			
			Clock clock = Clock.systemDefaultZone();

			/**
			 * get Instant Object of Clock object in milliseconds using millis() method
			 */
			long milliseconds = clock.millis();
			String uniqueId = customerDetails.getAccountId() + "T" + milliseconds;
			if(null != createLoanRequest && !isEmptyOrNull(createLoanRequest.getUniqueId())) {
				uniqueId  = createLoanRequest.getUniqueId();
			}
			return LoanGenerationRequest.builder().accountId(createLoanRequest.getLoanId()).loanAmount(loanAmount.intValue())
					.disbursalAmount(loanAmount.intValue()).tenure(tenure + EMPTY)
					.bankDetails(getBankDetails(customerDetails, accountId, createLoanRequest.getLoanId(), Boolean.FALSE, bankAccountDetailsRepository)).charges(getCharges(processingFee))
					.mandateDetails(getMandateDetails(accountId, loanAmount, apiStatusRespo)).uniqueId(uniqueId)
					.build();
		} else {
			return null;
		}
	}
	
	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}

	public MandateDetails getMandateDetails(String accountId, Double loanAmount, APIStatusRepository apiStatusRespo) {

		ApiStatus apiStatus = apiStatusRespo.findByAccountIdAndApiName(PL_E_MANDATE_POLLING, accountId);
		String profileId = EMPTY;
		if (null != apiStatus) {
			profileId = apiStatus.getProfileId();
		}
		return MandateDetails.builder().emandateStpFlag("Y").vendor("PP").status("R").referenceNo(profileId)
				.emandateMode("EM").emandateAmount(loanAmount + EMPTY).build();
	}

	public BankDetails getBankDetails(CustomerDetails customerDetails, String accountId, String loanId, Boolean active, BankAccountDetailsRepository bankAccountDetailsRepository) {

		String accountNumber = null;
		String ifscCode = null;
		BankAccountDetails bankAccountDetails = findByCustomerIdAndAccountIdAndLoanIdActiveForDisbursement(customerDetails.getCustomerId(), accountId, loanId, active, bankAccountDetailsRepository);
		if (Objects.nonNull(bankAccountDetails)) {
			accountNumber = bankAccountDetails.getAccountNumber();
			ifscCode = bankAccountDetails.getIfscCode();
		}
		accountNumber = null != accountNumber ? accountNumber : EMPTY;
		ifscCode = ifscCode != null ? ifscCode : EMPTY;

		return BankDetails.builder().iFSCCode(ifscCode).accountNumber(accountNumber).build();

	}

	public BankAccountDetails findByCustomerIdAndAccountIdAndLoanIdActiveForDisbursement(Long customerId, String accountId, String loanId, Boolean active, BankAccountDetailsRepository bankAccountDetailsRepository) {

		BankAccountDetails bankAccountDetails = null;
		Optional<BankAccountDetails> details = bankAccountDetailsRepository.findByCustomerIdAndAccountIdAndLoanIdActive(customerId, accountId, loanId, active);
		if (details.isPresent()) {
			bankAccountDetails = details.get();
		}
		return bankAccountDetails;
	}

	public List<Charges> getCharges(Double processingFee) {

		List<Charges> chargesList = new ArrayList<>();

		Charges charges = Charges.builder().chargeType("R").businessPartnerType("CS")
				.chargeAmount(processingFee + EMPTY).taxRate1("9").taxInclusive("Y").taxApplicable("Y").taxRate2("9")
				.businessPartnerName(EMPTY).finalAmount(processingFee + EMPTY).chargeCode("106").chargeMethod("F")
				.chargeCalculatedOn("2").build();
		chargesList.add(charges);

		return chargesList;
	}

	public LoanStatusRequest getCreateLoanStatusRequest(LoanRequest createLoanRequest) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != createLoanRequest) {
			String accNo = createLoanRequest.getAccountId();
			String unqId = createLoanRequest.getUniqueId();
			if (CommonUtil.isNullorBlank(accNo)) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (CommonUtil.isNullorBlank(unqId)) {
				msg = FILED_UNQ_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			throw new CustomException(msg);
		} else {
			return LoanStatusRequest.builder().accountId(createLoanRequest.getLoanId())
					.uniqueId(createLoanRequest.getUniqueId()).build();
		}
	}

	public List<LoanDispursalDtlResponse> getLoanDispursalDtlList(List<LoanDisbursementDetails> disList) {

		return (null != disList && !disList.isEmpty()) ? disList.stream()
				.map(details -> new LoanDispursalDtlResponse(details.getActive(), details.getDisburalStatus(),
						details.getEmiDate(), details.getLoanAmount(), details.getLoanDisbursalDate(),
						details.getLoanNo(), details.getLoanType(), details.getMonthlyEmi(),
						details.getRateOfInterest(), details.getTenure(),
						null == details.getIsAvailCoupons() ? Boolean.FALSE : details.getIsAvailCoupons()
				))
				.collect(Collectors.toList()) : new ArrayList<>();
	}
	
	public RegulatoryDataRequest validateRegulatoryRequest(RegulatoryDataRequest request, ApiStatusService apiService) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (StringUtils.isBlank(request.getAccountId())) {
			msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
		} else {
			request = loadData(request, apiService);
			if (StringUtils.isBlank(request.getAuditData())) {
				msg = FILED_ACC_ID + TILDA + DATA_NOT_FOUND + request.getAccountId();
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			throw new CustomException(msg);
		}
		return request;
	}
	
	public RegulatoryDataRequest loadData(RegulatoryDataRequest request, ApiStatusService apiService) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		ObjectMapper mapper = new ObjectMapper();
		try {
			List<ApiStatusResponse> list = apiService.getAllApiList(request.getAccountId());

			if (null != list && !list.isEmpty()) {
				String jsonData = mapper.writeValueAsString(list);
				jsonData = !StringUtils.isBlank(jsonData) ? CommonUtil.encodeBase64(jsonData.getBytes()) : EMPTY;
				request.setAuditData(jsonData);
			}
		} catch (JsonProcessingException ex) {
			log.error(methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return request;
	}
	
	public List<String> apiNameList(String whiteListedServices) {

		List<String> list = new ArrayList<>();
		if (!StringUtils.isBlank(whiteListedServices)) {
			String[] arr = whiteListedServices.split(COMMA);
			if (arr.length > 1) {
				for (String str : arr) {
					str = str.trim();
					list.add(str);
				}
			}
		}
		return list;
	}
	
	public Long accountIdRequest(Long customerId) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (customerId == null) {
	        msg = FILED_CUSTOMERID + TILDA + EMPTY_FIELD;
	    } else {
	        flag = false; 
	    }
	    
	    if (flag) {
	        throw new CustomException(msg);
	    }
	    
	    return customerId; 
	}

}
