package com.abc.personalloan.lgd.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.exception.CustomException;
import com.abc.personalloan.lgd.exception.RetryException;
import com.abc.personalloan.lgd.payload.request.DisburementCallBackRequest;
import com.abc.personalloan.lgd.payload.request.LoanRequest;
import com.abc.personalloan.lgd.payload.request.RegulatoryDataRequest;
import com.abc.personalloan.lgd.payload.response.LoanDispursalDtlResponse;
import com.abc.personalloan.lgd.service.LoanGenerationAndDisbursalService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.API + Constants.VERSION)
@Tag(name = "API for Loan Generation and Disbursal Service.")
public class LoanGenerationController extends BaseController {

	@Autowired
	private LoanGenerationAndDisbursalService loanService;
	
	@Value("${pl.disbursement.scheduler.enabled}")
	private String isSchEnabled;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	@Operation(summary = "API to check the status.", description = "")
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_CONDITION_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	@GetMapping(path = Constants.CHECK_API_STATUS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getAPIStatus() {
		return ResponseEntity
				.ok(LocalDateTime.now() + " ABC - The Personal Loan (loandisbursal) API is running successfully!..");
	}

	/**
	 * This API is used to call at the time of loan disbursement.
	 * @param request contains accountId, uniqueId, customerId, mobileNumber, panNumber.
	 * @return Response object contains data message, uniqueId, accountId, responseStatus.
	 * @throws this return CustomException if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping(LOAN_DISBURSEMENT)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> loanGeneration(@RequestBody LoanRequest request) {
		auditUrl();
		return loanService.loanGeneration(request);
	}

	/**
	 * This API is used to get the status of loan disbursement.
	 * @param request uniqueid, accountid
	 * @return It returns response object contains utrNo, dealNo, loanNo, disbursalStatus.
	 * @throws CustomException - If any external api client exception.
	 * @throws RetryException - If loan disbursement status is still IN_PROGRESS, it will retry to call disbursement Polling API.
	 */
	@PostMapping(DISBURSEMENT_STATUS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> disbursementStatus(@RequestBody LoanRequest request) throws CustomException, RetryException {
		auditUrl();
		return loanService.disbursementStatusWithRetry(request);
	}

	/**
	 * This API is used to get the status of loan disbursement.
	 * @param request uniqueid, accountid
	 * @return It returns response object contains utrNo, dealNo, loanNo, disbursalStatus.
	 * @throws CustomException - If any external api client exception.
	 * @throws RetryException - If loan disbursement status is still IN_PROGRESS, it will retry to call disbursement Polling API.
	 */
	@PostMapping(DISBURSEMENT_STATUS_APICALL)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> disbursementStatusApiCall(@RequestBody LoanRequest request) throws CustomException, RetryException {
		auditUrl();
		return loanService.disbursementStatus(request);
	}

	/**
	 * This API is used to get the loan disbursement details for customerID.
	 * @param customerID
	 * @return Response object contains disbursalStatus,emiDate,loanAmount,loanNo,loanType,monthlyEmi,rateOfInterest,tenure.
	 */
	@GetMapping(LOAN_DISBURSEMENT_DTLS)
	public List<LoanDispursalDtlResponse> getDisbursedLoans(@RequestParam long customerID) {
		return loanService.getLoanDisburseDts(customerID);
	}

	/**
	 * This API method will call by external api to confirm DISBURSEMENT polling is happened for that particular account id
	 * and insertion will happen in apistatus table for this callback api.
	 * @param disburementCallBackRequest this request pojo object contains status,uniqueId,accountId,loanNo,disbursalStatus,utrNo,dealNo.
	 * @return It will return response object, it is containing code and status and timestamp. Code is static value PL2206 and
	 * status is message like success.
	 */
	@PostMapping(DISBURSEMENT_CALLBACK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> disbursementcallback(@RequestBody DisburementCallBackRequest disburementCallBackRequest) {
		auditUrl();
		return loanService.disbursementcallback(disburementCallBackRequest);
	}

	/**
	 * This API is used to get the regulatory data for account id.
	 * @param request it contains accountId, auditData.
	 * @return Response object contains regulatory details of particular account id.
	 */
	@PostMapping(REGULATORY_DATA)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> fetchPanDetails(@RequestBody RegulatoryDataRequest request) {
		auditUrl();
		return loanService.uploadRegulatoryData(request);
	}

	/**
	 * This API is used to get the loan disbursal details of customerId.
	 * @param customerId
	 * @return Response object contains disbursalStatus.
	 */
	@GetMapping(DISBURSAL)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> disbursalStatus(@PathVariable Long customerId, @PathVariable String accountId, @PathVariable String loanId) {
		auditUrl();
		return loanService.disbursalStatus(customerId, accountId, loanId);
	}

	/**
	 * This API is used as scheduler to get the IN_PROGRESS and INITIATED disbursement status records and will
	 * call DISBURSEMENT POLLING api to get the status and update in api status table.
	 * @return
	 */
	@PostMapping(DISBURSEMENT_STATUS_JOB)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> disbursementStatusJob() {
		Object obj = null;
		if (null != isSchEnabled && isSchEnabled.equals(YES)) {
			return loanService.disbursementStatusJob();
		}else {
			obj = "PL Disbursement Scheduler is disabled";
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
}
