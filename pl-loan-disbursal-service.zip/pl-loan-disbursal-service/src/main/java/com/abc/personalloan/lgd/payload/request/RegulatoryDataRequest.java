package com.abc.personalloan.lgd.payload.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegulatoryDataRequest {

	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("auditData")
	private String auditData;

}
