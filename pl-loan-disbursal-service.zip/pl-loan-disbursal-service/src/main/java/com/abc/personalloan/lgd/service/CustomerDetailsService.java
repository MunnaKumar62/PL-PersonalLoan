package com.abc.personalloan.lgd.service;

import com.abc.personalloan.lgd.entity.CustomerDetails;

public interface CustomerDetailsService {

	CustomerDetails findByCustomerId(Long id);

	CustomerDetails findByMobileNumber(String mobileNumber);

	CustomerDetails findByAccountId(String accountId);

}
