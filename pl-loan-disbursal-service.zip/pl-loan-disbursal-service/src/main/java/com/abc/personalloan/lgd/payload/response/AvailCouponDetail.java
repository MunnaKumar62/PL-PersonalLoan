package com.abc.personalloan.lgd.payload.response;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AvailCouponDetail {

	private String requestId;

	private String couponId;

	private String couponCode;

	private String availedDate;

	private String customerUniqueId;

	private String couponExpiry;
}
