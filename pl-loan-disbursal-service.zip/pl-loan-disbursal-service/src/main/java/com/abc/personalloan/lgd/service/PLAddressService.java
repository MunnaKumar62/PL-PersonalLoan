package com.abc.personalloan.lgd.service;

import com.abc.personalloan.lgd.entity.PLAddress;
import com.abc.personalloan.lgd.payload.request.PLAddressRequest;

public interface PLAddressService {

	public PLAddress findByCustomerIdAndAccountIdAndLoanIdActive(Long customerId, String accountId, String loanId, Boolean active);

	public PLAddress saveOrUpdate(PLAddressRequest request);
}
