package com.abc.personalloan.lgd.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_pl_bank_account_details")
public class AccountDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2546793369822175436L;

	@Id
	@Column(name = "bank_account_id")
	private Long bankAccountId;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "ifsc_code")
	private String ifscCode;

	@Column(name = "account_holder_name")
	private String accountName;

	@Column(name = "account_no")
	private String accountNunber;

	@ManyToOne
	@JsonBackReference
	@JoinColumn(name = "customer_id")
	private CustomerDetails customerDetails;

	@Column(name = "active")
	private boolean active;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;

}
