package com.abc.personalloan.lgd.payload.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@lombok.Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class StatusData {

	@JsonProperty("dealNo")
	private String dealNo;

	@JsonProperty("loanNo")
	private String loanNo;

	@JsonProperty("disbursalStatus")
	private String disbursalStatus;

	@JsonProperty("utrNo")
	private String utrNo;

}
