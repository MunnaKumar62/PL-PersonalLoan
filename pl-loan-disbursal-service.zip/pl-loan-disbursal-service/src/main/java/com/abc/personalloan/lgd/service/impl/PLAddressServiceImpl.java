package com.abc.personalloan.lgd.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.personalloan.lgd.constants.Constants;
import com.abc.personalloan.lgd.entity.PLAddress;
import com.abc.personalloan.lgd.payload.request.PLAddressRequest;
import com.abc.personalloan.lgd.repository.PLAddressRepository;
import com.abc.personalloan.lgd.service.PLAddressService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PLAddressServiceImpl implements PLAddressService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	PLAddressRepository plAddressRepository;

	@Override
	public PLAddress findByCustomerIdAndAccountIdAndLoanIdActive(Long customerId, String accountId, String loanId,  Boolean active) {

		PLAddress plAddress = null;
		Optional<PLAddress> details = plAddressRepository.findByCustomerIdAndAccountIdAndLoanIdActive(customerId, accountId, loanId, active);
		if (details.isPresent()) {
			plAddress = details.get();
		}
		return plAddress;
	}

	@Override
	public PLAddress saveOrUpdate(PLAddressRequest plAddressRequest) {

		PLAddress address = null;
		if (null != plAddressRequest) {
			address = mergeAddressRequest(plAddressRequest, findByCustomerIdAndAccountIdAndLoanIdActive(plAddressRequest.getCustomerId(), plAddressRequest.getAccountId(), plAddressRequest.getLoanId(), Boolean.FALSE));
			if (null != address) {
				address = plAddressRepository.save(address);
				log.info(className + "[Address: " + address.toString() + "]");
			}
		}
		return address;
	}

	private PLAddress mergeAddressRequest(PLAddressRequest source, PLAddress dest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		if (null != dest) {
			log.info(className + methodName + "[UPDATING ADDRESS DETAILS ... ...]");
			dest.setActive(null != source.getActive() ? source.getActive() : dest.getActive());
			dest.setModifiedBy(CREATED_BY);
			dest.setModifiedDate(new Timestamp(new Date().getTime()));
		} else {
			log.info(className + methodName + "[ADDRESS DETAILS NOT FOUND]");
		}
		return dest;
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
}
