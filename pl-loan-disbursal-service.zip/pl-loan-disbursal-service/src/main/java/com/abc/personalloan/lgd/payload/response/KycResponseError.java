package com.abc.personalloan.lgd.payload.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class KycResponseError {
	private String code;
	private String description;
	private String errorType;
}
