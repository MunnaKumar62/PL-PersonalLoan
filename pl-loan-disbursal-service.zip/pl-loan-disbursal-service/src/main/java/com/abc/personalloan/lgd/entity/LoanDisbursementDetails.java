package com.abc.personalloan.lgd.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_pl_loan_offer_details")
public class LoanDisbursementDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -13671323230763931L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "loan_offer_id")
	private Double loanOfferId;

	@Column(name = "loanamount")
	private Double loanAmount;

	@Column(name = "is_avail_coupons")
	private Boolean isAvailCoupons = false;
	
	@Column(name = "tenure")
	private Integer tenure;

	@Column(name = "rateof_interest")
	private Double rateOfInterest;

	@Column(name = "monthly_emi")
	private Double monthlyEmi;

	@Column(name = "credited_amount")
	private Double creditedAmount;

	@Column(name = "emidate")
	private String emiDate;

	@Column(name = "customer_id")
	private long customerid;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "loan_no")
	private String loanNo;
	
	@Column(name = "account_id")
	private String accountId;

	@Column(name = "loan_type")
	private String loanType;

	@Column(name = "bankaccountdtl_id")
	private String bankaccountdtlId;

	@Column(name = "utrno")
	private String utrno;

	@Column(name = "unique_id")
	private String uniqueId;

	@Column(name = "disbursal_status")
	private String disburalStatus;

	@Column(name = "loan_disbursal_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime loanDisbursalDate;
	
	@Column(name = "loan_disbursal_start")
	private String loanDisbursalStart;

	@Column(name = "loan_disbursal_start_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime loanDisbursalStartDatetime;
	
	@Column(name = "loan_id")
	private String loanId;

}
