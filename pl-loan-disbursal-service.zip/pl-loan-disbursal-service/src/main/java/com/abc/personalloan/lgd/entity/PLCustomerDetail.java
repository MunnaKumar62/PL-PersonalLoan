package com.abc.personalloan.lgd.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_pl_customer_detail")
public class PLCustomerDetail implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_detail_id")
	private Long customerDetailId;

	@Column(name = "accnt_create_date")
	private Date accntCreateDate;

	@Column(name = "accountid")
	private String accountId;
	
	@Column(name = "applicationid")
	private String applicationId;

	@Column(name = "cccid")
	private String cccId;

	@Column(name = "mobilenumber")
	private String mobilenumber;

	@Column(name = "credit_score")
	private String creditScore;

	@Column(name = "loan_purpose")
	private String loanPurpose;

	@Column(name = "firstname_lastname")
	private String firstnameLastname;

	@Column(name = "pannumber")
	private String pannumber;

	@Column(name = "date_of_birth")
	@Temporal(TemporalType.DATE)
	private LocalDate dateOfBirth;

	@Column(name = "gender")
	private String gender;

	@Column(name = "email")
	private String email;

	@Column(name = "breloan_amount")
	private Double breloanAmount;

	@Column(name = "breroi")
	private Double breroi;

	@Column(name = "bre_offertime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date breOffertime;

	@Column(name = "bre_reject_reason")
	private String breRejectReason;

	@Column(name = "emandate_status")
	private String emandateStatus;

	@Column(name = "eman_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date emanDatetime;

	@Column(name = "ckyc_status")
	private String ckycStatus;

	@Column(name = "ckyctime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ckyctime;

	@Column(name = "digilocker_consent")
	private String digilockerConsent;

	@Column(name = "digilocker_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digilockerConsentDatetime;
	
	@Column(name = "digilocker_status")
	private String digilockerStatus;

	@Column(name = "digilocker_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digilockerTime;

	@Column(name = "ukyc_status")
	private String ukycStatus;

	@Column(name = "ukyc_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ukycTime;

	@Column(name = "current_screen")
	private String currentScreen;

	@Column(name = "app_platform")
	private String appPlatform;

	@Column(name = "basic_consent")
	private String basicConsent;

	@Column(name = "basic_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date basicConsentDatetime;

	@Column(name = "bank_consent")
	private String bankConsent;

	@Column(name = "bank_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date bankConsentDatetime;

	@Column(name = "kyc_address_consent")
	private String kycAddressConsent;

	@Column(name = "kyc_address_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date kycAddressConsentDatetime;
	
	@Column(name = "ukyc_address_consent")
	private String ukycAddressConsent;

	@Column(name = "ukyc_address_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ukycAddressConsentDatetime;
	
	@Column(name = "bankaccount_id")
	private String bankaccountId;
	
	@Column(name = "pennydrop_status")
	private String pennydropStatus;
	
	@Column(name = "bank_detail_validation")
	private String bankDetailValidation;

	@Column(name = "docusign_consent")
	private String digisignConsent;

	@Column(name = "docusign_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digisignConsentDatetime;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	@UpdateTimestamp
	private Date modifiedDate;
	
	@Column(name = "salaried") 
	private Boolean  salaried;
	
	@Column(name = "self_employed") 
	private Boolean selfEmployed;
	
	@Column(name = "loan_amount") 
	private Double loanAmount;
	
	@Column(name = "monthly_income") 
	private Double monthlyIncome;
	
	@Column(name = "work_address") 
	private String workAddress;
	
	@Column(name = "tenure") 
	private Integer tenure;
	
	@Column(name = "lead_id")
	private String leadId;

	@Column(name = "ukyc_init")
	private String ukycInit;

	@Column(name = "kyc_type")
	private String kycType;

	@Column(name = "ukyc_init_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ukycInitTime;
	
	@Column(name = "transactionid")
	private String transactionId;

	@Column(name = "journey_type")
	private String journeyType;

	@Column(name = "loan_id")
	private String loanId;

	@Column(name = "customer_id")
	private Long customerId;
}
