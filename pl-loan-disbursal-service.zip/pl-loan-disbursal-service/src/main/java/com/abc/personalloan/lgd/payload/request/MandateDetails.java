package com.abc.personalloan.lgd.payload.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@JsonPropertyOrder({ "emandateStpFlag", "vendor", "status", "referenceNo", "emandateMode", "emandateAmount" })
public class MandateDetails {

	@JsonProperty("emandateStpFlag")
	private String emandateStpFlag;

	@JsonProperty("vendor")
	private String vendor;

	@JsonProperty("status")
	private String status;

	@JsonProperty("referenceNo")
	private String referenceNo;

	@JsonProperty("emandateMode")
	private String emandateMode;

	@JsonProperty("emandateAmount")
	private String emandateAmount;

}
