package com.abc.personalloan.lgd.mixpanel.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Propertiesvalue {

	private long time;
	@JsonProperty("LoanAmount")
	private double loanAmount;
	@JsonProperty("EmiTenureMonths")
	private Integer emiTenureMonths;
	@JsonProperty("RateOfInterest")
	private Double rateOfInterest;
	@JsonProperty("EmiAmount")
	private double emiAmount;
	@JsonProperty("LoanAccNumber")
	private String loanAccNumber;
	@JsonProperty("DisbursalStatus")
	private String disbursalStatus;
	@JsonProperty("LoanDisbursalDate")
	private String loanDisbursalDate;
	@JsonProperty("LoanType")
	private String loanType;
	@JsonProperty("ScreenType")
	private String screenType;
	@JsonProperty("ScreenName")
	private String screenName;
	@JsonProperty("PreviousScreen")
	private String previousScreen;
	@JsonProperty("ProductName")
	private String productName;
	@JsonProperty("JourneyType")
	private String journeyType;
	@JsonProperty("UserAge")
	private long userAge;
	@JsonProperty("UserGender")
	private String userGender;
	@JsonProperty("ClientID")
	private Long clientId;
	@JsonProperty("GoldenID")
	private Long goldenId;

	@JsonProperty("AccountID")
	private String accountID;

	@JsonProperty("LoanID")
	private String loanID;
	@JsonProperty("GuestID")
	private Long guestId;
	@JsonProperty("$CleverTap_user_id")
	private String cleverTapUserId;
	@JsonProperty("AppsflyerID")
	private String appsflyerId;

	@JsonProperty("distinct_id")
	private String distinctId;

	@JsonProperty("$insert_id")
	@SerializedName("$insert_id")
	private String insertId;

	public String getInsertId() {
		return insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

}
