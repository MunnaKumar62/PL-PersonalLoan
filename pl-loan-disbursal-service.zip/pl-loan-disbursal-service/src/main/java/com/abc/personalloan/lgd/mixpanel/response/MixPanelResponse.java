package com.abc.personalloan.lgd.mixpanel.response;

import lombok.Data;

@Data
public class MixPanelResponse {
	
	private Integer code;
	private Integer num_records_imported;
	private String status;
	
}