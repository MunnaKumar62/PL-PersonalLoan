package com.abc.personalloan.lgd.common.model.offer;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FailureReason {

	
    @JsonProperty("Code") 
    public int code;
    @JsonProperty("Error") 
    public String error;
    @JsonProperty("Message") 
    public String message;
    @JsonProperty("Meta") 
    public String meta;

}
