package com.abc.personalloan.lgd.payload.response;

import java.time.LocalDateTime;
import com.abc.personalloan.lgd.constants.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.ToString;

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class LoanDispursalDtlResponse {

	private Boolean active;

	private String disbursalStatus;

	private String emiDate;

	private Double loanAmount;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT_1)
	private LocalDateTime loanDisbursalDate;

	private String loanNo;

	private String loanType;

	private Double monthlyEmi;

	private Double rateOfInterest;

	private Integer tenure;

	private Boolean isAvailCoupons;

}
