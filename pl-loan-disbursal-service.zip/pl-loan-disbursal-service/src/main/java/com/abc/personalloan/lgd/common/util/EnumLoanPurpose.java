package com.abc.personalloan.lgd.common.util;

import java.util.Arrays;
import java.util.Optional;

public enum EnumLoanPurpose {

	PersonalUseLoan("Personal Use"), Wedding("Wedding Loan"), Vacation("Vacation Loan"), DebtLoan("Debt Consolidation"),
	Medicalemergency("Medical Emergency"), HomeRenovation("Home Renovation");

	private String val;

	EnumLoanPurpose(String value) {
		this.val = value;
	}

	public String getVal() {
		return val;
	}

	public static String getValue(String key) {
		EnumLoanPurpose tmp = EnumLoanPurpose.valueOf(key);
		return tmp.getVal();
	}

	public static Optional<EnumLoanPurpose> getKeys(String val) {
		return Arrays.stream(EnumLoanPurpose.values()).filter(env -> env.val.equals(val)).findFirst();
	}

	public static String getKey(String value) {
		Optional<EnumLoanPurpose> tmp = EnumLoanPurpose.getKeys(value);
		return tmp.get().name();
	}
	
	public static void main(String[] args) {
		System.out.println(EnumLoanPurpose.getKey("Medical emergency loan"));
		System.out.println(EnumLoanPurpose.getValue("HomeRenovation"));
	}
}
