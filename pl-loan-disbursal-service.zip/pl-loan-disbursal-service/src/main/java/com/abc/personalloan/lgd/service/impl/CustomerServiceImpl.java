package com.abc.personalloan.lgd.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.personalloan.lgd.entity.CustomerDetails;
import com.abc.personalloan.lgd.repository.CustomerRepository;
import com.abc.personalloan.lgd.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRespo;

	public Optional<CustomerDetails> findByMobileNumber(String mobileNumber) {
		Optional<CustomerDetails> response = customerRespo.findByMobileNumber(mobileNumber);
		return response;
	}

}
