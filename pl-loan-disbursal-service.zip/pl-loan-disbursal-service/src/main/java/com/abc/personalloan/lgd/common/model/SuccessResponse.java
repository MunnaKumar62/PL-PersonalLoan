package com.abc.personalloan.lgd.common.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.abc.personalloan.lgd.constants.Constants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SuccessResponse {

	@JsonProperty("timestamp")
	private String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT));

	@JsonProperty("status")
	private String status;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("code")
	private String code;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("message")
	private String message;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private Object data;

}
