package com.abc.personalloan.lgd.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
@Table(name = "t_customer_activation")
public class AppActivationn {
	@Id
	@Column(name = "customer_activation_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long customerActivationId;
	
	@Column(name = "mdn")
	private String mdn;
	
	@Column(name = "device_id")
	private String deviceId;
	
	@Column(name = "imei")
	private String imei;
	
	@Column(name = "os_name")
	private String osName;
	
	@Column(name = "os_version")
	private String osVersion;
	
	@Column(name = "mobile_operator")
	private String mobileOperator;
	
	@Column(name = "battery_status")
	private String batteryStatus;
	
	@Column(name = "login_location_lat")
	private Float loginLocationLat;
	
	@Column(name = "login_location_long")
	private Float loginLocationLong;
	
	@Column(name = "ip_address")
	private String ipAddress;		
	
	@Column(name = "network_source")
	private String networkSource;
	
	@Column(name = "activation_count")
	private Integer activationCount;
	
	@CreationTimestamp
	@Column(name = "first_activation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime fistActivationDate;
		
	@Column(name = "current_app_version_id")
	private String currentAppVersionId;	

	@Column(name = "previous_version")
	private String previousVersion;
	
	@Column(name="clever_tap_id")
	private String cleverTapId;
	
	@Column(name ="apps_flyer_id")
	private String appsFlyerId;
	@Column(name ="mix_panel_id")
	private String mixPanelId;
	
	
	
}