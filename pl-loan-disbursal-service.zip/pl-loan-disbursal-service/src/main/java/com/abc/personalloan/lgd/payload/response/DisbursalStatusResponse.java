package com.abc.personalloan.lgd.payload.response;

import lombok.Data;

@Data
public class DisbursalStatusResponse {
	private String disbursalStatus;

}
