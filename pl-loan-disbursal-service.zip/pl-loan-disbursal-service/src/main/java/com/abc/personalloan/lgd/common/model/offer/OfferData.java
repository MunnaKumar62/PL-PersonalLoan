package com.abc.personalloan.lgd.common.model.offer;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OfferData {

    @JsonProperty("PageData") 
    public ArrayList<OfferPageDatum> pageData;
    @JsonProperty("TotalRecords") 
    public int totalRecords;
    @JsonProperty("PreviousIndex") 
    public Object previousIndex;
    @JsonProperty("NextIndex") 
    public Object nextIndex;

}
