package com.abcd.pl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalloanApplicationTests {

	@Test
	void contextLoads() {
	}

}
