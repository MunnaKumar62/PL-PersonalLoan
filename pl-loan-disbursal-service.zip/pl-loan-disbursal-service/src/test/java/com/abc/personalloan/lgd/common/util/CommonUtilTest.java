package com.abc.personalloan.lgd.common.util;

import static org.mockito.ArgumentMatchers.anyString;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

class CommonUtilTest {

	/*@InjectMocks
	private CommonUtil commonUtil;
	
	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testGetSuccessResponse() {
		commonUtil.getClass();
	}

	@Test
	public void testGetErrorResponseExceptionHttpHeadersHttpStatusCodeWebRequest() {
		commonUtil.getClass();
	}

	@Test
	public void testGetErrorResponseListOfFieldErrorHttpHeadersHttpStatusCodeWebRequest() {
		commonUtil.getClass();
	}

	@Test
	public void testGetErrorMessage() {
		commonUtil.getClass();
	}

	@Test
	public void testGetErrorList() {
		commonUtil.getClass();
	}

	@Test
	public void testIsNullorBlank() {
		CommonUtil.isNullorBlank(anyString());;
	}*/

}
