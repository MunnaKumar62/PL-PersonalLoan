package com.abc.pl.loan.generation.service;

import com.abc.pl.loan.generation.vo.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.abc.pl.loan.generation.manager.RestConnector;

class ABFLServiceProviderTest {
	@InjectMocks
	ABFLServiceProvider aBFLServiceProvider;

	@Mock
	private RestConnector restConnector;;

	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testScheduleRepaymentEstimate() throws Exception {
		RepaymentScheduleEstimateVO repaymentScheduleEstimateVO = new RepaymentScheduleEstimateVO();
		aBFLServiceProvider.scheduleRepaymentEstimate(repaymentScheduleEstimateVO, null);
	}

	@Test
	public void testSanctionLetter() {

	}

	@Test
	public void testScheduleRepaymentKFS() throws Exception {
		RepaymentSheduleKFSVO repaymentSheduleKFSVO = new RepaymentSheduleKFSVO();
		aBFLServiceProvider.scheduleRepaymentKFS(repaymentSheduleKFSVO, null);
	}

	@Test
	public void testScheduleRepaymentKFSJSON() throws Exception {
		RepaymentSheduleKFSVO repaymentSheduleKFSVO = new RepaymentSheduleKFSVO();
		aBFLServiceProvider.scheduleRepaymentKFS(repaymentSheduleKFSVO, null);
	}

	@Test
	public void testLoanAgreement() throws Exception {
		LoanAgreementGenerationVO loanAgreementGenerationVO = new LoanAgreementGenerationVO();
		aBFLServiceProvider.loanAgreement(null, null);
	}

	@Test
	public void testLoanAgreementPDF() {
		LoanAgreementGenerationVO loanAgreementGenerationVO = new LoanAgreementGenerationVO();
		aBFLServiceProvider.loanAgreementPDF(null, null);

	}

	@Test
	public void testDigitalSign() throws Exception {
		DigiSignRequestVO digiSignVO = new DigiSignRequestVO();
		aBFLServiceProvider.digitalSign(digiSignVO, null);
	}

	@Test
	public void testDigitalSignPolling() throws Exception {
		DigiSignPollRequestVO digiSignPollRequestVO = new DigiSignPollRequestVO();
		aBFLServiceProvider.digitalSignPolling(digiSignPollRequestVO, null);
	}

}
