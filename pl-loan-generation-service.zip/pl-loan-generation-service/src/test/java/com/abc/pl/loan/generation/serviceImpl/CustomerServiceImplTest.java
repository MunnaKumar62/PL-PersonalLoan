package com.abc.pl.loan.generation.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.abc.pl.loan.generation.repo.CustomerRepository;

class CustomerServiceImplTest {
	
	@InjectMocks
	CustomerServiceImpl customerServiceImpl;
	
	@Mock
	CustomerRepository customerRepo;

	@BeforeEach
	public	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testFindByMobileNumber() {

		String mobileNumber="";
		customerServiceImpl.findByMobileNumber(mobileNumber);
	}

	@Test
	public void testFindByAccountId() {
		String accountId="";
		customerServiceImpl.findByAccountId(accountId);
	}

}
