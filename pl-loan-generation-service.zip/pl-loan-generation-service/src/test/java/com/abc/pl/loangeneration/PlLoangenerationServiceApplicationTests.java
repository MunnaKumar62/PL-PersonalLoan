package com.abc.pl.loangeneration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@SpringBootConfiguration
class PlLoangenerationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
