package com.abc.pl.loan.generation.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.abc.pl.loan.generation.entity.RepaymentScheduleRequestDto;
import com.abc.pl.loan.generation.serviceImpl.LoanGenerationServiceImpl;
import com.abc.pl.loan.generation.vo.DigiSignPollResposeVO;
import com.abc.pl.loan.generation.vo.DigiSignVO;
import com.abc.pl.loan.generation.vo.LoanAgreementRequestBuilderVO;
import com.abc.pl.loan.generation.vo.OtpVO;
import com.abc.pl.loan.generation.vo.PdfRequest;
import com.abc.pl.loan.generation.vo.RepaymentScheduleVO;
import com.abc.pl.loan.generation.vo.RepaymentSheduleKFSVO;
import com.abc.pl.loan.generation.vo.SanctionLetterPDFVO;

class LoanGenerationControllerTest {

	@InjectMocks
	LoanGenerationController loanGenerationController;

	@Mock
	private LoanGenerationServiceImpl loanGenerationService;

	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testGetAPIStatus() {

	}

	@Test
	public void testGetRepaymentScheduleEstimate() throws Exception {
		RepaymentScheduleVO repaymentScheduleVO = new RepaymentScheduleVO();
		loanGenerationController.getRepaymentScheduleEstimate(repaymentScheduleVO);
	}

	@Test
	public void testGenerateSanctionLetter() {

	}

	@Test
	public void testGenerateSanctionLetterPDF() throws Exception {
		PdfRequest pdfRequest = new PdfRequest();
		loanGenerationController.generateSanctionLetterPDF(pdfRequest);
	}

	@Test
	public void testRepaymentScheduleKFS() throws Exception {
		RepaymentSheduleKFSVO repaymentSheduleKFSVO = new RepaymentSheduleKFSVO();
		loanGenerationController.repaymentScheduleKFS(repaymentSheduleKFSVO);
	}

	@Test
	public void testGenerateLoanAgreement() {
		// new LoanAgreementRequestBuilderVO();
	}

	@Test
	public void testGenerateLoanAgreementPDF() throws Exception {
		PdfRequest pdfRequest = new PdfRequest();
		loanGenerationController.generateLoanAgreementPDF(pdfRequest);
	}

	@Test
	public void testGetDigitalSign() throws Exception {
		DigiSignVO digiSignVO = new DigiSignVO();
		loanGenerationController.getDigitalSign(digiSignVO);
	}

	@Test
	public void testSendOtp() {
		OtpVO otpVO = new OtpVO();
		loanGenerationController.sendOtp(otpVO);
	}

	@Test
	public void testVerifyOtp() {
		OtpVO otpVO = new OtpVO();
		loanGenerationController.sendOtp(otpVO);
	}

	@Test
	public void testSaveDigiSignCallbackDetails() {
		DigiSignPollResposeVO digiSignPollResposeVO = new DigiSignPollResposeVO();
		loanGenerationController.saveDigiSignCallbackDetails(digiSignPollResposeVO);
	}

	@Test
	public void testGetDigiSignData() throws Exception {
		String customerId = "";
		loanGenerationController.getDigiSignData(null,customerId, customerId);
	}

}
