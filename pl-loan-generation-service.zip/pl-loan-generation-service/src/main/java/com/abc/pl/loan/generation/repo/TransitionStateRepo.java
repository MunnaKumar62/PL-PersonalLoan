package com.abc.pl.loan.generation.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.pl.loan.generation.entity.TransDetails;


@Repository
public interface TransitionStateRepo extends JpaRepository<TransDetails, Long>{

	TransDetails findByCustomerIdAndLobId(long customerId,long lobid);
	TransDetails findByCustomerId(long customerId);
}
