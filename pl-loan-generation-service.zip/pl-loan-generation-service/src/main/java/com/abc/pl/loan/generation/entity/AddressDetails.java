package com.abc.pl.loan.generation.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_address")
public class AddressDetails {

	@Id
	@Column(name = "id")
	private Long addressId;

	@Column(name = "active")
	private String active;

	@Column(name = "addresslineone")
	private String addresslineone;

	@Column(name = "addresslinetwo")
	private String addresslinetwo;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "landmark")
	private String landmark;

	@Column(name = "state")
	private String state;
	
	@Column(name = "pincode")
	private String pincode;

	@Column(name = "typeofaddress")
	private String typeOfAddress;	

	@Column(name = "createdby")
	private String createdBy;

	@Column(name = "createddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modifiedby")
	private String modifiedBy;

	@Column(name = "modifieddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;

	@ManyToOne
	@JsonBackReference
	@JoinColumn(name = "customerid")
	private CustomerDetails customerDetails;

}
