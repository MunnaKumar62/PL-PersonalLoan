package com.abc.pl.loan.generation.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@SuperBuilder
public class SanctionLetterRequestVO {	
	
	private String accountId;
	private String name;
	private String mobileNumber;
	private String panNo;	

}
