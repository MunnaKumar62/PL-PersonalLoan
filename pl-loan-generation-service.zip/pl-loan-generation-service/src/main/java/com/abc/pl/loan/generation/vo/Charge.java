package com.abc.pl.loan.generation.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class Charge {
	
	private String name;
	private String value;

}