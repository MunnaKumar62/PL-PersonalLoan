package com.abc.pl.loan.generation.exception;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ErrorDetail {
	 @JsonProperty("code")
	    public String code;

	    @JsonProperty("errorType")
	    public String errorType;

	    @JsonProperty("description")
	    public String description;

	    @JsonProperty("errors")
	    public List<InnerErrorDetail> errors;

}
