package com.abc.pl.loan.generation.vo;

import java.util.Map;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LoanDetails {

	private double loanAmount;
	private double rateOfInterest;
	private int loanTenure;
	private String disbursalDate;
	private double pf_with_gst;
	private Map<String, Charge> charges;
	private String frequency_type;
	private String number_of_repayment_period;
	private String applicant_name;

}
