package com.abc.pl.loan.generation.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
public class LoanGenerationResponse<T> {
	
	private String responseStatus;
	private Error error;

	public LoanGenerationResponse(String responseStatus, Error error){
		this.responseStatus = responseStatus;
		this.error = error;
	}
}
