package com.abc.pl.loan.generation.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.*;

import com.abc.pl.loan.generation.common.constants.Constants;
import com.abc.pl.loan.generation.entity.PLCustomerDetail;
import com.abc.pl.loan.generation.repo.PLCustomerDetailRepository;
import io.micrometer.common.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;

import com.abc.pl.loan.generation.common.util.EnumLoanPurpose;
import com.abc.pl.loan.generation.entity.CustomerDetails;
import com.abc.pl.loan.generation.entity.LoanOfferDetails;
import com.abc.pl.loan.generation.repo.CustomerRepository;
import com.abc.pl.loan.generation.repo.LoanOfferDetailsRepository;
import com.abc.pl.loan.generation.response.RepaymentScheduleBaseResponse;
import com.abc.pl.loan.generation.vo.Charge;
import com.abc.pl.loan.generation.vo.Installment;
import com.abc.pl.loan.generation.vo.LoanDetails;
import com.abc.pl.loan.generation.vo.PdfRequest;
import com.abc.pl.loan.generation.vo.RepaymentScheduleVO;
import com.abc.pl.loan.generation.vo.RepaymentSheduleKFSVO;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Service
@Log4j2
public class RepaymentScheduleKFSRequestService {

	private final CustomerRepository customerRepo;
	private final LoanOfferDetailsRepository loanOfferDetailsRepo;
	private final LoanGenerationServiceImpl loanGenerationService;
	
	
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	PLCustomerDetailRepository detailRepository;
	
	@Value("${abfl.product.code}")
	private String productCode;
	
	@Value("${abfl.pf.gst}")
	private Double pf_with_gst;

	@Value("${abfl.pf.preapprovedflow.gst}")
	private Double pf_with_pre_approved_gst;

	@Value("${pl.abfl.new.proceesingfee.date}")
	private String pl_pf_new_processingfee_date;

	@Value("${pl.abfl.pf.existing.gst}")
	private Double pl_pf_with_existing_gst;

	public RepaymentSheduleKFSVO setRepaymentSheduleKFSVO(PdfRequest request) throws Exception {
		/*
		 * ! RepaymentSheduleKFS Request - Being Static input. (Except these fields ->
		 * accountId, loanAmount, loanTenure, pf_with_gst, rateOfInterest,
		 * disbursalDate)
		 */
		RepaymentSheduleKFSVO repaymentScheduleKFSRequest = null;
		Optional<CustomerDetails> customerDetails;
		Optional<LoanOfferDetails> loanOfferDetails;
		Optional<PLCustomerDetail> plCustomerDetails;
		PLCustomerDetail plCustomerDetail = null;
		Double pfWithGst = pf_with_gst;
		customerDetails = customerRepo.findByAccountId(request.getAccountId());
		log.info(customerDetails.get().toString());
		plCustomerDetails = detailRepository.findByAccountIdAndLoanIdAndCustomerIdAndActive(request.getAccountId(), request.getLoanId(), request.getCustomerId(), Boolean.FALSE);
		SimpleDateFormat fmt = new SimpleDateFormat(Constants.NEW_PROCESSING_FEE_DATE);
		Date newPfDate = fmt.parse(pl_pf_new_processingfee_date);
		if (plCustomerDetails.isPresent()) {
			plCustomerDetail = plCustomerDetails.get();
			if(StringUtils.isNotEmpty(plCustomerDetail.getJourneyType())
					&& plCustomerDetail.getJourneyType().equals(Constants.PRE_APPROVED_FLOW)){
					pfWithGst = pf_with_pre_approved_gst;
			}else{
				if(plCustomerDetail.getBreOffertime().before(newPfDate)
						&& plCustomerDetail.getCeStatus().equals(Constants.GRANTED)){
					pfWithGst = pl_pf_with_existing_gst;
				}
			}
		}
		log.info("********Processing Fee With GST*********"+pfWithGst);
		Long customerId = customerDetails.get().getCustomerId();
		loanOfferDetails = loanOfferDetailsRepo.findByCustomerIdAndAccountIdAndLoanId(customerId, request.getAccountId(), request.getLoanId(), EnumLoanPurpose.getValue(request.getLoanType()));
		log.info(loanOfferDetails.get().toString());
		Map<String, Charge> charges = new HashMap<>();
		charges.put("dynamic_charge_1",
				Charge.builder().name("Processing fees, if any (in Rupees)").value(
						(pfWithGst * loanOfferDetails.get().getLoanAmount() / 100) + "")
						.build());
		charges.put("dynamic_charge_2",
				Charge.builder().name("Insurance charges, if any (in Rupees)").value("0").build());
		charges.put("dynamic_charge_3",
				Charge.builder().name("Others (if any) (in Rupees) (details to be provided)").value("0").build());

		RepaymentScheduleVO repaymentScheduleVO = new RepaymentScheduleVO();
		repaymentScheduleVO.setAccountId(request.getAccountId());
		repaymentScheduleVO.setLoanAmount((float) loanOfferDetails.get().getLoanAmount().doubleValue());
		repaymentScheduleVO.setLoanTenure(loanOfferDetails.get().getTenure());
		repaymentScheduleVO.setRateOfInterest((float) loanOfferDetails.get().getRateOfInterest().doubleValue());
		repaymentScheduleVO.setLoanId(request.getLoanId());
		repaymentScheduleVO.setCustomerId(request.getCustomerId());
		log.info("setRepaymentSheduleKFS-request="+ objectMapper.writeValueAsString(repaymentScheduleVO));
		
		RepaymentScheduleBaseResponse repaymentScheduleEstimateResponse = loanGenerationService
				.repaymentScheduleEstimate(repaymentScheduleVO);
		
		log.info("setRepaymentSheduleKFS-response=" + objectMapper.writeValueAsString(repaymentScheduleEstimateResponse));
				
		LoanDetails loanDetails = new LoanDetails();
		loanDetails.setApplicant_name(request.getName());
		loanDetails.setCharges(charges);
		loanDetails.setFrequency_type("Monthly");
		loanDetails.setNumber_of_repayment_period(loanOfferDetails.get().getTenure() + "");
		loanDetails.setDisbursalDate(loanOfferDetails.get().getOfferDate()+"");//
		loanDetails.setLoanAmount(loanOfferDetails.get().getLoanAmount());//
		loanDetails.setLoanTenure(loanOfferDetails.get().getTenure());//
		loanDetails.setPf_with_gst(pfWithGst);
		loanDetails.setRateOfInterest(loanOfferDetails.get().getRateOfInterest());//

		repaymentScheduleKFSRequest = new RepaymentSheduleKFSVO();
		repaymentScheduleKFSRequest.setAccountId(request.getLoanId());//
		repaymentScheduleKFSRequest.setInstallments(repaymentScheduleEstimateResponse.getData().getInstallments());
		repaymentScheduleKFSRequest.setLoanDetails(loanDetails);
		repaymentScheduleKFSRequest.setProductCode(Integer.parseInt(productCode));
		//log.debug("RepaymentSheduleKFSVO Request :: " + repaymentScheduleKFSRequest.toString());
		//log.info("/ " + repaymentScheduleKFSRequest.toString());

		return repaymentScheduleKFSRequest;
	}
}
