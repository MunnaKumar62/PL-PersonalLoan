package com.abc.pl.loan.generation.vo;

public class RepaymentScheduleVO {
	private String accountId;
	private float loanAmount;
	private float rateOfInterest;
	private Integer loanTenure;
	private String loanId;
	private Long customerId;

	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public float getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(float loanAmount) {
		this.loanAmount = loanAmount;
	}
	public float getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public Integer getLoanTenure() {
		return loanTenure;
	}
	public void setLoanTenure(Integer loanTenure) {
		this.loanTenure = loanTenure;
	}

	public String getLoanId() {
		return loanId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
}
