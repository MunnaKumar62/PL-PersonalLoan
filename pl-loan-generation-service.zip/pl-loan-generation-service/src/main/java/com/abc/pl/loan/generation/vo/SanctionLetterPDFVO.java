package com.abc.pl.loan.generation.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@Builder
@ToString
public class SanctionLetterPDFVO {
	
	private String cccId;
	private String accountId;
	private String pan;
	private String email;
	private String docName;
	private String dateOfBirth;
	private String loanAmount;
	private String name;
	private String offerDate;
	private String roi;
	private String emi;
	private String offerTime;
	private String tenure;	
	private Long customerId;
	private String loanId;
}
