package com.abc.pl.loan.generation.exception;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PartnerError {

	@JsonProperty("responseStatus")
    public String responseStatus;

    @JsonProperty("error")
    public ErrorDetail errorDetail;

}
