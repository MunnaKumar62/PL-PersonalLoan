package com.abc.pl.loan.generation.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SanctionLetterResponse {
	
	private String accountId;
	
	@JsonProperty("base64_pdf")
	private String sancationLetterPdf;
	

}
