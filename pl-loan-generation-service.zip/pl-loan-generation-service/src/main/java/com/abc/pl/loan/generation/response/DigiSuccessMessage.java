package com.abc.pl.loan.generation.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class DigiSuccessMessage {
	
	@JsonProperty("Message")
    private String mesage;
	@JsonProperty("Status")
    private String status;

}
