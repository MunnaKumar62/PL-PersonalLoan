package com.abc.pl.loan.generation.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RepaymentInstallmentsResponse {

	private Integer installmentNumber;
    private String dueDate;
    private Float dueAmount;
    private Float principalComponent;
    private Float interestComponent;
    private Float principalOutstanding;
}
