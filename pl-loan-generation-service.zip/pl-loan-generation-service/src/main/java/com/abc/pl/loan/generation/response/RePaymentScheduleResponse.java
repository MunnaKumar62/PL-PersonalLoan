package com.abc.pl.loan.generation.response;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import com.abc.pl.loan.generation.entity.CustomerDetails;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@ToString
@Getter
@Setter
public class RePaymentScheduleResponse{
	
	private RepaymentLoanDetailsResponse loanDetails;
	private List<RepaymentInstallmentsResponse> installments;

}
