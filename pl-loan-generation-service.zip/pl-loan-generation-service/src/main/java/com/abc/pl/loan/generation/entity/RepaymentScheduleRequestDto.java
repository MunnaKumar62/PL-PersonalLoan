package com.abc.pl.loan.generation.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RepaymentScheduleRequestDto {
	
	private String accountId;
	private String mobileNo;
	private String panNumber;
}
