package com.abc.pl.loan.generation.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_customer")
@EntityListeners(AuditingEntityListener.class)
public class CustomerDetails implements Serializable {

	private static final long serialVersionUID = 3944886206643636410L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long customerId;

	@Column(name = "firstname", length = 60)
	private String firstName;

	@Column(name = "lastname", length = 60)
	// @NotBlank(message = "{4102}")
	// @Size(min = 2, message = "{4108}")
	private String lastName;

	@Column(name = "dateofbirth")
	// @Past(message = "{4108}")
	@Temporal(TemporalType.DATE)
	private LocalDate dateOfBirth;

	@Column(name = "gender", length = 1)
	// @NotBlank(message = "{4103}")
	private String gender;

	@Column(name = "mobilenumber", length = 20)
	private String mobileNumber;

	@Column(name = "email", length = 60)
	private String emailAddress;

	@Column(name = "pannumber", length = 20)
	private String panNumber;

	@Column(name = "aadhaarnumber", length = 20)
	private String aadhaarNumber;

	//@Column(name = "loantype", length = 60)
	//private String loanType;

	@Column(name = "createdby", length = 60)
	private String createdBy;

	@Column(name = "createddate", updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modifiedby", length = 60)
	private String modifiedBy;

	@Column(name = "modifieddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;

	@Column(name = "active")
	private String status;

	@Column(name = "accountid")
	private String accountId;

	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customerDetails", cascade = CascadeType.ALL)
	private List<PLAddress> addressDetails;

	// @Valid
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customerDetails", cascade = CascadeType.ALL)
	private List<AccountDetails> accountDetails;

	// @Valid
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customerDetails", cascade = CascadeType.ALL)
	private List<LoanOfferDetails> loanOfferDetails;

}
