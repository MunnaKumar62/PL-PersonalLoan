

package com.abc.pl.loan.generation.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class RedisServerException extends ApplicationException {

    private static final long serialVersionUID = -7071168597575099295L;

    public RedisServerException(String message) {
        super(message);
    }
}
