package com.abc.pl.loan.generation.vo;

import com.abc.pl.loan.generation.response.Error;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigiSignPollResposeVO {
	
    public String responseStatus;
    public DigiSignData data;
    public Error error;

}
