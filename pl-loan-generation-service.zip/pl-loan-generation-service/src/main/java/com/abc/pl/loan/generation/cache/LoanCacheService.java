package com.abc.pl.loan.generation.cache;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.abc.pl.loan.generation.dto.PLCustomerDto;
import com.abc.pl.loan.generation.dto.PLLoanDetailsDto;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class LoanCacheService {

	private static final String LOAN_CACHE = "PLLoan";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper objectMapper;

	public PLLoanDetailsDto getLoanFromCache(String userId) {
		PLLoanDetailsDto plLoanDto = null;
		log.info("Fetching Loan from Loan Cache {} ", userId);
		try {
			String data = redisCacheProvider.getData(LOAN_CACHE, userId);
			if (StringUtils.isNotBlank(data)) {
				plLoanDto = objectMapper.readValue(data, PLLoanDetailsDto.class);
			}
		} catch (Exception e) {
			log.error("Failed to fetch Loan from Loan Cache", e);
		}
		return plLoanDto;
	}
	
	public void addLoanToCache(PLLoanDetailsDto plLoan) {
		log.info("Adding Loan to Loan Cache {} ", plLoan);
		try {
			 redisCacheProvider.addData(LOAN_CACHE, plLoan.getAccountId(),objectMapper.writeValueAsString(plLoan));			
		} catch (Exception e) {
			log.error("Failed to fetch Loan from Loan Cache", e);
		}		
	}
	
	public void updateLoanToCache(PLLoanDetailsDto plLoan) {
		log.info("Updating Loan to Loan Cache {} ", plLoan);
		try {
			 redisCacheProvider.addData(LOAN_CACHE, plLoan.getAccountId(),objectMapper.writeValueAsString(plLoan));			
		} catch (Exception e) {
			log.error("Failed to fetch Loan from Loan Cache", e);
		}		
	}

}
