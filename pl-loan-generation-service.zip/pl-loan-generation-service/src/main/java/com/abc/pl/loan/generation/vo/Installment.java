package com.abc.pl.loan.generation.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class Installment {
	
	private int installmentNumber;
	private String dueDate;
	private double dueAmount;
	private double principalComponent;
	private double interestComponent;
	private double principalOutstanding;

}