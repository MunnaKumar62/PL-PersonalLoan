package com.abc.pl.loan.generation.serviceImpl;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.pl.loan.generation.common.util.CommonUtil;
import com.abc.pl.loan.generation.exception.CustomException;
import com.abc.pl.loan.generation.response.TokenResponse;
import com.abc.pl.loan.generation.service.TokenService;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class TokenServiceImpl implements TokenService {


	@Autowired
	private RestTemplate restTemplate;

	@Value("${abc.token.url}")
	private String tokenUrl;

	@Value("${abc.token.grant-type}")
	private String grantType;

	@Value("${abc.token.client-id}")
	private String clientId;

	@Value("${abc.token.scope}")
	private String scope;

	@Value("${abc.token.auth-token}")
	private String authToken;

	private final String errorFieldName = "error_description";
	
	private final String partnerIssue = "Partner Issue";

	public String generateToken() throws Exception {

		// log.info(getClass().getCanonicalName() + " ::Inside generateToken method with
		// request body : ");
		UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam("client_id", clientId)
				.queryParam("scope", scope).queryParam("grant_type", grantType).build();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", "Basic " + authToken);
		
		try {
			HttpEntity<Object> request = new HttpEntity<>(headers);
			ResponseEntity<TokenResponse> apiResponse = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					request, TokenResponse.class);
			//log.info("generateToken=" + apiResponse);	
			//log.info("TokenResponse-response="+apiResponse);
			return apiResponse.getBody().getAccessToken();
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			String description = e.getResponseBodyAsString() + e.getMessage();
			//log.info("TokenResponse-exception="+e.getResponseBodyAsString());
			if (!CommonUtil.isNullorBlank(e.getResponseBodyAsString())) {
				JSONObject errorResponse = new JSONObject(e.getResponseBodyAsString());
				if (errorResponse.has(errorFieldName)) {
					description = errorResponse.has(errorFieldName) ? errorResponse.getString(errorFieldName)
							: partnerIssue;
				}
			}
			throw new CustomException(description);
		} catch (Exception e) {
			throw new CustomException(e.getMessage());
		}

	}
}