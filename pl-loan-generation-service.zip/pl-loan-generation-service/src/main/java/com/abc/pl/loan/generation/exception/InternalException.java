package com.abc.pl.loan.generation.exception;

import com.abc.pl.loan.generation.response.Error;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InternalException extends RuntimeException {

	private static final long serialVersionUID = 4087930070289795747L;

	private String errorCode;
	private String errorMessage;
	private Integer code;
	private String reason;
	
	private Error error;

	public InternalException() {
		super();
	}

	public InternalException(Throwable cause) {
		super(cause);
	}
	
	public InternalException(String errorCode, Error error) {
		super();
		this.errorCode = errorCode;
		this.error = error;
	}
	public InternalException(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	public InternalException(String errorCode,Integer code, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.code = code;
		this.errorMessage = errorMessage;
	}
	public InternalException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public InternalException(String errorCode, String errorMessage, Integer code, String reason) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.code = code;
		this.reason = reason;
	}
	
	

	

}