package com.abc.pl.loan.generation.response;

import java.time.LocalDateTime;
import java.util.List;

import com.abc.pl.loan.generation.common.model.Errors;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class ErrorResponse {

	private LocalDateTime timestamp;
	private String status;
	private String path;
	//private String message;
	private List<Errors> errors;

}
