package com.abc.pl.loan.generation.exception;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class InnerErrorDetail {
	@JsonProperty("code")
	public String code;

	@JsonProperty("description")
	public String description;

	@JsonProperty("errorType")
	public String errorType;

}
