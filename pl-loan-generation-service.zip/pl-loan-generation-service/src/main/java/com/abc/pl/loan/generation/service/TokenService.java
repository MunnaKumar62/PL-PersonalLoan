package com.abc.pl.loan.generation.service;

public interface TokenService {

	String generateToken() throws Exception;
}
