package com.abc.pl.loan.generation.service;

import java.util.Optional;

import com.abc.pl.loan.generation.entity.CustomerDetails;

public interface CustomerService {

	Optional<CustomerDetails> findByMobileNumber(String mobileNumber);

	Optional<CustomerDetails> findByAccountId(String accountId);

}
