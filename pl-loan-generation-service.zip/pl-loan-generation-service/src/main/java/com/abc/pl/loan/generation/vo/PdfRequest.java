package com.abc.pl.loan.generation.vo;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PdfRequest {

	private String accountId;	
	private String cccId;
	private String firstName;
	private String lastName;	
	private Long customerId;
	private String mobileNumber;
	private String panNumber;
	private String email;
	private LocalDate dateOfBirth;
	private String loanType;
	private String address;
	private String city;
	private String pincode;
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("name")
	private String name;
	private String loanId;
	
	
}
