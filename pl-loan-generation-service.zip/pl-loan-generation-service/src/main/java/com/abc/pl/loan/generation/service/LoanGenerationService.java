package com.abc.pl.loan.generation.service;

public interface LoanGenerationService {

}
