package com.abc.pl.loan.generation.common.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SuccessResponse {

	private String timestamp;
	private String status;
	private String code;
	private String message;
	private Object data;

}
