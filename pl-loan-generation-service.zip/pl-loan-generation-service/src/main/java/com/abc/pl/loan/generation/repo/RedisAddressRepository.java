package com.abc.pl.loan.generation.repo;

import java.util.List;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.abc.pl.loan.generation.dto.Address;
import com.abc.pl.loan.generation.dto.PLCustomerDto;
import com.abc.pl.loan.generation.dto.PLLoanDetailsDto;




@Repository
public class RedisAddressRepository {
	
	
 		private HashOperations hashOperations;

	    private RedisTemplate redisTemplate;

	    public RedisAddressRepository(RedisTemplate redisTemplate){
	        this.redisTemplate = redisTemplate;
	        this.hashOperations = this.redisTemplate.opsForHash();
	    }
	    
	    public void save(Address address){
	        hashOperations.put("PLAddress", address.getId(), address);	        
	    }
	    
	    public List findAll(){
	        return hashOperations.values("PLAddress");
	    }

	    public Address findByAccountId(long id){
	        return (Address) hashOperations.get("PLAddress", id);
	    }

	    public void update(Address address){
	        save(address);
	    }
	    

}
