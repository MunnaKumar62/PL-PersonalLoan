package com.abc.pl.loan.generation.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

import com.abc.pl.loan.generation.response.Error;

@Data
public class LoanGenerationException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;
	private String code;
	private String description;
	private String errorType;

	 
	  public LoanGenerationException(String message) {
	        super(message);
	    }

	  public LoanGenerationException(String message , Error error) {
	        super(message);
	        this.code = error.getErrorCode();
	        this.description = error.getErrorDesc();
	        this.errorType = error.getErrorType();
	    }
	
}
