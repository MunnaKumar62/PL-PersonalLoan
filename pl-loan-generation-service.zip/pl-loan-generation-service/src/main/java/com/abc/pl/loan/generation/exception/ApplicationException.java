package com.abc.pl.loan.generation.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class ApplicationException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;
	private int statusCode;
	private String errorCode;
	private Object object;

	 
	public ApplicationException(String message) {
        super(message);
    }

	public ApplicationException(String message,int statusCode,String errorCode) {
        super(message);
        this.statusCode = statusCode;
        this.errorCode = errorCode;
    }
	public ApplicationException(String message,String errorCode) {
		super(message);
		this.errorCode = errorCode;
	}
	public ApplicationException(String message,HttpStatus status,Object error) {
		super(message);
		statusCode = status.value();
		this.errorCode = errorCode;
		this.object = error;
	}
	public ApplicationException(String message,String errorCode,Object error) {
		super(message);
		this.errorCode = errorCode;
		this.object = error;
	}
}
