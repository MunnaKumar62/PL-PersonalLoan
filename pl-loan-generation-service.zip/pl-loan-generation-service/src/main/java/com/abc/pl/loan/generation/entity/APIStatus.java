package com.abc.pl.loan.generation.entity;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Table(name="t_pl_apistatus")
@EntityListeners(AuditingEntityListener.class)
public class APIStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="apistatus_id")
    private Integer id;

    @Column(name="apiname")
    private String apiName;

    @Column(name="customerid")
    private Long customerId;

    @Column(name="accountid")
    private String accountId;

    @Column(name="request_json")
    private String requestJson;

    @Column(name="response_json")
    private String responseJson;

    @Column(name="requestid")
    private String requestId;

    @Column(name="profileid")
    private String profileId;

    @Column(name="transactionid")
    private String transactionId;

    @Column(name="journey")
    private String journey;

    @Column(name="loanpurpose")
    private String loanPurpose;

    @Column(name="gcsreqjsonpath")
    private String gcsReqJsonPath;

    @Column(name="gcsrespjsonpath")
    private String gcsRespJsonPath;

    @Column(name="httpstatuscode")
    private int httpStatusCode;

    @Column(name="status")
    private String status;

    @Column(name="active")
    private Boolean active;

    @Column(name="created_by")
    private String createdBy;

    @CreatedDate
    @Column(name="created_date", updatable = false)   
    private Date createdDate;

    @Column(name="modified_by")
    private String modifiedBy;

    @LastModifiedDate
    @Column(name="modified_date")    
    private Date modifiedDate;

    @Column(name="loan_id")
    private String loanId;
}
