package com.abc.pl.loan.generation.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExternalException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5811352053910961806L;

	private String errorCode;
	private String errorMessage;
	private Integer code;
	private String reason;
	private String errorType;

	public ExternalException() {
		super();
	}

	public ExternalException(Throwable cause) {
		super(cause);
	}

	public ExternalException(String errorCode, String errorMessage, Integer code, String reason) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.code = code;
		this.reason = reason;
	}

	public ExternalException(Integer code, String errorMessage) {
		super();
		this.errorMessage = errorMessage;
		this.code = code;
	}
}
