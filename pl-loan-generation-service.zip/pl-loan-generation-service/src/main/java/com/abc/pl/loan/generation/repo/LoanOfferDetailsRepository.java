package com.abc.pl.loan.generation.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.abc.pl.loan.generation.entity.LoanOfferDetails;

public interface LoanOfferDetailsRepository extends JpaRepository<LoanOfferDetails, Integer> {

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE customer_id = ? and loan_type = ? ORDER BY loan_offer_id DESC LIMIT 1", nativeQuery = true)
	Optional<LoanOfferDetails> findByCustomerId(long customerId, String loanType);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE customer_id = ? and loan_id = ? and loan_type = ? ORDER BY loan_offer_id DESC LIMIT 1", nativeQuery = true)
	Optional<LoanOfferDetails> findByCustomerIdAndLoanId(long customerId, String loanId, String loanType);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE customer_id = ? and account_id = ? and loan_id = ? and loan_type = ? ORDER BY loan_offer_id DESC LIMIT 1", nativeQuery = true)
	Optional<LoanOfferDetails> findByCustomerIdAndAccountIdAndLoanId(long customerId, String accountId, String loanId, String loanType);
}
