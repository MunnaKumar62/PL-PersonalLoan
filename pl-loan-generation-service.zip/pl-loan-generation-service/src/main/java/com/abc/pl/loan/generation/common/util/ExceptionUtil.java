package com.abc.pl.loan.generation.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;

import com.abc.pl.loan.generation.exception.ExternalException;
import com.abc.pl.loan.generation.exception.PartnerError;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class ExceptionUtil {

	@Autowired
	ObjectMapper objectMapper;

	public void handleHttpClientError(HttpStatusCodeException ex, String apiName) throws Exception {
		log.info("handleHttpClientError()-apiName=" + apiName + "; statusCode=" + ex.getStatusCode().value()
				+ "; response =" + ex.getResponseBodyAsString());
		PartnerError partnerError = null;
		String errorMessage = null;
		String reason = null;
		if (ex.getResponseBodyAsString() != null && !ex.getResponseBodyAsString().isEmpty()) {
			try {
				partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
				errorMessage = partnerError.getErrorDetail().getDescription() != null ? partnerError.getErrorDetail().getDescription() : null;
			} catch (JsonProcessingException e) {
				errorMessage = "Error processing JSON response from the client";
				reason = ex.getStatusText();
				log.error("Error processing JSON response from client: " + ex.getResponseBodyAsString(), e);
			}
		} else {
			errorMessage = "Empty or null response from the client";
			log.error("Empty or null response received from client API: " + apiName);
		}

		if (ex instanceof HttpClientErrorException) {
			int httpStatusCode = ex.getStatusCode().value();
			if (partnerError != null && partnerError.getErrorDetail() != null && partnerError.getErrorDetail().getDescription() != null
					&& partnerError.getErrorDetail().getErrorType() != null) {
				throw new ExternalException("C" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
						httpStatusCode, partnerError.getErrorDetail().getDescription());
			} else {
				throw new ExternalException("C" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
						500, reason);
			}

		} else {
			int httpStatusCode = ex.getStatusCode().value();
			if (partnerError != null && partnerError.getErrorDetail() != null && partnerError.getErrorDetail().getDescription() != null
					&& partnerError.getErrorDetail().getCode() != null) {
				throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
						httpStatusCode, partnerError.getErrorDetail().getDescription());
			} else {
				throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
						500, reason);

			}
		}

	}

}
