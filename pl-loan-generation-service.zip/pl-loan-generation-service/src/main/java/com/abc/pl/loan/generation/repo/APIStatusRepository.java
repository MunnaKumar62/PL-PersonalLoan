package com.abc.pl.loan.generation.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.abc.pl.loan.generation.entity.APIStatus;

public interface APIStatusRepository extends JpaRepository<APIStatus, Integer>,JpaSpecificationExecutor<APIStatus> {
	
	APIStatus findByApiName(String apiName);
	
	APIStatus findByApiNameAndCustomerIdAndAccountId(String apiName,Long customerId,String accountId);
	
	APIStatus findByApiNameAndCustomerIdAndAccountIdAndLoanId(String apiName, Long customerId, String accountId, String loanId);

	@Query("SELECT a FROM APIStatus a WHERE a.id=(SELECT max(a.id) FROM APIStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS')")
	APIStatus findByAccountIdAndApiName(String accountId,String apiName);

	@Query("SELECT a FROM APIStatus a WHERE a.id=(SELECT max(a.id) FROM APIStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' and a.customerId= :customerId and a.loanId= :loanId)")
	APIStatus findByAccountIdAndApiNameAndCustomerIdAndLoanId(String accountId,String apiName,Long customerId,String loanId);

}
