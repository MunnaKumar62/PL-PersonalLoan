package com.abc.pl.loan.generation.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Errors {

	 private String code;
	 private String errorType;
	 private String description;
	 
	 

}
