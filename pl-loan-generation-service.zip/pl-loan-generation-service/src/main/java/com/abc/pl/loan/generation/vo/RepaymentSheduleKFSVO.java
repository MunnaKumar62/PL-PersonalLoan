package com.abc.pl.loan.generation.vo;

import java.util.List;

import com.abc.pl.loan.generation.response.RepaymentInstallmentsResponse;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RepaymentSheduleKFSVO {

	private int productCode;
	private String accountId;
	private LoanDetails loanDetails;
	private List<RepaymentInstallmentsResponse> installments;

}