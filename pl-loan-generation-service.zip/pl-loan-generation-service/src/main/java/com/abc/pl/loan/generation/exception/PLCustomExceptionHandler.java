package com.abc.pl.loan.generation.exception;

import java.util.List;

import org.hibernate.TypeMismatchException;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponseException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.abc.pl.loan.generation.common.constants.Constants;
import com.abc.pl.loan.generation.common.util.CommonUtil;
import com.abc.pl.loan.generation.common.util.MessageUtil;
import com.abc.pl.loan.generation.response.ErrorResponse;
import com.abc.pl.loan.generation.response.Response;
import com.abc.pl.loan.generation.response.ResponseStatusCode;
import com.abc.pl.loan.generation.response.ServiceProviderErrorResponse;

import io.micrometer.common.lang.Nullable;
import lombok.extern.log4j.Log4j2;

@RestControllerAdvice
@Log4j2
public class PLCustomExceptionHandler {
	
	@Autowired
	MessageUtil message;
	
	@Value("${api.service.code}")
	private String serviceCode;

	@Value("${external.errorcode.prefix}")
	private String externalErrorCodePrefix;

	@Value("${internal.errorcode.prefix}")
	private String internalErrorCodePrefix;

	@InitBinder
	private void activateDirectFieldAccess(DataBinder dataBinder) {
		dataBinder.initDirectFieldAccess();
	}

	@ExceptionHandler(Exception.class)
	public Response<Object> handleException1(Exception ex, WebRequest request) {
		return new Response<>(ex.getLocalizedMessage(), HttpStatus.BAD_REQUEST.value(),
				ResponseStatusCode.ERROR.getCode());
	}

	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public Response<Object> handleApplicationException(ApplicationException ex, WebRequest request) {
		return new Response<>(ex.getMessage(), ex.getStatusCode(), ex.getErrorCode());
	}

	@ExceptionHandler({ RedisServerException.class})
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public Response<Object> handlebadRequestException(ApplicationException ex, WebRequest request) {
		return new Response<>(ex.getMessage(), ex.getStatusCode(), ex.getErrorCode());
	}

	@ExceptionHandler(ServiceProviderException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ServiceProviderErrorResponse<Object> handlePANCheckException(ServiceProviderException ex, WebRequest request) {
		
		return new ServiceProviderErrorResponse(ex.getMessage(), ex.getCode(), ex.getDescription(), ex.getErrorType());
	}


	@ExceptionHandler(GcpStorageException.class)
	public Response<Object> hadleGcpStorageException(Exception ex, WebRequest request) {
		return new Response<>(ex.getLocalizedMessage(), HttpStatus.BAD_REQUEST.value(),
				ResponseStatusCode.ERROR.getCode());
	}
	
	@ExceptionHandler(CustomException.class)
	@Nullable
	public ResponseEntity<Object> customExceptionHandler(CustomException ex) {
		HttpHeaders headers = new HttpHeaders();
		WebRequest request = null;
		ErrorResponse errorResponse = CommonUtil.getCustomErrorResponse(ex, headers, HttpStatus.PARTIAL_CONTENT, request);
		return new ResponseEntity<>(errorResponse, headers, HttpStatus.PARTIAL_CONTENT);
	}

	@ExceptionHandler({ HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class,
			HttpMediaTypeNotAcceptableException.class, MissingPathVariableException.class,
			MissingServletRequestParameterException.class, MissingServletRequestPartException.class,
			ServletRequestBindingException.class, MethodArgumentNotValidException.class, NoHandlerFoundException.class,
			AsyncRequestTimeoutException.class, ErrorResponseException.class, ConversionNotSupportedException.class,
			TypeMismatchException.class, HttpMessageNotReadableException.class, HttpMessageNotWritableException.class,
			BindException.class })
	@Nullable
	public final ResponseEntity<Object> handleException(Exception ex, WebRequest request) throws Exception {
		if (ex instanceof HttpRequestMethodNotSupportedException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());
		} else if (ex instanceof HttpMediaTypeNotSupportedException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof HttpMediaTypeNotAcceptableException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MissingPathVariableException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MissingServletRequestParameterException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MissingServletRequestPartException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof ServletRequestBindingException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MethodArgumentNotValidException subEx) {
		
			BindingResult result = subEx.getBindingResult();
			List<FieldError> fieldErrors = result.getFieldErrors();
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(fieldErrors, subEx.getHeaders(),
					subEx.getStatusCode(), request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof NoHandlerFoundException subEx) {

			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getStatusCode());

		} else if (ex instanceof AsyncRequestTimeoutException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getStatusCode());

		} else if (ex instanceof ErrorResponseException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		}

		// Lower level exceptions, and exceptions used symmetrically on client and
		// server
		HttpHeaders headers = new HttpHeaders();
		if (ex instanceof ConversionNotSupportedException theEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.INTERNAL_SERVER_ERROR,
					request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (ex instanceof TypeMismatchException theEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_GATEWAY, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);
		} else if (ex instanceof HttpMessageNotReadableException theEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_REQUEST, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);
		} else if (ex instanceof HttpMessageNotWritableException theEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.INTERNAL_SERVER_ERROR,
					request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (ex instanceof BindException theEx) {

			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_REQUEST, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);

		} else {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_REQUEST, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);

		}
	}
	
	@ResponseStatus(HttpStatus.PARTIAL_CONTENT)
	@ExceptionHandler(ExternalException.class)
	public @ResponseBody ExceptionResponse handleExternalException(ExternalException ex) {
	    String errorCode = serviceCode + "-" + externalErrorCodePrefix + "-" + ex.getCode();
	    String errorMessage = ex.getErrorMessage();
	    return ExceptionResponse.builder().code(ex.getCode()).reason(ex.getReason()).errorCode(errorCode)
	          .errorMessage(errorMessage).message(errorCode + ": " + errorMessage).errorType(Constants.ERROR_TYPE_TECHNICAL).build();
	}

	@ResponseStatus(HttpStatus.PARTIAL_CONTENT)
	@ExceptionHandler(InternalException.class)
	public @ResponseBody ExceptionResponse handleInternalException(InternalException ex) {
		String errorCode = serviceCode + "-" + internalErrorCodePrefix + "-" + ex.getErrorCode();
		String errorMessage = message.getMessage(ex.getErrorCode())+" "+ex.getErrorMessage();
		log.info(errorMessage);
		String errorType;
		String[] errorMessageParts = errorMessage.split("-");
		if (errorMessageParts.length > 1) {
			errorType = errorMessageParts[0].equalsIgnoreCase("BE") ? Constants.ERROR_TYPE_BUSINESS : Constants.ERROR_TYPE_TECHNICAL;
			errorMessage = errorMessageParts[1];
		} else {
			errorType = Constants.ERROR_TYPE_TECHNICAL;
		}
		log.info(errorMessageParts[0]);
		String fullErrorMessage = errorCode + ": " + errorMessage;
		return ExceptionResponse.builder().code(null!=ex.getCode()?ex.getCode():500).reason(null!=ex.getReason()?ex.getReason():errorMessage).errorCode(errorCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(errorType).build();
	}

}
