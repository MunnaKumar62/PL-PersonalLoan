package com.abc.pl.loan.generation.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.abc.pl.loan.generation.entity.CustomerDetails;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@ToString
@Getter
@Setter
@SuperBuilder
public class PLLoanDetailsDto implements Serializable{

	private String accountId;
	
	private String loanAmount;
	private String rateOfInterest;
	private String loanTenure;
	private String disbursalDate;
	private String firstEMIDate;
	
	//private String cccId;
	//private String accountId;
	//private String applicationId;
	
	@Builder.Default
	private String docName = "SanctionLetter";
	private String offerDate;
	private String emi;
	private String offerTime;
	
	private Double gst;
	private String processingFee;
	private String insuranceCharges;
	private String otherCharges;
	private String frequencyType;
	private String repaymentPeriod;
	
	private Float totalInterest;
	private Float sumOtherCharges;
	private Float sumBorrower;
	private Integer numberOfInstallments;
	private Float annualPercentageRate;
	private Float internalRateOfReturn;
}
