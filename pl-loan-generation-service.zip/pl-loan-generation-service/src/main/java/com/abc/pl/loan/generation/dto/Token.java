package com.abc.pl.loan.generation.dto;

import java.io.Serializable;

public class Token   implements Serializable{
	
	private String tokenId;
	
	private String accessToken;

	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public Token() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Token(String tokenId, String accessToken) {
		super();
		this.tokenId = tokenId;
		this.accessToken = accessToken;
	}
	
	

	 
}
