package com.abc.pl.loan.generation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@EnableJpaAuditing
@OpenAPIDefinition(servers={@Server(url="${swagger.default.server.url}", description="Default Server URL")}, info=@Info(title="PL Loan Generation Service"))
public class PlLoangenerationServiceApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PlLoangenerationServiceApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(PlLoangenerationServiceApplication.class, args);

	}

}
