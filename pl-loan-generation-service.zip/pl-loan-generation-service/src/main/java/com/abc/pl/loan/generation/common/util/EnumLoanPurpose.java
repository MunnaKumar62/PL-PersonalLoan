package com.abc.pl.loan.generation.common.util;

import java.util.Arrays;
import java.util.Optional;

public enum EnumLoanPurpose {

	PERSONAL_LOAN("Personal Use"), WEDDING_LOAN("Wedding Loan"), DREAM_VACATION_LOAN("Vacation Loan"), DEBT_CONSOLIDATION_LOAN("Purchase of consumer Durables"),
	MEDICAL_EMERGENCY_LOAN("Medical Emergency"), HOME_RENOVATION_LOAN("Home Renovation");

	private String val;

	EnumLoanPurpose(String value) {
		this.val = value;
	}

	public String getVal() {
		return val;
	}

	public static String getValue(String key) {
		if (null != key) {
			String[] arr = key.split(" ");
			if (arr.length == 1) {
				EnumLoanPurpose tmp = EnumLoanPurpose.valueOf(key);
				key = tmp.getVal();
			}
		}
		return key;
	}

	public static Optional<EnumLoanPurpose> getKeys(String val) {
		return Arrays.stream(EnumLoanPurpose.values()).filter(env -> env.val.equals(val)).findFirst();
	}

	public static String getKey(String value) {
		Optional<EnumLoanPurpose> tmp = EnumLoanPurpose.getKeys(value);
		return tmp.get().name();
	}
}
