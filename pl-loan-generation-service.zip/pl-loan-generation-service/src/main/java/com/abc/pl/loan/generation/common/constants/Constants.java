package com.abc.pl.loan.generation.common.constants;

public interface Constants {

	public static final String EMPTY = "";
	
	public static final String API = "/api";

	public static final String VERSION_ONE = "/v1";

	public static final String PL = "PL";
	
	public static final String PL_JOURNEY = "PL";
	
	public static final String API_STATUS = "/api-status";

	public static final String PERSONAL_LOAN = "/personal-loan";

	public static final String LOAN_DISBURSEMENT = "/loan-disbursement";

	public static final String DISBURSEMENT_STATUS = "/disbursement-status";
	
	public static final String BEGIN = " Begin";

	public static final String END = " End";
	
	public static final String TILDA = "~";


	public static final String SUCCESS = "success";

	public static final String ERROR = "error";
	
	public static final String DOB_FORMAT = "dd-MM-yyyy";
	
	public static final String CREATED_BY = "system";
	
	public static final String EXCEPTION = "[EXCEPTION]";
	
	public static final String PL_PAN_NAME_CHECK = "PL_PAN_NAME_CHECK";
	
	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy hh:mm:ss a";
	
	public static final String FILED_ACC_ID = "accountId";
	
	public static final String PL_DIGISIGN_DATA_POLLING = "DIGISIGN_DATA_POLLING";
	
	public static final String PL_DIGISIGN_DATA_CALLBACK = "DIGISIGN_DATA_CALLBACK";
	
	public static final String ERROR_TYPE_BUSINESS="Business Error";
	
	public static final String ERROR_TYPE_TECHNICAL="Technical Error";

	public static final String PRE_APPROVED_FLOW="pre_approved_flow";

	public static final String NEW_PROCESSING_FEE_DATE = "yyyy-MM-dd HH:mm:ss.SSSSSS";

	public static final String GRANTED = "GRANTED";
}
