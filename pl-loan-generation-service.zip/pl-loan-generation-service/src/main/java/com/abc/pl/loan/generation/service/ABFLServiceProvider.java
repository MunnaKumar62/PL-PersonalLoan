package com.abc.pl.loan.generation.service;

import com.abc.pl.loan.generation.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.abc.pl.loan.generation.manager.RestConnector;
import com.abc.pl.loan.generation.response.DigiSignBaseResponse;
import com.abc.pl.loan.generation.response.LoanAgreementGenerationBaseResponse;
import com.abc.pl.loan.generation.response.RepaymentScheduleBaseResponse;
import com.abc.pl.loan.generation.response.RepaymentScheduleKFSBaseResponse;
import com.abc.pl.loan.generation.response.SanctionLetterBaseResponse;
import com.abc.pl.loan.generation.response.TokenResponse;

@Service
public class ABFLServiceProvider {

	@Autowired
	private RestConnector restConnector;

	@Value("${abfl.repaymentschedule.url}")
	private String repaymentScheduleUrl;

	@Value("${abfl.sanctionletter.url}")
	private String sanctionLetterUrl;
	
	@Value("${abfl.repaymentScheduleKFS.url}")
	private String repaymentScheduleKFSUrl;

	@Value("${abfl.loanagreement.url}")
	private String loanAgreementUrl;

	@Value("${abfl.digisign.url}")
	private String digiSignUrl;
	
	@Value("${abfl.digisign.polling.url}")
	private String digiSignPollingUrl;


	public TokenResponse generateToken() {
		return null;
		// return restConnector.postForEntity(TokenResponse.class, baseUrl, new
		// HttpEntt);
	}
	
	/*public ResponseEntity<String> scheduleRepaymentEstimate(RepaymentScheduleEstimateVO scheduleEstimateVO, HttpHeaders headers)  {
		return restConnector.postForStringEntity(RepaymentScheduleBaseResponse.class, repaymentScheduleUrl,
				scheduleEstimateVO, headers);
	}*/
	
	public RepaymentScheduleBaseResponse scheduleRepaymentEstimate(RepaymentScheduleEstimateVO scheduleEstimateVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(RepaymentScheduleBaseResponse.class, repaymentScheduleUrl,
				scheduleEstimateVO, headers);
	}

	public SanctionLetterBaseResponse sanctionLetter(SanctionLetterPDFVO sanctionLetterVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(SanctionLetterBaseResponse.class, sanctionLetterUrl,
				sanctionLetterVO, headers);
	}

	public SanctionLetterBaseResponse sanctionLetterConsolidatePDF(SanctionLetterPDFBuilderVO sanctionLetterVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(SanctionLetterBaseResponse.class, sanctionLetterUrl,
				sanctionLetterVO, headers);
	}
	
	public ResponseEntity<String> sanctionLetterPDF(SanctionLetterPDFVO sanctionLetterVO, HttpHeaders headers)  {
		return restConnector.postForEntityJSON(SanctionLetterBaseResponse.class, sanctionLetterUrl,
				sanctionLetterVO, headers);
	}
	
	public RepaymentScheduleKFSBaseResponse scheduleRepaymentKFS(RepaymentSheduleKFSVO repaymentSheduleKFSVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(RepaymentScheduleKFSBaseResponse.class, repaymentScheduleKFSUrl,
				repaymentSheduleKFSVO, headers);
	}
	
	public ResponseEntity<String> scheduleRepaymentKFSJSON(RepaymentSheduleKFSVO repaymentSheduleKFSVO, HttpHeaders headers)  {
		return restConnector.postForEntityJSON(RepaymentScheduleKFSBaseResponse.class, repaymentScheduleKFSUrl,
				repaymentSheduleKFSVO, headers);
	}
	
	public ResponseEntity<String> scheduleRepaymentKFSPDF(RepaymentSheduleKFSVO repaymentSheduleKFSVO, HttpHeaders headers)  {
		return restConnector.postForEntityJSON(RepaymentScheduleKFSBaseResponse.class, repaymentScheduleKFSUrl,
				repaymentSheduleKFSVO, headers);
	}
	
	public LoanAgreementGenerationBaseResponse loanAgreement(LoanAgreementRequestBuilderVO loanAgreementVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(LoanAgreementGenerationBaseResponse.class, loanAgreementUrl,
				loanAgreementVO, headers);
	}

	public LoanAgreementGenerationBaseResponse loanAgreementConsolidate(LoanAgreementRequestVO loanAgreementVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(LoanAgreementGenerationBaseResponse.class, loanAgreementUrl,
				loanAgreementVO, headers);
	}
	
	public ResponseEntity<String> loanAgreementPDF(LoanAgreementRequestBuilderVO loanAgreementVO, HttpHeaders headers)  {
		return restConnector.postForEntityJSON(LoanAgreementGenerationBaseResponse.class, loanAgreementUrl,
				loanAgreementVO, headers);
	}	
	
	public DigiSignBaseResponse digitalSign(DigiSignRequestVO digiSignVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(DigiSignBaseResponse.class, digiSignUrl,
				digiSignVO, headers);
	}
	
	public DigiSignPollResposeVO digitalSignPolling(DigiSignPollRequestVO digiSignPollVO, HttpHeaders headers) throws Exception  {
		return restConnector.postForEntity(DigiSignPollResposeVO.class, digiSignPollingUrl,
				digiSignPollVO, headers);
	}

	
}
