package com.abc.pl.loan.generation.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.abc.pl.loan.generation.entity.CustomerDetails;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerDetails, String> {
	
	Optional<CustomerDetails> findByMobileNumber(String mobileNumber);
	
	Optional<CustomerDetails> findByAccountId(String accountId);
}
