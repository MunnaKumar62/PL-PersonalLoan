package com.abc.pl.loan.generation.response;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.abc.pl.loan.generation.entity.CustomerDetails;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@ToString
@Getter
@Setter
public class RePaymentScheduleKFSResponse {

	/*
	 * private Double loanAmount; private Double totalInterest; private Double
	 * sumOtherCharges; private Double sumBorrower; private String
	 * repaymentFrequency; private String frequencyType; private String
	 * tenoreOfLoan; private Integer numberOfInstallments; private Double emiAmount;
	 * private Double annualPercentageRate; private Double internalRateOfReturn;
	 */

	@JsonProperty("KFS_PDF")
	private String kfsPDF;

}
