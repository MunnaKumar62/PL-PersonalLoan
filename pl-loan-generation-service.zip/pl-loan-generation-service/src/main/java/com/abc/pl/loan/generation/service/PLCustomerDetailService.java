package com.abc.pl.loan.generation.service;

import com.abc.pl.loan.generation.dto.PLCustomerDetailDto;
import com.abc.pl.loan.generation.entity.PLCustomerDetail;

public interface PLCustomerDetailService {

	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto plCustomerDetailDto, String serviceName);
	
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail, String serviceName);
	
	public PLCustomerDetail findByAccountIdAndActive(String accountId, Boolean active);

	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdAndActive(String accountId, String loanId, Long customerId, Boolean active);
}
