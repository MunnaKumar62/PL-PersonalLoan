package com.abc.pl.loan.generation.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@Builder
@ToString
public class LoanAgreementRequestBuilderVO {

	private String applicationId;
	private String email;
	private String firstName;
	private String lastName;
	private String pan;
	private String mobileNumber;
	private String dob;
	private String loanAmount;
	private String emi;
	private String tenure;
	private String roi;
	private String address;
	private String city;
	private String pincode;
	private String processingFee;
	private Long customerId;
	private String loanId;

}
