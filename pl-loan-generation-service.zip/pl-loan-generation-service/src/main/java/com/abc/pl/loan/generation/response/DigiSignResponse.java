package com.abc.pl.loan.generation.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class DigiSignResponse {
	
	private String accountId;
	
	private DigiSuccessMessage success_message;
    
    private String pdf_request_type;

}
