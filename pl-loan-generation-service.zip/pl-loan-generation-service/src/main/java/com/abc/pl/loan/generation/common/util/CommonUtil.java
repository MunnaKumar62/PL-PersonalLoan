package com.abc.pl.loan.generation.common.util;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.context.request.WebRequest;

import com.abc.pl.loan.generation.common.constants.Constants;
import com.abc.pl.loan.generation.common.model.Errors;
import com.abc.pl.loan.generation.common.model.SuccessResponse;
import com.abc.pl.loan.generation.exception.CustomException;
import com.abc.pl.loan.generation.response.ErrorResponse;

@Component
public class CommonUtil {

	@Value("${spring.application.name}")
	private static String applicationName;

	public static SuccessResponse getSuccessResponse(String code, String message, Object data) {

		SuccessResponse successResponse = new SuccessResponse();
		successResponse.setTimestamp(LocalDateTime.now()+"");
		successResponse.setStatus(Constants.SUCCESS);
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}

	public static ErrorResponse getCustomErrorResponse(CustomException ex, HttpHeaders headers, HttpStatusCode status,
			WebRequest request) {
		
		List<Errors> errorList = new ArrayList<>();
		Errors errors = new Errors();
		if(ex.getDescription()!=null) {
			if(ex.getDescription().equalsIgnoreCase("401 Unauthorized: [no body]")) {
				errors.setMessage("User not authenticated");
			}else if(ex.getDescription().equalsIgnoreCase("'ccc_request_id'")){
				errors.setMessage("Something went wrong, Please try after sometime");
			}else {
				errors.setMessage(ex.getDescription());
			}
			errors.setErrorCode(ex.getErrorCode());
		}
		else {
			errors.setMessage("Data sent in request is not correct");
			errors.setErrorCode("BAD_REQUEST");
		}
		
		errors.setErrorType(ex.getErrorType());
		String path = request != null ? request.getContextPath() : "";
		ErrorResponse errorMessage = new ErrorResponse();
		errorMessage.setTimestamp(LocalDateTime.now());
		if(ex.getErrorType() != null) {
			if(ex.getErrorType().equalsIgnoreCase("INTERNAL_API_FAILED_TO_RESPOND")) {
				errorMessage.setStatus("This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			}else {
				errorMessage.setStatus("ERROR");
			}
		}else {
			errorMessage.setStatus("ERROR");
			errors.setErrorType("INVALID_PAYLOAD");
			//errorMessage.setMessage("Something went wrong, Please try after sometime");
			//errors.setMessage(ex.getMessage());
			//errors.setErrorType("Not Acceptable");
			//errors.setErrorCode("406");
		}
		
		errorList.add(errors);
		errorMessage.setPath(path);
		
		errorMessage.setErrors(errorList);
		return errorMessage;
	} 

	public static ErrorResponse getErrorResponse(Exception ex, HttpHeaders headers, HttpStatusCode status,
			WebRequest request) {
		List<Errors> errorsList = new ArrayList<>();
		String errorCode = Constants.PL + "4" + status.value();
		String message = ex.getMessage() != null ? ex.getMessage() : "";
		String path = request != null ? request.getContextPath() : "";
		getErrorList(errorCode, "", message, errorsList);
		return getErrorMessage(path, errorsList);
	}

	public static ErrorResponse getErrorResponse(List<FieldError> fieldErrors, HttpHeaders headers,
			HttpStatusCode status, WebRequest request) {
		List<Errors> errorList = new ArrayList<>();
		String errorCode = Constants.PL + "4" + status.value();
		String path = request != null ? request.getContextPath() : "";
		for (FieldError fieldError : fieldErrors) {
			getErrorList(errorCode, fieldError.getField(), fieldError.getDefaultMessage(), errorList);
		}
		return getErrorMessage(path, errorList);
	}

	public static ErrorResponse getErrorMessage(String path, List<Errors> errorList) {
		ErrorResponse errorMessage = new ErrorResponse();
		errorMessage.setTimestamp(LocalDateTime.now());
		errorMessage.setStatus(Constants.ERROR);
		errorMessage.setPath(path);
		errorMessage.setErrors(errorList);
		return errorMessage;
	}

	public static void getErrorList(String errorCode, String fieldName, String message, List<Errors> errorList) {
		Errors errors = new Errors(errorCode, fieldName, message,"");
		errorList.add(errors);
	}

	public static String removeSpecialCharactersByRegexPattern(String inputStr, String pattern){
		if(StringUtils.isNotEmpty(inputStr)) {
			String nonMatching = inputStr.replaceAll(pattern, "");
			for (int i = 0; i < nonMatching.length(); i++) {
				inputStr = inputStr.replace(String.valueOf(nonMatching.charAt(i)), "");
			}
		}
		return inputStr;
	}
	
	public static boolean isNullorBlank(String str) {
		return (null == str || str.isBlank());
	}

}
