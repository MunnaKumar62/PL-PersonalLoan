package com.abc.pl.loan.generation.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.pl.loan.generation.entity.CustomerDetails;
import com.abc.pl.loan.generation.repo.CustomerRepository;
import com.abc.pl.loan.generation.service.CustomerService;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepo;

	public Optional<CustomerDetails> findByMobileNumber(String mobileNumber) {
		Optional<CustomerDetails> response = customerRepo.findByMobileNumber(mobileNumber);
		return response;
	}

	@Override
	public Optional<CustomerDetails> findByAccountId(String accountId) {
		Optional<CustomerDetails> response = customerRepo.findByAccountId(accountId);
		return response;
	}

}
