package com.abc.pl.loan.generation.common.util;

import java.util.Objects;
import java.util.ResourceBundle;

import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j2;
@Log4j2
@Component
public class MessageUtil {

	private String defaultLocale = "en";
	private String defaultCountryCode ="IN";

	public String getMessage(String messageKey) {
		String messageValue = null;
		try {
			ResourceBundle bundle = ResourceBundle
					.getBundle("messages" + "_" + defaultLocale + "_" + defaultCountryCode);
			messageValue = bundle.getString(messageKey);
		} catch (Exception e) {
			log.error("getMessage: {}", e.getMessage());
		}
		return null != messageValue ? messageValue : messageKey;
	}

	public String getMessage(String messageKey, String locale, String countryCode) {
		String messageValue = null;
		locale = (Objects.nonNull(locale)) ? locale : defaultLocale;
		countryCode = (Objects.nonNull(countryCode)) ? countryCode : defaultCountryCode;
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("messages" + "_" + locale + "_" + countryCode);
			messageValue = bundle.getString(messageKey);
		} catch (Exception e) {
			log.error("getMessage: {}", e.getMessage());
		}
		return null != messageValue ? messageValue : messageKey;
	}
}
