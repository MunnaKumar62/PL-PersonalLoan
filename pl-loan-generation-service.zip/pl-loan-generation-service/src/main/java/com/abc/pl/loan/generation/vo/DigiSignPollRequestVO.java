package com.abc.pl.loan.generation.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class DigiSignPollRequestVO {

	@Builder.Default
	private String accountId="UPSELL000000470";
}
