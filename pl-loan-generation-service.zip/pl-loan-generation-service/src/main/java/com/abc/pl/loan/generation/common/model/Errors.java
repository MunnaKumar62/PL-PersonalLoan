package com.abc.pl.loan.generation.common.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class Errors {

	private String errorCode;	
	private String fieldName;
	private String message;
	private String errorType;

}
