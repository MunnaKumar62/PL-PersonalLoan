package com.abc.pl.loan.generation.repo;

import java.util.List;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.abc.pl.loan.generation.dto.Token;



@Repository
public class RedisTokenRepository {

	private HashOperations hashOperations;

	private RedisTemplate redisTemplate;

	public RedisTokenRepository(RedisTemplate redisTemplate) {
		this.redisTemplate = redisTemplate;
		this.hashOperations = this.redisTemplate.opsForHash();
	}

	public void save(Token token) {
		hashOperations.put("Token", token.getTokenId(), token);

	}

	public List findAll() {
		return hashOperations.values("Token");
	}

	public Token findByTokenId(String tokenId) {
		return (Token) hashOperations.get("Token", tokenId);
	}

	public void update(Token token) {
		save(token);
	}

}
