package com.abc.pl.loan.generation.dto;


import java.io.Serializable;

import com.abc.pl.loan.generation.entity.LoanOfferDetails;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@ToString
@Getter
@Setter
@SuperBuilder
public class PLCustomerDto{

    private String id;
    private String accountId;
    private String transactionId;
    private String applicationId;
    private String cccId;
    private String mobileNumber;
    private String firstname;
    private String lastname;
    private String middlename;
    private String dateofbirth;
    private String loantype;
    private String pannumber;
    private String aadhaarnumber;
    private String email;
    private String gender;
    private Boolean panCheckFlag;
    private Address address;    
    private PLLoanDetailsDto loanDetails;
 
    
}
