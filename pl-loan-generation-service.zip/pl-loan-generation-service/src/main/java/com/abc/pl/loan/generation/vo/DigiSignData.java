package com.abc.pl.loan.generation.vo;

import com.google.auto.value.AutoValue.Builder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DigiSignData {

	private String status;
	private String shortUrl;
	private String accountId;
}
