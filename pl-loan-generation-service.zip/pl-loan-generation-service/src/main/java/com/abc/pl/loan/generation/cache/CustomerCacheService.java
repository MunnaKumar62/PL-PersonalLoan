package com.abc.pl.loan.generation.cache;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.abc.pl.loan.generation.exception.CustomException;
import com.abc.pl.loan.generation.dto.PLCustomerDto;
import com.abc.pl.loan.generation.exception.ApplicationException;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class CustomerCacheService {

	private static final String CUSTOMER_CACHE = "PLCustomer";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper objectMapper;

	public PLCustomerDto getCustomerFromCache(String userId)  {
		PLCustomerDto plCusDto = null;
		log.info("Fetching Customer from Customer Cache {} ", userId);
		try {
			String data = redisCacheProvider.getData(CUSTOMER_CACHE, userId);
			if (StringUtils.isNotBlank(data)) {
				plCusDto = objectMapper.readValue(data, PLCustomerDto.class);
			}
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
			throw new ApplicationException("Failed to get Customer with Given AccountID", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		return plCusDto;
	}
	
	/*public Optional <PLCustomerDto> getCustomerFromCache(String userId)  {
		PLCustomerDto plCusDto = null;
		log.info("Fetching Customer from Customer Cache {} ", userId);
		try {
			String data = redisCacheProvider.getData(CUSTOMER_CACHE, userId);
			if (StringUtils.isNotBlank(data)) {
				plCusDto = objectMapper.readValue(data, PLCustomerDto.class);
			}
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
			throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					"Failed to get Customer with Given AccountID",
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			
		}
		return Optional.ofNullable(plCusDto);
	}*/
	
	public void addUserToCache(PLCustomerDto customer) {
		log.info("Adding Customer To Customer Cache {} ", customer);
		try {
			 redisCacheProvider.addData(CUSTOMER_CACHE, customer.getAccountId(),objectMapper.writeValueAsString(customer));			
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
		}		
	}
	
	public void updateUserToCache(PLCustomerDto customer) {
		log.info("Updating Customer To Customer Cache {} ", customer);
		try {
			 redisCacheProvider.addData(CUSTOMER_CACHE, customer.getAccountId(),objectMapper.writeValueAsString(customer));			
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
		}		
	}

}
