package com.abc.pl.loan.generation.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoanAgreementGenerationResponse {

	@JsonProperty("LOAN_AGREEMENT")
	private String loanAgreementPdf;

}
