package com.abc.pl.loan.generation.exception;

public class CustomException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6411588775873452678L;

	private String errorType;
	private String errorCode;
	private String description;

	public CustomException() {
		super();
	}

	public CustomException(String message, Throwable cause) {
		super(message, cause);
	}

	public CustomException(String message) {
		super(message);
	}
	
	public CustomException(String errorCode,String description, String errorType) {
		//super(errorCode+description+errorType);
		this.errorCode = errorCode;
		this.description = description;
		this.errorType = errorType;
	}
	
	public CustomException(String errorCode,String message) {
		super(errorCode+message);
	}

	public CustomException(Throwable cause) {
		super(cause);
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	

}
