package com.abc.pl.loan.generation.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfig {

	  @Value("${spring.redis.host}")
	  private String redisHostName;

	  @Value("${spring.redis.port}")
	  private Integer redisPort;
	  
	  @Bean
	  public JedisConnectionFactory redisConnectionFactory() {
	    RedisStandaloneConfiguration redisStandaloneConfiguration =
	        new RedisStandaloneConfiguration(redisHostName, redisPort);
	    //redisStandaloneConfiguration.setPassword(RedisPassword.of(password));
	    JedisConnectionFactory jedisConnectionFactory =
	        new JedisConnectionFactory(redisStandaloneConfiguration);
	    jedisConnectionFactory.afterPropertiesSet();
	    return jedisConnectionFactory;
	  }

	  @Bean
	  public RedisTemplate<String, String> redisTemplate() {
	    RedisTemplate<String, String> redisTemplate = new RedisTemplate<>();
	    redisTemplate.setConnectionFactory(redisConnectionFactory());
	    redisTemplate.setKeySerializer(new StringRedisSerializer());
	    redisTemplate.setValueSerializer(new StringRedisSerializer());
	    redisTemplate.setHashKeySerializer(new StringRedisSerializer());
	    redisTemplate.setHashValueSerializer(new StringRedisSerializer());
	    redisTemplate.afterPropertiesSet();
	    return redisTemplate;
	  }
	  
}