package com.abc.pl.loan.generation.cache;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.abc.pl.loan.generation.dto.Token;
import com.abc.pl.loan.generation.exception.ApplicationException;
import com.abc.pl.loan.generation.response.ResponseStatusCode;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class TokenCacheService {

	private static final String TOKEN_CACHE = "Token";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper objectMapper;

	public Optional<Token> getTokenFromCache(String tokenId) {
		Token token = null;
		log.info("Fetching Token from  Cache {} ", tokenId);
		try {
			String data = redisCacheProvider.getData(TOKEN_CACHE, tokenId);
			if (StringUtils.isNotBlank(data)) {
				token = objectMapper.readValue(data, Token.class);
			}
		} catch (Exception e) {
			log.error("Failed to fetch User from User Cache", e);
			throw new ApplicationException(ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(), HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());		
		}
		return Optional.ofNullable(token);
	}
	
	public void addTokenToCache(Token token) {
		log.info("Fetching Token from  Cache {} ", token);
		try {
			 redisCacheProvider.addData(TOKEN_CACHE,token.getTokenId(),objectMapper.writeValueAsString(token));			
		} catch (Exception e) {			
			log.error("Failed to fetch Token from Token Cache", e);
			throw new ApplicationException("Failed to Add Token", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}		
	}
}
