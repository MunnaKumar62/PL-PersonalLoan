package com.abc.pl.loan.generation.repo;

import java.util.List;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.abc.pl.loan.generation.dto.PLCustomerDto;
import com.abc.pl.loan.generation.dto.PLLoanDetailsDto;




@Repository
public class RedisLoanOfferRepository {
	
	
 		private HashOperations hashOperations;

	    private RedisTemplate redisTemplate;

	    public RedisLoanOfferRepository(RedisTemplate redisTemplate){
	        this.redisTemplate = redisTemplate;
	        this.hashOperations = this.redisTemplate.opsForHash();
	    }
	    
	    public void save(PLLoanDetailsDto loanoffer){
	        hashOperations.put("PLLoanOffer", loanoffer.getAccountId(), loanoffer);	        
	    }
	    
	    public List findAll(){
	        return hashOperations.values("PLLoanOffer");
	    }

	    public PLLoanDetailsDto findByLoanId(String accountId){
	        return (PLLoanDetailsDto) hashOperations.get("PLLoanOffer", accountId);
	    }

	    public void update(PLLoanDetailsDto loanoffer){
	        save(loanoffer);
	    }
	    

}
