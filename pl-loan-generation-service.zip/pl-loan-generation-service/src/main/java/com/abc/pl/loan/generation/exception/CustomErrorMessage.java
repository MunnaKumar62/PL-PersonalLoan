package com.abc.pl.loan.generation.exception;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
@RequiredArgsConstructor
public class CustomErrorMessage {
	
	//private HttpStatus httpStatus;
   // private String responseStatus;
    //private List<String> errors;
    
    private String responseStatus;
	private String message;
	private int statusCode;
	private String errorCode;

	public CustomErrorMessage(String responseStatus, String message, int statusCode, String errorCode){
		this.responseStatus = responseStatus;
		this.message = message;
		this.statusCode = statusCode;
		this.errorCode = errorCode;
	}

	/*
	 * public CustomErrorMessage(HttpStatus status, String responseStatus,
	 * List<String> errors) { super(); this.status = status; this.responseStatus =
	 * responseStatus; this.errors = errors; }
	 */

	/*
	 * public CustomErrorMessage(HttpStatus status, String responseStatus, String
	 * error) { super(); this.status = status; this.message = responseStatus; errors
	 * = Arrays.asList(error); }
	 */

}
