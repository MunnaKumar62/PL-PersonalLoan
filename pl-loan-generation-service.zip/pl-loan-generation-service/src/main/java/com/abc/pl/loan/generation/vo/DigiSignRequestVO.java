package com.abc.pl.loan.generation.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DigiSignRequestVO {

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("mobile_number")
    private String mobile_number ="";

    @JsonProperty("email")
    private String email;

    @JsonProperty("merged_pdf_flag")
    private boolean merged_pdf_flag = false;

    @JsonProperty("sanction_letter")
    private String sanctionLetter;

    @JsonProperty("loan_agreement")
    private String loanAgreement;

    @JsonProperty("key_fact_statement")
    private String keyFactStatement;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("docusign_consent")
    private String docusignConsent;
}