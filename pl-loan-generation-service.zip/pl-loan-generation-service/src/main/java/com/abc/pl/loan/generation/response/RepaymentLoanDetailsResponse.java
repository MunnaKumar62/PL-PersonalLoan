package com.abc.pl.loan.generation.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RepaymentLoanDetailsResponse {
	

	private String loanAmount;
	private String rateOfInterest;
	private String loanTenure;
	private String disbursalDate;
	private String firstEMIDate;

}
