package com.abc.pl.loan.generation.controller;

import com.abc.pl.loan.generation.exception.InternalException;
import org.springframework.http.MediaType;

import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.abc.pl.loan.generation.common.constants.Constants;
import com.abc.pl.loan.generation.entity.TransDetails;
import com.abc.pl.loan.generation.response.DigiSignBaseResponse;
import com.abc.pl.loan.generation.response.LoanAgreementGenerationBaseResponse;
import com.abc.pl.loan.generation.response.RepaymentScheduleBaseResponse;
import com.abc.pl.loan.generation.response.RepaymentScheduleKFSBaseResponse;
import com.abc.pl.loan.generation.response.SanctionLetterBaseResponse;
import com.abc.pl.loan.generation.serviceImpl.LoanGenerationServiceImpl;
import com.abc.pl.loan.generation.vo.DigiSignPollResposeVO;
import com.abc.pl.loan.generation.vo.DigiSignVO;
import com.abc.pl.loan.generation.vo.LoanAgreementRequestBuilderVO;
import com.abc.pl.loan.generation.vo.OtpVO;
import com.abc.pl.loan.generation.vo.PdfRequest;
import com.abc.pl.loan.generation.vo.RepaymentScheduleVO;
import com.abc.pl.loan.generation.vo.RepaymentSheduleKFSVO;
import com.abc.pl.loan.generation.vo.SanctionLetterPDFVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.log4j.Log4j2;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Log4j2
@RequestMapping("/oneabc/adityabirla/api/v1/personalloan")
public class LoanGenerationController {

	@Autowired
	private LoanGenerationServiceImpl loanGenerationService;
	
	@Operation(summary = "API to check the status.", description = "")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "The Home Loan API is running successfully!.."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@GetMapping(path = Constants.API_STATUS, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getAPIStatus() {
		return ResponseEntity.ok(LocalDateTime.now() + " ABC - The Personal Loan (Loan Generation) API is running successfully!..");
	}

	/**
	 * This API is giving the response of splitting installments of loan amount based on loan tenure by calling external api.
	 * @param repaymentScheduleVO contains loanAmount and loanTenure and rateOfInterest.
	 * @return response object contains the loanDetails and installments.
	 * @throws InternalException, ExternalException will throw if any server down or external api exception.
	 */
	@PostMapping("/repaymentScheduleEstimate")
	public ResponseEntity<RepaymentScheduleBaseResponse> getRepaymentScheduleEstimate(@RequestBody RepaymentScheduleVO repaymentScheduleVO) throws Exception {
		log.info("repaymentScheduleEstimate-start");
		return new ResponseEntity<>(loanGenerationService.repaymentScheduleEstimate(repaymentScheduleVO), HttpStatus.OK);
	}

	/**
	 * This API is used to get the sansaction pdf letter by calling external api.
	 * @param SanctionLetterPDFVO contains accountid, loanAmount, cccId, emi, pan, rateofinterest, email, name, tenure and
	 *                               other loan offer details.
	 * @return response object contains accountid,base64_pdf.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * sansaction letter pdf.
	 */
	@PostMapping("/sanctionLetterGenerator")
	public ResponseEntity<SanctionLetterBaseResponse> generateSanctionLetter(@RequestBody SanctionLetterPDFVO SanctionLetterPDFVO) throws Exception{
		log.info("sanctionLetterGenerator-start");
		return new ResponseEntity<> (loanGenerationService.sanctionLetterGenerator(SanctionLetterPDFVO), HttpStatus.OK);
	}

	/**
	 * This API is used to get the sansaction pdf letter by calling external api.
	 * @param SanctionLetterPDFVO contains accountid, loanAmount, cccId, emi, pan, rateofinterest, email, name, tenure and
	 *                               other loan offer details.
	 * @return response object contains accountid,base64_pdf.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * sansaction letter pdf.
	 */
	@PostMapping("/sanctionletterPDFGenerator")
	public ResponseEntity<byte[]> generateSanctionLetterPDF(@RequestBody PdfRequest SanctionLetterPDFVO) throws Exception {
		log.info("sanctionletterPDFGenerator-start");
		ResponseEntity<byte[]> response = loanGenerationService.generateSanctionLetterPDF(SanctionLetterPDFVO);
		return response;
	}

	/**
	 * This API is used to generate PDF file to get the details of loan details and installment details.
	 * @param repaymentSheduleKFSVO accountid, loanDetails, productCode, installments.
	 * @return Response object contains pdf encoded.
	 * @throws InternalException, ExternalException - If any Error in Repayment Schedule KFS or External API.
	 */
	@PostMapping("/repaymentScheduleKFS")
	public ResponseEntity<RepaymentScheduleKFSBaseResponse> repaymentScheduleKFS(@RequestBody RepaymentSheduleKFSVO repaymentSheduleKFSVO) throws Exception {
		log.info("repaymentScheduleKFS-start");
		return new ResponseEntity<> (loanGenerationService.repaymentScheduleKFS(repaymentSheduleKFSVO), HttpStatus.OK);
	}

	/**
	 * This API is used to generate PDF file to get the details of loan details and installment details.
	 * @param request accountid, loanDetails, cccId, firstName, lastName, customerId, mobileNumber, panNumber, email, dateOfBirth,
	 *                   loanType, address, city, pincode.
	 * @return Response object contains pdf encoded.
	 * @throws InternalException, ExternalException - If any Error in Repayment Schedule KFS or External API.
	 */
	@PostMapping("/repaymentScheduleKFS/pdf")
	public ResponseEntity<byte[]> repaymentScheduleKFSPDF(@RequestBody PdfRequest request) throws Exception {
		ResponseEntity<byte[]> response = loanGenerationService.repaymentScheduleKFSPDF(request);
		log.info("End of repaymentScheduleKFS method with response : "
					+ response.getBody());
		return response;
	}

	/**
	 * This API is used to combine the pdf letter of sansaction and loan agreement and repaymentScheduleKFS PDF.
	 * @param request accountid, loanDetails, cccId, firstName, lastName, customerId, mobileNumber, panNumber, email, dateOfBirth,
	 * 	                    loanType, address, city, pincode.
	 * @return Response object contains pdf encoded.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * 	 consolidate letter pdf.
	 */
	@PostMapping("/consolidatedPDF")
	public ResponseEntity<byte[]> generatePDF(@RequestBody PdfRequest request) throws Exception {
        log.info("***********consolidatedPDF-start************");
        ResponseEntity<byte[]> response = loanGenerationService.generateConcolidatedPDF(request);
        log.info("End of repaymentScheduleKFS method with response : "
					+ response.getBody());
        return response;
	}

	/**
	 * This API is used to get the loan agreement pdf letter by calling external api.
	 * @param loanAgreementVO dob, emi, pan, roi, city, email, tenure, address, pincode, lastName, firstName, loanAmount, mobileNumber
	 *                        applicationId, processingFee.
	 * @return Response object contains pdf encoded.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * 	 loan agreement letter pdf.
	 */
	@PostMapping("/loanAgreementGenerator")
	public ResponseEntity<LoanAgreementGenerationBaseResponse> generateLoanAgreement(@RequestBody LoanAgreementRequestBuilderVO loanAgreementVO) throws Exception {
		log.info("loanAgreementGenerator-start");
		return new ResponseEntity<> (loanGenerationService.generateLoanAgreement(loanAgreementVO), HttpStatus.OK);		
	}

	/**
	 * This API is used to get the loan agreement pdf letter by calling external api.
	 * @param loanAgreementVO dob, emi, pan, roi, city, email, tenure, address, pincode, lastName, firstName, loanAmount, mobileNumber
	 *                        applicationId, processingFee.
	 * @return Response object contains pdf encoded.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * 	 loan agreement letter pdf.
	 */
	@PostMapping("/loanAgreementPDFGenerator")
	public ResponseEntity<byte[]> generateLoanAgreementPDF(@RequestBody PdfRequest loanAgreementVO) throws Exception {
		log.info("loanAgreementPDFGenerator-start");
		ResponseEntity<byte[]> response = loanGenerationService.generateLoanAgreementPDF(loanAgreementVO);
		return response;
	}

	/**
	 * This API is used to get digiSign Verification of sansaction and loan agreement and key fact statment.
	 * @param digiSignVO accountId, mobile_number, email, merged_pdf_flag, sanctionLetter, loanAgreement, keyFactStatement, docusignConsent.
	 * @return Response object contains accountId, success_message, pdf_request_type, responseStatus.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * 	 digiSign Verification.
	 */
	@PostMapping("/digiSignRequest")
	public ResponseEntity<DigiSignBaseResponse> getDigitalSign(@RequestBody DigiSignVO digiSignVO) throws Exception {
		log.info("digiSignRequest-start");
		return new ResponseEntity<> (loanGenerationService.getDigitalSignRequest(digiSignVO), HttpStatus.OK);
	}

	/**
	 * This API is used to send or generate OTP.
	 * @param otpVO applicationId, emailId, mobileNumber, mode, otp.
	 * @return Return Success Validation message.
	 */
	@PostMapping("/sendOtp")
	public ResponseEntity<String> sendOtp(@RequestBody OtpVO otpVO) {
		log.info("sendOtp-start");
		ResponseEntity<String> response = loanGenerationService.sendOtp(otpVO);
		return response;
	}

	/**
	 * This API is used to verify OTP.
	 * @param otpVO applicationId, emailId, mobileNumber, mode, otp.
	 * @return Return Success Validation message.
	 */
	@PostMapping("/verifyOtp")
	public ResponseEntity<String> verifyOtp(@RequestBody OtpVO otpVO) {
		log.info("verifyOtp-start");
		ResponseEntity<String> response = loanGenerationService.verifyOtp(otpVO);
		return response;
	}

	/**
	 * This API method will call by external api to confirm DIGI SIGN polling is happened for that particular account id
	 * and insertion will happen in apistatus table for this callback api.
	 * @param digisignVO this request pojo object contains responseStatus, digiSignData, error.
	 * @return It will return response object, it is containing code and status and timestamp. Code is static value PL2206 and
	 * status is message like success.
	 */
	@PostMapping("/callback/digisign")
	public ResponseEntity<Object> saveDigiSignCallbackDetails(@RequestBody DigiSignPollResposeVO digisignVO) {
		log.info("callback/digisign-start");
		return loanGenerationService.saveDigiSignCallbackDetails(digisignVO);
	}

	/**
	 * This API is used to get the Polling Status of Digi Sign.
	 * @param customerId
	 * @param accountId
	 * @return Response object contains the data and responseStatus.
	 * @throws InternalException, ExternalException - It will throw any server unavailable or external api exception or error in
	 * 	 * 	 digiSign Verification.
	 */
	@GetMapping("/digisigndata/{customerId}/{accountId}/{loanId}")
	public DigiSignPollResposeVO getDigiSignData(@PathVariable Long customerId, @PathVariable String accountId, @PathVariable String loanId)
			throws Exception {
		log.info("digisigndata-start");
		return loanGenerationService.getDigiSignDataPolling(customerId, accountId, loanId);
	}

	/**
	 * This API is used to resume journey of customerId.
	 * @param customerId
	 * @return Response object contains the transition_id, journey_data, lob_id, customer_id.
	 * @throws Exception - If any error.
	 */
	@GetMapping(value = "/resumejourney/{customerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getDigiSignData(@PathVariable long customerId)
			throws Exception {
		log.info("digisigndata-start");
		TransDetails transDetails =  loanGenerationService.getResumeJourneyDtls(customerId);
		return new ResponseEntity(transDetails.getJourneyData(),HttpStatus.OK);
	}

	/**
	 * This API is used to save journey of use details into t_transition_state table.
	 * @param journeyData request object contains the journeyId, journeyType and other details.
	 * @return It returns a response message saved successfully.
	 * @throws Exception - If any ApplicationException it will throw the exception.
	 */
	@PostMapping("/savejourney")
	public ResponseEntity<?> getDigiSignData(@RequestBody String journeyData)
			throws Exception {
		log.info("digisigndata-start");
		return new ResponseEntity(loanGenerationService.saveJourneyData(journeyData), HttpStatus.OK);
	}
		
}
