package com.abc.pl.loan.generation.common.constants;

public interface MessageConstants {

	public static final String STATUS_CODE_200 = "200";
	public static final String STATUS_CODE_500 = "500";
	public static final String BAD_REQUEST_400 = "400";
	public static final String STATUS_CODE_404 = "404";
	public static final String API_CONDITION_STATUS_200 = " API is working Fine";
	public static final String API_STATUS_200 = " Your Request is Succeeded";
	public static final String API_STATUS_500 = "Service temporarily unavailable";
	public static final String API_STATUS_404 = "Unable to process your request";
	public static final String EMPTY_REQUEST = "Request Body can not be empty";
	public static final String EMPTY_FIELD = "Field can not be empty";
	public static final String EMPTY_PARAM = "Parameter can not be empty";
	public static final String CUST_NOT_FOUND = "Customer not found for ";
	public static final String DETAILS_NOT_FOUND = "Details Not Found";
	public static final String DETAILS_UPDATED = "Details Updated Successfully";

}
