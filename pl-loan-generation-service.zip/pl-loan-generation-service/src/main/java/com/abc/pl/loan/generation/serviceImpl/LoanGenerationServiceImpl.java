package com.abc.pl.loan.generation.serviceImpl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.abc.pl.loan.generation.vo.*;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.abc.pl.loan.generation.cache.CustomerCacheService;
import com.abc.pl.loan.generation.cache.LoanCacheService;
import com.abc.pl.loan.generation.cache.TokenCacheService;
import com.abc.pl.loan.generation.common.constants.Constants;
import com.abc.pl.loan.generation.common.constants.MessageConstants;
import com.abc.pl.loan.generation.common.util.CommonUtil;
import com.abc.pl.loan.generation.common.util.EnumLoanPurpose;
import com.abc.pl.loan.generation.common.util.ExceptionUtil;
import com.abc.pl.loan.generation.dto.PLCustomerDetailDto;
import com.abc.pl.loan.generation.dto.PLCustomerDto;
import com.abc.pl.loan.generation.dto.PLLoanDetailsDto;
import com.abc.pl.loan.generation.entity.APIStatus;
import com.abc.pl.loan.generation.entity.CustomerDetails;
import com.abc.pl.loan.generation.entity.LoanOfferDetails;
import com.abc.pl.loan.generation.entity.PLAddress;
import com.abc.pl.loan.generation.entity.TransDetails;
import com.abc.pl.loan.generation.exception.ApplicationException;
import com.abc.pl.loan.generation.exception.CustomException;
import com.abc.pl.loan.generation.exception.ExternalException;
import com.abc.pl.loan.generation.exception.InternalException;
import com.abc.pl.loan.generation.exception.LoanCustomException;
import com.abc.pl.loan.generation.exception.RedisServerException;
import com.abc.pl.loan.generation.exception.ServiceProviderException;
import com.abc.pl.loan.generation.repo.APIStatusRepository;
import com.abc.pl.loan.generation.repo.LoanOfferDetailsRepository;
import com.abc.pl.loan.generation.repo.RedisTokenRepository;
import com.abc.pl.loan.generation.repo.TransitionStateRepo;
import com.abc.pl.loan.generation.response.DigiSignBaseResponse;
import com.abc.pl.loan.generation.response.Error;
import com.abc.pl.loan.generation.response.LoanAgreementGenerationBaseResponse;
import com.abc.pl.loan.generation.response.LoanAgreementGenerationResponse;
import com.abc.pl.loan.generation.response.RePaymentScheduleKFSResponse;
import com.abc.pl.loan.generation.response.RepaymentLoanDetailsResponse;
import com.abc.pl.loan.generation.response.RepaymentScheduleBaseResponse;
import com.abc.pl.loan.generation.response.RepaymentScheduleKFSBaseResponse;
import com.abc.pl.loan.generation.response.ResponseStatusCode;
import com.abc.pl.loan.generation.response.SanctionLetterBaseResponse;
import com.abc.pl.loan.generation.response.SanctionLetterResponse;
import com.abc.pl.loan.generation.response.SendOTPBaseResponse;
import com.abc.pl.loan.generation.response.VerifyOTPBaseResponse;
import com.abc.pl.loan.generation.service.ABFLServiceProvider;
import com.abc.pl.loan.generation.service.CustomerService;
import com.abc.pl.loan.generation.service.PLCustomerDetailService;
import com.abc.pl.loan.generation.service.TokenService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class LoanGenerationServiceImpl implements Constants, MessageConstants{

	private final String className = "[" + this.getClass().getSimpleName() + "]";
	
	@Autowired
	private RepaymentScheduleKFSRequestService kfsRequestService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private CustomerService customerService;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private APIStatusRepository apiStatusRepository;

	// @Value("${abfl.token.url}")
	// private String tokenUrl;

	@Autowired
	private TransitionStateRepo transitionStateRepo;

	@Autowired
	private LoanOfferDetailsRepository loanOfferDetailsRepo;
	
	@Autowired
	private ExceptionUtil exceptionUtil;

	@Value("${abfl.digisign.url}")
	private String digiSignUrl;

	@Value("${abfl.loanagreement.url}")
	private String loanAgreementUrl;

	@Value("${abfl.loanagreement.pdf.url}")
	private String loanAgreementPdfUrl;

	@Value("${abfl.repaymentschedule.url}")
	private String repaymentScheduleUrl;

	@Value("${abfl.sanctionletter.url}")
	private String sanctionLetterUrl;

	@Value("${abfl.sanctionletter.pdf.url}")
	private String sanctionLetterPdfUrl;

	@Value("${abfl.repaymentScheduleKFS.url}")
	private String repaymentScheduleKFSUrl;

	@Value("${abfl.sendotp.url}")
	private String sendOtpUrl;

	@Value("${abfl.verifyotp.url}")
	private String verifyOtpUrl;

	@Value("${abfl.digisign.polling.url}")
	private String digiSignPollingUrl;

	@Autowired
	private Environment env;

	@Autowired
	private RedisTokenRepository tokenRepository;

	@Autowired
	private TokenCacheService tokenCacheService;

	@Autowired
	private CustomerCacheService customerCacheService;

	@Autowired
	private LoanCacheService loanCacheService;

	@Autowired
	private ABFLServiceProvider serviceProvider;

	@Autowired
	private APIStatusRepository apiStatusRepo;
	
	@Autowired
	PLCustomerDetailService plCustomerDetailService;

//@CircuitBreaker(name = "repaymentScheduleEstimate", fallbackMethod = "fallback_repaymentScheduleEstimate")
	public RepaymentScheduleBaseResponse repaymentScheduleEstimate(RepaymentScheduleVO repaymentScheduleVO)
			throws Exception {

		log.info(getClass().getCanonicalName() + " ::Inside repaymentScheduleEstimate method with request body : "
				+ repaymentScheduleVO);
		// ResponseEntity<String> response = null;
		PLCustomerDto customerDto = null;
		PLLoanDetailsDto loanDetailsDto = null;
		RepaymentScheduleBaseResponse scheduleResponse = null;
		try {

			HttpHeaders headers = getRequestHeaders();
			/*
			 * Token token = tokenCacheService.getTokenFromCache("1"); Optional<Token> token
			 * = tokenCacheService.getTokenFromCache("1"); if (token.isPresent()) {
			 * headers.add("auth-token", generateToken()); } else { throw new
			 * ApplicationException(ResponseStatusCode.TOKEN_NOT_AVAILABLE.getValue(),
			 * HttpStatus.INTERNAL_SERVER_ERROR.value(),
			 * HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()); }
			 */
			// headers.add("ABFL-AG-OAuth", "Bearer " + generateToken());
			// customerDto = customerCacheService.getCustomerFromCache("UPSELL000000470");
			// customerDto =
			// customerCacheService.getCustomerFromCache(repaymentScheduleVO.getAccountId());

			RepaymentScheduleEstimateVO scheduleEstimateVO = new RepaymentScheduleEstimateVO();
			scheduleEstimateVO.setLoanAmount(repaymentScheduleVO.getLoanAmount());
			scheduleEstimateVO.setLoanTenure(repaymentScheduleVO.getLoanTenure());
			scheduleEstimateVO.setRateOfInterest(repaymentScheduleVO.getRateOfInterest());

			HttpEntity entityHeader = new HttpEntity<>(scheduleEstimateVO, headers);

			scheduleResponse = serviceProvider.scheduleRepaymentEstimate(scheduleEstimateVO, headers);

			saveApiSuccessResponse("REPAYMENT_SCHEDULE_ESTIMATE", repaymentScheduleVO.getAccountId(),
					scheduleEstimateVO, scheduleResponse,repaymentScheduleVO.getCustomerId(),repaymentScheduleVO.getLoanId());
			if (Optional.ofNullable(scheduleResponse).isPresent()) {
				if (scheduleResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getCode(), scheduleResponse.getError().getErrorDesc());
				}
			}
			RepaymentLoanDetailsResponse loanData = scheduleResponse.getData().getLoanDetails();
			if (loanData != null && customerDto != null) {
				loanDetailsDto = customerDto.getLoanDetails();
				if (loanDetailsDto != null) {
					loanDetailsDto = PLLoanDetailsDto.builder().build();
					loanDetailsDto.setLoanAmount((String) loanData.getLoanAmount());
					loanDetailsDto.setRateOfInterest((String) loanData.getRateOfInterest());
					loanDetailsDto.setLoanTenure((String) loanData.getLoanTenure());
					loanDetailsDto.setDisbursalDate((String) loanData.getDisbursalDate());
					loanDetailsDto.setFirstEMIDate((String) loanData.getFirstEMIDate());
					loanCacheService.addLoanToCache(loanDetailsDto);
					customerDto.setLoanDetails(loanDetailsDto);
					// customerCacheService.updateUserToCache(customerDto);
				}
			}
			log.info(getClass().getCanonicalName() + " :: End of repaymentScheduleEstimate method : ");

		} catch (RedisServerException e) {

			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(), scheduleResponse.getError());
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2001", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2001", ex.getMessage());
		}

		return scheduleResponse;

	}
	public RepaymentScheduleBaseResponse fallback_repaymentScheduleEstimate(Throwable throwable) {
		// log.info("ABFL is down");
		RepaymentScheduleBaseResponse response = new RepaymentScheduleBaseResponse();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");

			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else {

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	// @CircuitBreaker(name = "sanctionLetterGenerator", fallbackMethod =
	// "fallback_sanctionLetterGenerator")
	public SanctionLetterBaseResponse sanctionLetterGenerator(SanctionLetterPDFVO sanctionLetterPDFVO)
			throws Exception {

		log.info(getClass().getCanonicalName() + " ::Inside generateSanctionLetterPDF method with request body : "
				+ sanctionLetterPDFVO);
		PLCustomerDto customerDto = null;
		PLLoanDetailsDto loanDetailsDto = null;
		SanctionLetterBaseResponse sanctionLetterResponse = null;
		try {
			customerDto = null;
			if (customerDto != null) {
				loanDetailsDto = customerDto.getLoanDetails();
				if (loanDetailsDto == null)
					loanDetailsDto = PLLoanDetailsDto.builder().build();
				loanDetailsDto.setOfferDate(sanctionLetterPDFVO.getOfferDate());
				loanDetailsDto.setEmi(sanctionLetterPDFVO.getEmi());
				loanDetailsDto.setOfferTime(sanctionLetterPDFVO.getOfferTime());
				customerDto.setLoanDetails(loanDetailsDto);
				customerCacheService.updateUserToCache(customerDto);
			}
			SanctionLetterPDFBuilderVO sanctionLetterPDFBuilderVO = new SanctionLetterPDFBuilderVO();
			sanctionLetterPDFBuilderVO.setOfferTime(sanctionLetterPDFVO.getOfferTime());
			sanctionLetterPDFBuilderVO.setCccId(sanctionLetterPDFVO.getCccId());
			sanctionLetterPDFBuilderVO.setEmi(sanctionLetterPDFVO.getEmi());
			sanctionLetterPDFBuilderVO.setAccountId(sanctionLetterPDFVO.getLoanId());
			sanctionLetterPDFBuilderVO.setEmail(sanctionLetterPDFVO.getEmail());
			sanctionLetterPDFBuilderVO.setLoanAmount(sanctionLetterPDFVO.getLoanAmount());
			sanctionLetterPDFBuilderVO.setName(sanctionLetterPDFVO.getName());
			sanctionLetterPDFBuilderVO.setOfferDate(sanctionLetterPDFVO.getOfferDate());
			sanctionLetterPDFBuilderVO.setPan(sanctionLetterPDFVO.getPan());
			sanctionLetterPDFBuilderVO.setRoi(sanctionLetterPDFVO.getRoi());
			sanctionLetterPDFBuilderVO.setTenure(sanctionLetterPDFVO.getTenure());
			sanctionLetterPDFBuilderVO.setDocName(sanctionLetterPDFVO.getDocName());
			sanctionLetterPDFBuilderVO.setDateOfBirth(sanctionLetterPDFVO.getDateOfBirth());

			HttpHeaders headers = getRequestHeaders();
			sanctionLetterResponse = serviceProvider.sanctionLetterConsolidatePDF(sanctionLetterPDFBuilderVO, headers);
			saveApiSuccessResponse("SANCTION_LETTER_PDF", sanctionLetterPDFVO.getAccountId(), sanctionLetterPDFBuilderVO,
					sanctionLetterResponse, sanctionLetterPDFVO.getCustomerId(), sanctionLetterPDFVO.getLoanId());
			if (Optional.ofNullable(sanctionLetterResponse).isPresent()) {
				if (sanctionLetterResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
							sanctionLetterResponse.getError());
				}
			}
			log.info(getClass().getCanonicalName() + " :: End of generateSanctionLetterPDF method : ");
		} catch (RedisServerException e) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
					sanctionLetterResponse.getError());
		} catch (ExternalException ex) {
			log.info("pl-Rest-connector-Exception=" + ex.getMessage());
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new InternalException("2000", e.getMessage());
		} catch (Exception ex) {
			log.info("pl-Rest-connector-Exception=" + ex.getMessage());
			throw new InternalException("2000", ex.getMessage());
		}
		return sanctionLetterResponse;
	}

	public SanctionLetterBaseResponse callExternalAPIForSansactionLetterPDF(SanctionLetterPDFVO sanctionLetterPDFVO, SanctionLetterPDFBuilderVO sanctionLetterPDFBuilderVO)
			throws Exception {

		log.info(getClass().getCanonicalName() + " ::Inside generateSanctionLetterPDF method with request body : "
				+ sanctionLetterPDFVO);
		PLCustomerDto customerDto = null;
		PLLoanDetailsDto loanDetailsDto = null;
		SanctionLetterBaseResponse sanctionLetterResponse = null;
		try {
			customerDto = null;
			if (customerDto != null) {
				loanDetailsDto = customerDto.getLoanDetails();
				if (loanDetailsDto == null)
					loanDetailsDto = PLLoanDetailsDto.builder().build();
				loanDetailsDto.setOfferDate(sanctionLetterPDFVO.getOfferDate());
				loanDetailsDto.setEmi(sanctionLetterPDFVO.getEmi());
				loanDetailsDto.setOfferTime(sanctionLetterPDFVO.getOfferTime());
				customerDto.setLoanDetails(loanDetailsDto);
				customerCacheService.updateUserToCache(customerDto);
			}

			HttpHeaders headers = getRequestHeaders();
			sanctionLetterResponse = serviceProvider.sanctionLetterConsolidatePDF(sanctionLetterPDFBuilderVO, headers);
			saveApiSuccessResponse("SANCTION_LETTER_PDF", sanctionLetterPDFVO.getAccountId(), sanctionLetterPDFBuilderVO,
					sanctionLetterResponse, sanctionLetterPDFVO.getCustomerId(), sanctionLetterPDFVO.getLoanId());
			if (Optional.ofNullable(sanctionLetterResponse).isPresent()) {
				if (sanctionLetterResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
							sanctionLetterResponse.getError());
				}
			}
			log.info(getClass().getCanonicalName() + " :: End of generateSanctionLetterPDF method : ");
		} catch (RedisServerException e) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
					sanctionLetterResponse.getError());
		} catch (ExternalException ex) {
			log.info("pl-Rest-connector-Exception=" + ex.getMessage());
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new InternalException("2000", e.getMessage());
		} catch (Exception ex) {
			log.info("pl-Rest-connector-Exception=" + ex.getMessage());
			throw new InternalException("2000", ex.getMessage());
		}
		return sanctionLetterResponse;
	}

	public SanctionLetterBaseResponse fallback_sanctionLetterGenerator(Throwable throwable) {
		// log.info("ABFL is down");
		SanctionLetterBaseResponse response = new SanctionLetterBaseResponse();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else {
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	public ResponseEntity<byte[]> generateConcolidatedPDF(PdfRequest pdfRequest) throws Exception {
		try {
			log.info(getClass().getCanonicalName() + " ::Inside generateConcolidatedPDF method with request body : "
					+ pdfRequest);
			byte[] sanct = generateSLPDF(pdfRequest);
			byte[] agree = generateLoanAgreePDF(pdfRequest);
			byte[] repay = repaymentScheKFSPDF(pdfRequest);

			PDFMergerUtility merger = new PDFMergerUtility();
			merger.addSource(new ByteArrayInputStream(agree));
			merger.addSource(new ByteArrayInputStream(sanct));
			merger.addSource(new ByteArrayInputStream(repay));

			// Step: Setting the destination file
			ByteArrayOutputStream pdfDocOutputstream = new ByteArrayOutputStream();
			merger.setDestinationFileName("ConsolidatedLetter.pdf");
			merger.setDestinationStream(pdfDocOutputstream);
			merger.mergeDocuments(MemoryUsageSetting.setupTempFileOnly());

			HttpHeaders responseHeaders = getResponseHeaders("ConsolidatedLetter.pdf");

			ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(pdfDocOutputstream.toByteArray(),
					responseHeaders, HttpStatus.OK);
			log.info(getClass().getCanonicalName() + " :: End of generateConcolidatedPDF method with response : "
					+ response.getBody());
			return response;
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2010",e.getErrorMessage());
		} catch (Exception ex) {
			throw new InternalException("2010", ex.getMessage());
		}
	}


	public byte[] repaymentScheKFSPDF(PdfRequest request) throws Exception {
		byte[] decoded = new byte[0];
		try {
			log.info(getClass().getCanonicalName() + " ::Inside repaymentScheduleKFSPDF method with request body : "
					+ request);
			RepaymentSheduleKFSVO repaymentSheduleKFSVO = kfsRequestService.setRepaymentSheduleKFSVO(request);
			RepaymentScheduleKFSBaseResponse kfsResponse = repaymentScheduleKFS(repaymentSheduleKFSVO);

			saveApiSuccessResponse("KEY_FACT_STATEMENT_PDF", request.getAccountId(), repaymentSheduleKFSVO,
					kfsResponse,request.getCustomerId(),request.getLoanId());

			RePaymentScheduleKFSResponse kfsData = kfsResponse.getData();
			String encryptedData = null;
			if (kfsData != null) {
				encryptedData = kfsData.getKfsPDF();
				if (encryptedData != null) {
					decoded = java.util.Base64.getDecoder().decode(encryptedData);
				}
			}
			return decoded;

		} catch (HttpClientErrorException he) {
			String description = he.getMessage() + he.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.error("pl-Rest-connector-HttpStatusCodeException=" + he.getResponseBodyAsString());
			saveApiErrorResponse("KEY_FACT_STATEMENT_PDF", request.getAccountId(), request,
					he.getResponseBodyAsString(),request.getCustomerId(),request.getLoanId());
			log.info("request.getAccountId()::" + request.getAccountId() + "::" + request + "::"
					+ he.getResponseBodyAsString());

			if (null != he.getResponseBodyAsString() && !he.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(he.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=" + he.getResponseBodyAsString());
			exceptionUtil.handleHttpClientError(he, "KEY_FACT_STATEMENT_PDF");
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2009", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2009", ex.getMessage());
		}
		return decoded;

	}

	public byte[] generateLoanAgreePDF(PdfRequest loanAgreementVO) throws Exception {
		log.info(getClass().getCanonicalName() + " ::Inside of generateLoanAgreementPDF method with request body : "
				+ loanAgreementVO);
		LoanAgreementRequestBuilderVO requestObject = null;
		LoanAgreementGenerationBaseResponse loanAgreementResponse = null;
		byte[] decoded = new byte[0];
		LoanAgreementRequestVO loanAgreementRequestVO = new LoanAgreementRequestVO();
		try {
			requestObject = getLoanAgreementLetterRequest(loanAgreementVO);
			log.info("generateLoanAgreementPDF-requestObject=" + requestObject);
			loanAgreementRequestVO.setCity(requestObject.getCity());
			loanAgreementRequestVO.setAddress(requestObject.getAddress());
			loanAgreementRequestVO.setDob(requestObject.getDob());
			loanAgreementRequestVO.setEmi(requestObject.getEmi());
			loanAgreementRequestVO.setEmail(requestObject.getEmail());
			loanAgreementRequestVO.setPan(requestObject.getPan());
			loanAgreementRequestVO.setLoanAmount(requestObject.getLoanAmount());
			loanAgreementRequestVO.setRoi(requestObject.getRoi());
			loanAgreementRequestVO.setFirstName(requestObject.getFirstName());
			loanAgreementRequestVO.setPincode(requestObject.getPincode());
			loanAgreementRequestVO.setApplicationId(requestObject.getLoanId());
			loanAgreementRequestVO.setTenure(requestObject.getTenure());
			loanAgreementRequestVO.setLastName(requestObject.getLastName());
			loanAgreementRequestVO.setProcessingFee(requestObject.getProcessingFee());
			loanAgreementRequestVO.setMobileNumber(requestObject.getMobileNumber());
			loanAgreementResponse = externalAPICallForLoanAgreementPDF(requestObject, loanAgreementRequestVO);
			saveApiSuccessResponse("LOAN_AGREEMENT_PDF", requestObject.getApplicationId(), loanAgreementRequestVO,
					loanAgreementResponse,loanAgreementVO.getCustomerId(),loanAgreementVO.getLoanId());

			LoanAgreementGenerationResponse loanData = loanAgreementResponse.getData();
			String loanAgreementPdf = null;
			if (loanData != null) {
				loanAgreementPdf = loanData.getLoanAgreementPdf();
				if (loanAgreementPdf != null) {
					decoded = java.util.Base64.getDecoder().decode(loanAgreementPdf);
				}
			}
			return decoded;
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("LOAN_AGREEMENT_PDF", requestObject.getApplicationId(), loanAgreementRequestVO,
					loanAgreementResponse,loanAgreementVO.getCustomerId(),loanAgreementVO.getLoanId());
			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=" + ex.getResponseBodyAsString());
			exceptionUtil.handleHttpClientError(ex, "LOAN_AGREEMENT_PDF");
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2006", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2006", ex.getMessage());
		}
		return decoded;

	}


	public byte[] generateSLPDF(PdfRequest pdfRequest) throws Exception {
		byte[] decoded = new byte[0];
		SanctionLetterPDFBuilderVO sanctionLetterPDFBuilderVO = new SanctionLetterPDFBuilderVO();
		try {

			SanctionLetterPDFVO sanctionLetterPDFVO = getSanctionLetterRequest(pdfRequest);
			sanctionLetterPDFBuilderVO.setOfferTime(sanctionLetterPDFVO.getOfferTime());
			sanctionLetterPDFBuilderVO.setCccId(sanctionLetterPDFVO.getCccId());
			sanctionLetterPDFBuilderVO.setEmi(sanctionLetterPDFVO.getEmi());
			sanctionLetterPDFBuilderVO.setAccountId(sanctionLetterPDFVO.getLoanId());
			sanctionLetterPDFBuilderVO.setEmail(sanctionLetterPDFVO.getEmail());
			sanctionLetterPDFBuilderVO.setLoanAmount(sanctionLetterPDFVO.getLoanAmount());
			sanctionLetterPDFBuilderVO.setName(sanctionLetterPDFVO.getName());
			sanctionLetterPDFBuilderVO.setOfferDate(sanctionLetterPDFVO.getOfferDate());
			sanctionLetterPDFBuilderVO.setPan(sanctionLetterPDFVO.getPan());
			sanctionLetterPDFBuilderVO.setRoi(sanctionLetterPDFVO.getRoi());
			sanctionLetterPDFBuilderVO.setTenure(sanctionLetterPDFVO.getTenure());
			sanctionLetterPDFBuilderVO.setDocName(sanctionLetterPDFVO.getDocName());
			sanctionLetterPDFBuilderVO.setDateOfBirth(sanctionLetterPDFVO.getDateOfBirth());
			SanctionLetterBaseResponse sanctionLetterResponse = callExternalAPIForSansactionLetterPDF(sanctionLetterPDFVO, sanctionLetterPDFBuilderVO);
			saveApiSuccessResponse("SANCTION_LETTER_PDF", sanctionLetterPDFVO.getAccountId(), sanctionLetterPDFBuilderVO,
					sanctionLetterResponse,pdfRequest.getCustomerId(),pdfRequest.getLoanId());

			SanctionLetterResponse sanctionData = sanctionLetterResponse.getData();
			String sancationLetterPdf = null;
			if (sanctionData != null) {
				sancationLetterPdf = sanctionData.getSancationLetterPdf();
				if (sancationLetterPdf != null) {
					decoded = java.util.Base64.getDecoder().decode(sancationLetterPdf);
				}
			}
			return decoded;
		} catch (HttpStatusCodeException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";

			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("SANCTION_LETTER_PDF", pdfRequest.getAccountId(), sanctionLetterPDFBuilderVO,
					ex.getResponseBodyAsString(),pdfRequest.getCustomerId(),pdfRequest.getLoanId());

			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=");
			exceptionUtil.handleHttpClientError(ex, "SANCTION_LETTER_PDF");
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			log.error("error in sanction letter pdf " + e.getErrorMessage());
			throw new InternalException("2008", e.getErrorMessage());
		} catch (Exception ex) {
			throw new InternalException("2008", ex.getMessage());
		}
		return decoded;

	}


	// @CircuitBreaker(name = "generateSanctionLetterPDF", fallbackMethod =
	// "fallback_generateSanctionLetterPDF")
	public ResponseEntity<byte[]> generateSanctionLetterPDF(PdfRequest pdfRequest) throws Exception {
		SanctionLetterPDFBuilderVO sanctionLetterPDFBuilderVO = new SanctionLetterPDFBuilderVO();
		try {

			SanctionLetterPDFVO sanctionLetterPDFVO = getSanctionLetterRequest(pdfRequest);
			log.info("generateLoanAgreementPDF-request=" + sanctionLetterPDFVO);

			sanctionLetterPDFBuilderVO.setOfferTime(sanctionLetterPDFVO.getOfferTime());
			sanctionLetterPDFBuilderVO.setCccId(sanctionLetterPDFVO.getCccId());
			sanctionLetterPDFBuilderVO.setEmi(sanctionLetterPDFVO.getEmi());
			sanctionLetterPDFBuilderVO.setAccountId(sanctionLetterPDFVO.getLoanId());
			sanctionLetterPDFBuilderVO.setEmail(sanctionLetterPDFVO.getEmail());
			sanctionLetterPDFBuilderVO.setLoanAmount(sanctionLetterPDFVO.getLoanAmount());
			sanctionLetterPDFBuilderVO.setName(sanctionLetterPDFVO.getName());
			sanctionLetterPDFBuilderVO.setOfferDate(sanctionLetterPDFVO.getOfferDate());
			sanctionLetterPDFBuilderVO.setPan(sanctionLetterPDFVO.getPan());
			sanctionLetterPDFBuilderVO.setRoi(sanctionLetterPDFVO.getRoi());
			sanctionLetterPDFBuilderVO.setTenure(sanctionLetterPDFVO.getTenure());
			sanctionLetterPDFBuilderVO.setDocName(sanctionLetterPDFVO.getDocName());
			sanctionLetterPDFBuilderVO.setDateOfBirth(sanctionLetterPDFVO.getDateOfBirth());
			SanctionLetterBaseResponse sanctionLetterResponse = callExternalAPIForSansactionLetterPDF(sanctionLetterPDFVO, sanctionLetterPDFBuilderVO);
			//log.info("generateLoanAgreementPDF-sanctionLetterResponse=" + sanctionLetterResponse);
			saveApiSuccessResponse("SANCTION_LETTER_PDF", sanctionLetterPDFVO.getAccountId(), sanctionLetterPDFBuilderVO,
					sanctionLetterResponse,pdfRequest.getCustomerId(),pdfRequest.getLoanId());
			byte[] decoded = new byte[0];
			SanctionLetterResponse sanctionData = sanctionLetterResponse.getData();
			if (sanctionData != null) {
				String sancationLetterPdf = sanctionData.getSancationLetterPdf();
				if (sancationLetterPdf != null) {
					decoded = java.util.Base64.getDecoder().decode(sancationLetterPdf);
				}
			}
			HttpHeaders responseHeaders = getResponseHeaders("SanctionLetter.pdf");
			ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(decoded, responseHeaders, HttpStatus.OK);
			log.info(getClass().getCanonicalName() + " :: End of generateSanctionLetterPDF method with response : "
					+ response.getBody());
			return response;
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";

			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("SANCTION_LETTER_PDF", pdfRequest.getAccountId(), sanctionLetterPDFBuilderVO,
					ex.getResponseBodyAsString(),pdfRequest.getCustomerId(),pdfRequest.getLoanId());

			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=");
			exceptionUtil.handleHttpClientError(ex, "SANCTION_LETTER_PDF");
			//throw new CustomException(code, description, errorType);
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2008", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2008", ex.getMessage());
		}
		return null;
	}

	public SanctionLetterPDFVO getSanctionLetterRequest(PdfRequest createLoanRequest) {
		SanctionLetterPDFVO sanctionLetterRequest = null;
		try {
			Optional<CustomerDetails> customerDetails = customerService
					.findByMobileNumber(createLoanRequest.getMobileNumber());
			log.info("Flag>>>>>>");
			String accountId = null;
			String firstName = null;
			String lastName=null, panNumber = null;
			Double loanAmount = 0.00;
			Double emiAmount = 0.00;
			Double rateOfInterest = 0.00;
			Integer tenure = 0;
			LocalDateTime offerDateTime = null;
			LocalDate offerDate = null;
			LocalTime offerTime = null;
			String emailAddress = null;
			if (customerDetails.isPresent()) {
				Optional<LoanOfferDetails> loanOfferDetails = loanOfferDetailsRepo
						.findByCustomerIdAndAccountIdAndLoanId(customerDetails.get().getCustomerId(), createLoanRequest.getAccountId(), createLoanRequest.getLoanId(), EnumLoanPurpose.getValue(createLoanRequest.getLoanType()));
				if (loanOfferDetails.isPresent()) {
					loanAmount = loanOfferDetails.get().getLoanAmount();
					tenure = loanOfferDetails.get().getTenure();
					rateOfInterest = loanOfferDetails.get().getRateOfInterest();
					emiAmount = loanOfferDetails.get().getMonthlyEmi();
					offerDateTime = loanOfferDetails.get().getOfferDate();
				}
				offerDate = offerDateTime != null ? offerDateTime.toLocalDate() : LocalDate.now();
				offerTime = offerDateTime != null ? offerDateTime.toLocalTime() : LocalTime.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
				String fromatedOfferTime = offerTime.format(formatter);
				log.info("offerDate=" + offerDate + "; offerTime=" + offerTime + "; fromatedOfferTime="
						+ fromatedOfferTime);
				if (createLoanRequest.getName() != null) {
					String[] arr = createLoanRequest.getName().split(" ");
					if(arr!=null&&arr.length>1) {
					lastName = arr[arr.length - 1];
					firstName = createLoanRequest.getName().replace(lastName, " ").trim();
					}
				}
				accountId = !isEmptyOrNull(createLoanRequest.getAccountId()) ? createLoanRequest.getAccountId()
						: customerDetails.get().getAccountId();
				firstName = !isEmptyOrNull(firstName) ? firstName : customerDetails.get().getFirstName();
				lastName = !isEmptyOrNull(lastName) ? lastName : customerDetails.get().getLastName();
				emailAddress = !isEmptyOrNull(createLoanRequest.getEmail()) ? createLoanRequest.getEmail()
						: customerDetails.get().getEmailAddress();
				LocalDate dateOfBirth = createLoanRequest.getDateOfBirth() != null ? createLoanRequest.getDateOfBirth()
						: customerDetails.get().getDateOfBirth();
				panNumber = !isEmptyOrNull(createLoanRequest.getPanNumber()) ? createLoanRequest.getPanNumber()
						: customerDetails.get().getPanNumber();
				loanAmount = loanAmount != null ? loanAmount : 0.00;
				emiAmount = emiAmount != null ? emiAmount : 0.00;
				tenure = tenure != null ? tenure : 0;
				rateOfInterest = rateOfInterest != null ? rateOfInterest : 0.00;

				sanctionLetterRequest = SanctionLetterPDFVO.builder().cccId(createLoanRequest.getCccId())
						.accountId(accountId).roi(rateOfInterest + "").emi(emiAmount + "").pan(panNumber)
						.email(emailAddress).docName("SanctionLetter").dateOfBirth(dateOfBirth + "")
						.loanAmount(loanAmount + "").name(firstName + lastName).offerDate(offerDate + "")
						.offerTime(fromatedOfferTime).tenure(tenure + "").loanId(createLoanRequest.getLoanId())
						.customerId(createLoanRequest.getCustomerId()).build();
				log.info("sanctionLetterRequest=" + sanctionLetterRequest);
			}
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2007", e.getMessage());
		} catch (Exception ex) {
			log.error("error in sanction letter"+ex.getMessage());
			throw new InternalException("2007", ex.getMessage());
		}
		return sanctionLetterRequest;
	}

	public ResponseEntity<byte[]> fallback_generateSanctionLetterPDF(Throwable throwable) {

		HttpHeaders responseHeaders = new HttpHeaders();
		String filename = "LoanAgreement.pdf";
		responseHeaders.setContentType(MediaType.parseMediaType("application/pdf"));
		responseHeaders.add("content-disposition", "inline;filename=" + filename);
		responseHeaders.setContentDispositionFormData(filename, filename);
		responseHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		String str = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";
		byte[] decoded = new byte[0];
		decoded = java.util.Base64.getDecoder().decode(str);
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(decoded, responseHeaders,
				HttpStatus.INTERNAL_SERVER_ERROR);
		return response;
	}

	// @CircuitBreaker(name = "repaymentScheduleKFS", fallbackMethod =
	// "fallback_repaymentScheduleKFS")
	public RepaymentScheduleKFSBaseResponse repaymentScheduleKFS(RepaymentSheduleKFSVO repaymentSheduleKFSVO)
			throws Exception {

		log.info(getClass().getCanonicalName() + " :: Inside repaymentScheduleKFS method with request : "
				+ repaymentSheduleKFSVO.toString());
		ResponseEntity<String> response = null;
		PLCustomerDto customerDto = null;
		PLLoanDetailsDto loanDetailsDto = null;
		RepaymentScheduleKFSBaseResponse kfsResponse = null;
		try {
			// customerDto =
			// customerCacheService.getCustomerFromCache(repaymentSheduleKFSVO.getAccountId());
			customerDto = null;
			LoanDetails loanData = repaymentSheduleKFSVO.getLoanDetails();
			if (loanData != null && customerDto != null) {
				loanDetailsDto = customerDto.getLoanDetails();
				if (loanDetailsDto == null)
					loanDetailsDto = PLLoanDetailsDto.builder().build();
				loanDetailsDto.setGst(loanData.getPf_with_gst());
				Map<String, Charge> charges = loanData.getCharges();
				Charge charge1 = charges.get("dynamic_charge_1");
				loanDetailsDto.setProcessingFee(charge1.getValue());
				Charge charge2 = charges.get("dynamic_charge_2");
				loanDetailsDto.setInsuranceCharges(charge2.getValue());
				Charge charge3 = charges.get("dynamic_charge_3");
				loanDetailsDto.setOtherCharges(charge3.getValue());
				loanDetailsDto.setFrequencyType(loanData.getFrequency_type());
				loanDetailsDto.setRepaymentPeriod(loanData.getNumber_of_repayment_period());
				customerDto.setLoanDetails(loanDetailsDto);
				customerCacheService.updateUserToCache(customerDto);
			}
			HttpHeaders headers = getRequestHeaders();
			// Optional<Token> token = tokenCacheService.getTokenFromCache("1");

			// HttpEntity entityHeader = new HttpEntity<>(repaymentSheduleKFSVO, headers);
			log.info("repaymentScheduleKFS-request=" + objectMapper.writeValueAsString(repaymentSheduleKFSVO));
			kfsResponse = serviceProvider.scheduleRepaymentKFS(repaymentSheduleKFSVO, headers);
			// log.info("repaymentScheduleKFS-kfsResponse="+objectMapper.writeValueAsString(kfsResponse));

			if (Optional.ofNullable(kfsResponse).isPresent()) {
				if (kfsResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
							kfsResponse.getError());
				}
			}
			RePaymentScheduleKFSResponse kfsData = kfsResponse.getData();
			if (kfsData != null && customerDto != null) {
				/*
				 * loanDetailsDto.setTotalInterest((Double) kfsData.getTotalInterest());
				 * loanDetailsDto.setSumOtherCharges((Double) kfsData.getSumOtherCharges());
				 * loanDetailsDto.setSumBorrower((Double) kfsData.getSumBorrower());
				 * loanDetailsDto.setNumberOfInstallments((Integer)
				 * kfsData.getNumberOfInstallments());
				 * loanDetailsDto.setAnnualPercentageRate((Double)
				 * kfsData.getAnnualPercentageRate()); //
				 * loanDetailsDto.setInternalRateOfReturn((Float)
				 * kfsData.getInternalRateOfReturn());
				 * customerDto.setLoanDetails(loanDetailsDto);
				 */
				customerCacheService.updateUserToCache(customerDto);
			}
			log.info(getClass().getCanonicalName() + " :: End of repaymentScheduleKFS method with response : ");
		} catch (RedisServerException e) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(), kfsResponse.getError());
		}catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2002", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2002", ex.getMessage());
		}
		return kfsResponse;
	}

	public RepaymentScheduleKFSBaseResponse fallback_repaymentScheduleKFS(Throwable throwable) {
		// log.info("ABFL is down");
		RepaymentScheduleKFSBaseResponse response = new RepaymentScheduleKFSBaseResponse();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");

			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else {
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	// @CircuitBreaker(name = "repaymentScheduleKFSPDF", fallbackMethod =
	// "fallback_repaymentScheduleKFSPDF")
	public ResponseEntity<byte[]> repaymentScheduleKFSPDF(PdfRequest request) throws Exception {
		ResponseEntity<byte[]> response = null;
		try {
			log.info(getClass().getCanonicalName() + " ::Inside repaymentScheduleKFSPDF method with request body : "
					+ request);
			RepaymentSheduleKFSVO repaymentSheduleKFSVO = kfsRequestService.setRepaymentSheduleKFSVO(request);
			RepaymentScheduleKFSBaseResponse kfsResponse = repaymentScheduleKFS(repaymentSheduleKFSVO);

			log.info("repaymentScheduleKFSPDF-request=" + objectMapper.writeValueAsString(repaymentSheduleKFSVO));
			//log.info("repaymentScheduleKFSPDF-response=" + objectMapper.writeValueAsString(kfsResponse));

			saveApiSuccessResponse("KEY_FACT_STATEMENT_PDF", request.getAccountId(), repaymentSheduleKFSVO,
					kfsResponse,request.getCustomerId(),request.getLoanId());
			log.info("RepaymentSheduleKFSVO::" + repaymentSheduleKFSVO + "::And Request::" + request);
			log.info("RepaymentScheduleKFSBaseResponse::" + kfsResponse);

			byte[] decoded = new byte[0];
			RePaymentScheduleKFSResponse kfsData = kfsResponse.getData();
			log.info("RePaymentScheduleKFSResponse::" + kfsData);
			if (kfsData != null) {
				String encryptedData = kfsData.getKfsPDF();
				if (encryptedData != null) {
					decoded = java.util.Base64.getDecoder().decode(encryptedData);
				}
			}
			HttpHeaders responseHeaders = getResponseHeaders("RepaymentScheduleKFS.pdf");
			response = new ResponseEntity<byte[]>(decoded, responseHeaders, HttpStatus.OK);
			log.info(getClass().getCanonicalName() + " :: End of repaymentScheduleKFSPDF method with response : "
					+ response.getBody());
		} catch (HttpClientErrorException he) {
			String description = he.getMessage() + he.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.error("pl-Rest-connector-HttpStatusCodeException=" + he.getResponseBodyAsString());
			saveApiErrorResponse("KEY_FACT_STATEMENT_PDF", request.getAccountId(), request,
					he.getResponseBodyAsString(),request.getCustomerId(),request.getLoanId());
			log.info("request.getAccountId()::" + request.getAccountId() + "::" + request + "::"
					+ he.getResponseBodyAsString());

			if (null != he.getResponseBodyAsString() && !he.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(he.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=" + he.getResponseBodyAsString());
			exceptionUtil.handleHttpClientError(he, "KEY_FACT_STATEMENT_PDF");
			// throw new CustomException(code, description, errorType);
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2009", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2009", ex.getMessage());
		}
		return response;
	}

	public ResponseEntity<byte[]> fallback_repaymentScheduleKFSPDF(Throwable throwable) {

		HttpHeaders responseHeaders = new HttpHeaders();
		String filename = "LoanAgreement.pdf";
		responseHeaders.setContentType(MediaType.parseMediaType("application/pdf"));
		responseHeaders.add("content-disposition", "inline;filename=" + filename);
		responseHeaders.setContentDispositionFormData(filename, filename);
		responseHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		String str = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";
		byte[] decoded = new byte[0];
		decoded = java.util.Base64.getDecoder().decode(str);
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(decoded, responseHeaders, HttpStatus.OK);
		return response;
	}

	// @CircuitBreaker(name = "generateLoanAgreement", fallbackMethod =
	// "fallback_generateLoanAgreement")
	public LoanAgreementGenerationBaseResponse generateLoanAgreement(LoanAgreementRequestBuilderVO loanAgreementVO)
			throws Exception {
		
		LoanAgreementGenerationBaseResponse loanAgreementResponse = null;
		try {

			HttpHeaders headers = getRequestHeaders();
			loanAgreementVO.setCity(loanAgreementVO.getCity().replace(" ", ""));
			log.info(getClass().getCanonicalName() + " ::Inside generateLoanAgreement method with request body : "
					+ loanAgreementVO);

			LoanAgreementRequestVO loanAgreementRequestVO = new LoanAgreementRequestVO();
			loanAgreementRequestVO.setCity(loanAgreementVO.getCity());
			loanAgreementRequestVO.setAddress(loanAgreementVO.getAddress());
			loanAgreementRequestVO.setDob(loanAgreementVO.getDob());
			loanAgreementRequestVO.setEmi(loanAgreementVO.getEmi());
			loanAgreementRequestVO.setEmail(loanAgreementVO.getEmail());
			loanAgreementRequestVO.setPan(loanAgreementVO.getPan());
			loanAgreementRequestVO.setLoanAmount(loanAgreementVO.getLoanAmount());
			loanAgreementRequestVO.setRoi(loanAgreementVO.getRoi());
			loanAgreementRequestVO.setFirstName(loanAgreementVO.getFirstName());
			loanAgreementRequestVO.setPincode(loanAgreementVO.getPincode());
			loanAgreementRequestVO.setApplicationId(loanAgreementVO.getLoanId());
			loanAgreementRequestVO.setTenure(loanAgreementVO.getTenure());
			loanAgreementRequestVO.setLastName(loanAgreementVO.getLastName());
			loanAgreementRequestVO.setProcessingFee(loanAgreementVO.getProcessingFee());
			loanAgreementRequestVO.setMobileNumber(loanAgreementVO.getMobileNumber());
			
			loanAgreementResponse = serviceProvider.loanAgreementConsolidate(loanAgreementRequestVO, headers);
			saveApiSuccessResponse("LOAN_AGREEMENT_PDF", loanAgreementVO.getApplicationId(), loanAgreementRequestVO,
					loanAgreementResponse,loanAgreementVO.getCustomerId(),loanAgreementVO.getLoanId());

			if (Optional.ofNullable(loanAgreementResponse).isPresent()) {
				if (loanAgreementResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
							loanAgreementResponse.getError());
				}
			}
			log.info(getClass().getCanonicalName() + " :: End of generateLoanAgreement method with response : ");

		} catch (RedisServerException e) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
					loanAgreementResponse.getError());
		}catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2006", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2006", ex.getMessage());
		}
		return loanAgreementResponse;
	}

	public LoanAgreementGenerationBaseResponse externalAPICallForLoanAgreementPDF(LoanAgreementRequestBuilderVO loanAgreementVO, LoanAgreementRequestVO loanAgreementRequestVO)
			throws Exception {

		LoanAgreementGenerationBaseResponse loanAgreementResponse = null;
		try {

			HttpHeaders headers = getRequestHeaders();
			loanAgreementVO.setCity(loanAgreementVO.getCity().replace(" ", ""));
			log.info(getClass().getCanonicalName() + " ::Inside generateLoanAgreement method with request body : "
					+ loanAgreementVO);

			loanAgreementResponse = serviceProvider.loanAgreementConsolidate(loanAgreementRequestVO, headers);
			saveApiSuccessResponse("LOAN_AGREEMENT_PDF", loanAgreementVO.getApplicationId(), loanAgreementRequestVO,
					loanAgreementResponse,loanAgreementVO.getCustomerId(),loanAgreementVO.getLoanId());

			if (Optional.ofNullable(loanAgreementResponse).isPresent()) {
				if (loanAgreementResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
							loanAgreementResponse.getError());
				}
			}
			log.info(getClass().getCanonicalName() + " :: End of generateLoanAgreement method with response : ");

		} catch (RedisServerException e) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
					loanAgreementResponse.getError());
		}catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2006", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2006", ex.getMessage());
		}
		return loanAgreementResponse;
	}


	public LoanAgreementGenerationBaseResponse fallback_generateLoanAgreement(Throwable throwable) {
		// log.info("ABFL is down");
		LoanAgreementGenerationBaseResponse response = new LoanAgreementGenerationBaseResponse();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");

			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else {

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	// @CircuitBreaker(name = "generateLoanAgreementPDF", fallbackMethod =
	// "fallback_generateLoanAgreementPDF")
	public ResponseEntity<byte[]> generateLoanAgreementPDF(PdfRequest loanAgreementVO) throws Exception {
		log.info(getClass().getCanonicalName() + " ::Inside generateLoanAgreementPDF method with request body : "
				+ loanAgreementVO);
		LoanAgreementRequestBuilderVO requestObject = null;
		LoanAgreementGenerationBaseResponse loanAgreementResponse = null;
		LoanAgreementRequestVO loanAgreementRequestVO = new LoanAgreementRequestVO();
		try {
			requestObject = getLoanAgreementLetterRequest(loanAgreementVO);
			log.info("generateLoanAgreementPDF-requestObject=" + requestObject);

			loanAgreementRequestVO.setCity(requestObject.getCity());
			loanAgreementRequestVO.setAddress(requestObject.getAddress());
			loanAgreementRequestVO.setDob(requestObject.getDob());
			loanAgreementRequestVO.setEmi(requestObject.getEmi());
			loanAgreementRequestVO.setEmail(requestObject.getEmail());
			loanAgreementRequestVO.setPan(requestObject.getPan());
			loanAgreementRequestVO.setLoanAmount(requestObject.getLoanAmount());
			loanAgreementRequestVO.setRoi(requestObject.getRoi());
			loanAgreementRequestVO.setFirstName(requestObject.getFirstName());
			loanAgreementRequestVO.setPincode(requestObject.getPincode());
			loanAgreementRequestVO.setApplicationId(requestObject.getLoanId());
			loanAgreementRequestVO.setTenure(requestObject.getTenure());
			loanAgreementRequestVO.setLastName(requestObject.getLastName());
			loanAgreementRequestVO.setProcessingFee(requestObject.getProcessingFee());
			loanAgreementRequestVO.setMobileNumber(requestObject.getMobileNumber());
			loanAgreementResponse = externalAPICallForLoanAgreementPDF(requestObject, loanAgreementRequestVO);

			log.info("generateLoanAgreementPDF-loanAgreementResponse=" + requestObject);
			saveApiSuccessResponse("LOAN_AGREEMENT_PDF", requestObject.getApplicationId(), loanAgreementRequestVO,
					loanAgreementResponse,loanAgreementVO.getCustomerId(),loanAgreementVO.getLoanId());

			byte[] decoded = new byte[0];
			LoanAgreementGenerationResponse loanData = loanAgreementResponse.getData();
			if (loanData != null) {
				String loanAgreementPdf = loanData.getLoanAgreementPdf();
				if (loanAgreementPdf != null) {
					decoded = java.util.Base64.getDecoder().decode(loanAgreementPdf);
				}
			}
			HttpHeaders responseHeaders = getResponseHeaders("LoanAgreement.pdf");
			ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(decoded, responseHeaders, HttpStatus.OK);
			log.info(getClass().getCanonicalName() + " :: End of generateLoanAgreementPDF method with response : "
					+ response.getBody());
			return response;
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("LOAN_AGREEMENT_PDF", requestObject.getApplicationId(), loanAgreementRequestVO,
					loanAgreementResponse,loanAgreementVO.getCustomerId(),loanAgreementVO.getLoanId());
			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=" + ex.getResponseBodyAsString());
			exceptionUtil.handleHttpClientError(ex, "LOAN_AGREEMENT_PDF");
			//throw new CustomException(code, description, errorType);
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2006", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2006", ex.getMessage());
		}	 
		return null;
	}


	public LoanAgreementRequestBuilderVO getLoanAgreementLetterRequest(PdfRequest createLoanRequest) {
		LoanAgreementRequestBuilderVO loanAgreementLetterRequest = null;
		try {
			Optional<CustomerDetails> customerDetails = customerService.findByMobileNumber(createLoanRequest.getMobileNumber());
			
			String accountId = null;
			String firstName = null;
			String lastName = null;
			String panNumber = null;
			String mobileNumber = null;
			String email = null;
			String address = null;
			String city = null;
			String pincode = null;
			Double loanAmount = 0.00;
			Integer tenure = 0;
			Double emiAmount = 0.00;
			Double rateOfInterest = 0.00;
			LocalDate dateOfBirth = LocalDate.now();
			Double proceessingFee = 0.00;
			if (customerDetails.isPresent()) {
				// List<LoanOfferDetails> loanDetailsList =
				// customerDetails.get().getLoanOfferDetails();
				List<PLAddress> addressDetailsList = customerDetails.get().getAddressDetails();
				
				Optional<LoanOfferDetails> loanOfferDetails = loanOfferDetailsRepo
						.findByCustomerIdAndAccountIdAndLoanId(customerDetails.get().getCustomerId(), createLoanRequest.getAccountId(), createLoanRequest.getLoanId(), EnumLoanPurpose.getValue(createLoanRequest.getLoanType()));
				if (loanOfferDetails.isPresent()) {
					loanAmount = loanOfferDetails.get().getLoanAmount();
					
					tenure = loanOfferDetails.get().getTenure();
					rateOfInterest = loanOfferDetails.get().getRateOfInterest();
					emiAmount = loanOfferDetails.get().getMonthlyEmi();
					proceessingFee = loanOfferDetails.get().getProcessingFee();

				}
				
				address = createLoanRequest.getAddress();
				
				city =  createLoanRequest.getCity();

				pincode = createLoanRequest.getPincode();

				if (!addressDetailsList.isEmpty()) {

					address = isEmptyOrNull(address) ? addressDetailsList.get(0).getAddressLineOne():createLoanRequest.getAddress();

					city = isEmptyOrNull(city) ? addressDetailsList.get(0).getCity(): createLoanRequest.getCity();
					
					pincode = isEmptyOrNull(pincode) ? addressDetailsList.get(0).getPincode():createLoanRequest.getPincode();

				}
				city = city.replace(" ", "");
				if (createLoanRequest.getName() != null) {
					String[] arr = createLoanRequest.getName().split(" ");
					if (arr != null && arr.length > 1) {
						lastName = arr[arr.length - 1];
						firstName = createLoanRequest.getName().replace(lastName, " ").trim();
					}
				}
				address = CommonUtil.removeSpecialCharactersByRegexPattern(address, "[^<>'\\\"\\/;`%#!*()~]*");
				city = CommonUtil.removeSpecialCharactersByRegexPattern(city, "[a-zA-Z]*");
				accountId = !isEmptyOrNull(createLoanRequest.getAccountId()) ? createLoanRequest.getAccountId()
						: customerDetails.get().getAccountId();
				accountId = CommonUtil.removeSpecialCharactersByRegexPattern(accountId, "[^<>'\\\"\\/;`%#!*()~]*");
				firstName = !isEmptyOrNull(firstName) ? firstName : customerDetails.get().getFirstName();
				firstName = CommonUtil.removeSpecialCharactersByRegexPattern(firstName, "[^<>'\\\"\\/;`%#!*()~]*");
				lastName = !isEmptyOrNull(lastName) ? lastName : customerDetails.get().getLastName();
				lastName = CommonUtil.removeSpecialCharactersByRegexPattern(lastName, "[^<>'\\\"\\/;`%#!*()~]*");
				mobileNumber = !isEmptyOrNull(createLoanRequest.getMobileNumber()) ? createLoanRequest.getMobileNumber()
						: customerDetails.get().getMobileNumber();
				dateOfBirth = createLoanRequest.getDateOfBirth() != null ? createLoanRequest.getDateOfBirth()
						: customerDetails.get().getDateOfBirth();
				panNumber = !isEmptyOrNull(createLoanRequest.getPanNumber()) ? createLoanRequest.getPanNumber()
						: customerDetails.get().getPanNumber();
				email = !isEmptyOrNull(createLoanRequest.getEmail()) ? createLoanRequest.getEmail()
						: customerDetails.get().getEmailAddress();
				loanAgreementLetterRequest = LoanAgreementRequestBuilderVO.builder().applicationId(accountId)
						.email(email.toLowerCase()).pan(panNumber).firstName(firstName).lastName(lastName)
						.dob(dateOfBirth + "").mobileNumber(mobileNumber).loanAmount(loanAmount + "")
						.roi(rateOfInterest + "").emi(emiAmount + "").tenure(tenure + "")
						.processingFee(proceessingFee + "").address(address).city(city).pincode(pincode)
						.loanId(createLoanRequest.getLoanId()).customerId(createLoanRequest.getCustomerId()).build();
				log.info("loanAgreementLetterRequest=" + loanAgreementLetterRequest);
			} /*
				 * else { //throw new CustomException("Customer not found."); /*String
				 * description = "Data sent in request is not correct/Customer not found : " +
				 * createLoanRequest.getAccountId(); String code =
				 * HttpStatus.BAD_REQUEST.toString(); String errorType = "INVALID_PAYLOAD";
				 * throw new CustomException(code,description,errorType); }
				 */
		}catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2005", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2005", ex.getMessage());
		}
	return loanAgreementLetterRequest;
}

	public ResponseEntity<byte[]> fallback_generateLoanAgreementPDF(Throwable throwable) {
		HttpHeaders responseHeaders = new HttpHeaders();
		String filename = "LoanAgreement.pdf";
		responseHeaders.setContentType(MediaType.parseMediaType("application/pdf"));
		responseHeaders.add("content-disposition", "inline;filename=" + filename);
		responseHeaders.setContentDispositionFormData(filename, filename);
		responseHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		String str = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";
		byte[] decoded = new byte[0];
		decoded = java.util.Base64.getDecoder().decode(str);
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(decoded, responseHeaders, HttpStatus.OK);
		return response;

	}

	// @CircuitBreaker(name = "getDigitalSignRequest", fallbackMethod =
	// "fallback_getDigitalSignRequest")
	public DigiSignBaseResponse getDigitalSignRequest(DigiSignVO digiSignVO) throws Exception {

		log.info(getClass().getCanonicalName() + " ::Inside getDigitalSignRequest method with request body : "
				+ digiSignVO);
		ResponseEntity<String> response = null;
		DigiSignBaseResponse digiSignResponse = null;
		APIStatus loanPdfResponse = apiStatusRepo.findByAccountIdAndApiNameAndCustomerIdAndLoanId(digiSignVO.getAccountId(),
				"LOAN_AGREEMENT_PDF",digiSignVO.getCustomerId(),digiSignVO.getLoanId());
		APIStatus sancationPdfResponse = apiStatusRepo.findByAccountIdAndApiNameAndCustomerIdAndLoanId(digiSignVO.getAccountId(),
				"SANCTION_LETTER_PDF",digiSignVO.getCustomerId(),digiSignVO.getLoanId());
		APIStatus keyFactPdfResponse = apiStatusRepo.findByAccountIdAndApiNameAndCustomerIdAndLoanId(digiSignVO.getAccountId(),
				"KEY_FACT_STATEMENT_PDF",digiSignVO.getCustomerId(),digiSignVO.getLoanId());

		LoanAgreementGenerationBaseResponse loanPdf = objectMapper.readValue(loanPdfResponse.getResponseJson(),
				LoanAgreementGenerationBaseResponse.class);
		SanctionLetterBaseResponse sancationPdf = objectMapper.readValue(sancationPdfResponse.getResponseJson(),
				SanctionLetterBaseResponse.class);
		RepaymentScheduleKFSBaseResponse keyFactPdf = objectMapper.readValue(keyFactPdfResponse.getResponseJson(),
				RepaymentScheduleKFSBaseResponse.class);
		try {
			HttpHeaders headers = getRequestHeaders();
			DigiSignRequestVO digiSignRequestVO = new DigiSignRequestVO();
			digiSignRequestVO.setAccountId(digiSignVO.getLoanId());
			digiSignRequestVO.setMobile_number(digiSignVO.getMobile_number());
			digiSignRequestVO.setEmail(digiSignVO.getEmail());
			digiSignRequestVO.setMerged_pdf_flag(digiSignVO.isMerged_pdf_flag());
			digiSignRequestVO.setLoanAgreement(loanPdf.getData().getLoanAgreementPdf());
			digiSignRequestVO.setSanctionLetter(sancationPdf.getData().getSancationLetterPdf());
			digiSignRequestVO.setKeyFactStatement(keyFactPdf.getData().getKfsPDF());
			
			PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
			String docusignConsent = null != digiSignVO.getDocusignConsent()&& "Y".equalsIgnoreCase(digiSignVO.getDocusignConsent()) ? "Y" : "N";
			digiSignRequestVO.setDocusignConsent(null);
			digiSignResponse = serviceProvider.digitalSign(digiSignRequestVO, headers);

			// PL_JOURNEY_AUDIT
			if (null != digiSignResponse && null != digiSignResponse.getResponseStatus()
					&& Constants.SUCCESS.equalsIgnoreCase(digiSignResponse.getResponseStatus())) {
				plCustomerDetailDto.setAccountId(digiSignVO.getAccountId());
				plCustomerDetailDto.setDigisignConsent(docusignConsent);
				plCustomerDetailDto.setDigisignConsentDatetime(new Timestamp(new Date().getTime()));
				plCustomerDetailDto.setCurrentScreen("Loan Agreement Page");
				plCustomerDetailDto.setLoanId(digiSignVO.getLoanId());
				plCustomerDetailDto.setCustomerId(digiSignVO.getCustomerId());
				plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
			}
			
			saveApiSuccessResponse("DIGITAL_SIGN_REQUEST", digiSignVO.getAccountId(), digiSignRequestVO, digiSignResponse,digiSignVO.getCustomerId(),digiSignVO.getLoanId());
			if (Optional.ofNullable(digiSignResponse).isPresent()) {
				if (digiSignResponse.getResponseStatus().equals("ERROR")) {
					throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
							digiSignResponse.getError());
				}
			}
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			log.info("DIGITAL_SIGN_REQUEST-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("DIGITAL_SIGN_REQUEST", digiSignVO.getAccountId(), digiSignVO,
					ex.getResponseBodyAsString(),digiSignVO.getCustomerId(),digiSignVO.getLoanId());
			exceptionUtil.handleHttpClientError(ex, "DIGITAL_SIGN_REQUEST");
		} catch (RedisServerException e) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(), digiSignResponse.getError());
		}catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2004", e.getMessage());
		} catch (Exception ex) {
			throw new InternalException("2004", ex.getMessage());
		}
		return digiSignResponse;
	}

	public DigiSignBaseResponse fallback_getDigitalSignRequest(Throwable throwable) {
		// log.info("ABFL is down");
		DigiSignBaseResponse response = new DigiSignBaseResponse();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");

			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			response.setError(error);
			return response;

		} else {

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	public ResponseEntity<String> sendOtp(OtpVO otpVO) {
		log.info(getClass().getCanonicalName() + " ::Inside OtpVO method with request body : " + otpVO);
		ResponseEntity<String> response = null;
		SendOTPBaseResponse otpResponse = null;
		try {

			HttpHeaders headers = getRequestHeaders();
			// Optional<Token> token = tokenCacheService.getTokenFromCache("1");

			HttpEntity<Object> entityHeader = new HttpEntity<>(otpVO, headers);

			response = restTemplate.exchange(sendOtpUrl, HttpMethod.POST, entityHeader, String.class);

			if (response != null) {
				otpResponse = objectMapper.readValue(response.getBody(), SendOTPBaseResponse.class);
			}
			if (response == null) {
				throw new LoanCustomException("ERROR", otpResponse.getError());
			}
			saveApiSuccessResponse("SEND_OTP", otpVO.getApplicationId(), otpVO, otpResponse,null,null);
			log.info(getClass().getCanonicalName() + " :: End of sendOtp method with response : " + response.getBody());
		} catch (Exception e) {
			throw new InternalException("ERROR", new Error(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e.getLocalizedMessage()));
		}
		return response;
	}

	public ResponseEntity<String> verifyOtp(OtpVO otpVO) {
		log.info(getClass().getCanonicalName() + " ::Inside verifyOtp method with request body : " + otpVO);
		ResponseEntity<String> response = null;
		VerifyOTPBaseResponse verifyResponse = null;
		try {
			HttpHeaders headers = getRequestHeaders();
			// Optional<Token> token = tokenCacheService.getTokenFromCache("1");

			HttpEntity<Object> entityHeader = new HttpEntity<>(otpVO, headers);

			response = restTemplate.exchange(verifyOtpUrl, HttpMethod.POST, entityHeader, String.class);

			if (response != null) {
				verifyResponse = objectMapper.readValue(response.getBody(), VerifyOTPBaseResponse.class);
			}
			if (response == null) {
				throw new InternalException("ERROR", verifyResponse.getError());
			}
			saveApiSuccessResponse("VERIFY_OTP", otpVO.getApplicationId(), otpVO, verifyResponse,null,null);
			log.info(getClass().getCanonicalName() + " :: End of verifyOtp method with response : "
					+ response.getBody());
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2011", e.getMessage());
		} catch (Exception e) {
			throw new InternalException("ERROR", new Error(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e.getLocalizedMessage()));
		}
		return response;
	}

	// @CircuitBreaker(name = "saveDigiSignCallbackDetails", fallbackMethod =
	// "fallback_saveDigiSignCallbackDetails")
	public ResponseEntity<Object> saveDigiSignCallbackDetails(DigiSignPollResposeVO digisignPollVO) {
		
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		APIStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		Object obj = null;
		final String code = "PL2206";
		try {
			if (null == digisignPollVO) {
				throw new InternalException(EMPTY_REQUEST);
			} else if (null == digisignPollVO.getData() || isEmptyOrNull(digisignPollVO.getData().getAccountId())) {
				throw new InternalException(FILED_ACC_ID + TILDA + EMPTY_FIELD);
			} else {
				apiStatus = apiStatusRepository.findByAccountIdAndApiName(digisignPollVO.getData().getAccountId(),
						PL_DIGISIGN_DATA_POLLING);
				requestJsonObject = objectMapper.writeValueAsString(digisignPollVO);
				if (apiStatus == null) {
					throw new InternalException(DETAILS_NOT_FOUND);
				} else {
					apiStatus.setResponseJson(requestJsonObject);
					apiStatusRepository.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, "DIGI_SIGN Details Updated Successfully", EMPTY);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(APIStatus.builder().apiName(PL_DIGISIGN_DATA_CALLBACK)
							.accountId(digisignPollVO.getData().getAccountId()).profileId(EMPTY).requestId(EMPTY)
							.transactionId(EMPTY).requestJson(requestJsonObject).responseJson(responseJsonObject)
							.status(SUCCESS).httpStatusCode(HttpStatus.OK.value()).active(Boolean.FALSE).build(), null);
				}
			}
			log.info(className + methodName + END);

		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	public DigiSignPollResposeVO fallback_saveDigiSignCallbackDetails(Throwable throwable) {
		// log.info("ABFL is down");
		DigiSignPollResposeVO response = new DigiSignPollResposeVO();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");

			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			// response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			// response.setError(error);
			return response;

		} else {

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	// @CircuitBreaker(name = "getDigiSignData", fallbackMethod =
	// "fallback_getDigiSigPollData")
	public DigiSignPollResposeVO getDigiSignData(Long customerId, String accountId) throws Exception {
		log.debug("Entering into getDigiSignData ");
//		int custId = Integer.parseInt(customerId);
		DigiSignPollResposeVO pollResponse = new DigiSignPollResposeVO();
		APIStatus status = apiStatusRepository.findByApiNameAndCustomerIdAndAccountId("DigiSign", customerId, accountId);
		if (status == null) {
			HttpHeaders headers = getRequestHeaders();
			DigiSignPollRequestVO digiSignPollRequest = DigiSignPollRequestVO.builder().accountId(accountId).build();
			try {
				HttpEntity<Object> request = new HttpEntity<>(digiSignPollRequest, headers);
				ResponseEntity<DigiSignPollResposeVO> responseEntity = restTemplate.exchange(digiSignPollingUrl,
						HttpMethod.POST, request, DigiSignPollResposeVO.class);
				log.debug("DigiSign Polling API Success");
				pollResponse = responseEntity.getBody();
				saveApiSuccessResponse("DIGI_SIGN_DATA", accountId, customerId, pollResponse,null,null);
			} catch (HttpClientErrorException | HttpServerErrorException ex) {
				log.error("ERROR :: " + ex.getResponseBodyAsString());
				saveApiErrorResponse("DIGI_SIGN_DATA", accountId, customerId, ex.getResponseBodyAsString(),null,null);
				exceptionUtil.handleHttpClientError(ex, "DIGI_SIGN_DATA");
			}catch (ExternalException ex) {
				throw new ExternalException(ex.getCode(), ex.getErrorMessage());
			} catch (InternalException e) {
				throw new InternalException("2003", e.getMessage());
			} catch (Exception ex) {
				throw new InternalException("2003", ex.getMessage());
			}
		} else {
			String json = status.getResponseJson();
			ObjectMapper objectMapper = new ObjectMapper();
			pollResponse = objectMapper.readValue(json, DigiSignPollResposeVO.class);

		}
		log.debug("Exiting from getDigiSignData ");
		return pollResponse;
	}

	public DigiSignPollResposeVO getDigiSignDataPolling(Long customerId, String accountId,String loanId) throws Exception {

		DigiSignPollResposeVO pollResponse = null;
		try {
			log.debug("Entering into getDigiSignData ");
//			int custId = Integer.parseInt(customerId);
			APIStatus status = apiStatusRepository.findByApiNameAndCustomerIdAndAccountIdAndLoanId("DIGI_SIGN", customerId,
					accountId, loanId);
			if (status == null) {
				HttpHeaders headers = getRequestHeaders();

				DigiSignPollRequestVO digiSignPollRequest = DigiSignPollRequestVO.builder().accountId(loanId)
						.build();
				HttpEntity<Object> request = new HttpEntity<>(digiSignPollRequest, headers);
				pollResponse = serviceProvider.digitalSignPolling(digiSignPollRequest, headers);
				saveApiSuccessResponse("DIGISIGN_DATA_POLLING", accountId, digiSignPollRequest,
						pollResponse, customerId, loanId);
				if (Optional.ofNullable(pollResponse).isPresent()) {
					if (pollResponse.getResponseStatus().equals("ERROR")) {
						throw new InternalException(ResponseStatusCode.ABFL_ERROR.getValue(),
								pollResponse.getError());
					}
				}
				log.info(getClass().getCanonicalName() + " :: End of getDigiSignData method with response : ");
			} else {
				String json = status.getResponseJson();
				ObjectMapper objectMapper = new ObjectMapper();
				pollResponse = objectMapper.readValue(json, DigiSignPollResposeVO.class);
			}
		} catch (RedisServerException ex) {
			throw new InternalException("Redis Server Is Down", HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		} catch (ServiceProviderException e) {
			throw new ServiceProviderException(ResponseStatusCode.ABFL_ERROR.getValue(), pollResponse.getError());
		} catch (ExternalException ex) {
			throw new ExternalException(ex.getCode(), ex.getErrorMessage());
		} catch (InternalException e) {
			throw new InternalException("2012", e.getMessage());
		} 
		catch (Exception e) {
			throw new InternalException("Something went wrong, Please try after some time.",
					HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		log.debug("Exiting from getDigiSignDataPolling ");
		return pollResponse;
	}

	public DigiSignPollResposeVO fallback_getDigiSigPollData(Throwable throwable) {
		DigiSignPollResposeVO response = new DigiSignPollResposeVO();
		Error error = new Error();
		if (throwable instanceof ApplicationException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");

			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			// response.setError(error);
			return response;

		} else if (throwable instanceof CustomException) {
			// log.info("ABFL is down" + throwable.getMessage() + "test" +
			// throwable.toString());
			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			error.setErrorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
			error.setErrorType(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			error.setErrorDesc(throwable.getMessage());
			// response.setError(error);
			return response;

		} else {

			response.setResponseStatus(
					"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			return response;
		}
	}

	/*
	 * public ResponseEntity<Object>
	 * loanAgreementGenerator(LoanAgreementGenerationVO loanAgreementVO) {
	 * log.info(getClass().getCanonicalName() +
	 * " ::Inside loanAgreementGenerator method with request body : " +
	 * loanAgreementVO); ResponseEntity<Object> response = null; try {
	 * LoanAgreementRequestBuilderVO loanAgreementRequestBuilderVO =
	 * LoanAgreementRequestBuilderVO.builder().build();
	 * 
	 * //Optional<CustomerDetails> customerDetails =
	 * customerService.findByMobileNumber(loanAgreementVO.getMobileNumber());
	 * Optional<CustomerDetails> customerDetails =
	 * customerService.findByAccountId("");
	 * 
	 * if (customerDetails.isPresent()) {
	 * 
	 * //setLoanAgreementRequest(loanAgreementVO, loanAgreementRequestBuilderVO,
	 * customerDetails);
	 * 
	 * Token cacheToken = tokenRepository.findByTokenId("1"); HttpHeaders headers =
	 * new HttpHeaders(); headers.add("Content-Type", "application/json");
	 * headers.add("auth-token", generateToken());
	 * 
	 * HttpEntity<Object> entityHeader = new
	 * HttpEntity<>(loanAgreementRequestBuilderVO, headers);
	 * 
	 * response = restTemplate.exchange(loanAgreementUrl, HttpMethod.POST,
	 * entityHeader, Object.class); if(response==null){ Error respError = new
	 * Error(); respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Data sent in request is not correct");
	 * respError.setErrorType("INVALID_PAYLOAD"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.BAD_REQUEST); }
	 * 
	 * log.info(getClass().getCanonicalName() +
	 * " :: End of generateLoanAgreementPDF method with response : " +
	 * response.getBody()); }else { Error respError = new Error();
	 * respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Data not found for the customer.");
	 * respError.setErrorType("INVALID_REQUEST"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.BAD_REQUEST); } } catch (Exception e) { e.printStackTrace(); Error
	 * respError = new Error();
	 * respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Internal Server Error Occured.");
	 * respError.setErrorType("INTERNAL_SERVER_ERROR"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.INTERNAL_SERVER_ERROR); //throw new LoanCustomException("ERROR",
	 * respError); } return response; }
	 */

	/*
	 * private void setLoanAgreementRequest(LoanAgreementGenerationVO
	 * loanAgreementVO, LoanAgreementRequestBuilderVO loanAgreementRequestBuilderVO,
	 * Optional<CustomerDetails> customerDetails) {
	 * 
	 * String[] arrOfName = loanAgreementVO.getName().split(" ");
	 * loanAgreementRequestBuilderVO.setFirstName(arrOfName[0]);
	 * loanAgreementRequestBuilderVO.setLastName(arrOfName[1]);
	 * loanAgreementRequestBuilderVO.setMobileNumber(loanAgreementVO.getMobileNumber
	 * ()); loanAgreementRequestBuilderVO.setPan(loanAgreementVO.getPan());
	 * loanAgreementRequestBuilderVO.setDob(DateUtil.getDateString(customerDetails.
	 * get().getDateOfBirth()));
	 * 
	 * setLoanDetails(loanAgreementRequestBuilderVO, customerDetails);
	 * 
	 * setLoanAdressDetails(loanAgreementRequestBuilderVO, customerDetails); }
	 */

	/*
	 * private void setLoanDetails(LoanAgreementRequestBuilderVO
	 * loanAgreementRequestBuilderVO, Optional<CustomerDetails> customerDetails) {
	 * List<LoanOfferDetails> loanOfferDetails =
	 * customerDetails.get().getLoanOfferDetails();
	 * loanAgreementRequestBuilderVO.setLoanAmount(loanOfferDetails.get(0).
	 * getLoanAmount().toString());
	 * loanAgreementRequestBuilderVO.setEmi(loanOfferDetails.get(0).getEmiDate());
	 * loanAgreementRequestBuilderVO.setTenure(loanOfferDetails.get(0).getTenure().
	 * toString()); loanAgreementRequestBuilderVO.setRoi(loanOfferDetails.get(0).
	 * getRateOfInterest().toString()); }
	 */

	/*
	 * private void setLoanAdressDetails(LoanAgreementRequestBuilderVO
	 * loanAgreementRequestBuilderVO, Optional<CustomerDetails> customerDetails) {
	 * List<AddressDetails> addressDetails =
	 * customerDetails.get().getAddressDetails();
	 * loanAgreementRequestBuilderVO.setAddress(addressDetails.get(0).
	 * getAddresslineone());
	 * loanAgreementRequestBuilderVO.setCity(addressDetails.get(0).getCity());
	 * loanAgreementRequestBuilderVO.setPincode(addressDetails.get(0).getPincode());
	 * }
	 */

	/*
	 * public ResponseEntity<Object>
	 * getRepaymentScheduleEstimate(RepaymentScheduleVO repaymentScheduleVO) {
	 * log.info(getClass().getCanonicalName() +
	 * " ::Inside generateSanctionLetterPDF method with request body : " +
	 * repaymentScheduleVO); ResponseEntity<Object> response = null; try { //Token
	 * cacheToken = tokenRepository.findByTokenId("1"); Token cacheToken = null;
	 * HttpHeaders headers = new HttpHeaders(); headers.add("Content-Type",
	 * "application/json"); headers.add("auth-token", generateToken());
	 * 
	 * HttpEntity<Object> entityHeader = new HttpEntity<>(repaymentScheduleVO,
	 * headers);
	 * 
	 * response = restTemplate.exchange(repaymentScheduleUrl, HttpMethod.POST,
	 * entityHeader, Object.class); if(response==null){ Error respError = new
	 * Error(); respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Data sent in request is not correct");
	 * respError.setErrorType("INVALID_PAYLOAD"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.BAD_REQUEST); } log.info(getClass().getCanonicalName() +
	 * " :: End of getRepaymentScheduleEstimate method with response : " +
	 * response.getBody()); } catch (Exception e) { e.printStackTrace(); Error
	 * respError = new Error();
	 * respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Internal Server Error Occured.");
	 * respError.setErrorType("INTERNAL_SERVER_ERROR"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.INTERNAL_SERVER_ERROR); //throw new LoanCustomException("ERROR",
	 * respError); } return response; }
	 */

	/*
	 * public ResponseEntity<Object> generateSanctionLetter(SanctionLetterRequestVO
	 * sanctionLetterRequestVO) { log.info(getClass().getCanonicalName() +
	 * " ::Inside generateSanctionLetter method with request body : " +
	 * sanctionLetterRequestVO); ResponseEntity<Object> response = null; try {
	 * SanctionLetterRequestBuilderVO sanctionLetterRequestBuilderVO =
	 * SanctionLetterRequestBuilderVO.builder().build();
	 * 
	 * Optional<CustomerDetails> customerDetails =
	 * customerService.findByAccountId(sanctionLetterRequestVO.getAccountId()); if
	 * (customerDetails.isPresent()) {
	 * 
	 * setSanctionLetterRequest(sanctionLetterRequestVO,
	 * sanctionLetterRequestBuilderVO, customerDetails);
	 * 
	 * Token cacheToken = tokenRepository.findByTokenId("1"); HttpHeaders headers =
	 * new HttpHeaders(); headers.add("Content-Type", "application/json");
	 * headers.add("auth-token", generateToken());
	 * 
	 * //sanctionLetterRequestBuilderVO.setAccountId("UPSELL000000470");
	 * HttpEntity<Object> entityHeader = new
	 * HttpEntity<>(sanctionLetterRequestBuilderVO, headers);
	 * 
	 * response = restTemplate.exchange(sanctionLetterUrl, HttpMethod.POST,
	 * entityHeader, Object.class);
	 * 
	 * if(response==null){ Error respError = new Error();
	 * respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Data sent in request is not correct");
	 * respError.setErrorType("INVALID_PAYLOAD"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.BAD_REQUEST); } log.info(getClass().getCanonicalName() +
	 * " :: End of generateSanctionLetter method with response : " +
	 * response.getBody()); }else { Error respError = new Error();
	 * respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Data not found for the Customer.");
	 * respError.setErrorType("INVALID_PAYLOAD"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.BAD_REQUEST); } } catch (Exception e) { e.printStackTrace(); Error
	 * respError = new Error();
	 * respError.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	 * respError.setErrorDesc("Internal Server Error Occured. "
	 * +sanctionLetterRequestVO.getMobileNumber());
	 * respError.setErrorType("INTERNAL_SERVER_ERROR"); LoanGenerationResponse<?>
	 * errorMessage = new LoanGenerationResponse("ERROR",respError); return new
	 * ResponseEntity<Object>(errorMessage, response.getHeaders(),
	 * HttpStatus.INTERNAL_SERVER_ERROR); //throw new LoanCustomException("ERROR",
	 * respError); } return response; }
	 */

	/*
	 * private void setSanctionLetterRequest(SanctionLetterRequestVO
	 * sanctionLetterRequestVO, SanctionLetterRequestBuilderVO
	 * sanctionLetterRequestBuilderVO, Optional<CustomerDetails> customerDetails) {
	 * 
	 * sanctionLetterRequestBuilderVO.setAccountId(sanctionLetterRequestVO.
	 * getAccountId());
	 * sanctionLetterRequestBuilderVO.setPan(sanctionLetterRequestVO.getPanNo());
	 * sanctionLetterRequestBuilderVO.setEmail(customerDetails.get().getEmailAddress
	 * ());
	 * sanctionLetterRequestBuilderVO.setName(sanctionLetterRequestVO.getName());
	 * sanctionLetterRequestBuilderVO.setDateOfBirth(DateUtil.getDateString(
	 * customerDetails.get().getDateOfBirth()));
	 * 
	 * 
	 * List<LoanOfferDetails> loanOfferDetails =
	 * customerDetails.get().getLoanOfferDetails(); if(loanOfferDetails.size()>0) {
	 * setSanctionLoanDetails(sanctionLetterRequestVO,
	 * sanctionLetterRequestBuilderVO, loanOfferDetails); } }
	 * 
	 * private void setSanctionLoanDetails(SanctionLetterRequestVO
	 * sanctionLetterRequestVO, SanctionLetterRequestBuilderVO
	 * sanctionLetterRequestBuilderVO, List<LoanOfferDetails> loanOfferDetails) {
	 * 
	 * sanctionLetterRequestBuilderVO.setLoanAmount(loanOfferDetails.get(0).
	 * getLoanAmount().toString());
	 * sanctionLetterRequestBuilderVO.setOfferDate(DateUtil.getDateTimeString(
	 * loanOfferDetails.get(0).getOfferDate()));
	 * sanctionLetterRequestBuilderVO.setRoi(loanOfferDetails.get(0).
	 * getRateOfInterest().toString());
	 * sanctionLetterRequestBuilderVO.setEmi(loanOfferDetails.get(0).getMonthlyEmi()
	 * .toString());
	 * sanctionLetterRequestBuilderVO.setTenure(loanOfferDetails.get(0).getTenure().
	 * toString());
	 * sanctionLetterRequestBuilderVO.setOfferTime(DateUtil.getTimeString(
	 * loanOfferDetails.get(0).getOfferDate())); }
	 */

	/*
	 * public ResponseEntity<String>
	 * repaymentScheduleKFS(RepaymentScheduleRequestDto request) throws
	 * JsonMappingException, JsonProcessingException { //public
	 * RepaymentScheduleKFSBaseResponse
	 * repaymentScheduleKFS(RepaymentScheduleRequestDto request) {
	 * 
	 * RepaymentSheduleKFSVO repaymentSheduleKFSVO =
	 * kfsRequestService.setRepaymentSheduleKFSVO(request);
	 * 
	 * 
	 * //RepaymentScheduleKFSBaseResponse kfsResponse =
	 * repaymentScheduleKFS(repaymentSheduleKFSVO); //return kfsResponse;
	 * 
	 * log.info(getClass().getCanonicalName() +
	 * " :: Inside repaymentScheduleKFS method with request : " +
	 * repaymentSheduleKFSVO.toString()); ResponseEntity<String> response = null;
	 * RepaymentScheduleKFSBaseResponse kfsResponse = null; PLCustomerDto
	 * customerDto =null; PLLoanDetailsDto loanDetailsDto = null; try { customerDto
	 * =
	 * customerCacheService.getCustomerFromCache(repaymentSheduleKFSVO.getAccountId(
	 * )); LoanDetails loanData = repaymentSheduleKFSVO.getLoanDetails();
	 * if(loanData!=null && customerDto!=null) { loanDetailsDto =
	 * customerDto.getLoanDetails(); if(loanDetailsDto==null) loanDetailsDto =
	 * PLLoanDetailsDto.builder().build();
	 * 
	 * loanDetailsDto.setGst(loanData.getPf_with_gst()); Map<String,Charge> charges
	 * = loanData.getCharges(); Charge charge1 = charges.get("dynamic_charge_1");
	 * loanDetailsDto.setProcessingFee(charge1.getValue()); Charge charge2 =
	 * charges.get("dynamic_charge_2");
	 * loanDetailsDto.setInsuranceCharges(charge2.getValue()); Charge charge3 =
	 * charges.get("dynamic_charge_3");
	 * loanDetailsDto.setOtherCharges(charge3.getValue());
	 * loanDetailsDto.setFrequencyType(loanData.getFrequency_type());
	 * loanDetailsDto.setRepaymentPeriod(loanData.getNumber_of_repayment_period());
	 * customerDto.setLoanDetails(loanDetailsDto);
	 * customerCacheService.updateUserToCache(customerDto); } //Token cacheToken =
	 * tokenRepository.findByTokenId("1"); HttpHeaders headers = new HttpHeaders();
	 * headers.add("Content-Type", "application/json"); headers.add("auth-token",
	 * generateToken());
	 * 
	 * HttpEntity<RepaymentSheduleKFSVO> entityHeader = new
	 * HttpEntity<>(repaymentSheduleKFSVO, headers);
	 * 
	 * //response = restTemplate.exchange(repaymentScheduleKFSUrl, HttpMethod.POST,
	 * entityHeader, String.class); response =
	 * serviceProvider.scheduleRepaymentKFSJSON(repaymentSheduleKFSVO, headers);
	 * if(response!=null) { kfsResponse = objectMapper.readValue(response.getBody(),
	 * RepaymentScheduleKFSBaseResponse.class);
	 * 
	 * RePaymentScheduleKFSResponse kfsData = kfsResponse.getData();
	 * if(kfsData!=null && customerDto!=null) {
	 * loanDetailsDto.setTotalInterest((Float)kfsData.getTotalInterest());
	 * loanDetailsDto.setSumOtherCharges((Float)kfsData.getSumOtherCharges());
	 * loanDetailsDto.setSumBorrower((Float)kfsData.getSumBorrower());
	 * loanDetailsDto.setNumberOfInstallments((Integer)kfsData.
	 * getNumberOfInstallments());
	 * loanDetailsDto.setAnnualPercentageRate((Float)kfsData.getAnnualPercentageRate
	 * ());
	 * loanDetailsDto.setInternalRateOfReturn((Float)kfsData.getInternalRateOfReturn
	 * ()); customerDto.setLoanDetails(loanDetailsDto);
	 * customerCacheService.updateUserToCache(customerDto); } } if(response==null){
	 * kfsResponse = objectMapper.readValue(response.getBody(),
	 * RepaymentScheduleKFSBaseResponse.class); if
	 * (Optional.ofNullable(kfsResponse).isPresent()) { if
	 * (kfsResponse.getResponseStatus().equals("ERROR")) { throw new
	 * ServiceProviderException(ResponseStatusCode.ABFL_ERROR.getValue(),
	 * kfsResponse.getError()); } } } log.info(getClass().getCanonicalName() +
	 * " :: End of repaymentScheduleKFS method with response : " +
	 * response.getBody()); } catch (RedisServerException e) { throw new
	 * ApplicationException("Redis Server Is Down",
	 * HttpStatus.INTERNAL_SERVER_ERROR.value(),
	 * HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
	 * 
	 * } catch (ServiceProviderException e) { throw new
	 * ServiceProviderException(ResponseStatusCode.ABFL_ERROR.getValue(),
	 * kfsResponse.getError()); } return response; }
	 */

	@SuppressWarnings("unused")
	private HttpHeaders getResponseHeaders(String filename) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType("application/pdf"));
		headers.add("content-disposition", "inline;filename=" + filename);
		headers.setContentDispositionFormData(filename, filename);
		headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
		return headers;
	}

	public void saveApiSuccessResponse(String apiName, String acctId, Object reqestObject, Object responseObject,Long customerId,String loanId)
			throws Exception {
		String resquestJsonObject = objectMapper.writeValueAsString(reqestObject);
		String responseJsonObject = objectMapper.writeValueAsString(responseObject);
		log.info("apiName--" + apiName + "--request--" + resquestJsonObject);
		//log.info("apiName--" + apiName + "--response--" + responseJsonObject);
		APIStatus successStatusObj = APIStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.status("SUCCESS").requestJson(resquestJsonObject).responseJson(responseJsonObject)
				.customerId(customerId).loanId(loanId).status("SUCCESS")
				.build();
		apiStatusRepository.save(successStatusObj);
	}

	public void saveApiErrorResponse(String apiName, String acctId, Object requestJavaObject, Object errorJavaResponse,Long customerId,String loanId)
			throws Exception {
		String resquestJsonObject = objectMapper.writeValueAsString(requestJavaObject);
		String errorJsonObject = objectMapper.writeValueAsString(errorJavaResponse);
		log.info("apiName--" + apiName + "--request--" + resquestJsonObject);
		log.info("apiName--" + apiName + "--response--" + errorJsonObject);
		APIStatus failureStatusObj = APIStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.status("ERROR").requestJson(resquestJsonObject).responseJson(errorJsonObject).customerId(customerId).loanId(loanId).build();
		apiStatusRepository.save(failureStatusObj);
	}

	public String getPartnerErrorMessage(String partnerError) {
		String partnerErrorMessage = "Unable to connect with Partner, Please try after sometime.";
		if (!CommonUtil.isNullorBlank(partnerError)) {
			JSONObject errorResponse = new JSONObject(partnerError);
			if (errorResponse.has("error")) {
				JSONObject errorObj = errorResponse.getJSONObject("error");
				partnerErrorMessage = errorObj.has("description") ? errorObj.getString("description")
						: "Unable to connect with Partner, Please try after sometime.";
			} else {
				partnerErrorMessage = errorResponse.has("description") ? errorResponse.getString("description")
						: "Unable to connect with Partner, Please try after sometime.";
			}
		}
		return "PE0100 " + partnerErrorMessage;
	}

	@SuppressWarnings("unused")
	private HttpHeaders getRequestHeaders() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("auth-token", tokenService.generateToken());
		// headers.add("Accept", "*/* ");
		return headers;

	}

	public TransDetails getResumeJourneyDtls(long customerId) {
		// TODO Auto-generated method stub
		return transitionStateRepo.findByCustomerIdAndLobId(customerId, 1);
	}

	public TransDetails saveJourneyData(String journeyData) {
		JsonNode jsonNode = null;
		String customerId = null;
		long transId = 0l;
		try {
			jsonNode = objectMapper.readTree(journeyData);
			customerId = jsonNode.get("customerId").asText();
			TransDetails transDetails = transitionStateRepo.findByCustomerId(Long.valueOf(customerId));
			if(null != transDetails) {
				transId = transDetails.getId();
			}
			
		} catch (JsonMappingException e) {
			throw new ApplicationException(e.getLocalizedMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		
		} catch (JsonProcessingException e) {
			throw new ApplicationException(e.getLocalizedMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		
		}
		TransDetails transDetails = new TransDetails();
		transDetails.setId(transId);
		transDetails.setCustomerId(Long.valueOf(customerId));
		transDetails.setJourneyData(journeyData);
		transDetails.setLobId(1l);
		return transitionStateRepo.save(transDetails);
	}
	
	public APIStatus saveApiResponse(APIStatus apiStatus, APIStatus existApiStatus) {

		if (null != existApiStatus && null != existApiStatus.getId()) {
			existApiStatus.setProfileId(apiStatus.getProfileId());
			existApiStatus.setRequestId(apiStatus.getRequestId());
			existApiStatus.setTransactionId(apiStatus.getTransactionId());
			existApiStatus.setAccountId(apiStatus.getAccountId());
			existApiStatus.setRequestJson(apiStatus.getRequestJson());
			existApiStatus.setResponseJson(apiStatus.getResponseJson());
			existApiStatus.setStatus(apiStatus.getStatus().toUpperCase());
			existApiStatus.setModifiedBy(CREATED_BY);
			existApiStatus.setModifiedDate(new Timestamp(new Date().getTime()));
		} else {
			existApiStatus = apiStatus;
			existApiStatus.setStatus(existApiStatus.getStatus().toUpperCase());
			existApiStatus.setJourney(PL_JOURNEY);
			existApiStatus.setCreatedBy(CREATED_BY);
			existApiStatus.setCreatedDate(new Timestamp(new Date().getTime()));
		}
		return apiStatusRepository.save(existApiStatus);
	}
	
	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
}
