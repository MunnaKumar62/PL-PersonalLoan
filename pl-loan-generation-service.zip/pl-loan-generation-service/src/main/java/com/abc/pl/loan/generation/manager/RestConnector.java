package com.abc.pl.loan.generation.manager;


import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.abc.pl.loan.generation.common.util.ExceptionUtil;
import com.abc.pl.loan.generation.entity.APIStatus;
import com.abc.pl.loan.generation.exception.CustomException;
import com.abc.pl.loan.generation.exception.InternalException;
import com.abc.pl.loan.generation.repo.APIStatusRepository;

import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Log4j2
public class RestConnector {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private APIStatusRepository apiStatusRepo;
	
	@Autowired
	private ExceptionUtil exceptionUtil;

	public <T> T getForEntity(Class<T> clazz, String url, Object... uriVariables) {
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
			JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
			return readValue(response, javaType);
		} catch (HttpClientErrorException exception) {
			if (exception.getStatusCode() == HttpStatus.NOT_FOUND) {
				log.info("No data found {}", url);
			} else {
				log.info("rest client exception", exception.getMessage());
			}
		}
		return null;
	}
	
	public <T> ResponseEntity<String> getForEntityJSON(Class<T> clazz, String url, Object... uriVariables) {
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
			//JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
			//return readValue(response, javaType);
			return response;
		} catch (HttpClientErrorException exception) {
			if (exception.getStatusCode() == HttpStatus.NOT_FOUND) {
				log.info("No data found {}", url);
			} else {
				log.info("rest client exception", exception.getMessage());
			}
		}
		return null;
	}

	public <T> List<T> getForList(Class<T> clazz, String url, Object... uriVariables) {
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
			CollectionType collectionType = objectMapper.getTypeFactory().constructCollectionType(List.class, clazz);
			return readValue(response, collectionType);
		} catch (HttpClientErrorException exception) {
			if (exception.getStatusCode() == HttpStatus.NOT_FOUND) {
				log.info("No data found {}", url);
			} else {
				log.info("rest client exception", exception.getMessage());
			}
		}
		return null;
	}

	public <T, R> T postForEntity(Class<T> clazz, String url, R body, HttpHeaders h, Object... uriVariables) throws Exception {
		HttpEntity<R> request = null;
		try {
			request = new HttpEntity<>(body, h);
			ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class, uriVariables);
			JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
			return readValue(response, javaType);
		}catch (HttpStatusCodeException he) {
			
			log.info("request=" + request);	
			log.info("pl-Rest-connector-HttpStatusCodeException=" + he.getResponseBodyAsString());	

			log.info("PL-LoanGenerationService-HttpClientErrorException=" + he.getResponseBodyAsString());
			exceptionUtil.handleHttpClientError(he,url);
			//throw new CustomException(code,description,errorType); 
		} catch (Exception e) {
			//log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new InternalException("2000", e.getMessage());
		}
		return null;
	}

	public <T, R> ResponseEntity<String> postForEntityJSON(Class<T> clazz, String url, R body, HttpHeaders h, Object... uriVariables) {
		try {
			HttpEntity<R> request = new HttpEntity<>(body, h);
			ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class, uriVariables);
			//JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
			//return readValue(response, javaType);
			return response;
		}catch (HttpClientErrorException he) {
			String description = he.getMessage() + he.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + he.getResponseBodyAsString());
			
			if (null != he.getResponseBodyAsString() && !he.getResponseBodyAsString().isBlank()) {				
				JSONObject errorResponse = new JSONObject(he.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Something went wrong, Please try after some time.";
					description = errorObj.has("description") ? errorObj.getString("description") : "Something went wrong, Please try after some time.";
					code = errorObj.has("code") ? errorObj.getString("code") : "Something went wrong, Please try after some time.";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description") : "Something went wrong, Please try after some time.";
				}
			}
			log.info("PL-LoanGenerationService-HttpClientErrorException=" + he.getResponseBodyAsString());
			throw new CustomException(code,description,errorType);
		} catch (HttpStatusCodeException ex) {
			ex.printStackTrace();
			//log.info("PL-LoanGenerationService-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			//log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {				
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Something went wrong, Please try after some time.";
					description = errorObj.has("description") ? errorObj.getString("description") : "Something went wrong, Please try after some time.";
					code = errorObj.has("code") ? errorObj.getString("code") : "Something went wrong, Please try after some time.";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description") : "Something went wrong, Please try after some time.";
				}
			}
			throw new CustomException(code,description,errorType);
		} catch (Exception e) {
			//log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	public <T, R> T putForEntity(Class<T> clazz, String url, R body, Object... uriVariables) {
		HttpEntity<R> request = new HttpEntity<>(body);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class,
				uriVariables);
		JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
		return readValue(response, javaType);
	}

	public void delete(String url, Object... uriVariables) {
		try {
			restTemplate.delete(url, uriVariables);
		} catch (RestClientException exception) {
			log.info(exception.getMessage());
		}
	}

	private <T> T readValue(ResponseEntity<String> response, JavaType javaType) {
		T result = null;
		if (response.getStatusCode() == HttpStatus.OK || response.getStatusCode() == HttpStatus.CREATED) {
			try {
				result = objectMapper.readValue(response.getBody(), javaType);
			} catch (IOException e) {
				log.info(e.getMessage());
			}
		} else {
			log.info("No data found {}", response.getStatusCode());
		}
		return result;
	}
	
	public void saveApiErrorResponse(String apiName, String acctId, Object javaObject, String errorResponse)
			throws Exception {
		String responseJsonObject = objectMapper.writeValueAsString(javaObject);
		APIStatus failureStatusObj = APIStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.status("ERROR").requestJson(responseJsonObject).responseJson(errorResponse).build();
		apiStatusRepo.save(failureStatusObj);
	}
}
