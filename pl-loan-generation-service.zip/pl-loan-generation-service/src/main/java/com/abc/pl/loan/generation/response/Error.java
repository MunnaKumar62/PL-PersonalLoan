package com.abc.pl.loan.generation.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
//@AllArgsConstructor
public class Error {
	
	@JsonProperty("code")
    String errorCode;
    @JsonProperty("description")
    String errorDesc;
    @JsonProperty("errorType")
    String errorType;
    
    public Error(String errorCode,String errorDesc,String errorType) {
		this.errorCode = errorCode;
		this.errorDesc = errorDesc;
		this.errorType = errorType;
	}
    public Error() { 
		this.errorCode = errorCode;
		this.errorDesc = errorDesc;
		this.errorType = errorType;
    }
}