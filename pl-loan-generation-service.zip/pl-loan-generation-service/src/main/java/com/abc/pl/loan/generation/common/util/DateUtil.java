package com.abc.pl.loan.generation.common.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtil {
	


	public static String getDateString(LocalDate localDate) {
		DateTimeFormatter dobFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return localDate.format(dobFormatter);
	}

	public static String getDateTimeString(LocalDateTime localDateTime) {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return localDateTime.format(dateFormatter);
	}
	
	public static String getTimeString(LocalDateTime localDateTime) {
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm:ss");
		return localDateTime.format(timeFormatter);
	}

}
