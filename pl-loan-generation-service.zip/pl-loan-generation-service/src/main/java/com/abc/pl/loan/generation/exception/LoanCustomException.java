package com.abc.pl.loan.generation.exception;

import lombok.Getter;
import lombok.Setter;


import com.abc.pl.loan.generation.response.Error;
@Setter
@Getter
public class LoanCustomException extends RuntimeException {

	/**
	 * 
	 */
	private String responseStatus;
	private Error error;

	public LoanCustomException(String responseStatus, Error error){
		this.responseStatus = responseStatus;
		this.error = error;
	}

}
