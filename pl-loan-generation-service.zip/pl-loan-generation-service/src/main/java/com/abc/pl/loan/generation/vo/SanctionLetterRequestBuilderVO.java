package com.abc.pl.loan.generation.vo;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@SuperBuilder
public class SanctionLetterRequestBuilderVO {

	// @JsonProperty("cccId")
	// @Builder.Default
	private String cccId; // ;= "DIGITAL1829226819";

	// @Builder.Default
	private String accountId; // = "UPSELL000000470";

	// @Builder.Default
	private String pan;

	// @Builder.Default
	private String email; // = "fname.lname123@gmail.com";

	@Builder.Default
	private String docName = "SanctionLetter";

	// @Builder.Default
	private String dateOfBirth; // = "1980-04-04";

	// @Builder.Default
	private String loanAmount; // = "150000.00";

	// @Builder.Default
	private String name;

	// @Builder.Default
	private String offerDate; // = "2022-11-29";

	// @Builder.Default
	private String roi; // = "14.00";

	// @Builder.Default
	private String emi; // = "15000.00";

	// @Builder.Default
	private String offerTime; // = "15:15:20";

	// @Builder.Default
	private String tenure; // = "60";

}
