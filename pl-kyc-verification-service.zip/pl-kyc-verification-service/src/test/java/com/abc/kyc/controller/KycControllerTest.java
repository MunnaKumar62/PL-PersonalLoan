package com.abc.kyc.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.abc.kyc.request.CkycRequest;
import com.abc.kyc.request.DigilockerKycRequest;
import com.abc.kyc.request.UnifiedKyccallBackRequest;
import com.abc.kyc.response.DigilockerPollingResponse;
import com.abc.kyc.service.KycService;

class KycControllerTest {
	@InjectMocks
	KycController kycController;
	
	@Mock
	private  KycService kycService;

	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testPerformCKYC() throws Exception {
		CkycRequest ckycRequest = new CkycRequest();
		//kycController.performCKYC(ckycRequest);
	}

	@Test
	public void testPerformDigilockerKYC() throws Exception {
		DigilockerKycRequest digilockerKycRequest = new DigilockerKycRequest();
		kycController.performDigilockerKYC(digilockerKycRequest);
	}

	@Test
	public void testSaveDigilockerCallbackDetails() throws Exception {
		DigilockerPollingResponse digilockerPollingResponse = new DigilockerPollingResponse();
		kycController.saveDigilockerCallbackDetails(digilockerPollingResponse);
	}

	@Test
	public void testGetDigilockerKYCDetails() throws Exception {
		String accountId="";
		Long customerId= null;
		String loanId="";
		kycController.getDigilockerKYCDetails(accountId, customerId, loanId);
	}

	@Test
	public void testPerformUnifiedCkyc() throws Exception {
		String accountId="";
		Long customerId= null;
		String loanId="";
		kycController.getDigilockerKYCDetails(accountId, customerId, loanId);
	}

	@Test
	public void testSaveUnifiedKycCallbackDetails() throws Exception {
		UnifiedKyccallBackRequest unifiedKycPollingResponse = new UnifiedKyccallBackRequest();
		kycController.saveUnifiedKycCallbackDetails(unifiedKycPollingResponse);
	}

	@Test
	public void testGetUnifiedKYCDetails() throws Exception {
		String accountId="";
		Long customerId= null;
		String loanId="";
		kycController.getUnifiedKYCDetails(accountId, customerId, loanId);
	}

}
