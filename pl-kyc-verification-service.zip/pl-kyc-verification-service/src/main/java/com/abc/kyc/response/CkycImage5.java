package com.abc.kyc.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class CkycImage5 {
	  public String ckyc_image_data;
	    public String ckyc_img_type;
}
