package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycImage3{
    public String ckyc_image_data;
    public String ckyc_img_type;
}
