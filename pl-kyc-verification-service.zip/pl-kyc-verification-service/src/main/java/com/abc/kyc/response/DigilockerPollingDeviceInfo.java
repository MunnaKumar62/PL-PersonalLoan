package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingDeviceInfo{
    public String final_ipv4;
    public String user_agent;
}
