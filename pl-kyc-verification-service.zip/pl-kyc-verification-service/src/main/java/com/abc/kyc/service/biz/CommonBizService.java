package com.abc.kyc.service.biz;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.entity.ApiStatus;
import com.abc.kyc.entity.CustomerDetails;
import com.abc.kyc.exception.InternalException;
import com.abc.kyc.model.RetryConfg;
import com.abc.kyc.request.ApiCommonRequest;
import com.abc.kyc.response.Error;
import com.abc.kyc.response.ErrorResponse;
import com.abc.kyc.service.ApiStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CommonBizService implements Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	protected Environment env;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private ApiStatusService apiService;

	public ApiStatus saveApiResponse(ApiStatus apiStatus, ApiStatus existApiStatus) {

		if (null != existApiStatus && null != existApiStatus.getId()) {
			existApiStatus.setProfileId(apiStatus.getProfileId());
			existApiStatus.setRequestId(apiStatus.getRequestId());
			existApiStatus.setTransactionId(apiStatus.getTransactionId());
			existApiStatus.setCustomerId(apiStatus.getCustomerId());
			existApiStatus.setAccountId(apiStatus.getAccountId());
			existApiStatus.setLoanId(apiStatus.getLoanId());
			existApiStatus.setRequestJson(apiStatus.getRequestJson());
			existApiStatus.setResponseJson(apiStatus.getResponseJson());
			existApiStatus.setStatus(apiStatus.getStatus().toUpperCase());
			existApiStatus.setModifiedBy(CREATED_BY);
			existApiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
		} else {
			existApiStatus = apiStatus;
			existApiStatus.setStatus(existApiStatus.getStatus().toUpperCase());
			existApiStatus.setCustomerId(apiStatus.getCustomerId());
			existApiStatus.setAccountId(apiStatus.getAccountId());
			existApiStatus.setLoanId(apiStatus.getLoanId());
			existApiStatus.setJourney(PL_JOURNEY);
			existApiStatus.setCreatedBy(CREATED_BY);
			existApiStatus.setCreatedDt(new Timestamp(new Date().getTime()));
		}

		return apiService.savOrUpdateApiStatus(existApiStatus);
	}

	public void updateApiStatus(CustomerDetails CustomerDetails, ApiStatus apiStatus) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			if (null != CustomerDetails) {
				apiStatus.setAccountId(isEmptyOrNull(apiStatus.getAccountId()) ? CustomerDetails.getAccountId()
						: apiStatus.getAccountId());
				apiStatus.setCustomerId(CustomerDetails.getCustomerId());
				apiStatus.setModifiedBy(CREATED_BY);
				apiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
				apiService.savOrUpdateApiStatus(apiStatus);
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}

	public HttpHeaders getTokenRequestHeaders(String authToken) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", "Basic " + authToken);

		return headers;
	}

	public HttpHeaders getRequestHeaders(String token) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTH_TOKEN, token);

		return headers;
	}

	public String getPartnerErrorMessage(String partnerError) {
		String partnerErrorMessage = "";
		try {
			String code = "PE0100";
			partnerErrorMessage = code + env.getProperty(code);
			final String desc = "description";
			final String desc1 = "message";
			final String error = "error";
			if (!isEmptyOrNull(partnerError)) {
				JSONObject errorResponse = new JSONObject(partnerError);
				if (errorResponse.has(error)) {
					JSONObject errorObj = errorResponse.getJSONObject(error);

					if (errorObj.has(desc)) {
						partnerErrorMessage = errorObj.getString(desc);
					} else if (errorObj.has(desc1)) {
						partnerErrorMessage = errorObj.getString(desc1);
					} else {
						partnerErrorMessage = ERROR_ + errorObj.toString();
					}

				} else {
					partnerErrorMessage = errorResponse.has(desc) ? errorResponse.getString(desc) : partnerErrorMessage;
				}
			}
		} catch (JSONException e) {
			partnerErrorMessage = ERROR_ + partnerError;
		}

		return partnerErrorMessage;
	}

	public static boolean isJSONValid(String jsonInString ) {
	    try {
	       final ObjectMapper mapper = new ObjectMapper();
	       mapper.readTree(jsonInString);
	       return true;
	    } catch (IOException e) {
	       return false;
	    }
	  }

	/**
	 * This method is to call external API and audit request & response in database
	 * 
	 * @param <T>
	 * @param commonRequest
	 * @param clazz
	 * @return
	 */
	public <T> Map<String, Object> callExternalApi(ApiCommonRequest commonRequest, Class<T> responseType) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		Map<String, Object> map = new HashMap<>();
		String requestJsonObject = null;
		String responseJsonObject = null;
		String status = ERROR;
		int statusCode = STATUS_CODE_400;
		boolean isValid = Boolean.TRUE;
		ResponseEntity<T> apiResponse = null;
		try {
			requestJsonObject = null != commonRequest.getRequest()
					? mapper.writeValueAsString(commonRequest.getRequest())
					: null;
			//log.info(className + methodName + "[API_URL= " + commonRequest.getUrl() + "]");
			HttpEntity<Object> apiRequest = new HttpEntity<>(commonRequest.getRequest(),
					commonRequest.getRequestHeaders());
			//log.info(className + methodName + "[API_REQUEST= " + requestJsonObject + "]");

			apiResponse = restTemplate.exchange(commonRequest.getUrl(), commonRequest.getMethod(), apiRequest,
					responseType);

			if (null != apiResponse && null != apiResponse.getBody()) {
				status = SUCCESS;
				responseJsonObject = mapper.writeValueAsString(apiResponse.getBody());
				//log.info(className + methodName + "[API_RESPONSE= " + responseJsonObject + "]");
			}

			map.put(API_RESPONSE, apiResponse);
			statusCode = apiResponse.getStatusCode().value();
		} catch (HttpClientErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[HttpClientErrorException | HttpServerErrorException= "
					+ ex.getMessage());
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();
			Object error = null;
			try {
				if (!isEmptyOrNull(partnerErrorMessage) && partnerErrorMessage.startsWith(ERROR_)) {
					error = mapper.readValue(partnerErrorMessage.replace(ERROR_, EMPTY), Object.class);
				} else {
					error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
							partnerErrorMessage);
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			String apiName = commonRequest.getApiName();
			String message = "Error while calling external API ".concat(apiName);
			String errorMessage = ex.getStatusText();
			String errorCode = "PL-EE-C" + ex.getStatusCode().value();
			map.put(API_RESPONSE, new ResponseEntity<>(new ErrorResponse(status, error, errorCode, errorMessage,
					"C" + ex.getStatusCode(), errorCode + ": " + message, "Technical-error"), ex.getStatusCode()));
		} catch (HttpServerErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[HttpClientErrorException | HttpServerErrorException= "
					+ ex.getMessage());
			log.info("Json Error in External api check");
			log.info(ex.getResponseBodyAsString());
			log.info(ex.getResponseBodyAsString().toString());
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();
			Object error = null;
			try {
				if (!isEmptyOrNull(partnerErrorMessage) && partnerErrorMessage.startsWith(ERROR_)) {
					error = mapper.readValue(partnerErrorMessage.replace(ERROR_, EMPTY), Object.class);
				} else {
					error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
							partnerErrorMessage);
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			String apiName = commonRequest.getApiName();
			String message = "Error while calling external API ".concat(apiName);
			String errorMessage = ex.getStatusText();
			String errorCode = "PL-EE-S" + ex.getStatusCode().value();
			map.put(API_RESPONSE, new ResponseEntity<>(new ErrorResponse(status, error, errorCode, errorMessage,
					"S" + ex.getStatusCode(), errorCode + ": " + message, "Technical-error"), ex.getStatusCode()));

			statusCode = ex.getStatusCode().value();
		} catch (Exception ex) {
			isValid = Boolean.FALSE;
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("2001");
		} finally {
			//log.debug(className + methodName + FINALLY_BLOCK + " Called");
			log.info(className + methodName + FINALLY_BLOCK + " API Status Code: " + statusCode);

			if (commonRequest.isAudit() && isValid) {
				ApiStatus apiStatus = saveApiResponse(
						ApiStatus.builder().apiName(commonRequest.getApiName()).accountId(commonRequest.getAccountId())
								.profileId(commonRequest.getProfileId()).requestId(commonRequest.getRequestId())
								.transactionId(commonRequest.getTransactionId()).requestJson(requestJsonObject)
								.responseJson(responseJsonObject).status(status)
								.customerId(commonRequest.getCustomerId()).loanId(commonRequest.getLoanId())
								.httpStatusCode(statusCode).active(commonRequest.getActive()).build(),
						commonRequest.getApiStatus());
				map.put(API_STATUS, apiStatus);
			}
		}

		return map;
	}

	public <T> boolean validateResponse(ResponseEntity<T> apiResponse) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		boolean isSuccess = Boolean.TRUE;
		String error = "error";
		String errors = "errors";
		try {
			if (null != apiResponse && null != apiResponse.getBody()) {
				String json = mapper.writeValueAsString(apiResponse.getBody());

				if (!isEmptyOrNull(json)) {
					JSONObject errorResponse = new JSONObject(json);
					JSONObject errorObj = null;
					if (errorResponse.has(error)) {
						errorObj = errorResponse.getJSONObject(error);
					} else if (errorResponse.has(errors)) {
						errorObj = errorResponse.getJSONObject(errors);
					}
					if (null != errorObj) {
						isSuccess = Boolean.FALSE;
					}
				}
			}
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return isSuccess;
	}

	public RetryTemplate createRetryTemplate(int maxAttempts, long backOffPeriod) {

		RetryTemplate retryTemplate = new RetryTemplate();
		// Fixed delay of XX seconds between retries
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		fixedBackOffPolicy.setBackOffPeriod(backOffPeriod);
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy);

		// Retry only XX times
		SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
		retryPolicy.setMaxAttempts(maxAttempts);
		retryTemplate.setRetryPolicy(retryPolicy);

		return retryTemplate;
	}

	public List<RetryConfg> getRetryConfig(String value) {

		int maxAttempts = 1;
		List<RetryConfg> list = new ArrayList<>();
		if (!isEmptyOrNull(value) && value.contains(Constants.TILDA)) {
			String[] arr1 = value.trim().split(Constants.TILDA);
			for (String str : arr1) {
				if (!isEmptyOrNull(str) && str.contains(Constants.UNDER_SQUARE)) {
					String[] arr2 = str.split(Constants.UNDER_SQUARE);
					maxAttempts = null != arr2[0] ? Integer.parseInt(arr2[0]) : maxAttempts;
					list.add(new RetryConfg(maxAttempts, calculateWaitDuration(arr2[1])));
				}
			}
		} else if (!isEmptyOrNull(value) && value.contains(Constants.UNDER_SQUARE)) {
			String[] arr2 = value.trim().split(Constants.UNDER_SQUARE);
			maxAttempts = null != arr2[0] ? Integer.parseInt(arr2[0]) : maxAttempts;
			list.add(new RetryConfg(maxAttempts, calculateWaitDuration(arr2[1])));
		} else {
			list.add(new RetryConfg(maxAttempts, 1000L));
		}

		return list;
	}

	public static long calculateWaitDuration(String str) {

		long waitDuration = 1000L;

		try {
			boolean flag = isNumeric(str);
			if (flag) {
				// default seconds
				waitDuration = Integer.parseInt(str) * waitDuration;
			} else if (str.length() > 1) {
				String loadFactor = str.substring(0, str.length() - 1);
				char format = str.charAt(str.length() - 1);
				if (format == 's') {
					// seconds
					waitDuration = Integer.parseInt(loadFactor) * waitDuration;
				} else if (format == 'm') {
					// minutes
					waitDuration = Integer.parseInt(loadFactor) * (60 * waitDuration);
				}
			}
		} catch (NumberFormatException e) {
			return waitDuration;
		}
		return waitDuration;
	}

	private static boolean isNumeric(String s) {
		// match a number with optional '-' and decimal.
		return s.matches("-?\\d+(\\.\\d+)?");
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
	
	public List<String> apiNameList(String whiteListedServices) {
		List<String> list = new ArrayList<>();
		if (!StringUtils.isBlank(whiteListedServices)) {
			String[] arr = whiteListedServices.split(COMMA);
			if (arr.length > 1) {
				for (String str : arr) {
					str = str.trim();
					list.add(str);
				}
			}
		}
		return list;
	}
	
}
