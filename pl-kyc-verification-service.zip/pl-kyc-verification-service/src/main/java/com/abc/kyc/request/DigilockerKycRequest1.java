package com.abc.kyc.request;

import lombok.Data;

@Data
public class DigilockerKycRequest1 {
	private String accountId;
	private String journeyType; 
	
}
