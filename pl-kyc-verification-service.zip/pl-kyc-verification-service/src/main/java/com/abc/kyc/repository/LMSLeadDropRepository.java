package com.abc.kyc.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.kyc.entity.LMSLeadDrop;

@Repository
public interface LMSLeadDropRepository extends JpaRepository<LMSLeadDrop, Long> {

	Optional<LMSLeadDrop> findByLeadId(String leadId);
}
