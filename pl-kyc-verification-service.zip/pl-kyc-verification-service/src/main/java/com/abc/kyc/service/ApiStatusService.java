package com.abc.kyc.service;

import com.abc.kyc.entity.ApiStatus;


public interface ApiStatusService {

	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName, Boolean active);

	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus);
}
