package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycContactDetails{
    public String ckyc_email;
    public String ckyc_mobile_isd;
    public String ckyc_mobile_no;
    public String ckyc_off_tel_no;
    public String ckyc_off_tel_std;
    public String ckyc_res_tel_no;
    public String ckyc_res_tel_std;
}
