package com.abc.kyc.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UnifiedKycData{
	
    public String code;
    public String accountId;
    public String transactionId;
    public String description;
}
