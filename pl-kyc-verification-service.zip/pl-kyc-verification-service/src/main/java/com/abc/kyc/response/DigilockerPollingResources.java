package com.abc.kyc.response; 
import java.util.ArrayList;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingResources{
    public ArrayList<DigilockerPollingDocument> documents;
    public ArrayList<DigilockerPollingImage> images;
    public ArrayList<String> text;
    public ArrayList<String> videos;
}
