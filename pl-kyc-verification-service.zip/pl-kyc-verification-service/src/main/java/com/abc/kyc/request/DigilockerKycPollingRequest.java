package com.abc.kyc.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DigilockerKycPollingRequest extends Request{
    private String accountId;
    private String journeyType;
    private String profileId;
}
