package com.abc.kyc.request;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class DigilockerKycRequest{
	 @JsonProperty("accountId")
    private String accountId;
    private String journeyType;
    @JsonProperty("customerId")
    private Long customerId;
    @JsonProperty("loanId")
    private String loanId;
}
