package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycPersonalDetails {

	private String ckyc_maiden_full_name;
	private String ckyc_form60;
	private CkycAddresses ckyc_addresses;
	private String ckyc_father_first_name;
	private String ckyc_father_name_prefix;
	private String ckyc_mother_first_name;
	private String ckyc_gender;
	private String ckyc_mother_last_name;
	private String ckyc_pan;
	private String ckyc_const_type;
	private String ckyc_father_full_name;
	private String ckyc_spouse_middle_name;
	private String ckyc_last_name;
	private String ckyc_first_name;
	private String ckyc_maiden_middle_name;
	private String ckyc_maiden_first_name;
	private String ckyc_number;
	private String ckyc_mother_full_name;
	private String ckyc_spouse_first_name;
	private CkycContactDetails ckyc_contact_details;
	private String ckyc_father_middle_name;
	private String ckyc_full_name;
	private String ckyc_mother_middle_name;
	private String ckyc_maiden_name_prefix;
	private CkycImageDetails ckyc_image_details;
	private String ckyc_mother_name_prefix;
	private String ckyc_dob;
	private String ckyc_remarks;
	private String ckyc_name_prefix;
	private String ckyc_spouse_full_name;
	private CkycIdDetails ckyc_id_details;
	private String ckyc_acc_type;
	private String ckyc_maiden_last_name;
	private String ckyc_spouse_last_name;
	private CkycDeclarationDetails ckyc_declaration_details;
	private String ckyc_spouse_name_prefix;
	private String ckyc_middle_name;
	private String ckyc_father_last_name;
	private String ckycDocType;
	private String ckycCustomerPhoto;
	private String ckycDocFrontPhoto;

}
