package com.abc.kyc.exception;

public class CustomException extends RuntimeException {

	private static final long serialVersionUID = -6411588775873452678L;

	public CustomException() {
		super();
	}

	public CustomException(String message, Throwable cause) {
		super(message, cause);
	}

	public CustomException(String message) {
		super(message);
	}

	public CustomException(String errorCode, String message) {
		super(errorCode + message);
	}

	public CustomException(Throwable cause) {
		super(cause);
	}

}
