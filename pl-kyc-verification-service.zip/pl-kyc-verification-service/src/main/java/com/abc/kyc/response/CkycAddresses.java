package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycAddresses{
    public CkycCorAddress ckyc_cor_address;
    public String ckyc_per_add_same_as_cor;
    public CkycPerAddress ckyc_per_address;
}
