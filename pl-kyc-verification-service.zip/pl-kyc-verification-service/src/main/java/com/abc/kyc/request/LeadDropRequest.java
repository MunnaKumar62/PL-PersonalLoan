package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LeadDropRequest {

private String lead_id;
	
    private String customer_id;

    @JsonProperty("Product_category__c")
    private String product_category__c;

    @JsonProperty("Product_name__c")
    private String product_name__c;
    
    @JsonProperty("LoB_Application_ID__c")
    private String loB_Application_ID__c;
    
    @JsonProperty("Lead_Milestone__c")
    private String lead_Milestone__c;
    
    @JsonProperty("Co_Browsing_Flag__c")
    private Boolean co_Browsing_Flag__c;
    
    @JsonProperty("UNFYD_Session_ID__c")
    private String uNFYD_Session_ID__c;

    @JsonInclude(value = Include.NON_NULL)
    @JsonProperty("abcd_app_status_code__c")
    private String abcd_app_status_code__c;
    
    @JsonProperty("Loan_Amount_Required__c")
    private String loan_Amount_Required__c;

    @JsonProperty("Segment_Type__c")
    private String segment_Type__c;
}

