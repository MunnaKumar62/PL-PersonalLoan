package com.abc.kyc.cache;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.abc.kyc.model.PLCustomerDto;
import io.micrometer.common.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CustomerCacheService {

	private static final String CUSTOMER_CACHE = "PLCustomer";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper objectMapper;

	public PLCustomerDto getCustomerFromCache(String userId) {
		PLCustomerDto plCusDto = null;
		log.info("Fetching Customer from Customer Cache {} ", userId);
		try {
			String data = redisCacheProvider.getData(CUSTOMER_CACHE, userId);
			if (StringUtils.isNotBlank(data)) {
				plCusDto = objectMapper.readValue(data, PLCustomerDto.class);
			}
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
		}
		return plCusDto;
	}
	
	public void addCustomerToCache(PLCustomerDto customer) {
		log.info("Fetching Customer from Customer Cache {} ", customer);
		try {
			 redisCacheProvider.addData(CUSTOMER_CACHE, customer.getAccountId(),objectMapper.writeValueAsString(customer));
			
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
		}
		
	}
	
	public void updateCustomerToCache(PLCustomerDto customer) {
		log.info("Fetching Customer from Customer Cache {} ", customer);
		try {
			 redisCacheProvider.updateData(CUSTOMER_CACHE, customer.getAccountId(),objectMapper.writeValueAsString(customer));
			
		} catch (Exception e) {
			log.error("Failed to fetch Customer from Customer Cache", e);
		}
		
	}


}
