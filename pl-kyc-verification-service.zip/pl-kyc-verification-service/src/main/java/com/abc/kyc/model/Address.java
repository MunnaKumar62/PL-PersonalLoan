package com.abc.kyc.model;

import lombok.*;

@Data
@AllArgsConstructor
@ToString
@Getter
@Setter
public class Address {
    private long id;

    private String typeOfAddress;

    private String addressLineOne;

    private String addressLineTwo;

    private String state;

    private String city;

    private String landmark;

    private String pincode;
}
