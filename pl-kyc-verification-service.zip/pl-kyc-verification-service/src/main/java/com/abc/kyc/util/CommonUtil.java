package com.abc.kyc.util;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.WebRequest;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.exception.ExternalException;
import com.abc.kyc.response.FieldError;
import com.abc.kyc.response.FieldErrorResponse;
import com.abc.kyc.response.PartnerError;
import com.abc.kyc.response.SuccessResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class CommonUtil {
	@Autowired
	public ObjectMapper objectMapper;
	@Autowired
	public Message message;

	public static SuccessResponse getSuccessResponse(String code, String message, Object data) {

		SuccessResponse successResponse = new SuccessResponse();
	//	successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.SUCCESS);
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}
	
	public static SuccessResponse getErrorResponse(Object data) {
		SuccessResponse successResponse = new SuccessResponse();
		//successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.ERROR);
		successResponse.setData(data);
		return successResponse;
	}

	public static FieldErrorResponse getErrorResponse(Exception ex, HttpStatusCode status, WebRequest request) {
		List<FieldError> errorsList = new ArrayList<>();
		String[] arr = new String[2];
		String errorCode = "PL" + "2" + status.value();
		String msg = ex.getMessage();
		arr = null != msg && msg.contains(Constants.TILDA) ? msg.split(Constants.TILDA) : arr;

		String fieldName = !isNullorBlank(arr[0]) ? arr[0] : Constants.EMPTY;
		String message = !isNullorBlank(arr[1]) ? arr[1] : msg;
		String path = null != request ? request.getContextPath() : Constants.EMPTY;
		getErrorList(errorCode, fieldName, message, errorsList);

		return getErrorMessage(path, errorsList);
	}

	public static FieldErrorResponse getErrorMessage(String path, List<FieldError> errorList) {
		FieldErrorResponse errorMessage = new FieldErrorResponse();
		errorMessage.setTimestamp(LocalDateTime.now().toString());
		errorMessage.setStatus(Constants.ERROR);
		errorMessage.setPath(path);
		errorMessage.setErrors(errorList);
		return errorMessage;
	}

	public static void getErrorList(String errorCode, String fieldName, String message, List<FieldError> errorList) {
		FieldError errors = new FieldError(errorCode, fieldName, message);
		errorList.add(errors);
	}

	public static boolean isNullorBlank(String str) {
		return (null == str || str.isBlank());
	}

	public void handleHttpClientError(HttpStatusCodeException ex, String apiName) throws Exception {
		// Your existing code to log and extract information
		PartnerError partnerError = null;
		String errorMessage = null;
		int httpStatusCode = ex.getStatusCode().value();

		if (ex.getResponseBodyAsString() != null && !ex.getResponseBodyAsString().isEmpty()) {
			try {
				partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
				errorMessage = partnerError.getError().getDescription();
			} catch (JsonProcessingException e) {
				errorMessage = "Error processing JSON response from the client";
				// Log the error
			}
		} else {
			errorMessage = "Empty or null response from the client";
			// Log the error
		}

		// Throw ExternalException
		throw new ExternalException("C" + httpStatusCode, errorMessage, httpStatusCode,
				partnerError != null ? partnerError.getError().getErrorType() : null);
	}

	public void handleHttpServerError(HttpStatusCodeException ex, String apiName) throws Exception {
		// Your existing code to log and extract information
		PartnerError partnerError = null;
		String errorMessage = null;
		int httpStatusCode = ex.getStatusCode().value();

		if (ex.getResponseBodyAsString() != null && !ex.getResponseBodyAsString().isEmpty()) {
			try {
				partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
				errorMessage = partnerError.getError().getDescription();
			} catch (JsonProcessingException e) {
				errorMessage = "Error processing JSON response from the server";
				// Log the error
			}
		} else {
			errorMessage = "Empty or null response from the server";
			// Log the error
		}

		// Throw ExternalException
		throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
				httpStatusCode, partnerError != null ? partnerError.getError().getErrorType() : null);
	}
	}