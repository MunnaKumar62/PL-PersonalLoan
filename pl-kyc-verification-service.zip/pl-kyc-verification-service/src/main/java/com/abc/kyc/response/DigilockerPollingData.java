package com.abc.kyc.response; 
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingData{
	
	private DigilockerPollingConfig config;
    private DigilockerPollingDeviceInfo device_info;
    private DigilockerPollingProfileData profile_data;
    private String profile_id;
    private String reference_id;
    private DigilockerPollingResources resources;
    private String reviewer_action;
    private String schema_version;
    private String status;
    private DigilockerPollingStatusDescription status_description;
    private String status_detail;
    private ArrayList<DigilockerPollingTask> tasks;
    private String version;
    
    @JsonProperty("digixmlaadhaar")
    private String okycXml;
    
    private String accountId;
}
