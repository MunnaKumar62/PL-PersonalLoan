package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycPerAddress{
    public String ckyc_per_add1;
    public String ckyc_per_add2;
    public String ckyc_per_add3;
    public String ckyc_per_add_city;
    public String ckyc_per_add_country;
    public String ckyc_per_add_district;
    public String ckyc_per_add_pin;
    public String ckyc_per_add_poa;
    public String ckyc_per_add_state;
}
