package com.abc.kyc.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.abc.kyc.entity.ApiStatus;

import jakarta.transaction.Transactional;

public interface ApiStatusRepository extends JpaRepository<ApiStatus, Integer> {

	@Query("SELECT a FROM ApiStatus a WHERE a.requestId=:requestId and a.apiName=:apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByRequestIdAndApiName(@Param("requestId")String requestId, @Param("apiName") String apiName);

	@Query("SELECT a FROM ApiStatus a WHERE a.profileId=:profileId and a.apiName=:apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByProfileIdAndApiName(@Param("profileId") String profileId, @Param("apiName") String apiName);

	@Query("SELECT a FROM ApiStatus a WHERE a.transactionId=:transactionId and a.apiName=:apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByTransactionIdAndApiName(@Param("transactionId") String transactionId, @Param("apiName") String apiName);
	
	@Query("SELECT a FROM ApiStatus a WHERE a.transactionId=:transactionId and a.apiName=:apiName and a.status ='ERROR' order by a.id desc limit 1")
	ApiStatus findByTransactionIdAndApiNameError(@Param("transactionId") String transactionId, @Param("apiName") String apiName);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus getDetailsPollingStatus(@Param("accountId") String accountId, @Param("apiName") String apiName);

	ApiStatus findByApiName(String apiName);

	ApiStatus findByApiNameAndCustomerIdAndAccountId(String apiName, int customerId, String accountId);

	ApiStatus findByApiNameAndCustomerId(String apiName, int customerId);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName=:apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	ApiStatus findByAccountIdAndApiName(String accountId, String apiName, Boolean active);
	
	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName=:apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	String findResponseByAccountIdAndApiName(String accountId, String apiName, Boolean active);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("UPDATE ApiStatus a set a.status =:status, a.modifiedDt =:modifiedDt WHERE a.active = false AND a.accountId =:accountId AND a.apiName IN (:list) AND a.status ='SUCCESS'")
	public void updateStatusError(@Param("list") List<String> list, @Param("accountId") String accountId, @Param("status") String status, @Param("modifiedDt") Date modifiedDt);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName=:apiName and a.status ='SUCCESS' and a.active= :active and a.loanId= :loanId and a.customerId=:customerId order by a.id desc limit 1")
	ApiStatus findByAccountIdAndApiNameAndCustomerIdAndLoanId(String accountId, String loanId, Long customerId, String apiName,
			Boolean active);
	
	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName=:apiName and a.status ='SUCCESS' and a.active= :active and a.customerId= :customerId and a.loanId= :loanId order by a.id desc limit 1")
	String findResponseByAccountIdAndApiNameAndCustomerIdAndLoanId(String accountId, String apiName,Long customerId,String loanId, Boolean active);

	@Query("SELECT b FROM ApiStatus b WHERE b.id=(SELECT max(a.id) FROM ApiStatus a WHERE\n" +
			" a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId and a.apiName =:apiName and a.active =:active)\n" +
			" and b.responseJson LIKE %:responseJsonTxt% ")
	ApiStatus findByAccountIdAndLoanIdAndApiNameAndResponseJsonTxtAndActive(String accountId, String loanId, Long customerId, String apiName, String responseJsonTxt, Boolean active);
}
