package com.abc.kyc.exception;

import com.abc.kyc.response.KycResponseError;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class KYCException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    private String errorType;
    private String errorCode;
    private String description;
}
