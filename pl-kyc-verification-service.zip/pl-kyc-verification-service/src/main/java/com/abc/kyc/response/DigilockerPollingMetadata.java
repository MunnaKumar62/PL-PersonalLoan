package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingMetadata{
    public String capture_mechanism;
}
