package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycId1{
    public String ckyc_id_no;
    public String ckyc_id_type;
    public String ckyc_ver_status;
}
