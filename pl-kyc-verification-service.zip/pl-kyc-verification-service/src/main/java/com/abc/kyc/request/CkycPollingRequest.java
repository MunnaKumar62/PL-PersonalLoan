package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CkycPollingRequest {

	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("z_request_id")
	private String zRequestId;
}
