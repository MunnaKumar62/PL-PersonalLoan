package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycRequestStatus{
    public String ckyc_arn;
    public boolean ckyc_is_success;
    public String ckyc_rejection_message;
}
