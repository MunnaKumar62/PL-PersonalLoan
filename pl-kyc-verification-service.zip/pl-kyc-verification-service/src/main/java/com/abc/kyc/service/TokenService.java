package com.abc.kyc.service;

import org.springframework.http.ResponseEntity;

public interface TokenService {

	public String getAccessToken();

	public ResponseEntity<Object> callTokenApi();
}
