package com.abc.kyc.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UnifiedKycPollingRequest{
	
    private String accountId;
    private String transactionId;
    private String cccId;
}
