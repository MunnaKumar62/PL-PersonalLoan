package com.abc.kyc.response;

import java.util.List;

import com.abc.kyc.constant.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldErrorResponse {

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	private String timestamp;

	private String status;

	private String path;

	private List<FieldError> errors;

}
