package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerResponse{
    public String responseStatus;
    public DigilockerData data;
    private KycResponseError error;
}
