package com.abc.kyc.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldError {

	private String errorCode;
	private String fieldName;
	private String message;

}
