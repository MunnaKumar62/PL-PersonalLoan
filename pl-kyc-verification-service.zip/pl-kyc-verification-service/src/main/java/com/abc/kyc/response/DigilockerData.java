package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerData{
    public String captureExpiresAt;
    public String captureLink;
    public String profileId;
    public String partner_request_id;
}
