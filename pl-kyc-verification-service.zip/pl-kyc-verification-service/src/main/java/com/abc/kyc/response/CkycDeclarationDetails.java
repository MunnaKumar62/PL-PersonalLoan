package com.abc.kyc.response;
import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycDeclarationDetails{
    public String ckyc_date_of_declaration;
    public String ckyc_no_of_ids;
    public String ckyc_no_of_images;
    public String ckyc_no_of_rel_person;
    public String ckyc_place_of_declaration;
    public String ckyc_type_of_doc_submitted;
    public String ckyc_ver_branch;
    public String ckyc_ver_date;
    public String ckyc_ver_designation;
    public String ckyc_ver_emp_code;
    public String ckyc_ver_name;
}
