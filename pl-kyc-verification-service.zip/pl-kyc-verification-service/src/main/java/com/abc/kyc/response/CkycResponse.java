package com.abc.kyc.response;

import lombok.ToString;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CkycResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonProperty("data")
	private CkycData data;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("pollingData")
	public CkycPollingData pollingData;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private KycResponseError error;
}
