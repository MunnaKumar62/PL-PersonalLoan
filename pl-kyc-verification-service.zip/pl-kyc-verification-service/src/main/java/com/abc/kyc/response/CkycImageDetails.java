package com.abc.kyc.response;
import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycImageDetails{
	
    private CkycImage1 ckyc_image_1;
    private CkycImage2 ckyc_image_2;
    private CkycImage3 ckyc_image_3;
    private CkycImage4 ckyc_image_4;
    private CkycImage5 ckyc_image_5;
    private CkycImage6 ckyc_image_6;
}
