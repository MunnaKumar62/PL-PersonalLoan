package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingResult{
    public DigilockerPollingAutomatedResponse automated_response;
    public Object manual_response;
}
