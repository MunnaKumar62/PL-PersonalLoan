package com.abc.kyc.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CkycAddress {
    private String country;
    private String address_line_2;
    private String address_line_3;
    private String address_line_1;
    private String city;
    private String district;
    private String pincode;
    private String state;
}
