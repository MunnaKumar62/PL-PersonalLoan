package com.abc.kyc.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.abc.kyc.entity.PLCustomerDetail;

@Repository
public interface PLCustomerDetailRepository extends JpaRepository<PLCustomerDetail, Long> {

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndActive(String accountId, Boolean active);

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndLoanIdAndCustomerIdActive(String accountId, String loanId, Long customerId, Boolean active);
}
