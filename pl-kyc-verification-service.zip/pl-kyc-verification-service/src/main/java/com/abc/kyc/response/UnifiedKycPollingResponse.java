package com.abc.kyc.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UnifiedKycPollingResponse{
	
	public UnifiedKycPollingResponse(String responseStatus) {
		super();
		this.responseStatus = responseStatus;
	}

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("request_id")
	public String requestId;

	@JsonProperty("responseStatus")
	public String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	public UnifiedKycPollingData data;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Object error;
	
}
