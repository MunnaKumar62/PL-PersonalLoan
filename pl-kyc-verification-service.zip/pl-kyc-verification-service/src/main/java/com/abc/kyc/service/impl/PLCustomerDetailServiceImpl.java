package com.abc.kyc.service.impl;

import java.sql.Timestamp;
import java.time.Clock;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.constant.MessageConstants;
import com.abc.kyc.entity.PLCustomerDetail;
import com.abc.kyc.exception.CustomException;
import com.abc.kyc.exception.InternalException;
import com.abc.kyc.model.PLCustomerDetailDto;
import com.abc.kyc.repository.PLCustomerDetailRepository;
import com.abc.kyc.request.ApiCommonRequest;
import com.abc.kyc.request.LeadDropRequest;
import com.abc.kyc.response.SuccessResponse;
import com.abc.kyc.service.PLCustomerDetailService;
import com.abc.kyc.service.TokenService;
import com.abc.kyc.service.biz.CommonBizService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PLCustomerDetailServiceImpl extends CommonBizService implements PLCustomerDetailService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	PLCustomerDetailRepository detailRepository;
	
	@Autowired
	TokenService tokenService;

	@Autowired
	private ObjectMapper mapper;
	
	@Value("${abc.leaddrop.url}")
	private String leaddropUrl;

	@Override
	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto tmp, PLCustomerDetail details) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		PLCustomerDetail detail = details;
		if (null != tmp) {
			/**
			 * Get Last updated record from t_pl_customer_detail table by accountId &
			 * active=false
			 */
			detail = (null == detail) ? findByAccountIdAndLoanIdAndCustomerIdActive(tmp.getAccountId(), tmp.getLoanId(), tmp.getCustomerId(), Boolean.FALSE) : detail;
			if (null != detail) {
				log.info(className + methodName + "[PLCustomerDetail: " + detail.toString() + "]");
				detail = mergeDetails(tmp, detail);
				savOrUpdateCustomerDetails(detail);
			}
		}else {
			throw new CustomException("1017",MessageConstants.EMPTY_REQUEST + tmp);
		}
		return detail;
	}
	
	@Override
	public PLCustomerDetail auditCustomerDetailsError(PLCustomerDetailDto tmp, PLCustomerDetail details) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		PLCustomerDetail detail = details;
		if (null != tmp) {
			/**
			 * Get Last updated record from t_pl_customer_detail table by accountId &
			 * active=false
			 */
			detail = (null == detail) ? findByAccountIdAndActive(tmp.getAccountId(), Boolean.FALSE) : detail;
			if (null != detail) {
				log.info(className + methodName + "[PLCustomerDetail: " + detail.toString() + "]");
				detail = mergeDetailsError(tmp, detail);
				savOrUpdateCustomerDetails(detail);
			}
		}else {
			throw new CustomException("1017",MessageConstants.EMPTY_REQUEST + tmp);
		}
		return detail;
	}

	@Override
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail) {

		return detailRepository.save(plCustomerDetail);
	}

	@Override
	public PLCustomerDetail findByAccountIdAndActive(String accountId, Boolean active) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountIdAndActive(accountId, active);
		if (details.isPresent()) {
			customerDetail = details.get();
		}else {
			throw new CustomException("1018" + MessageConstants.PL_CUSTOMER_NOT_FOUND + "accountId:: "+accountId + "active_status "+active);
		}
		return customerDetail;
	}

	@Override
	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdActive(String accountId, String loanId, Long customerId, Boolean active) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountIdAndLoanIdAndCustomerIdActive(accountId, loanId, customerId, active);
		if (details.isPresent()) {
			customerDetail = details.get();
		}else {
			throw new CustomException("1018" + MessageConstants.PL_CUSTOMER_NOT_FOUND + "accountId:: "+accountId + "active_status "+active);
		}
		return customerDetail;
	}
	
	private PLCustomerDetail mergeDetails(PLCustomerDetailDto tmp, PLCustomerDetail detail) {
		
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		
		try {
			detail.setAccntCreateDate(null!=tmp.getAccntCreateDate()?tmp.getAccntCreateDate():detail.getAccntCreateDate());
			detail.setAccountId(tmp.getAccountId());
			detail.setApplicationId(!isEmptyOrNull(tmp.getApplicationId())?tmp.getApplicationId():detail.getApplicationId());
			detail.setTransactionId(!isEmptyOrNull(tmp.getTransactionId())?tmp.getTransactionId():detail.getTransactionId());
			detail.setCccId(!isEmptyOrNull(tmp.getCccId())?tmp.getCccId():detail.getCccId());
			detail.setMobilenumber(!isEmptyOrNull(tmp.getMobilenumber())?tmp.getMobilenumber():detail.getMobilenumber());
			detail.setCreditScore(!isEmptyOrNull(tmp.getCreditScore())?tmp.getCreditScore():detail.getCreditScore());
			detail.setLoanPurpose(!isEmptyOrNull(tmp.getLoanPurpose())?tmp.getLoanPurpose():detail.getLoanPurpose());
			detail.setFirstnameLastname(!isEmptyOrNull(tmp.getFirstnameLastname())?tmp.getFirstnameLastname():detail.getFirstnameLastname());
			detail.setPannumber(!isEmptyOrNull(tmp.getPannumber())?tmp.getPannumber():detail.getPannumber());
			detail.setDateOfBirth(null!=tmp.getDateOfBirth()?tmp.getDateOfBirth():detail.getDateOfBirth());
			detail.setGender(!isEmptyOrNull(tmp.getGender())?tmp.getGender():detail.getGender());
			detail.setEmail(!isEmptyOrNull(tmp.getEmail())?tmp.getEmail():detail.getEmail());
			detail.setWorkEmail(!isEmptyOrNull(tmp.getWorkEmail())?tmp.getWorkEmail():detail.getWorkEmail());
			detail.setWorkemailAddedDate(null!=tmp.getWorkemailAddedDate()?tmp.getWorkemailAddedDate():detail.getWorkemailAddedDate());
			detail.setBreloanAmount(null!=tmp.getBreloanAmount()?tmp.getBreloanAmount():detail.getBreloanAmount());
			detail.setBreroi(null!=tmp.getBreroi()?tmp.getBreroi():detail.getBreroi());
			detail.setBreOffertime(null!=tmp.getBreOffertime()?tmp.getBreOffertime():detail.getBreOffertime());
			detail.setBreRejectReason(!isEmptyOrNull(tmp.getBreRejectReason())?tmp.getBreRejectReason():detail.getBreRejectReason());
			detail.setCeStatus(!isEmptyOrNull(tmp.getCeStatus())?tmp.getCeStatus():detail.getCeStatus());
			detail.setBre2loanAmount(null!=tmp.getBre2loanAmount()?tmp.getBre2loanAmount():detail.getBre2loanAmount());
			detail.setBre2roi(null!=tmp.getBre2roi()?tmp.getBre2roi():detail.getBre2roi());
			detail.setBre2Offertime(null!=tmp.getBre2Offertime()?tmp.getBre2Offertime():detail.getBre2Offertime());
			detail.setBre2RejectReason(!isEmptyOrNull(tmp.getBre2RejectReason())?tmp.getBre2RejectReason():detail.getBre2RejectReason());
			detail.setCe2Status(!isEmptyOrNull(tmp.getCe2Status())?tmp.getCe2Status():detail.getCe2Status());
			detail.setEmandateStatus(!isEmptyOrNull(tmp.getEmandateStatus())?tmp.getEmandateStatus():detail.getEmandateStatus());
			detail.setEmanDatetime(null!=tmp.getEmanDatetime()?tmp.getEmanDatetime():detail.getEmanDatetime());
			detail.setDigilockerConsent(!isEmptyOrNull(tmp.getDigilockerConsent())?tmp.getDigilockerConsent():detail.getDigilockerConsent());
			detail.setDigilockerConsentDatetime(null!=tmp.getDigilockerConsentDatetime()?tmp.getDigilockerConsentDatetime():detail.getDigilockerConsentDatetime());
			detail.setDigilockerStatus(!isEmptyOrNull(tmp.getDigilockerStatus())?tmp.getDigilockerStatus():detail.getDigilockerStatus());
			detail.setDigilockerTime(null!=tmp.getDigilockerTime()?tmp.getDigilockerTime():detail.getDigilockerTime());
			detail.setUkycStatus(!isEmptyOrNull(tmp.getUkycStatus())?tmp.getUkycStatus():detail.getUkycStatus());
			detail.setUkycTime(null!=tmp.getUkycTime()?tmp.getUkycTime():detail.getUkycTime());
			detail.setCurrentScreen(!isEmptyOrNull(tmp.getCurrentScreen())?tmp.getCurrentScreen():detail.getCurrentScreen());
			detail.setAppPlatform(!isEmptyOrNull(tmp.getAppPlatform())?tmp.getAppPlatform():detail.getAppPlatform());
			detail.setBasicConsent(!isEmptyOrNull(tmp.getBasicConsent())?tmp.getBasicConsent():detail.getBasicConsent());
			detail.setBasicConsentDatetime(null!=tmp.getBasicConsentDatetime()?tmp.getBasicConsentDatetime():detail.getBasicConsentDatetime());
			detail.setBankConsent(!isEmptyOrNull(tmp.getBankConsent())?tmp.getBankConsent():detail.getBankConsent());
			detail.setBankConsentDatetime(null!=tmp.getBankConsentDatetime()?tmp.getBankConsentDatetime():detail.getBankConsentDatetime());
			detail.setKycAddressConsent(!isEmptyOrNull(tmp.getKycAddressConsent())?tmp.getKycAddressConsent():detail.getKycAddressConsent());
			detail.setKycAddressConsentDatetime(null!=tmp.getKycAddressConsentDatetime()?tmp.getKycAddressConsentDatetime():detail.getKycAddressConsentDatetime());
			detail.setUkycAddressConsent(!isEmptyOrNull(tmp.getUkycAddressConsent())?tmp.getUkycAddressConsent():detail.getUkycAddressConsent());
			detail.setUkycAddressConsentDatetime(null!=tmp.getUkycAddressConsentDatetime()?tmp.getUkycAddressConsentDatetime():detail.getUkycAddressConsentDatetime());
			detail.setBankaccountId(!isEmptyOrNull(tmp.getBankaccountId())?tmp.getBankaccountId():detail.getBankaccountId());	
			detail.setPennydropStatus(!isEmptyOrNull(tmp.getPennydropStatus())?tmp.getPennydropStatus():detail.getPennydropStatus());
			detail.setBankDetailValidation(!isEmptyOrNull(tmp.getBankDetailValidation())?tmp.getBankDetailValidation():detail.getBankDetailValidation());
			detail.setDigisignConsent(!isEmptyOrNull(tmp.getDigisignConsent())?tmp.getDigisignConsent():detail.getDigisignConsent());
			detail.setDigisignConsentDatetime(null!=tmp.getDigisignConsentDatetime()?tmp.getDigisignConsentDatetime():detail.getDigisignConsentDatetime());
			detail.setActive(null!=tmp.getActive()?tmp.getActive():detail.getActive());
			detail.setModifiedBy(CREATED_BY);
			detail.setModifiedDate(new Timestamp(new Date().getTime()));
			detail.setSalaried(null!=tmp.getSalaried()?tmp.getSalaried():detail.getSalaried());
			detail.setSelfEmployed(null!=tmp.getSelfEmployed()?tmp.getSelfEmployed():detail.getSelfEmployed());
			detail.setLoanAmount(null!=tmp.getLoanAmount()?tmp.getLoanAmount():detail.getLoanAmount());
			detail.setMonthlyIncome(null!=tmp.getMonthlyIncome()?tmp.getMonthlyIncome():detail.getMonthlyIncome());
			detail.setWorkAddress(!isEmptyOrNull(tmp.getWorkAddress())?tmp.getWorkAddress():detail.getWorkAddress());
			detail.setTenure(null!=tmp.getTenure()?tmp.getTenure():detail.getTenure());
			detail.setUkycInit(!isEmptyOrNull(tmp.getUkycInit())?tmp.getUkycInit():detail.getUkycInit());
			detail.setKycType(!isEmptyOrNull(tmp.getKycType())?tmp.getKycType():detail.getKycType());
			detail.setUkycInitTime(null!=tmp.getUkycInitTime()?tmp.getUkycInitTime():detail.getUkycInitTime());
			detail.setLeadId(!isEmptyOrNull(tmp.getLeadId())?tmp.getLeadId():detail.getLeadId());

			detail.setA8ApplicationStatus(!isEmptyOrNull(tmp.getA8ApplicationStatus()) ? tmp.getA8ApplicationStatus():detail.getA8ApplicationStatus());
			detail.setA8CallbackResp(!isEmptyOrNull(tmp.getA8CallbackResp()) ? tmp.getA8CallbackResp():detail.getA8CallbackResp());
			detail.setA8VideoPdStatus(!isEmptyOrNull(tmp.getA8VideoPdStatus()) ? tmp.getA8VideoPdStatus():detail.getA8VideoPdStatus());
			detail.setA8FlgUpdFrom(!isEmptyOrNull(tmp.getA8FlgUpdFrom()) ? tmp.getA8FlgUpdFrom():detail.getA8FlgUpdFrom());
			detail.setA8ProcessInstanceId(!isEmptyOrNull(tmp.getA8ProcessInstanceId()) ? tmp.getA8ProcessInstanceId():detail.getA8ProcessInstanceId());
			detail.setPrevA8CeStatus(!isEmptyOrNull(tmp.getPrevA8CeStatus()) ? tmp.getPrevA8CeStatus():detail.getPrevA8CeStatus());
			detail.setA8FiStatus(!isEmptyOrNull(tmp.getA8FiStatus()) ? tmp.getA8FiStatus() : detail.getA8FiStatus());
			detail.setA8SanctionDetails(!isEmptyOrNull(tmp.getA8SanctionDetails()) ? tmp.getA8SanctionDetails():detail.getA8SanctionDetails());

			detail.setProfileid(!isEmptyOrNull(tmp.getProfileid())?tmp.getProfileid():detail.getProfileid());
			detail.setIncomeVerifyTxnid(!isEmptyOrNull(tmp.getIncomeVerifyTxnid())?tmp.getIncomeVerifyTxnid():detail.getIncomeVerifyTxnid());
			detail.setCeStart(!isEmptyOrNull(tmp.getCeStart())?tmp.getCeStart():detail.getCeStart());
			detail.setCeStartDatetime(null!=tmp.getCeStartDatetime()?tmp.getCeStartDatetime():detail.getCeStartDatetime());
			detail.setCe2Start(!isEmptyOrNull(tmp.getCe2Start())?tmp.getCe2Start():detail.getCe2Start());
			detail.setCe2StartDatetime(null!=tmp.getCe2StartDatetime()?tmp.getCe2StartDatetime():detail.getCe2StartDatetime());
			detail.setDigilockerStart(!isEmptyOrNull(tmp.getDigilockerStart())?tmp.getDigilockerStart():detail.getDigilockerStart());
			detail.setDigilockerStartDatetime(null!=tmp.getDigilockerStartDatetime()?tmp.getDigilockerStartDatetime():detail.getDigilockerStartDatetime());
			detail.setPersonalDetailsComplete(!isEmptyOrNull(tmp.getPersonalDetailsComplete())?tmp.getPersonalDetailsComplete():detail.getPersonalDetailsComplete());
			detail.setPersonalDetailsCompleteDatetime(null!=tmp.getPersonalDetailsCompleteDatetime()?tmp.getPersonalDetailsCompleteDatetime():detail.getPersonalDetailsCompleteDatetime());
			detail.setWorkDetailsStatus(!isEmptyOrNull(tmp.getWorkDetailsStatus())?tmp.getWorkDetailsStatus():detail.getWorkDetailsStatus());
			detail.setWorkDetailsStatusDatetime(null!=tmp.getWorkDetailsStatusDatetime()?tmp.getWorkDetailsStatusDatetime():detail.getWorkDetailsStatusDatetime());
			detail.setContactRefComplete(!isEmptyOrNull(tmp.getContactRefComplete())?tmp.getContactRefComplete():detail.getContactRefComplete());
			detail.setContactRefCompleteDatetime(null!=tmp.getContactRefCompleteDatetime()?tmp.getContactRefCompleteDatetime():detail.getContactRefCompleteDatetime());
			detail.setContactRefName1(!isEmptyOrNull(tmp.getContactRefName1())?tmp.getContactRefName1():detail.getContactRefName1());
			detail.setContactRefName2(!isEmptyOrNull(tmp.getContactRefName2())?tmp.getContactRefName2():detail.getContactRefName2());
			detail.setContactRefMob1(!isEmptyOrNull(tmp.getContactRefMob1())?tmp.getContactRefMob1():detail.getContactRefMob1());
			detail.setContactRefMob2(!isEmptyOrNull(tmp.getContactRefMob2())?tmp.getContactRefMob2():detail.getContactRefMob2());
			detail.setFinalLoanComplete(!isEmptyOrNull(tmp.getFinalLoanComplete())?tmp.getFinalLoanComplete():detail.getFinalLoanComplete());
			detail.setFinalLoanCompleteDatetime(null!=tmp.getFinalLoanCompleteDatetime()?tmp.getFinalLoanCompleteDatetime():detail.getFinalLoanCompleteDatetime());
			detail.setLoanId(!isEmptyOrNull(tmp.getLoanId())?tmp.getLoanId():detail.getLoanId());
			detail.setCustomerId((tmp.getCustomerId()!=null)?tmp.getCustomerId():detail.getCustomerId());
			
		}catch (CustomException e) {
			log.info("Error in PLCustomerDetailServiceImpl mergeDetails API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in PLCustomerDetailServiceImpl mergeDetails API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in PLCustomerDetailServiceImpl mergeDetails API: " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1019");
		}
		return detail;
	}
	
	private PLCustomerDetail mergeDetailsError(PLCustomerDetailDto tmp, PLCustomerDetail detail) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			detail.setCurrentScreen(tmp.getTransactionId());
			detail.setUkycInit(tmp.getUkycInit());
			detail.setKycType(null);
			detail.setUkycInitTime(null);
			detail.setModifiedBy(CREATED_BY);
			detail.setModifiedDate(new Timestamp(new Date().getTime()));

		}catch (CustomException e) {
			log.info("Error in PLCustomerDetailServiceImpl mergeDetailsError API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in PLCustomerDetailServiceImpl mergeDetailsError API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in PLCustomerDetailServiceImpl mergeDetailsError API: " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1020");
		}
		return detail;
	}
	
	@Override
	public void updateLeadMileStone(LeadDropRequest request, String loanId, Long customerId, String accountId) {
		/**
		 * Get Last updated record from t_pl_customer_detail table by accountId &
		 * active=false
		 */
		PLCustomerDetail detail = findByAccountIdAndLoanIdAndCustomerIdActive(accountId, loanId, customerId, Boolean.FALSE);
		if (null != detail && !isEmptyOrNull(detail.getLeadId())) {
			Clock clock = Clock.systemDefaultZone();
			long milliseconds = clock.millis();
			String uniqueId = accountId + "T" + milliseconds;
			request.setUNFYD_Session_ID__c(uniqueId);
			request.setCo_Browsing_Flag__c(false);
			request.setLead_id(detail.getLeadId());
			request.setLoB_Application_ID__c(detail.getApplicationId());
			request.setLoan_Amount_Required__c(detail.getLoanAmount() != null ? String.valueOf(detail.getLoanAmount()) : null);
			request.setSegment_Type__c(StringUtils.isNotEmpty(detail.getJourneyType()) && detail.getJourneyType().equals("pre_approved_flow") ? "Pre-approved": "");
			updateLead(request);
		} else {
			log.info(className + "[updateLeadMileStone] lead_id not available for " + accountId);
		}
	}

	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> updateLead(LeadDropRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;
		try {
			/**
			 * External API Call
			 */
			log.info(className + methodName + "REQUEST: " + mapper.writeValueAsString(request));
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_LEAD_UPDATE)
					.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).url(leaddropUrl)
					.method(HttpMethod.POST).request(request).accountId(EMPTY).profileId(EMPTY).requestId(EMPTY)
					.transactionId(EMPTY).active(false).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, SuccessResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}
		}catch (CustomException e) {
			log.info("Error in PLCustomerDetailServiceImpl updateLead API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in PLCustomerDetailServiceImpl updateLead API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in PLCustomerDetailServiceImpl updateLead API: " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1021");
		}
		log.info(className + methodName + END);

		return apiResponse;
	}
}
