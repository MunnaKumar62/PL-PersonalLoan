package com.abc.kyc.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.constant.MessageConstants;
import com.abc.kyc.entity.CustomerDetails;
import com.abc.kyc.exception.CustomException;
import com.abc.kyc.repository.CustomerRepository;
import com.abc.kyc.service.CustomerDetailsService;
import com.abc.kyc.service.biz.CommonBizService;


@Service
public class CustomerDetailsServiceImpl extends CommonBizService implements CustomerDetailsService, Constants {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public CustomerDetails findByCustomerId(Long id) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findById(id);
		if (details.isPresent()) {
			customerDetails = details.get();
		}else {
			throw new CustomException("1015" + MessageConstants.CUSTOMER_NOT_FOUND + id);
		}
		return customerDetails;
	}

	@Override
	public CustomerDetails findByMobileNumber(String mobileNumber) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findByMobileNumber(mobileNumber);
		if (details.isPresent()) {
			customerDetails = details.get();
		}else {
			throw new CustomException("1015" + MessageConstants.CUSTOMER_NOT_FOUND + mobileNumber);
		}
		return customerDetails;
	}

	@Override
	public CustomerDetails findByAccountId(String accountId) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findByAccountId(accountId);
		if (details.isPresent()) {
			customerDetails = details.get();
		}else {
			throw new CustomException("1015" + MessageConstants.CUSTOMER_NOT_FOUND + accountId);
		}
		return customerDetails;
	}

}
