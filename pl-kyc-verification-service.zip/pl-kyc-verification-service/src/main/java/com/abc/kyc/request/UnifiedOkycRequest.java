package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UnifiedOkycRequest extends Request{
    public String kycType;
    public String accountId;
    public String xmlZipPass;
    public String transactionId;
    public String selfie;
    public String okycXml;
    public String declaredAddress;
    public String okycDocType;
    public String declaredName;
    public String declaredDoB;
    public String declaredPAN;
    public String declaredCity;
    public String declaredState;
    public int declaredPincode;
    public String gender;
    public String mobile;
    public String nsdlName;
    
    @JsonProperty("latitude")
    private String latitude;
    
    @JsonProperty("longitude")
    private String longitude;
}
