package com.abc.kyc.response;

import lombok.*;

@Builder
@AllArgsConstructor
@Data
public class Response<T> {
    private int statusCode;
    private String message;
}
