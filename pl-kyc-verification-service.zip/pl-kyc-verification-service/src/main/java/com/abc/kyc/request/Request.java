package com.abc.kyc.request;

public class Request<T> {
    T request;
}
