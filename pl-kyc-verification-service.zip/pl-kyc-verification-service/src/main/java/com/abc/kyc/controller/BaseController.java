package com.abc.kyc.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.constant.MessageConstants;
import com.abc.kyc.service.biz.CommonBizService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.log4j.Log4j2;

@Log4j2
public abstract class BaseController extends CommonBizService implements Constants, MessageConstants {

	@Autowired
	HttpServletRequest request;

	public abstract void auditUrl();

	public void logUrl(String className) {
		String fullURL = request.getRequestURL().toString();
		log.info("[" + className + "][" + fullURL + "]");
	}
}
