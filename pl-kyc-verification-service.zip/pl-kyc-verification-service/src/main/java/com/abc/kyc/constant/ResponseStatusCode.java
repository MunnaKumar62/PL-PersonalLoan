package com.abc.kyc.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResponseStatusCode {

    SUCCESS(2002, "SUCCESS"),
    ERROR(2001, "ERROR"),
    RECORD_SAVED(2000, "Record Saved Successfully"),
    BAD_REQUEST(4000,"Provided CKYC details are empty/null"),
    FAILED_TO_FETCH_CUSTOMER_OBJECT( 1020, "Failed to Get Customer with Given AccountID "),
    FAILED_TO_GET_API_RESPONSE(1012,"Failed to get API Response" ),
    FAILED_TO_GET_TOKEN(1020,"Failed to get Token From External API" ),
    TOKEN_NOT_AVAILABLE(1021 , "Token is not Available in Cache" ),
    USER_UNAUTHORIZED(1017 ,"Failed to get API Response, User Unauthorized" ),
    AUTH_TOKEN_ERROR(2008, "Error Getting Authentication Token.");

    private int code;
    private String value;

    public static ResponseStatusCode getResponseStatusCode(String cValue) {
        for (ResponseStatusCode cEnum : values()) {
            if (cEnum.getValue().equalsIgnoreCase(cValue)) {
                return cEnum;
            }
        }
        return null;
    }
}
