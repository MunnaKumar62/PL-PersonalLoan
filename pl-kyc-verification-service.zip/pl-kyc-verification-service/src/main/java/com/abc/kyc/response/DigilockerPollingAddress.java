package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingAddress{
    public String co;
    public String country;
    public String dist;
    public String house;
    public String lm;
    public String loc;
    public String pc;
    public String state;
    public String street;
    public String vtc;
}
