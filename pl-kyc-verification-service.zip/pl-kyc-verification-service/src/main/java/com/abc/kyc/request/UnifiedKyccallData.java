package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
public class UnifiedKyccallData {
	@JsonInclude(value = Include.NON_NULL)
	public String transactionId;

	public String kycStatus;

	public String kycType;

	@JsonInclude(value = Include.NON_NULL)
	public String failureReason;

}
