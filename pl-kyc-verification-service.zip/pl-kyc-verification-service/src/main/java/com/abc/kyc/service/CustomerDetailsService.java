package com.abc.kyc.service;

import com.abc.kyc.entity.CustomerDetails;

public interface CustomerDetailsService {

	CustomerDetails findByCustomerId(Long id);
	
	CustomerDetails findByMobileNumber(String mobileNumber);

	CustomerDetails findByAccountId(String accountId);

}
