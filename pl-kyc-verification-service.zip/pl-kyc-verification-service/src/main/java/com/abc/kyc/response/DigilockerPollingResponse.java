package com.abc.kyc.response;
import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingResponse{
    public String responseStatus;
    public DigilockerPollingData data;
    private KycResponseError error;
}
