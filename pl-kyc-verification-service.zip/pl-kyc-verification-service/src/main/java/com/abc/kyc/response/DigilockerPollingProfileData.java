package com.abc.kyc.response;

import java.util.ArrayList;
import java.util.Date;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingProfileData{
    public Date completed_at;
    public Date created_at;
    public ArrayList<String> email;
    public ArrayList<String> mobile_number;
    public String notes;
    public ArrayList<String> performed_by;
    public String purged_at;
}
