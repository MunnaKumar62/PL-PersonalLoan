package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UnifiedKyccallBackRequest {
	@JsonProperty("responseStatus")
	public String responseStatus;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	public UnifiedKyccallData data;
}

