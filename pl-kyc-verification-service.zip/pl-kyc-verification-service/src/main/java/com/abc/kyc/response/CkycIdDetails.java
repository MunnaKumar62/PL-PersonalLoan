package com.abc.kyc.response;
import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycIdDetails{
    public CkycId1 ckyc_id_1;
    public CkycId2 ckyc_id_2;
}
