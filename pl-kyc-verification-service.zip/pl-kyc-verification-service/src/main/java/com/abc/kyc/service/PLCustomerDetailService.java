package com.abc.kyc.service;

import com.abc.kyc.entity.PLCustomerDetail;
import com.abc.kyc.model.PLCustomerDetailDto;
import com.abc.kyc.request.LeadDropRequest;

public interface PLCustomerDetailService {

	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto plCustomerDetailDto, PLCustomerDetail detail);
	
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail);
	
	public PLCustomerDetail findByAccountIdAndActive(String accountId, Boolean active);

	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdActive(String accountId, String loanId, Long customerId, Boolean active);

	public void updateLeadMileStone(LeadDropRequest request, String loanId, Long customerId, String accountId);

	public PLCustomerDetail auditCustomerDetailsError(PLCustomerDetailDto plCustomerDetailDto, PLCustomerDetail detail);
}
