package com.abc.kyc.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UnifiedKycResponse{
    
    @JsonProperty("responseStatus")
	private String responseStatus;

	@JsonProperty("data")
	private UnifiedKycData data;
	
	@JsonInclude(value = Include.NON_NULL)
    @JsonProperty("pollingData")
	public UnifiedKycPollingData pollingData;
    
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
    private KycResponseError error;
	
}
