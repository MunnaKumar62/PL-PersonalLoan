package com.abc.kyc.service.impl;

import java.sql.Timestamp;
import java.util.*;

import com.abc.kyc.response.*;
import com.abc.kyc.service.*;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.constant.MessageConstants;
import com.abc.kyc.entity.ApiStatus;
import com.abc.kyc.entity.CustomerDetails;
import com.abc.kyc.entity.PLCustomerDetail;
import com.abc.kyc.exception.CustomException;
import com.abc.kyc.exception.InternalException;
import com.abc.kyc.exception.RetryException;
import com.abc.kyc.model.PLCustomerDetailDto;
import com.abc.kyc.model.RetryConfg;
import com.abc.kyc.repository.ApiStatusRepository;
import com.abc.kyc.request.ApiCommonRequest;
import com.abc.kyc.request.DigilockerKycPollingRequest;
import com.abc.kyc.request.DigilockerKycRequest;
import com.abc.kyc.request.DigilockerKycRequest1;
import com.abc.kyc.request.DigilockerSucessRequest;
import com.abc.kyc.request.KYCSuccessRequest;
import com.abc.kyc.request.LeadDropRequest;
import com.abc.kyc.request.UnifiedKycPollingRequest;
import com.abc.kyc.request.UnifiedKyccallBackRequest;
import com.abc.kyc.service.biz.CommonBizService;
import com.abc.kyc.service.biz.KycBizService;
import com.abc.kyc.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class KycServiceImpl extends CommonBizService implements KycService, Constants, MessageConstants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;
	
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ApiStatusRepository apiStatusRepository;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private CustomerDetailsService customerDetailsService;

	@Autowired
	private PLCustomerDetailService plCustomerDetailService;

	@Value("${abfl.kyc.digilocker.url}")
	private String digilockerKycUrl;

	@Value("${abfl.kyc.digilocker.polling.url}")
	private String digilockerKycPollingUrl;

	@Value("${abfl.kyc.unified.url}")
	private String unifiedkycUrl;

	@Value("${abfl.kyc.unified.polling.url}")
	private String unifiedkycPollingUrl;

	@Value("${pl.retry.unifiedkycdetails}")
	private String unifiedKycRetryConfig;
	
	@Value("${pl.kyc.whitelist.services}")
	private String whiteListedServices;

	@Autowired
	ApiStatusService apiService;

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> initiateDigilockerKYC(DigilockerKycRequest digilockerKycRequest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		DigilockerResponse digilockerResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		KycBizService bizService = new KycBizService();
		Map<String, Object> map = null;
		Object obj = null;
		String accountId = null;
		String transactionId = null;
		ApiStatus apiStatus = null;

		/**
		 * Input request validation
		 */
		digilockerKycRequest = bizService.validateDigilockerKycRequest(digilockerKycRequest);
		try {
			accountId = digilockerKycRequest.getAccountId();
			// Get PL_DIGI_LOCKER API updated success record from api_status table
			// To update same record if exist
			apiStatus = apiStatusRepository.findByAccountIdAndApiNameAndCustomerIdAndLoanId(accountId,digilockerKycRequest.getLoanId(),digilockerKycRequest.getCustomerId(), PL_DIGI_LOCKER, Boolean.FALSE);
			/**
			 * External API Call
			 */
			DigilockerKycRequest1 digilockerKycRequest1= new DigilockerKycRequest1();
			digilockerKycRequest1.setAccountId(digilockerKycRequest.getLoanId());
			digilockerKycRequest1.setJourneyType(digilockerKycRequest.getJourneyType());
			
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_DIGI_LOCKER).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(transactionId).url(digilockerKycUrl)
					.customerId(digilockerKycRequest.getCustomerId())
					.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
					.loanId(digilockerKycRequest.getLoanId()).request(digilockerKycRequest1).active(Boolean.FALSE)
					.isAudit(Boolean.TRUE).apiStatus(apiStatus).build();

			map = callExternalApi(commonRequest, DigilockerResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					if (null != apiResponse && null != apiResponse.getBody()) {
						digilockerResponse = (DigilockerResponse) apiResponse.getBody();
						// PL_JOURNEY_AUDIT
						if (null != digilockerResponse && null != digilockerResponse.getData()
								&& SUCCESS.equalsIgnoreCase(digilockerResponse.getResponseStatus())) {
							PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
							plCustomerDetailDto.setAccountId(digilockerKycRequest.getAccountId());
							plCustomerDetailDto.setDigilockerConsent(YES);
							plCustomerDetailDto.setLoanId(digilockerKycRequest.getLoanId());
							plCustomerDetailDto.setCustomerId(digilockerKycRequest.getCustomerId());
							plCustomerDetailDto.setDigilockerConsentDatetime(new Timestamp(new Date().getTime()));
							plCustomerDetailDto.setCurrentScreen("KYC Pages");
							plCustomerDetailDto.setProfileid(digilockerResponse.getData().getProfileId());
							plCustomerDetailDto.setDigilockerStart(YES);
							plCustomerDetailDto.setDigilockerStartDatetime(new Timestamp(new Date().getTime()));
							plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
						}
						// Update response details for polling call
						if (null != digilockerResponse && null != digilockerResponse.getData() && null != map
								&& !map.isEmpty() && null != map.get(API_STATUS)) {
							apiStatus = (ApiStatus) map.get(API_STATUS);
							apiStatus.setProfileId(digilockerResponse.getData().getProfileId());
							apiStatus.setTransactionId(digilockerResponse.getData().getProfileId());
							apiStatus.setRequestId(digilockerResponse.getData().getPartner_request_id());
							updateApiStatus(customerDetailsService.findByAccountId(accountId), apiStatus);
						}
					}
					obj = digilockerResponse;
				} else {
					obj = apiResponse.getBody();
				}
			}
		} catch (CustomException e) {
			log.info("Error in initiateDigilockerKYC API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in initiateDigilockerKYC API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in initiateDigilockerKYC API: " + e.getResponseBodyAsString());
			throw e;
		}catch(InternalException e) {
			throw e;
		}catch (Exception ex) {
			ex.printStackTrace();
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1006");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}


	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callDigilockerKycPollingApi(String accountId,Long customerId,String loanId ) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		DigilockerPollingResponse pollingResponse = new DigilockerPollingResponse();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		ApiStatus apiStatus = null;
		Map<String, Object> map = null;
		KycBizService kycBizService = new KycBizService();
		Object obj = null;
		boolean inProgressStatusFlag = false;
		/**
		 * Input request validation
		 */
		try {
		accountId = kycBizService.validateCkycRequest(accountId);
		if (!isEmptyOrNull(accountId)) {
			// Check whether Profileid exist in DB
			PLCustomerDetail detail= plCustomerDetailService.findByAccountIdAndLoanIdAndCustomerIdActive(accountId, loanId, customerId, Boolean.FALSE);
			if (null != detail && !isEmptyOrNull(detail.getProfileid())) {
				// Prepare digilockerKycPollingRequest
				DigilockerKycPollingRequest request = new DigilockerKycPollingRequest();
				request.setAccountId(loanId);
				request.setJourneyType("AADHAAR_DIGILOCKER");
				request.setProfileId(detail.getProfileid());
				// Get DIGI_LOCKER_POLLING api updated success record from api_status table
				// To update same record if exist
				apiStatus = apiStatusRepository.findByAccountIdAndApiNameAndCustomerIdAndLoanId(accountId,loanId,customerId, PL_DIGI_LOCKER_POLLING,Boolean.FALSE);
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_DIGI_LOCKER_POLLING)
						.accountId(accountId).profileId(detail.getProfileid()).requestId(EMPTY).transactionId(EMPTY).loanId(loanId).customerId(customerId)
						.url(digilockerKycPollingUrl).requestHeaders(getRequestHeaders(tokenService.getAccessToken()))
						.method(HttpMethod.POST).request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE)
						.apiStatus(apiStatus).build();

				map = callExternalApi(commonRequest, DigilockerPollingResponse.class);
				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					ApiStatus hitsPerSecondApiStatus = apiStatusRepository.findByAccountIdAndLoanIdAndApiNameAndResponseJsonTxtAndActive(accountId, loanId, customerId, "DIGI_LOCKER_POLLING", "Reached allowed limit 1 hits per 1 second!", Boolean.FALSE);
					if(Objects.nonNull(hitsPerSecondApiStatus)){
						inProgressStatusFlag = true;
						DigilockerPollingData digilockerPollingData = getInProgressStatusDigiLockerPollingData();
						pollingResponse.setData(digilockerPollingData);
						pollingResponse.setResponseStatus(SUCCESS);
					}else{

						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					}
					if (validateResponse(apiResponse)) {
						if (null != apiResponse && null != apiResponse.getBody()) {
							if(inProgressStatusFlag){
								DigilockerPollingData digilockerPollingData = getInProgressStatusDigiLockerPollingData();
								pollingResponse.setData(digilockerPollingData);
								pollingResponse.setResponseStatus(SUCCESS);
							}else{
								pollingResponse = (DigilockerPollingResponse) apiResponse.getBody();
							}
							// PL_JOURNEY_AUDIT
							if (null != pollingResponse && null != pollingResponse.getData()
									&& !pollingResponse.getData().getTasks().isEmpty()) {
								PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
								plCustomerDetailDto.setAccountId(accountId);
								plCustomerDetailDto.setCustomerId(customerId);
								plCustomerDetailDto.setLoanId(loanId);
								plCustomerDetailDto.setDigilockerStatus(pollingResponse.getData().getTasks().get(0).getStatus());
								plCustomerDetailDto.setDigilockerTime(new Timestamp(new Date().getTime()));
								plCustomerDetailDto.setCurrentScreen("KYC Pages");
								plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, detail);
							}
						}
						obj = pollingResponse;
					} else {
						obj = apiResponse.getBody();
					}
				 }
            } else {
                log.info(className + methodName + "DIGI_LOCKER Response not Available");
                throw new InternalException("1000");
            }
        }
    }catch (CustomException e) {
		log.info("Error in callDigilockerKycPollingApi API " + e.getMessage());
		throw e;
	} catch (HttpClientErrorException e) {
		log.error("Error in callDigilockerKycPollingApi API: " + e.getResponseBodyAsString());
		throw e;
	} catch (HttpServerErrorException e) {
		log.error("Error in callDigilockerKycPollingApi API: " + e.getResponseBodyAsString());
		throw e;
	} catch (InternalException e) {
        log.error("InternalException occurred in callDigilockerKycPollingApi API: " + e.getMessage(), e);
        obj = e.getMessage();
        throw new InternalException("1005");
    } catch (Exception e) {
        log.error("Unexpected Exception occurred: " + e.getMessage(), e);
        obj = "Unexpected error occurred";
        throw new InternalException("1012");
    }

    log.info(className + methodName + END);

    return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	public DigilockerPollingData getInProgressStatusDigiLockerPollingData(){
		DigilockerPollingData digilockerPollingData = new DigilockerPollingData();
		DigilockerPollingTask digilockerPollingTask = new DigilockerPollingTask();
		digilockerPollingTask.setStatus("in_progress");
		ArrayList<DigilockerPollingTask> digilockerPollingTaskList = new ArrayList<>();
		digilockerPollingTaskList.add(digilockerPollingTask);
		digilockerPollingData.setTasks(digilockerPollingTaskList);
		return digilockerPollingData;
	}
	
	public ResponseEntity<Object> saveDigilockerCallbackDetails(DigilockerPollingResponse digilockerPollingResponse){
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		Object obj = null;
		final String code = "PL2203";

		if (null == digilockerPollingResponse) {
			throw new CustomException(EMPTY_REQUEST);
		} else if (null == digilockerPollingResponse.getData()
				|| isEmptyOrNull(digilockerPollingResponse.getData().getOkycXml())) {
			throw new CustomException(FILED_OKYC_XML + TILDA + EMPTY_FIELD);
		} else {
			try {
				apiStatus = apiStatusRepository.findByProfileIdAndApiName(digilockerPollingResponse.getData().getProfile_id(), PL_DIGI_LOCKER_POLLING);
				requestJsonObject = objectMapper.writeValueAsString(digilockerPollingResponse);
				if (apiStatus == null) {
					throw new CustomException("1013",MessageConstants.DETAILS_NOT_FOUND + apiStatus);
				} else {
					apiStatus.setResponseJson(requestJsonObject);
					apiStatusRepository.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), EMPTY);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_DIGI_LOCKER_CALLBACK)
							.accountId(apiStatus.getAccountId())
							.loanId(apiStatus.getLoanId())
							.profileId(digilockerPollingResponse.getData().getProfile_id()).requestId(EMPTY)
							.transactionId(EMPTY).requestJson(requestJsonObject).responseJson(responseJsonObject)
							.status(SUCCESS).httpStatusCode(HttpStatus.OK.value()).active(Boolean.FALSE).build(), null);
				}
			}catch (CustomException e) {
				log.info("Error in saveDigilockerCallbackDetails API " + e.getMessage());
				throw e;
			} catch (HttpClientErrorException e) {
				log.error("Error in saveDigilockerCallbackDetails API: " + e.getResponseBodyAsString());
				throw e;
			} catch (HttpServerErrorException e) {
				log.error("Error in saveDigilockerCallbackDetails API: " + e.getResponseBodyAsString());
				throw e;
			} catch (JsonProcessingException ex) {
				log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		 } catch (Exception ex) {
		        log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		        // Handle other exceptions, if needed
		        throw new InternalException("1000 "+PL_DIGI_LOCKER_POLLING);
		    }
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	public ResponseEntity<Object> saveUnifiedKycCallbackDetails(UnifiedKyccallBackRequest unifiedKycResponse) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		Object obj = null;
		final String code = "PL2202";
		try {
//		
			if (Objects.nonNull(unifiedKycResponse) && Objects.nonNull(unifiedKycResponse.getData())) {
				if (StringUtils.isEmpty(unifiedKycResponse.getData().getTransactionId())) {
					throw new CustomException("1014",Constants.FILED_TXN_ID + Constants.TILDA + MessageConstants.EMPTY_FIELD + unifiedKycResponse.getData().getTransactionId());
				}
				apiStatus = apiStatusRepository.findByTransactionIdAndApiName(
						unifiedKycResponse.getData().getTransactionId(), PL_UNIFIED_KYC_POLLING);
				requestJsonObject = objectMapper.writeValueAsString(unifiedKycResponse);

				apiStatus = apiStatusRepository.findByTransactionIdAndApiNameError(
						unifiedKycResponse.getData().getTransactionId(), PL_UNIFIED_KYC_POLLING);
				requestJsonObject = objectMapper.writeValueAsString(unifiedKycResponse);

				if (apiStatus == null) {
					throw new CustomException("1013",MessageConstants.DETAILS_NOT_FOUND +apiStatus);
				} else {
					apiStatus.setResponseJson(requestJsonObject);
					apiStatusRepository.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), EMPTY);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_UNIFIED_KYC_CALLBACK)
							.accountId(apiStatus.getAccountId()).profileId(EMPTY).requestId(EMPTY)
							.loanId(apiStatus.getLoanId())
							.transactionId(unifiedKycResponse.getData().getTransactionId())
							.requestJson(requestJsonObject).responseJson(responseJsonObject).status(SUCCESS)
							.httpStatusCode(HttpStatus.OK.value()).active(Boolean.FALSE).build(), null);

					// PL_LEAD_UPDATE
					String kycStatus = unifiedKycResponse.getData().getKycStatus();
					Long custId = apiStatus.getCustomerId();
					String accountId = apiStatus.getAccountId();
					String loanId = apiStatus.getLoanId();
					new Thread(() -> {
						if (!isEmptyOrNull(kycStatus) && REJECTED.equalsIgnoreCase(kycStatus)) {
							LeadDropRequest leadDropRequest = LeadDropRequest.builder()
									.abcd_app_status_code__c(kycStatus).lead_Milestone__c("KYC Pages")
									.customer_id(String.valueOf(custId)).build();
							plCustomerDetailService.updateLeadMileStone(leadDropRequest, loanId, custId, accountId);
						}
					}).start();
				}
			}

			log.info(className + methodName + END);

		}catch (CustomException e) {
			log.info("Error in saveUnifiedKycCallbackDetails API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in saveUnifiedKycCallbackDetails API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in saveUnifiedKycCallbackDetails API: " + e.getResponseBodyAsString());
			throw e;
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		} catch (InternalException e) {
			throw e;
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			// Handle other exceptions, if needed
			throw new InternalException("1000" + " " + Constants.PL_UNIFIED_KYC_CALLBACK);
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> initiateUnifiedCkyc(Long customerId, String loanId, String unifiedkycRequest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		UnifiedKycResponse unifiedKycResponse = null;
		KycBizService kycBizService = new KycBizService();
		String jsonResponse = null;
		boolean flag = Boolean.FALSE;
		Object obj = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		JSONObject jsnObj = new JSONObject(unifiedkycRequest);
		String kycType = jsnObj.has("kycType") ? jsnObj.getString("kycType") : "";
		String customerId1 = jsnObj.has("customerId") ? jsnObj.getString("customerId") : "";
		String accountId = jsnObj.has("accountId") ? jsnObj.getString("accountId") : "";
		String ckycAddressConsent = jsnObj.has("kyc_address_consent") ? jsnObj.getString("kyc_address_consent") : "N";
		String ukycAddressConsent = jsnObj.has("ukyc_address_consent") ? jsnObj.getString("ukyc_address_consent") : "N";
		unifiedkycRequest = unifiedkycRequest.replaceAll(accountId, loanId);
		try {
			/**
			 * Input request validation
			 */
			kycBizService.validateUnifiedKycRequest(accountId);
			PLCustomerDetail detail= plCustomerDetailService.findByAccountIdAndLoanIdAndCustomerIdActive(accountId, loanId, customerId, Boolean.FALSE);
			if(null != detail) {
				String ukycInit = detail.getUkycInit();	
				String ukycType = detail.getKycType();
				boolean callUkycCheck = Boolean.FALSE;
				KYCSuccessRequest kycSuccessRequest = null;
				DigilockerSucessRequest digilockerSucessRequest = null;
				if (!isEmptyOrNull(ukycInit) && SUCCESS.equalsIgnoreCase(ukycInit) && !isEmptyOrNull(ukycType)
						&& kycType.equals(ukycType)) {
					// Get UNIFIED_KYC API updated success record from t_pl_apistatus table
					jsonResponse = apiStatusRepository.findResponseByAccountIdAndApiNameAndCustomerIdAndLoanId(accountId, PL_UNIFIED_KYC, customerId, loanId, Boolean.FALSE);
					log.info(className + methodName + " UNIFIED_KYC API record is exist: " + jsonResponse);
					unifiedKycResponse = (null != jsonResponse) ? objectMapper.readValue(jsonResponse, UnifiedKycResponse.class): null;
					// Check eligibility for polling
					if (null != unifiedKycResponse && !isEmptyOrNull(unifiedKycResponse.getResponseStatus())
							&& SUCCESS.equalsIgnoreCase(unifiedKycResponse.getResponseStatus())) {
						flag = Boolean.TRUE;
					}
					obj = unifiedKycResponse;
				} else if (kycType.equals("1")) {
					kycSuccessRequest = objectMapper.readValue(unifiedkycRequest, KYCSuccessRequest.class);
					if (null != kycSuccessRequest && !kycSuccessRequest.getDeclaredAddress()
							.contains(String.valueOf(kycSuccessRequest.getDeclaredPincode()))) {
						kycSuccessRequest.setDeclaredAddress(kycSuccessRequest.getDeclaredAddress() + COMMA
								+ kycSuccessRequest.getDeclaredPincode());
					}
					callUkycCheck = Boolean.TRUE;
				} else if (kycType.equals("2")) {
					digilockerSucessRequest = objectMapper.readValue(unifiedkycRequest, DigilockerSucessRequest.class);
					digilockerSucessRequest.setOkycXml(digilockerSucessRequest.getOkycXml());
					if (null != digilockerSucessRequest && !digilockerSucessRequest.getDeclaredAddress()
							.contains(String.valueOf(digilockerSucessRequest.getDeclaredPincode()))) {
						digilockerSucessRequest.setDeclaredAddress(digilockerSucessRequest.getDeclaredAddress() + COMMA
								+ digilockerSucessRequest.getDeclaredPincode());
					}
					callUkycCheck = Boolean.TRUE;
				}
				// call UNIFIED_KYC API
				if(callUkycCheck) {
					apiResponse = callUnifiedCkycApi(kycSuccessRequest, digilockerSucessRequest, loanId, customerId, accountId);
					if (validateResponse(apiResponse)) {
						if (null != apiResponse && null != apiResponse.getBody()) {
							unifiedKycResponse = (UnifiedKycResponse) apiResponse.getBody();
							// Check eligibility for polling
							if (null != unifiedKycResponse && !isEmptyOrNull(unifiedKycResponse.getResponseStatus())
									&& SUCCESS.equalsIgnoreCase(unifiedKycResponse.getResponseStatus())) {
								flag = Boolean.TRUE;
								// PL_JOURNEY_AUDIT
								plCustomerDetailDto.setAccountId(accountId);
								plCustomerDetailDto.setCustomerId(customerId);
								plCustomerDetailDto.setLoanId(loanId);
								plCustomerDetailDto.setKycAddressConsent(ckycAddressConsent);
								plCustomerDetailDto.setKycAddressConsentDatetime(new Timestamp(new Date().getTime()));
								plCustomerDetailDto.setUkycAddressConsent(ukycAddressConsent);
								plCustomerDetailDto.setUkycAddressConsentDatetime(new Timestamp(new Date().getTime()));
								plCustomerDetailDto.setTransactionId(unifiedKycResponse.getData().getTransactionId());
								plCustomerDetailDto.setKycType(kycType);
								plCustomerDetailDto.setUkycInit(unifiedKycResponse.getResponseStatus());
								plCustomerDetailDto.setUkycInitTime(new Timestamp(new Date().getTime()));
								plCustomerDetailDto.setCurrentScreen("Selfie Page");
								plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, detail);
							}
						}
						obj = unifiedKycResponse;
					} else {
						obj = apiResponse.getBody();
						//Handled from Front end in new build
						/*if(!apiResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT) && apiResponse.getStatusCode().is4xxClientError()) {
							apiStatusRepository.updateStatusError(apiNameList(whiteListedServices), accountId,UKYC_ERROR, new Timestamp(new Date().getTime()));
							plCustomerDetailService.auditCustomerDetailsError(PLCustomerDetailDto.builder().accountId(accountId).ukycInit(UKYC_ERROR).build(), detail);	
						}*/
					}
				}
			}else{
				log.info(className + methodName + "UNIFIED_KYC Response not Available");
				throw new CustomException("1000",MessageConstants.INVALID_DETAILS + detail);
			}
			
			if (flag) {
				new Thread(() -> {
					// Call UNIFIED_KYC_POLLING (DB/API)
					ResponseEntity<Object> apiResponse1=null;
					try {
						apiResponse1 = getUnifiedKycPollinStatus(accountId,customerId,loanId);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						if (validateResponse(apiResponse1)) {
							UnifiedKycPollingResponse response = (UnifiedKycPollingResponse) apiResponse1.getBody();
							if (null != response && null != response.getResponseStatus()
									&& (null != response.getData() && null != response.getData().getKycStatus()
													&& INPROGRESS.equalsIgnoreCase(response.getData().getKycStatus()))) {
								log.info(className + methodName + " Initiating Asynchronous call - UNIFIED_KYC_POLLING API with Retry ");
								// Asynchronous call - with Retry
								callUnifiedKycPollingStatus(accountId,customerId,loanId);
							}
						}
					} catch (CustomException | RetryException e) {
						e.printStackTrace();
					}
				}).start();
			}
		}catch (CustomException e) {
			log.info("Error in initiateUnifiedCkyc API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in initiateUnifiedCkyc API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in initiateUnifiedCkyc API: " + e.getResponseBodyAsString());
			throw e;
		}  catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		} catch (Exception ex) {
	        log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
	        // Handle other exceptions, if needed
	        throw new InternalException("1001");
	    }
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public UnifiedKycPollingResponse callUnifiedKycPollingStatus(String accountId,Long customerId,String loanId)
			throws RetryException, CustomException {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		UnifiedKycPollingResponse response = null;
		CommonBizService bizService = new CommonBizService();
		List<RetryConfg> configList = bizService.getRetryConfig(unifiedKycRetryConfig);
		log.info(className + methodName + " Retry Configuration: " + unifiedKycRetryConfig);
		for (RetryConfg confg : configList) {
			try {
				// External Api with Retry
				response = getUnifiedKycPollingStatusRetry(accountId, confg.getMaxAttempts(), confg.getDelay(),customerId,loanId);
				// Stop processing
				// Check null for REJECTED scenario
				if (null == response || ((null != response.getData() && null != response.getData().getKycStatus()
						&& !INPROGRESS.equalsIgnoreCase(response.getData().getKycStatus())))) {
					break;
				}
			} catch (CustomException | RetryException ex) {
				log.error(className + methodName + EXCEPTION + ex.getMessage());
				throw ex;
			} catch (HttpClientErrorException e) {
				log.error("Error in callUnifiedKycPollingStatus API: " + e.getResponseBodyAsString());
				throw e;
			} catch (HttpServerErrorException e) {
				log.error("Error in callUnifiedKycPollingStatus API: " + e.getResponseBodyAsString());
				throw e;
			} catch (Exception ex) {
		        log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		        // Handle other exceptions, if needed
		        throw new InternalException("1001");
		    }
		}
		return response;
	}
	
	public UnifiedKycPollingResponse getUnifiedKycPollingStatusRetry(String accountId, int maxAttempts,
			long backOffPeriod,Long customerId,String loanId) throws RetryException, CustomException {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		CommonBizService bizService = new CommonBizService();
		RetryTemplate retryTemplate = bizService.createRetryTemplate(maxAttempts, backOffPeriod);

		RetryCallback<UnifiedKycPollingResponse, RetryException> retryCallback = context -> {
			UnifiedKycPollingResponse response = null;
			// Call External Api
			ResponseEntity<Object> apiResponse = callUnifiedKycPollingApi(accountId,customerId,loanId);
			if (validateResponse(apiResponse)) {
				response = (UnifiedKycPollingResponse) apiResponse.getBody();
				log.info(className + methodName + " Count:: " + context.getRetryCount());

				if (null != response && (null != response.getData() && null != response.getData().getKycStatus()
								&& INPROGRESS.equalsIgnoreCase(response.getData().getKycStatus()))) {
					log.info(className + methodName + " ResponseStatus: " + response.getResponseStatus() + "]");
					throw new RetryException(response.getResponseStatus(), response.getData());
				} else {
					String status = null != response && null != response.getResponseStatus() ? response.getResponseStatus()
							: Constants.EMPTY;
					log.info(className + methodName + " ResponseStatus Changed To " + status);
				}
			}
			
			return response;
		};

		RecoveryCallback<UnifiedKycPollingResponse> recoveryCallback = context -> {
			log.info(className + methodName + " Recovery action taken");
			return new UnifiedKycPollingResponse(Constants.IN_PROGRESS);
		};

		return retryTemplate.execute(retryCallback, recoveryCallback);

	}
	@Override
	public ResponseEntity<Object> getUnifiedKycPollinStatus(String accountId, Long customerId, String loanId) throws Exception {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		UnifiedKycPollingResponse unifiedkycPollingResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		boolean flag = Boolean.FALSE;
		// Check whether UNIFIED_KYC_POLLING exist in DB
		String jsonResponse = apiStatusRepository.findResponseByAccountIdAndApiNameAndCustomerIdAndLoanId(accountId, PL_UNIFIED_KYC_POLLING,customerId,loanId,Boolean.FALSE);
		try {
			if (!isEmptyOrNull(jsonResponse)) {
			log.info("UNIFIED_KYC_POLLING api record is exist: " + jsonResponse);
				try {
					unifiedkycPollingResponse = objectMapper.readValue(jsonResponse, UnifiedKycPollingResponse.class);
					if (null != unifiedkycPollingResponse
							&& (null != unifiedkycPollingResponse.getData()
											&& null != unifiedkycPollingResponse.getData().getKycStatus()
											&& INPROGRESS.equalsIgnoreCase(
													unifiedkycPollingResponse.getData().getKycStatus()))) {
						flag = Boolean.TRUE;
					}
				} catch (JsonProcessingException ex) {
					log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
				}catch (Exception ex) {
					log.info("pl-Rest-connector-Exception " + ex.getMessage());
					String errorResponseJsonObject = objectMapper.writeValueAsString(ex.getMessage());
					throw new InternalException("1004");
				}
			obj = unifiedkycPollingResponse;
		} else {
			flag = Boolean.TRUE;
		}
		if (flag) {
			try {
				apiResponse = callUnifiedKycPollingApi(accountId,customerId,loanId);
				if (validateResponse(apiResponse)) {
					unifiedkycPollingResponse = (UnifiedKycPollingResponse) apiResponse.getBody();
					obj = unifiedkycPollingResponse;
				} else {
					obj = apiResponse.getBody();
				}
			} catch (Exception ex) {
				log.info("pl-Rest-connector-Exception " + ex.getMessage());
				String errorResponseJsonObject = objectMapper.writeValueAsString(ex.getMessage());
				throw new InternalException("1004");
			}
		 }
		}catch (CustomException e) {
			log.info("Error in getUnifiedKycPollinStatus API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in getUnifiedKycPollinStatus API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in getUnifiedKycPollinStatus API: " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception ex) {
			log.info("pl-Rest-connector-Exception " + ex.getMessage());
			throw new InternalException("1004");
			}

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callUnifiedCkycApi(KYCSuccessRequest kycSuccessRequest,
			DigilockerSucessRequest digilockerSucessRequest, String loanId, Long customerId, String accountIdAbc) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		UnifiedKycResponse unifiedkycResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		KycBizService kycBizService = new KycBizService();
		Map<String, Object> map = null;
		Object obj = null;
		Object request = null;
		String accountId = null;
		String transactionId = null;
		String jsonResponse = null;
		ApiStatus apiStatus = null;

		if (null != kycSuccessRequest) {
			request = kycSuccessRequest;
			accountId = kycSuccessRequest.getAccountId();
			transactionId = kycSuccessRequest.getTransactionId();
		} else if (null != digilockerSucessRequest) {
			request = digilockerSucessRequest;
			accountId = digilockerSucessRequest.getAccountId();
			transactionId = digilockerSucessRequest.getTransactionId();
		}
		try {
			/**
			 * Input request validation
			 */
			accountId = kycBizService.validateUnifiedKycRequest(accountId);
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_UNIFIED_KYC).accountId(accountIdAbc)
					.profileId(EMPTY).requestId(EMPTY).transactionId(transactionId).url(unifiedkycUrl)
					.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
					.request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, UnifiedKycResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					if (null != apiResponse && null != apiResponse.getBody()) {
						unifiedkycResponse = (UnifiedKycResponse) apiResponse.getBody();
					}
					obj = unifiedkycResponse;
				} else {
					if (null != apiResponse && null != apiResponse.getBody()) {
						String json = objectMapper.writeValueAsString(apiResponse.getBody());
						String errCode = EMPTY;
						if (!isEmptyOrNull(json)) {
							JSONObject errorResponse = new JSONObject(json);
							JSONObject errorObj = null;
							if (errorResponse.has("error")) {
								errorObj = errorResponse.getJSONObject("error");
								if (errorObj.has("code")) {
									errCode = errorObj.getString("code");
								}
							}
							if (!isEmptyOrNull(errCode) && MAX_RETRIES_EXCEEDED.equalsIgnoreCase(errCode)) {
								// MAX_RETRIES_EXCEEDED scenario
								// Get UNIFIED_KYC api updated success record from t_pl_apistatus table
								apiStatus = apiStatusRepository.findByAccountIdAndApiNameAndCustomerIdAndLoanId(accountId, loanId, customerId, PL_UNIFIED_KYC, Boolean.FALSE);
								if (null != apiStatus) {
									jsonResponse = apiStatus.getResponseJson();
									log.info(className + methodName + " UNIFIED_KYC api record is exist: "
											+ jsonResponse);
									unifiedkycResponse = objectMapper.readValue(jsonResponse, UnifiedKycResponse.class);
									obj = unifiedkycResponse;
								} else {
									obj = apiResponse.getBody();
								}
							} else {
								obj = apiResponse.getBody();
							}
						}
					}			
				}
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatusByLoanId = (ApiStatus) map.get(API_STATUS);
				updateApiStatusByLoanId(customerId, apiStatusByLoanId, loanId);
			}
		}catch (CustomException e) {
			log.info("Error in callUnifiedCkycApi API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in callUnifiedCkycApi API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in callUnifiedCkycApi API: " + e.getResponseBodyAsString());
			throw e;
		} catch(InternalException e) {
			throw e;
		}catch (Exception ex) {
			ex.printStackTrace();
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1010");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	public void updateApiStatusByLoanId(Long customerId, ApiStatus apiStatus, String loanId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			if (null != apiStatus) {
				apiStatus.setLoanId(loanId);
				apiStatus.setCustomerId(customerId);
				apiStatus.setModifiedBy(CREATED_BY);
				apiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
			}
			apiService.savOrUpdateApiStatus(apiStatus);

		}catch (CustomException e) {
			log.info("Error in updateApiStatusByLoanId API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in updateApiStatusByLoanId API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in updateApiStatusByLoanId API: " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}


	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> callUnifiedKycPollingApi(String accountId,Long customerId,String loanId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		UnifiedKycPollingResponse unifiedkycPollingResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		ApiStatus apiStatus = null;
		Map<String, Object> map = null;
		KycBizService kycBizService = new KycBizService();
		Object obj = null;
			/**
			 * Input request validation
			 */
		try {
			accountId = kycBizService.validateCkycRequest(accountId);
			if (!isEmptyOrNull(accountId)) {
				PLCustomerDetail detail = plCustomerDetailService.findByAccountIdAndLoanIdAndCustomerIdActive(accountId, loanId, customerId, Boolean.FALSE);
				if (null != detail && !isEmptyOrNull(detail.getUkycInit())
						&& (SUCCESS.equalsIgnoreCase(detail.getUkycInit())
								|| RETRYABLE_TRUE.equalsIgnoreCase(detail.getUkycInit()))) {
					// Prepare unifiedKycPollingRequest
					UnifiedKycPollingRequest unifiedKycPollingRequest = new UnifiedKycPollingRequest();
					unifiedKycPollingRequest.setAccountId(loanId);
					unifiedKycPollingRequest.setCccId(detail.getCccId());
					unifiedKycPollingRequest.setTransactionId(detail.getTransactionId());
					// Get UNIFIED_KYC_POLLING api updated success record from api_status table
					apiStatus = apiStatusRepository.findByAccountIdAndApiNameAndCustomerIdAndLoanId(accountId, loanId, customerId, PL_UNIFIED_KYC_POLLING, Boolean.FALSE);
					/**
					 * External API Call
					 */
					ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_UNIFIED_KYC_POLLING)
							.accountId(accountId).customerId(customerId).profileId(unifiedKycPollingRequest.getCccId())
							.requestId(EMPTY).loanId(loanId)
							.transactionId(unifiedKycPollingRequest.getTransactionId()).url(unifiedkycPollingUrl)
							.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
							.request(unifiedKycPollingRequest).active(Boolean.FALSE).isAudit(Boolean.TRUE).apiStatus(apiStatus)
							.build();

					map = callExternalApi(commonRequest, UnifiedKycPollingResponse.class);

					if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
						if (validateResponse(apiResponse)) {
							if (null != apiResponse && null != apiResponse.getBody()) {
								unifiedkycPollingResponse = (UnifiedKycPollingResponse) apiResponse.getBody();
								CustomerDetails customerDetails = customerDetailsService.findByAccountId(accountId);
								// PL_JOURNEY_AUDIT
								if (null != customerDetails && null != unifiedkycPollingResponse
										&& null != unifiedkycPollingResponse.getData()
										&& null != unifiedkycPollingResponse.getData().getKycStatus()) {
									plCustomerDetailDto.setAccountId(accountId);
									plCustomerDetailDto.setUkycStatus(unifiedkycPollingResponse.getData().getKycStatus());
									plCustomerDetailDto.setUkycTime(new Timestamp(new Date().getTime()));
									plCustomerDetailDto.setCurrentScreen("KYC Pages");
									plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, detail);
									// PL_LEAD_UPDATE
									String kycStatus = unifiedkycPollingResponse.getData().getKycStatus();
									String accountId1 = accountId;
									new Thread(() -> {
										try {
											if (!isEmptyOrNull(kycStatus) && INPROGRESS.equalsIgnoreCase(kycStatus)) {
												LeadDropRequest leadDropRequest = LeadDropRequest.builder()
														.abcd_app_status_code__c(kycStatus)
														.lead_Milestone__c("KYC Pages")
														.customer_id(String.valueOf(customerDetails.getCustomerId()))
														.build();
												plCustomerDetailService.updateLeadMileStone(leadDropRequest,
														loanId,
														customerId,
														accountId1);
											}
										} catch (Exception ex) {
											ex.printStackTrace();
											log.error(className + "[isRetryable]" + EXCEPTION + "[" + ex.getMessage() + "]");
										}
									}).start();
								}
							}
							obj = unifiedkycPollingResponse;
						} else {
							obj = apiResponse.getBody();
							// invalidate UKYC Request
							isRetryable(accountId, loanId, customerId, obj, detail);
							//Handled from Front end in new build
							/*boolean isInvalid = Boolean.FALSE;
							String kycStatus = null;
							JSONObject errorResponse = new JSONObject(apiResponse.getBody());
							if (null != errorResponse && errorResponse.has("error")) {
								JSONObject errorObj = errorResponse.getJSONObject("error");
								if (errorObj.has("kycStatus")) {
									kycStatus = errorObj.getString("kycStatus");
								}
							}
							if (!isEmptyOrNull(kycStatus) && kycStatus.equalsIgnoreCase(REJECTED)) {
								isInvalid = Boolean.TRUE;
							}
							if(!apiResponse.getStatusCode().equals(HttpStatus.PARTIAL_CONTENT) && apiResponse.getStatusCode().is4xxClientError()) {
								isInvalid = Boolean.TRUE;	
							}
							if(isInvalid) {
								apiStatusRepository.updateStatusError(apiNameList(whiteListedServices), accountId,UKYC_POLLING_ERROR, new Timestamp(new Date().getTime()));
								plCustomerDetailService.auditCustomerDetailsError(PLCustomerDetailDto.builder().accountId(accountId).ukycInit(UKYC_POLLING_ERROR).build(), null);
							}*/
						}
					}
				} else {
					String msg = DETAILS_NOT_FOUND;
					if (null != detail) {
						msg = "UNIFIED_KYC Status: " + detail.getUkycStatus() + " " + detail.getUkycInit();
					}
					log.info(className + methodName + msg);
					throw new InternalException(msg);
				}
			}
		}catch (CustomException e) {
			log.info("Error in purgeOldData API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in purgeOldData API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in purgeOldData API: " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception e) {
			throw new InternalException("1011");
		}
			log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}
	
	public void isRetryable(String accountId, String loanId, Long customerId, Object partnerError, PLCustomerDetail detail) {

		boolean isRetryable = false;
		String kycStatus = null;
		final String desc = "isRetryable";
		final String desc1 = "kycStatus";
		final String error = "error";

		if (!isEmptyOrNull(partnerError.toString())) {
			JSONObject errorResponse = new JSONObject(partnerError);
			if (errorResponse.has(error)) {
				JSONObject errorObj = errorResponse.getJSONObject(error);
				if (errorObj.has(desc)) {
					isRetryable = errorObj.getBoolean(desc);
					log.info(className + "[isRetryable: " + isRetryable + "]");
				}
				if (errorObj.has(desc1)) {
					kycStatus = errorObj.getString(desc1);
					log.info(className + "[kycStatus: " + kycStatus + "]");

					// PL_JOURNEY_AUDIT
					PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
					plCustomerDetailDto.setAccountId(accountId);
					plCustomerDetailDto.setUkycStatus(kycStatus);
					plCustomerDetailDto.setUkycTime(new Timestamp(new Date().getTime()));
					if (isRetryable) {
						plCustomerDetailDto.setUkycInit(RETRYABLE_TRUE);
					} else if (!isRetryable) {
						plCustomerDetailDto.setUkycInit(RETRYABLE_FALSE);
					}
					plCustomerDetailDto.setCurrentScreen("KYC Pages");
					plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, detail);

					// PL_LEAD_UPDATE
					String kycStatus1 = kycStatus;
					new Thread(() -> {
						try {
							if (!isEmptyOrNull(kycStatus1) && REJECTED.equalsIgnoreCase(kycStatus1)) {
								LeadDropRequest leadDropRequest = LeadDropRequest.builder()
										.abcd_app_status_code__c(kycStatus1).lead_Milestone__c("KYC Pages").build();
								plCustomerDetailService.updateLeadMileStone(leadDropRequest, loanId, customerId, accountId);
							}
						} catch (Exception ex) {
							ex.printStackTrace();
							log.error(className + "[isRetryable]" + EXCEPTION + "[" + ex.getMessage() + "]");
						}
					}).start();
				}
			}
		}
	}
}
