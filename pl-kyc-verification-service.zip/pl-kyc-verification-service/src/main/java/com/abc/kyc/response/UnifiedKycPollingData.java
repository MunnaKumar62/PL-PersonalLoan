package com.abc.kyc.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UnifiedKycPollingData {
	private String transactionId;
	private String kycStatus;
	private String kycType;
	private String failureReason;
}
