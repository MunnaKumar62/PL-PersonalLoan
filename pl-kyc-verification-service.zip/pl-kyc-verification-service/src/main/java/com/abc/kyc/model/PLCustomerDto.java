package com.abc.kyc.model;


import java.io.Serializable;

import com.abc.kyc.request.CkycAddress;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data

@ToString
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PLCustomerDto {

    private String id;
    private String accountId;
    private String transactionId;
    private String applicationId;
    private String cccId;
    private String mobileNumber;
    private String firstname;
    private String lastname;
    private String middlename;
    private String dateofbirth;
    private String loantype;
    private String pannumber;
    private String aadhaarnumber;
    private String email;
    private String gender;
    private Boolean panCheckFlag;
    private Address address;
    private String ckycDoB;
    private String ckycName;
    private String ckycDocType;
    private CkycAddress ckycAddress;
    private String ckycDocFrontPhoto;
    private String ckycCustomerPhoto;
}

