package com.abc.kyc.response;

import lombok.Data;

@Data
public class PartnerError {
	public Error error;
	public String responseStatus;

}

