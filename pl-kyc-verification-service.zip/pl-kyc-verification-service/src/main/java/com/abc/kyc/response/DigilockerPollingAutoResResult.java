package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingAutoResResult {
    public DigilockerPollingXmlOutput xml_output;

}
