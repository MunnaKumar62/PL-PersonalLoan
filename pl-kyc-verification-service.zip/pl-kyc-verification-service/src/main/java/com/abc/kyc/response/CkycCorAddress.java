package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycCorAddress{
    public String ckyc_cor_add1;
    public String ckyc_cor_add2;
    public String ckyc_cor_add3;
    public String ckyc_cor_add_city;
    public String ckyc_cor_add_country;
    public String ckyc_cor_add_district;
    public String ckyc_cor_add_pin;
    public String ckyc_cor_add_poa;
    public String ckyc_cor_add_state;
}
