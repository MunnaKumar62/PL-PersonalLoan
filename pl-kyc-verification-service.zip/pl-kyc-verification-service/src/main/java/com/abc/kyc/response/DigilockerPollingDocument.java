package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingDocument{
    public String attr;
    public DigilockerPollingLocation location;
    public DigilockerPollingMetadata metadata;
    public String ref_id;
    public int source;
    public String tags;
    public String type;
    public String value;
}
