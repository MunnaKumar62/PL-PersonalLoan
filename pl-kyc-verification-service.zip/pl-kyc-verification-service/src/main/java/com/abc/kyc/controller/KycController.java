package com.abc.kyc.controller;

import com.abc.kyc.exception.CustomException;
import com.abc.kyc.exception.InternalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.request.DigilockerKycRequest;
import com.abc.kyc.request.UnifiedKyccallBackRequest;
import com.abc.kyc.response.DigilockerPollingResponse;
import com.abc.kyc.service.KycService;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.ONE_ABC + Constants.KYC)
public class KycController extends BaseController {

	@Autowired
	private KycService kycService;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	/**
	 * This API is used for AADHAR verification of customer. This will call external api to verify the customer.
	 * @param digilockerKycRequest contains accountid and journeytype.
	 * @return This returns response as object. It contains profileId, captureLink, partner_request_id.
	 * @throws InternalException - If any external api HttpClientErrorException or HttpServerErrorException .
	 */
	@PostMapping(DIGI_LOCKER)
	public ResponseEntity<Object> performDigilockerKYC(@RequestBody DigilockerKycRequest digilockerKycRequest)throws Exception {
		auditUrl();
		return kycService.initiateDigilockerKYC(digilockerKycRequest);
	}

	/**
	 * This API is used for DIGI LOCKER POLLING Api. This used to get the status of AADHAR verification of customer.
	 * @param accountId
	 * @return It returns an object. It contains the status and other aadhar verification details.
	 * @throws InternalException - If any external api HttpClientErrorException or HttpServerErrorException or any Invalid details provided
	 * or Request Parameter is Empty.
	 */
	@GetMapping(DIGI_LOCKER_POLLING)
	public ResponseEntity<Object> getDigilockerKYCDetails(@PathVariable String accountId,
			@PathVariable Long customerId, @PathVariable String loanId) throws Exception {
		auditUrl();
		return kycService.callDigilockerKycPollingApi(accountId, customerId, loanId);
	}

	/**
	 * This API is used for
	 * This API method will call by external api to confirm DIGI LOCKER polling is happened for that particular account id
	 * and insertion will happen in apistatus table for this callback api.
	 * @param digilockerPollingResponse this request pojo object contains profileid and digi locker details, kycresponsedata.
	 * @return It will return response object, it is containing code and status and timestamp. Code is static value PL2205 and
	           status is message like success.
	 * @throws InternalException - If any Invalid details provided.
	 */
	@PostMapping(DIGI_LOCKER_CALLBACK)
	public ResponseEntity<Object> saveDigilockerCallbackDetails(
			@RequestBody DigilockerPollingResponse digilockerPollingResponse)throws Exception {
		auditUrl();
		return kycService.saveDigilockerCallbackDetails(digilockerPollingResponse);
	}

	/**
	 * This API is used to validate the face match selfi kyc details by calling external api.
	 * @param request contains cccId, email, gender, mobile, selfie object.
	 * @return response object contains responseStatus and transaction id.
	 * @throws InternalException - Invalid details provided, kyc error while fetching detail or external api client exception.
	 */
	@PostMapping(UNIFIED_CKYC)
	public ResponseEntity<Object> performUnifiedCkyc(@PathVariable Long customerId,@PathVariable String loanId,@RequestBody String request)throws Exception {
		auditUrl();
		return kycService.initiateUnifiedCkyc(customerId,loanId,request);
	}

	/**
	 * This API is used to fetch the Kyc fact math Polling Status by calling external API.
	 * @param accountId
	 * @return Returns a response as object, contains the kycStatus and kycType and transactionId and responseStatus.
	 * @throws InternalException - kyc error while fetching detail or details not found or external api client exception.
	 */
	@GetMapping(UNIFIED_CKYC_POLLING)
	public ResponseEntity<Object> getUnifiedKYCDetails(@PathVariable String accountId,@PathVariable Long customerId,@PathVariable String loanId)throws Exception {
		auditUrl();
		return kycService.getUnifiedKycPollinStatus(accountId,customerId,loanId);
	}

	/**
	 * This API method will call by external api to confirm Unified KYC polling is happened for that particular account id
	 * and insertion will happen in apistatus table for this callback api.
	 * @param unifiedKycResponse contains transaction id, kycType, kycStatus, failureReason, responseStatus.
	 * @return It will return response object, it is containing code and status and timestamp. Code is static value PL2205 and
	 * 	 status is message like success.
	 * @throws CustomException, InternalException - If details not provided or any other exception.
	 */
	@PostMapping(UNIFIED_CKYC_CALLBACK)
	public ResponseEntity<Object> saveUnifiedKycCallbackDetails(
			@RequestBody UnifiedKyccallBackRequest unifiedKycResponse) throws Exception {
		auditUrl();
		return kycService.saveUnifiedKycCallbackDetails(unifiedKycResponse);
	}
}
