package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@ToString
@Getter
@Setter
public class DigilockerPollingXmlOutput{
    public DigilockerPollingAddress address;
    public int age;
    public String dob;
    public String doc_type;
    public boolean exact_age;
    public String file_format;
    public String gender;
    public Date generated_at;
    public String h;
    public String lang;
    public String name;
    public String reference_id;
    public String status;
    public String street_address;
    public String task_id;
    public String uid;
}
