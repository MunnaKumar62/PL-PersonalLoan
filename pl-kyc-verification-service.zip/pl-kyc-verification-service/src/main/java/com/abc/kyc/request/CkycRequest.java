package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class CkycRequest {

	@JsonProperty("account_id")
	private String accountId;

	@JsonProperty("dob")
	private String dob;

	@JsonProperty("pan_number")
	private String panNumber;
}
