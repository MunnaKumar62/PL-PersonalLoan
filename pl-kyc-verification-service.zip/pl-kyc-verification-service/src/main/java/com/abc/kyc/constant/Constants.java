package com.abc.kyc.constant;

public interface Constants {

	public static final String ALL = "*";

	public static final String API = "/api";

	public static final String VERSION = Constants.SLASH + "${pl.url.version}";

	public static final String ONE_ABC = "/oneabc";

	public static final String KYC = "/kyc";

	public static final String DIGI_LOCKER = "/digilocker";

	public static final String DIGI_LOCKER_POLLING = "/digilockerDetails/{accountId}/{customerId}/{loanId}";

	public static final String UNIFIED_CKYC = "/unifiedCkyc/{customerId}/{loanId}";

	public static final String UNIFIED_CKYC_POLLING = "/unifiedDetails/{accountId}/{customerId}/{loanId}";

	public static final String DIGI_LOCKER_CALLBACK = "/digilockerCallback";

	public static final String UNIFIED_CKYC_CALLBACK = "/unifiedCallback";

	public static final String PL_JOURNEY = "PL";

	public static final String PL_AUTH_TOKEN = "AUTH_TOKEN";

	public static final String DATE_FORMAT = "yyyy-MM-dd";

	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy hh:mm:ss a";

	public static final String DOB_FORMAT = "dd-MM-yyyy";

	public static final String BEGIN = " Begin";

	public static final String END = " End";

	public static final String EXCEPTION = "[EXCEPTION]";

	public static final String FINALLY_BLOCK = "[FINALLY_BLOCK]";

	public static final String SUCCESS = "success";

	public static final String ERROR = "error";
	
	public static final String UKYC_ERROR = "UKYC_ERROR";
	
	public static final String UKYC_POLLING_ERROR = "UKYC_POLLING_ERROR";

	public static final String ERROR_ = "ERROR_";

	public static final String FAIL = "fail";

	public static final String SLASH = "/";

	public static final String EMPTY = "";

	public static final String COMMA = ",";

	public static final String TILDA = "~";

	public static final String UNDER_SQUARE = "_";

	public static final String YES = "Y";

	public static final String NO = "N";

	public static final String INPROGRESS = "In Progress";

	public static final String IN_PROGRESS = "in_progress";

	public static final String REJECTED = "REJECTED";

	public static final String API_STATUS = "API_STATUS";

	public static final String API_RESPONSE = "API_RESPONSE";

	public static final int STATUS_CODE_400 = 400;

	public static final String CLIENT_ID = "client_id";

	public static final String SCOPE = "scope";

	public static final String GRANT_TYPE = "grant_type";

	public static final String AUTH_TOKEN = "auth-token";

	public static final String CREATED_BY = "system";

	public static final String FILED_ACC_ID = "accountId";

	public static final String FILED_REQUEST_ID = "request_id";

	public static final String FILED_OKYC_XML = "okycXml";

	public static final String FILED_TXN_ID = "transactionId";

	public static final String PL_UNIFIED_KYC = "UNIFIED_KYC";

	public static final String PL_DIGI_LOCKER = "DIGI_LOCKER";

	public static final String PL_DIGI_LOCKER_POLLING = "DIGI_LOCKER_POLLING";

	public static final String PL_DIGI_LOCKER_CALLBACK = "DIGI_LOCKER_CALLBACK";

	public static final String PL_UNIFIED_KYC_POLLING = "UNIFIED_KYC_POLLING";

	public static final String PL_UNIFIED_KYC_CALLBACK = "UNIFIED_KYC_CALLBACK";

	public static final String MAX_RETRIES_EXCEEDED = "MAX_RETRIES_EXCEEDED";

	public static final String PL_LEAD_UPDATE = "LEAD_UPDATE";

	public static final String RETRYABLE_TRUE = "isRetryable-true";

	public static final String RETRYABLE_FALSE = "isRetryable-false";

	public static final String LOCALE_MESSAGE_COUNTRYCODE = "IN";

	public static final String LOCALE_MESSAGE_ENGLISH = "en";

	public static final String TECHNICAL_ERROR = "technical-error";

}
