package com.abc.kyc.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.abc.kyc.response.*;
import com.abc.kyc.response.Error;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.sql.Timestamp;

//@ControllerAdvice
public class KYCExceptionHandler extends ResponseEntityExceptionHandler {
	/*
	 * @Autowired private ObjectMapper objectMapper;
	 * 
	 * @ExceptionHandler(KYCNotFoundException.class) protected
	 * ResponseEntity<ErrorResponseVO> handleKycNotFoundException(){ Timestamp
	 * timestamp = new Timestamp(System.currentTimeMillis()); ErrorResponseVO
	 * errorResponseVO = new ErrorResponseVO(timestamp.toString(),"ERROR",new
	 * Error("NOT_FOUND","KYC Details not found","Details missing")); return new
	 * ResponseEntity<>(errorResponseVO, HttpStatus.NOT_FOUND); }
	 * 
	 * @ExceptionHandler(Exception.class) protected ResponseEntity<ErrorResponseVO>
	 * handleException(Exception e){ String errorMessage = e.getMessage();
	 * System.out.println("errorMessage: "+errorMessage);
	 * 
	 * ErrorResponseVO errorResponseVO = new ErrorResponseVO(); //401 Unauthorized:
	 * [no body] if(errorMessage.equalsIgnoreCase("401 Unauthorized: [no body]")) {
	 * errorMessage="User not authenticated"; Timestamp timestamp = new
	 * Timestamp(System.currentTimeMillis()); errorResponseVO = new
	 * ErrorResponseVO(timestamp.toString(),"ERROR",new
	 * Error("INVALID_CREDENTIALS",errorMessage,"Provided credentials are wrong"));
	 * return new ResponseEntity<>(errorResponseVO, HttpStatus.UNAUTHORIZED ); }
	 * 
	 * if (errorMessage != null && errorMessage.contains("error")) { int f =
	 * errorMessage.indexOf("{", 0); int l = errorMessage.lastIndexOf("}");
	 * 
	 * String substr = (String) errorMessage.subSequence(f, l + 1);
	 * System.out.println("substr: "+substr);
	 * 
	 * KycResponse kycResponse; try { kycResponse =
	 * objectMapper.readValue(substr,KycResponse.class); } catch
	 * (JsonProcessingException ex) { Timestamp timestamp = new
	 * Timestamp(System.currentTimeMillis()); errorResponseVO = new
	 * ErrorResponseVO(timestamp.toString(),"ERROR",new
	 * Error("INVALID_JSON","Json Processing Error","Json incorrect")); return new
	 * ResponseEntity<>(errorResponseVO, HttpStatus.INTERNAL_SERVER_ERROR); }
	 * Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	 * errorResponseVO.setTimestamp(timestamp.toString());
	 * errorResponseVO.setStatus(kycResponse.getResponseStatus()); String
	 * description=kycResponse.getError().getDescription();
	 * if(kycResponse.getError().getErrors() != null){ for(KycResponseError res:
	 * kycResponse.getError().getErrors()){ description = description
	 * +", "+res.getDescription(); } }
	 * 
	 * errorResponseVO.setErrors(new
	 * Error(kycResponse.getError().getCode(),description,
	 * kycResponse.getError().getErrorType() != null ?
	 * kycResponse.getError().getErrorType() : "Partner Issue"));
	 * 
	 * } return new ResponseEntity<>(errorResponseVO,
	 * HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * //@ExceptionHandler(HttpClientErrorException.class) protected
	 * ResponseEntity<ErrorResponseVO>
	 * handleClientException(HttpClientErrorException e){ Timestamp timestamp = new
	 * Timestamp(System.currentTimeMillis()); ErrorResponseVO errorResponseVO = new
	 * ErrorResponseVO(timestamp.toString(),"ERROR",new
	 * Error(e.getStatusCode().toString(),e.getMessage(),"Client Error")); return
	 * new ResponseEntity<>(errorResponseVO, e.getStatusCode()); }
	 * 
	 * //@ExceptionHandler(HttpServerErrorException.class) protected
	 * ResponseEntity<ErrorResponseVO>
	 * handleServerException(HttpServerErrorException e){ Timestamp timestamp = new
	 * Timestamp(System.currentTimeMillis()); ErrorResponseVO errorResponseVO = new
	 * ErrorResponseVO(timestamp.toString(),"ERROR",new
	 * Error(e.getStatusCode().toString(),e.getMessage(),"Server Error")); return
	 * new ResponseEntity<>(errorResponseVO, e.getStatusCode()); }
	 */

}
