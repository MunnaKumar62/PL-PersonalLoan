package com.abc.kyc.service.biz;

import org.springframework.stereotype.Component;

import com.abc.kyc.constant.Constants;
import com.abc.kyc.constant.MessageConstants;
import com.abc.kyc.exception.InternalException;
import com.abc.kyc.request.DigilockerKycRequest;

@Component
public class KycBizService implements Constants, MessageConstants {

	public DigilockerKycRequest validateDigilockerKycRequest(DigilockerKycRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (isEmptyOrNull(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			throw new InternalException("1005"," "+msg);
		}
		return request;
	}

	public String validateCkycRequest(String accountId) {

		String msg = EMPTY;
		boolean flag = Boolean.TRUE;
		if (isEmptyOrNull(accountId)) {
			msg = FILED_ACC_ID + TILDA + EMPTY_PARAM;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			throw new InternalException("1005"," "+msg);
		}
		return accountId;
	}
	
	public String validateUnifiedKycRequest(String accountId) {

		String msg = EMPTY;
		boolean flag = Boolean.TRUE;
		if (isEmptyOrNull(accountId)) {
			msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			throw new InternalException("1005"," "+msg);
		}
		return accountId;
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
}
