package com.abc.kyc.service;

import org.springframework.http.ResponseEntity;

import com.abc.kyc.exception.CustomException;
import com.abc.kyc.exception.RetryException;
import com.abc.kyc.request.DigilockerKycRequest;
import com.abc.kyc.request.DigilockerSucessRequest;
import com.abc.kyc.request.KYCSuccessRequest;
import com.abc.kyc.request.UnifiedKyccallBackRequest;
import com.abc.kyc.response.DigilockerPollingResponse;
import com.abc.kyc.response.UnifiedKycPollingResponse;

public interface KycService {
	
	public ResponseEntity<Object> initiateDigilockerKYC(DigilockerKycRequest digilockerKycRequest) throws Exception;
	
	public ResponseEntity<Object> callDigilockerKycPollingApi(String accountId,Long customerId,String loanId )throws Exception;
	
	public ResponseEntity<Object> saveDigilockerCallbackDetails(DigilockerPollingResponse digilockerPollingResponse)throws Exception;

	public ResponseEntity<Object> saveUnifiedKycCallbackDetails(UnifiedKyccallBackRequest unifiedKycResponse)throws Exception;

	public ResponseEntity<Object> initiateUnifiedCkyc(Long customerId, String loanId,String request)throws Exception;
	
	public ResponseEntity<Object> callUnifiedCkycApi(KYCSuccessRequest kycSuccessRequest, DigilockerSucessRequest digilockerSucessRequest, String loanId, Long customerId, String accountIdAbc)throws Exception;

	public ResponseEntity<Object> callUnifiedKycPollingApi(String accountId,Long customerId,String loanId)throws Exception;
	
	public ResponseEntity<Object> getUnifiedKycPollinStatus(String accountId,Long customerId,String loanId)throws Exception;

	public UnifiedKycPollingResponse callUnifiedKycPollingStatus(String accountId,Long customerId,String loanId) throws Exception, CustomException;

}
