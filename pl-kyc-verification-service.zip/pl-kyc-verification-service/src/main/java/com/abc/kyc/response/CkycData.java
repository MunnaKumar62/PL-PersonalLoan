package com.abc.kyc.response;

import lombok.ToString;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycData {

	@JsonProperty("request_id")
	private String requestId;
}
