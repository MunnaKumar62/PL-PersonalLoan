package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class CkycPollingSourceOutput {
    public CkycPersonalDetails ckyc_personal_details;
    public CkycRequestStatus ckyc_request_status;
    public String status;
}
