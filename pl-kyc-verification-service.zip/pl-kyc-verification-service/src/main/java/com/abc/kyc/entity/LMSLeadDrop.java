package com.abc.kyc.entity;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Entity
@Table(name="t_lms_lead_drop")
@Data
@EntityListeners(AuditingEntityListener.class)
public class LMSLeadDrop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "lead_drop_lms_id")
    private long id;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "customer_id")
    private long customerId;

    @Column(name = "source")
    private String source;

    @Column(name = "subsource")
    private String subSource;

    @Column(name = "lob_name")
    private String lobname;

    @Column(name = "product_category")
    private String productCategory;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "iscobrowsing")
    private boolean isCoBrowsing = false;

    @Column(name = "reference_id")
    private String referenceId;

    @Column(name = "lead_id")
    private String leadId;

}
