package com.abc.kyc.response;

import java.util.ArrayList;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingTask{
    public String key;
    public ArrayList<String> resources;
    public DigilockerPollingResult result;
    public String status;
    public String task_id;
    public String task_type;
}
