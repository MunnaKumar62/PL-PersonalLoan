package com.abc.kyc.response;

import lombok.*;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class KycResponse {
    private String responseStatus;
    private KycResponseError error;
}
