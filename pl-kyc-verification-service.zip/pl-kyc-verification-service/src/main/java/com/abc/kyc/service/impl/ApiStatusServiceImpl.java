package com.abc.kyc.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.kyc.entity.ApiStatus;
import com.abc.kyc.repository.ApiStatusRepository;
import com.abc.kyc.service.ApiStatusService;


@Service
public class ApiStatusServiceImpl implements ApiStatusService {

	@Autowired
	ApiStatusRepository apiStatusRepo;

	@Override
	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName, Boolean active) {

		return apiStatusRepo.findByAccountIdAndApiName(accountId, apiName, active);
	}

	@Override
	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus) {

		return apiStatusRepo.save(apiStatus);
	}

}
