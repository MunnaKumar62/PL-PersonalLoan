package com.abc.kyc.response;

import lombok.*;

import java.util.List;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class KycResponseError {
    private String code;
    private String description;
    private String errorType;
    private List<KycResponseError> errors;

    public KycResponseError(String code, String description, String errorType) {
        this.code=code;
        this.description=description;
        this.errorType=errorType;
    }
}
