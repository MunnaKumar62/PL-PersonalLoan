package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@ToString
public class KYCSuccessRequest {
	
	private String kycType;            
	private String accountId;   
	private String cccId;
	private String transactionId;      
	private boolean delinkExisting;    
	private String mobile;             
	private String selfie;             
	private String ckycDocFrontPhoto;  
	private String ckycCustomerPhoto;  
	private String declaredAddress;    
	private String declaredName;       
	private String declaredDoB;        
	private String declaredPAN;        
	private String declaredCity;       
	private String declaredState;      
	private Integer declaredPincode;   
	private String gender;             
	private String email;              
	private String ckycDoB;            
	private String ckycName;           
	private String ckycDocType;   
	private CkycAddress ckycAddress;
	private String nsdlPAN;
	private String nsdlName;
	 
    @JsonProperty("latitude")
    private String latitude;
    
    @JsonProperty("longitude")
    private String longitude;
}
