package com.abc.kyc.exception;

public class KYCNotFoundException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}
