package com.abc.kyc.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CkycPollingResponse {
	
	public CkycPollingResponse(String responseStatus) {
		super();
		this.responseStatus = responseStatus;
	}

	@JsonProperty("request_id")
	public String requestId;

	@JsonProperty("responseStatus")
	public String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	public CkycPollingData data;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;

}
