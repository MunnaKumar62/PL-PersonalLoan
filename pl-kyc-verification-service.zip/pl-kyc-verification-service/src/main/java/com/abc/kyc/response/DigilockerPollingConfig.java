package com.abc.kyc.response;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;

@ToString
@Getter
@Setter
public class DigilockerPollingConfig{
    public String id;
    public String overrides;
}
