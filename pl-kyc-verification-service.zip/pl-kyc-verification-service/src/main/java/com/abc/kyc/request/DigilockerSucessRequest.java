package com.abc.kyc.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DigilockerSucessRequest {
	
	private String kycType;
	private String accountId;
	private String cccId;
	private String transactionId;
	private String selfie;
	private String okycXml;
	private String declaredAddress;
	private String okycDocType;
	private boolean delinkExisting;
	private String declaredName;
	private String declaredDoB;
	private String declaredPAN;
	private String declaredCity;
	private String declaredState;
	private Integer declaredPincode;
	private String email;
	private String mobile;
	private String gender;
	private String nsdlPAN;
	private String nsdlName;
	 
    @JsonProperty("latitude")
    private String latitude;
    
    @JsonProperty("longitude")
    private String longitude;
}
