package com.abc.kyc.response;

import lombok.*;

@ToString
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class ErrorResponseVO {
    private String timestamp;
    private String status;
    private Error errors;
}
