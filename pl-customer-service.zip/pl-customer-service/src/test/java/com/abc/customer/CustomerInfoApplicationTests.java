package com.abc.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerInfoAppliscationTests {

	@Test
	void contextLoads() {
	}

}
