package com.abc.customer.entity;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@Table(name = "t_employee_leads ")
public class EmployeeLeads {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "lead_int_id")
	private Long leadIntId;

	@Column(name = "customer_id")
	private Long customerId;

	@Column(name = "journey")
	private String journey;

	@Column(name = "lob_id")
	private String lobId;

	@Column(name = "page_name")
	private String pageName;

	@Column(name = "channel")
	private String channel;
	
	@Column(name = "url_link")
	private String urlLink;

	@Column(name = "created_by")
	private String createdBy;

	@CreatedDate
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate;

}
