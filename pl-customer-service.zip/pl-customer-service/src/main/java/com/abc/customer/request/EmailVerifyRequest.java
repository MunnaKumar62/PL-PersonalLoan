package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EmailVerifyRequest {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("accountId")
	public String accountId;

	@JsonProperty("entity_id")
	public String entityId;

	@JsonProperty("employer_name")
	public String employerName;

	@JsonProperty("email")
	public String email;

	@JsonProperty("employee_name")
	public String employeeName;
}
