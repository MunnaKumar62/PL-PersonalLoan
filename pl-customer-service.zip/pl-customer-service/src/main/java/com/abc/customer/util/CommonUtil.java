package com.abc.customer.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.WebRequest;

import com.abc.customer.constant.Constants;
import com.abc.customer.dto.PLMISReport;
import com.abc.customer.entity.PLCustomerDetail;
import com.abc.customer.response.FieldError;
import com.abc.customer.response.FieldErrorResponse;
import com.abc.customer.response.SuccessResponse;


@Component
public class CommonUtil implements Constants {

	public static SuccessResponse getSuccessResponse(String code, String message, Object data) {

		SuccessResponse successResponse = new SuccessResponse();
		successResponse.setStatus(Constants.SUCCESS);
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}
	
	public static SuccessResponse getErrorResponse(Object data) {
		SuccessResponse successResponse = new SuccessResponse();
		successResponse.setStatus(Constants.ERROR);
		successResponse.setData(data);
		return successResponse;
	}

	public static FieldErrorResponse getErrorResponse(Exception ex, HttpStatusCode status, WebRequest request) {
		List<FieldError> errorsList = new ArrayList<>();
		String[] arr = new String[2];
		String errorCode = "PL" + "2" + status.value();
		String msg = ex.getMessage();
		arr = null != msg && msg.contains(Constants.TILDA) ? msg.split(Constants.TILDA) : arr;

		String fieldName = !isNullorBlank(arr[0]) ? arr[0] : Constants.EMPTY;
		String message = !isNullorBlank(arr[1]) ? arr[1] : msg;
		String path = null != request ? request.getContextPath() : Constants.EMPTY;
		getErrorList(errorCode, fieldName, message, errorsList);

		return getErrorMessage(path, errorsList);
	}

	public static FieldErrorResponse getErrorMessage(String path, List<FieldError> errorList) {
		FieldErrorResponse errorMessage = new FieldErrorResponse();
		//errorMessage.setTimestamp(LocalDateTime.now().toString());
		errorMessage.setStatus(Constants.ERROR);
		errorMessage.setPath(path);
		errorMessage.setErrors(errorList);
		return errorMessage;
	}

	public static void getErrorList(String errorCode, String fieldName, String message, List<FieldError> errorList) {
		FieldError errors = new FieldError(errorCode, fieldName, message);
		errorList.add(errors);
	}

	public static boolean isNullorBlank(String str) {
		return (null == str || str.isBlank());
	}
	
	public static String encodeBase64(byte [] encodeMe){
	    byte[] encodedBytes = Base64.getEncoder().encode(encodeMe);
	    return new String(encodedBytes) ;
	    } 
	
	public static String decodeBase64(String encodedData){
	    byte[] decodedBytes = Base64.getDecoder().decode(encodedData.getBytes());
	    return new String(decodedBytes);
	    }

	public static void fillData(File xlsxFile, List<PLMISReport> list, String args) {
		try {
			// Creating input stream
			FileInputStream inputStream = new FileInputStream(xlsxFile);
			// Creating workbook from input stream
			Workbook workbook = WorkbookFactory.create(inputStream);
			// Reading first sheet of excel file
			Sheet sheet = workbook.getSheet(args);
			// Getting the count of existing records
			int rowCount1 = sheet.getLastRowNum();
			
			XSSFRow header = (XSSFRow) sheet.getRow(0);
			
			for(int i=1; i<=rowCount1; i++) {
				sheet.removeRow(sheet.getRow(i));
			}
			int rowCount = sheet.getLastRowNum();
			for (PLMISReport report : list) {
				// Creating new row from the next row count
				Row row = sheet.createRow(++rowCount);
				Map<String, Object> map = loadMap(report);
				for (int i = 0; i < header.getLastCellNum(); i++) {
					Cell cell = row.createCell(i);
					Object obj = map.get(header.getCell(i).getStringCellValue());
					String value = Objects.isNull(obj) ? EMPTY : (String) obj;
					cell.setCellValue(value);
				}
			}
			// Close input stream
			inputStream.close();
			// Crating output stream and writing the updated workbook
			FileOutputStream os = new FileOutputStream(xlsxFile);
			workbook.write(os);
		
			// Close the workbook and output stream
			workbook.close();
			os.close();

		} catch (IOException e) {
			System.err.println("Exception while updating an existing excel file.");
			e.printStackTrace();
		}
		
	}

	private static Map<String, Object> loadMap(PLMISReport report) {
		Map<String, Object> map = new LinkedHashMap<>();
		if(null!=report.getPlCustomerDetailDto()) {
		// t_pl_customer_detail table
		map.put("customer_detail_id", convertToString(report.getPlCustomerDetailDto().getCustomerDetailId()));
		map.put("accnt_create_date", convertToString(report.getPlCustomerDetailDto().getAccntCreateDate()));
		map.put("accountid", convertToString(report.getPlCustomerDetailDto().getAccountId()));
		map.put("cccid", convertToString(report.getPlCustomerDetailDto().getCccId()));
		map.put("mobilenumber", convertToString(report.getPlCustomerDetailDto().getMobilenumber()));
		map.put("credit_score", convertToString(report.getPlCustomerDetailDto().getCreditScore()));
		map.put("loan_purpose", convertToString(report.getPlCustomerDetailDto().getLoanPurpose()));
		map.put("firstname_lastname", convertToString(report.getPlCustomerDetailDto().getFirstnameLastname()));
		map.put("pannumber", convertToString(report.getPlCustomerDetailDto().getPannumber()));
		map.put("date_of_birth", convertToString(report.getPlCustomerDetailDto().getDateOfBirth()));
		map.put("gender", convertToString(report.getPlCustomerDetailDto().getGender()));
		map.put("email", convertToString(report.getPlCustomerDetailDto().getEmail()));
		Double breloanAmount = report.getPlCustomerDetailDto().getBreloanAmount();
		map.put("breloan_amount", convertToString(breloanAmount != null ?breloanAmount:0.0));
		Double breroi = report.getPlCustomerDetailDto().getBreroi();
		map.put("breroi", convertToString(breroi != null ?breroi:0.0));
		map.put("bre_offertime", convertToString(report.getPlCustomerDetailDto().getBreOffertime()));
		map.put("bre_reject_reason", convertToString(report.getPlCustomerDetailDto().getBreRejectReason()));
		map.put("emandate_status", convertToString(report.getPlCustomerDetailDto().getEmandateStatus()));
		map.put("eman_datetime", convertToString(report.getPlCustomerDetailDto().getEmanDatetime()));
		map.put("digilocker_status", convertToString(report.getPlCustomerDetailDto().getDigilockerStatus()));
		map.put("digilocker_time", convertToString(report.getPlCustomerDetailDto().getDigilockerTime()));
		map.put("digilocker_consent", convertToString(report.getPlCustomerDetailDto().getDigilockerConsent()));
		map.put("digilocker_consent_datetime", convertToString(report.getPlCustomerDetailDto().getDigilockerConsentDatetime()));
		map.put("ukyc_status", convertToString(report.getPlCustomerDetailDto().getUkycStatus()));
		map.put("ukyc_time", convertToString(report.getPlCustomerDetailDto().getUkycInit()));
		map.put("current_screen", convertToString(report.getPlCustomerDetailDto().getCurrentScreen()));
		map.put("app_platform", convertToString(report.getPlCustomerDetailDto().getAppPlatform()));
		map.put("basic_consent", convertToString(report.getPlCustomerDetailDto().getBasicConsent()));
		map.put("basic_consent_datetime", convertToString(report.getPlCustomerDetailDto().getBasicConsentDatetime()));
		map.put("bank_consent", convertToString(report.getPlCustomerDetailDto().getBankConsent()));
		map.put("bank_consent_datetime", convertToString(report.getPlCustomerDetailDto().getBankConsentDatetime()));
		map.put("docusign_consent", convertToString(report.getPlCustomerDetailDto().getDigisignConsent()));
		map.put("docusign_consent_datetime", convertToString(report.getPlCustomerDetailDto().getDigisignConsentDatetime()));
		map.put("ukyc_address_consent", convertToString(report.getPlCustomerDetailDto().getUkycAddressConsent()));
		map.put("ukyc_address_consent_datetime", convertToString(report.getPlCustomerDetailDto().getUkycAddressConsentDatetime()));
		map.put("bankaccount_id", convertToString(report.getPlCustomerDetailDto().getBankaccountId()));
		map.put("pennydrop_status", convertToString(report.getPlCustomerDetailDto().getPennydropStatus()));
		map.put("bank_detail_validation", convertToString(report.getPlCustomerDetailDto().getBankDetailValidation()));
		map.put("work_email", convertToString(report.getPlCustomerDetailDto().getWorkEmail()));
		map.put("workemail_added_date", convertToString(report.getPlCustomerDetailDto().getWorkemailAddedDate()));
		map.put("transactionid", convertToString(report.getPlCustomerDetailDto().getTransactionId()));
		map.put("applicationid", convertToString(report.getPlCustomerDetailDto().getApplicationId()));
		map.put("salaried", convertToString(report.getPlCustomerDetailDto().getSalaried()));
		map.put("self_employed", convertToString(report.getPlCustomerDetailDto().getSelfEmployed()));
		Double monthlyIncome = report.getPlCustomerDetailDto().getMonthlyIncome();
		map.put("monthly_income", convertToString(monthlyIncome != null ? monthlyIncome : 0.0));
		Double loanAmount = report.getPlCustomerDetailDto().getLoanAmount();
		map.put("loan_amount", convertToString(loanAmount != null ? loanAmount : 0.0));
		map.put("work_address", convertToString(report.getPlCustomerDetailDto().getWorkAddress()));
		map.put("tenure", convertToString(report.getPlCustomerDetailDto().getTenure()));
		map.put("lead_id", convertToString(report.getPlCustomerDetailDto().getLeadId()));
		map.put("active", convertToString(report.getPlCustomerDetailDto().getActive()));
		map.put("created_by", convertToString(report.getPlCustomerDetailDto().getCreatedBy()));
		map.put("modified_by", convertToString(report.getPlCustomerDetailDto().getModifiedBy()));
		map.put("created_date", convertToString(report.getPlCustomerDetailDto().getCreatedDate()));
		map.put("modified_date", convertToString(report.getPlCustomerDetailDto().getModifiedDate()));
		Double bre2loanAmount = report.getPlCustomerDetailDto().getBre2loanAmount();
		map.put("bre2loan_amount", convertToString(bre2loanAmount != null ? bre2loanAmount : 0.0));
		Double bre2roi = report.getPlCustomerDetailDto().getBre2roi();
		map.put("bre2roi", convertToString(bre2roi != null ? bre2roi : 0.0));
		map.put("bre2_offertime", convertToString(report.getPlCustomerDetailDto().getBre2Offertime()));
		map.put("bre2_reject_reason", convertToString(report.getPlCustomerDetailDto().getBre2RejectReason()));
		map.put("ce_status", convertToString(report.getPlCustomerDetailDto().getCeStatus()));
		map.put("ce_2_status", convertToString(report.getPlCustomerDetailDto().getCe2Status()));
		map.put("a8_application_status", convertToString(report.getPlCustomerDetailDto().getA8ApplicationStatus()));
		map.put("a8_callback_resp", convertToString(report.getPlCustomerDetailDto().getA8CallbackResp()));
		map.put("a8_video_pd_status", convertToString(report.getPlCustomerDetailDto().getA8VideoPdStatus()));
		map.put("a8_flg_upd_from", convertToString(report.getPlCustomerDetailDto().getA8FlgUpdFrom()));
		map.put("a8_process_instance_id", convertToString(report.getPlCustomerDetailDto().getA8ProcessInstanceId()));
		map.put("prev_a8_ce_status", convertToString(report.getPlCustomerDetailDto().getPrevA8CeStatus()));
		map.put("a8_fi_status", convertToString(report.getPlCustomerDetailDto().getA8FiStatus()));
		map.put("a8_sanction_details", convertToString(report.getPlCustomerDetailDto().getA8SanctionDetails()));
		map.put("ukyc_init", convertToString(report.getPlCustomerDetailDto().getUkycInit()));
		map.put("kyc_type", convertToString(report.getPlCustomerDetailDto().getKycType()));
		map.put("ukyc_init_time", convertToString(report.getPlCustomerDetailDto().getUkycInitTime()));
		map.put("profileid", convertToString(report.getPlCustomerDetailDto().getProfileid()));
		map.put("income_verify_txnid", convertToString(report.getPlCustomerDetailDto().getIncomeVerifyTxnid()));
		map.put("ce_start", convertToString(report.getPlCustomerDetailDto().getCeStart()));
		map.put("ce_start_datetime", convertToString(report.getPlCustomerDetailDto().getCeStartDatetime()));
		map.put("ce_2_start", convertToString(report.getPlCustomerDetailDto().getCe2Start()));
		map.put("ce_2_start_datetime", convertToString(report.getPlCustomerDetailDto().getCe2StartDatetime()));
		map.put("digilocker_start", convertToString(report.getPlCustomerDetailDto().getDigilockerStart()));
		map.put("digilocker_start_datetime", convertToString(report.getPlCustomerDetailDto().getDigilockerStartDatetime()));
		map.put("personal_details_complete", convertToString(report.getPlCustomerDetailDto().getPersonalDetailsComplete()));
		map.put("personal_details_complete_datetime", convertToString(report.getPlCustomerDetailDto().getPersonalDetailsCompleteDatetime()));
		map.put("work_details_status", convertToString(report.getPlCustomerDetailDto().getWorkDetailsStatus()));
		map.put("work_details_status_datetime", convertToString(report.getPlCustomerDetailDto().getWorkDetailsStatusDatetime()));
		map.put("contact_ref_complete", convertToString(report.getPlCustomerDetailDto().getContactRefComplete()));
		map.put("contact_ref_complete_datetime", convertToString(report.getPlCustomerDetailDto().getContactRefCompleteDatetime()));
		map.put("contact_ref_name1", convertToString(report.getPlCustomerDetailDto().getContactRefName1()));
		map.put("contact_ref_name2", convertToString(report.getPlCustomerDetailDto().getContactRefName2()));
		map.put("contact_ref_mob1", convertToString(report.getPlCustomerDetailDto().getContactRefMob1()));
		map.put("contact_ref_mob2", convertToString(report.getPlCustomerDetailDto().getContactRefMob2()));
		map.put("final_loan_complete", convertToString(report.getPlCustomerDetailDto().getFinalLoanComplete()));
		map.put("final_loan_complete_datetime", convertToString(report.getPlCustomerDetailDto().getFinalLoanCompleteDatetime()));
		map.put("decision_engine_reject_reason", convertToString(report.getPlCustomerDetailDto().getDecisionEngineRejectReason()));
		map.put("bre_sub_reject_reason", convertToString(report.getPlCustomerDetailDto().getBreSubRejectReason()));
		map.put("bre2_sub_reject_reason", convertToString(report.getPlCustomerDetailDto().getBre2SubRejectReason()));
		}
		if(null!=report.getLoanOfferDetailsDto()) {
		// t_pl_loan_offer_details
		map.put("loan_offer_id", convertToString(report.getLoanOfferDetailsDto().getLoanOfferId()));
		map.put("customer_id", convertToString(report.getLoanOfferDetailsDto().getCustomerid()));
		map.put("credited_amount", convertToString(report.getLoanOfferDetailsDto().getCreditedAmount()));
		map.put("interest", convertToString(report.getLoanOfferDetailsDto().getInterest()));
		map.put("loanamount", convertToString(report.getLoanOfferDetailsDto().getLoanAmount()));
		Double monthlyEmi = report.getLoanOfferDetailsDto().getMonthlyEmi();
		map.put("monthly_emi", convertToString(monthlyEmi != null ? monthlyEmi : 0.0));
		Double processingFee = report.getLoanOfferDetailsDto().getProcessingFee();
		map.put("processing_fee", convertToString(processingFee != null ? processingFee : 0.0));
		Double rateOfInterest = report.getLoanOfferDetailsDto().getRateOfInterest();
		map.put("rateof_interest", convertToString(rateOfInterest != null ? rateOfInterest : 0.0));
		map.put("repayment_amount", convertToString(report.getLoanOfferDetailsDto().getRepaymentAmount()));
		map.put("stampduty_charges", convertToString(report.getLoanOfferDetailsDto().getStampDutyCharges()));
		map.put("tenure", convertToString(report.getLoanOfferDetailsDto().getTenure()));
		map.put("offerdate", convertToString(report.getLoanOfferDetailsDto().getOfferDate()));
		map.put("emidate", convertToString(report.getLoanOfferDetailsDto().getEmiDate()));
		map.put("loan_no", convertToString(report.getLoanOfferDetailsDto().getLoanNo()));
		map.put("utrno", convertToString(report.getLoanOfferDetailsDto().getUtrno()));
		map.put("unique_id", convertToString(report.getLoanOfferDetailsDto().getUniqueId()));
		map.put("loan_disbursal_date", convertToString(report.getLoanOfferDetailsDto().getLoanDisbursalDate()));
		map.put("disbursal_status", convertToString(report.getLoanOfferDetailsDto().getDisburalStatus()));
		map.put("loan_type", convertToString(report.getLoanOfferDetailsDto().getLoanType()));
		Double apr = report.getLoanOfferDetailsDto().getApr();
		map.put("apr", convertToString(apr != null ? apr : 0.0));
		map.put("is_avail_coupons", convertToString(report.getLoanOfferDetailsDto().getIsAvailCoupons()));
		map.put("loan_disbursal_start", convertToString(report.getLoanOfferDetailsDto().getLoanDisbursalStart()));
		map.put("loan_disbursal_start_datetime", convertToString(report.getLoanOfferDetailsDto().getLoanDisbursalStartDatetime()));
		}
		if(null!=report.getPlAddressDto()) {
		// t_pl_address
		map.put("address_id", convertToString(report.getPlAddressDto().getAddressId()));
		map.put("address_line_one", convertToString(report.getPlAddressDto().getAddressLineOne()));
		map.put("address_line_two", convertToString(report.getPlAddressDto().getAddressLineTwo()));
		map.put("city", convertToString(report.getPlAddressDto().getCity()));
		map.put("landmark", convertToString(report.getPlAddressDto().getLandmark()));
		map.put("pincode", convertToString(report.getPlAddressDto().getPincode()));
		map.put("state", convertToString(report.getPlAddressDto().getState()));
		map.put("org_addressline_one", convertToString(report.getPlAddressDto().getOrgAddressLineOne()));
		map.put("org_addressline_two", convertToString(report.getPlAddressDto().getOrgAddressLineTwo()));
		map.put("org_city", convertToString(report.getPlAddressDto().getOrgCity()));
		map.put("org_state", convertToString(report.getPlAddressDto().getOrgState()));
		map.put("org_pincode", convertToString(report.getPlAddressDto().getOrgPincode()));
		map.put("org_email", convertToString(report.getPlAddressDto().getOrgEmail()));
		}
		return map;
	}
	
	private static String convertToString(Object obj){
		return Objects.isNull(obj) ? EMPTY : String.valueOf(obj);
	}
}
