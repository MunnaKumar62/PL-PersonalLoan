package com.abc.customer.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.customer.constant.Constants;
import com.abc.customer.exception.CustomException;
import com.abc.customer.exception.InternalException;
import com.abc.customer.request.ApiCommonRequest;
import com.abc.customer.response.TokenResponse;
import com.abc.customer.service.TokenService;
import com.abc.customer.service.biz.CommonBizService;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class TokenServiceImpl extends CommonBizService implements TokenService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${pl.token.client_id}")
	private String clientId;

	@Value("${pl.token.scope}")
	private String inputScope;

	@Value("${pl.token.grant_type}")
	private String grantType;

	@Value("${pl.token.auth}")
	private String authToken;

	@Override
	public String getAccessToken() {

		ResponseEntity<Object> apiResponse = callTokenApi();
		String token = EMPTY;
		if (null != apiResponse && null != apiResponse.getBody()) {
			TokenResponse response = (TokenResponse) apiResponse.getBody();
			token = null != response && null != response.getAccessToken() ? response.getAccessToken() : token;
		}
		return token;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callTokenApi() {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;

		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam(CLIENT_ID, clientId)
					.queryParam(SCOPE, inputScope).queryParam(GRANT_TYPE, grantType).build();
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_AUTH_TOKEN)
					.requestHeaders(getTokenRequestHeaders(authToken)).url(builder.toUriString())
					.method(HttpMethod.POST).request(null).accountId(EMPTY).profileId(EMPTY).requestId(EMPTY)
					.transactionId(EMPTY).active(true).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, TokenResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}

		}catch (CustomException e) {
			log.info("Error in callTokenApi API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in callTokenApi API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in callTokenApi API: " + e.getResponseBodyAsString());
			throw e;
		}   catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1003");

		}
		log.info(className + methodName + END);

		return apiResponse;
	}

}
