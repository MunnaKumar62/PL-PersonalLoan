/*******************************************************************************
 *
 * BaseResponse.java
 *
 * Copyright (c) 2008-2021 Avaya Inc., All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 *
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 * Some third-party source code components may have  been modified from their
 * original versions by Avaya Inc.
 *
 * The modifications are Copyright Avaya Inc., All Rights Reserved.
 * Avaya (tm) Confidential & Restricted. May not be distributed further
 * without written permission of the Avaya owner.
 *
 ******************************************************************************/

package com.abc.customer.response;

import java.io.Serializable;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.abc.customer.model.APIError;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

/**
 * Base class for API responses. See {@link SingleResponse} and {@link ListResponse}
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class CCIDBaseResponse {
    private String responseStatus;
    private CCIDResponse data;
    @JsonProperty("Error")
    private APIError error;
}
