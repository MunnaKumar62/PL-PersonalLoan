package com.abc.customer.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_pl_bank_list")
public class PLBank {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "plbank_id")
	private Long bankId;

	@Column(name = "name")
	private String name;

	@Column(name = "fullname")
	private String fullName;

	@Column(name = "aa_available")
	private String aaAvailable;

	@Column(name = "netbanking_available")
	private String netbankingAvailable;

	@Column(name = "fip_mapping")
	private String fipMapping;

	@Column(name = "netbanking_mapping")
	private String netbankingMapping;

	@Column(name = "logo_url")
	private String logoUrl;

}
