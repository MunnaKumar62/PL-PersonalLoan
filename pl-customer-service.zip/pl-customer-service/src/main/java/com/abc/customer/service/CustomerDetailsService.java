package com.abc.customer.service;

import org.springframework.http.ResponseEntity;

import com.abc.customer.entity.CustomerDetails;
import com.abc.customer.request.CompanyMasterRequest;
import com.abc.customer.request.EmailVerifyRequest;
import com.abc.customer.request.EmployeeLeadsRequest;
import com.abc.customer.request.GenerateCCCIDRequest;
import com.abc.customer.request.PANRequest;
import com.abc.customer.request.PLAddressRequest;
import com.abc.customer.request.PLCustomerDetailRequest;
import com.abc.customer.request.PanCheckRequest;
import com.abc.customer.request.PanNameCheckRequest;

public interface CustomerDetailsService {

	public String getAccessToken();
	
	public String getNetCoreAccessToken();
	
	public CustomerDetails findByCustomerId(Long id);

	public CustomerDetails findByMobileNumber(String mobileNumber);

	public CustomerDetails findByAccountId(String accountId);

	public ResponseEntity<Object> bankList();

	public ResponseEntity<Object> companyList(String employerName);

	public ResponseEntity<Object> generateCCCID(GenerateCCCIDRequest request);

	public ResponseEntity<Object> getPANCheck(PanCheckRequest request);

	public ResponseEntity<Object> getPANNameCheck(PanNameCheckRequest request);

	public ResponseEntity<Object> saveAddress(PLAddressRequest request);

	public ResponseEntity<Object> searchAddressList(String input);
	
	public ResponseEntity<Object> fetchPanDetails(PANRequest request);

	public ResponseEntity<Object> emailVerification(EmailVerifyRequest request);

	public ResponseEntity<Object> auditEvent(PLCustomerDetailRequest request);

	public ResponseEntity<Object> auditEmpLead(EmployeeLeadsRequest request);

	public ResponseEntity<Object> accdetails(String accountid, String loanId, String customerId);

	public ResponseEntity<Object> statusUpdate(String accountid);

	public ResponseEntity<Object> getCompanyMaster(CompanyMasterRequest request);
	
	public ResponseEntity<Object> generatePLMIS();	

}
