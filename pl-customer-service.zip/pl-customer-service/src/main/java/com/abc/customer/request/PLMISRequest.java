package com.abc.customer.request;

import java.util.List;

import com.abc.customer.dto.mis.Attachment;
import com.abc.customer.dto.mis.Content;
import com.abc.customer.dto.mis.EmailFrom;
import com.abc.customer.dto.mis.Personalization;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PLMISRequest {

	@JsonProperty("from")
	public EmailFrom from;
	
	@JsonProperty("subject")
	public String subject;
	
	@JsonProperty("content")
	public List<Content> content;
	
	@JsonProperty("attachments")
	public List<Attachment> attachments;
	
	@JsonProperty("personalizations")
	public List<Personalization> personalizations;
	
}
