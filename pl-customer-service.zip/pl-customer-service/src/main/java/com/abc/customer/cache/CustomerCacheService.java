package com.abc.customer.cache;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.customer.dto.PLCustomerDto;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerCacheService {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	private static final String CUSTOMER_CACHE = "PLCustomer";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper mapper;

	public Optional<PLCustomerDto> getCustomerFromCache(String accountId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		PLCustomerDto plCusDto = null;
		try {
			String data = redisCacheProvider.getData(CUSTOMER_CACHE, accountId);
			if (StringUtils.isNotBlank(data)) {
				log.info(className + methodName + "Customer Cache: ", accountId);
				plCusDto = mapper.readValue(data, PLCustomerDto.class);
			}
		} catch (Exception ex) {
			log.error(className + methodName + "[EXCEPTION]" + "[" + ex.getMessage() + "]");
		}
		return Optional.ofNullable(plCusDto);
	}

	public void addCustomerToCache(PLCustomerDto customer) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		try {
			redisCacheProvider.addData(CUSTOMER_CACHE, customer.getAccountId(), mapper.writeValueAsString(customer));

		} catch (Exception ex) {
			log.error(className + methodName + "[EXCEPTION]" + "[" + ex.getMessage() + "]");
		}
	}
}
