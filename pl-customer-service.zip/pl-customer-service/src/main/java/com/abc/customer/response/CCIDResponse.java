package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CCIDResponse {
	
	private String cccId;
	private String isExistingCustomer;
	private String applicationId;

}
