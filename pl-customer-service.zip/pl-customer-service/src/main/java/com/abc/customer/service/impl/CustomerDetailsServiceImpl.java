package com.abc.customer.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abc.customer.request.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.customer.cache.CompanyCacheService;
import com.abc.customer.cache.CustomerCacheService;
import com.abc.customer.constant.Constants;
import com.abc.customer.dto.PLCompanyDto;
import com.abc.customer.dto.PLCustomerDetailDto;
import com.abc.customer.dto.PLCustomerDto;
import com.abc.customer.dto.PLMISReport;
import com.abc.customer.dto.mis.Attachment;
import com.abc.customer.dto.mis.Content;
import com.abc.customer.dto.mis.EmailFrom;
import com.abc.customer.dto.mis.EmailTo;
import com.abc.customer.dto.mis.Personalization;
import com.abc.customer.entity.ApiStatus;
import com.abc.customer.entity.CustomerDetails;
import com.abc.customer.entity.EmployeeLeads;
import com.abc.customer.entity.PLAddress;
import com.abc.customer.entity.PLBank;
import com.abc.customer.entity.PLCustomerDetail;
import com.abc.customer.exception.CustomException;
import com.abc.customer.exception.ExternalException;
import com.abc.customer.exception.InternalException;
import com.abc.customer.repository.APIStatusRepository;
import com.abc.customer.repository.BankRepository;
import com.abc.customer.repository.CustomerRepository;
import com.abc.customer.repository.EmployeeLeadsRepository;
import com.abc.customer.repository.PLCustomerDetailRepository;
import com.abc.customer.response.AccdetailsResponse;
import com.abc.customer.response.AddressResponse;
import com.abc.customer.response.CCIDBaseResponse;
import com.abc.customer.response.CompanyMasterResponse;
import com.abc.customer.response.EmailVerifyResponse;
import com.abc.customer.response.PANResponse;
import com.abc.customer.response.PLAddressResponse;
import com.abc.customer.response.PLCustomerDetailsResponse;
import com.abc.customer.response.PLMISResponse;
import com.abc.customer.response.PanCheckBaseResponse;
import com.abc.customer.response.PanNameCheckResponse;
import com.abc.customer.service.CustomerDetailsService;
import com.abc.customer.service.NetCoreTokenService;
import com.abc.customer.service.PLAddressService;
import com.abc.customer.service.PLCustomerDetailService;
import com.abc.customer.service.TokenService;
import com.abc.customer.service.biz.CommonBizService;
import com.abc.customer.service.biz.CustomerBizService;
import com.abc.customer.util.CommonUtil;

import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerDetailsServiceImpl extends CommonBizService implements CustomerDetailsService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private BankRepository bankRepository;

	@Autowired
	private TokenService tokenService;
	
	@Autowired
	private NetCoreTokenService netCoreTokenService;
	
	@Autowired
	private CustomerCacheService customerService;

	@Autowired
	private CompanyCacheService companyCacheService;

	@Autowired
	private PLCustomerDetailService plCustomerDetailService;
	
	@Autowired
	private PLCustomerDetailRepository pLCustomerDetailRepository;

	@Autowired
	private PLAddressService plAddressService;

	@Autowired
	private APIStatusRepository aPIStatusRepository;
	
	@Autowired
	private EmployeeLeadsRepository employeeLeadsRepository;

	@Value("${pl.google.addresssearch.url}")
	private String addressSearchUrl;

	@Value("${pl.google.addresssearch.api.key}")
	private String addressApiKey;

	@Value("${abfl.verifypan.url}")
	private String panUrl;

	@Value("${abfl.verifypanname.url}")
	private String panNameUrl;

	@Value("${abfl.generatecccid.url}")
	private String cccIdUrl;

	@Value("${abfl.pan.v2.fetch.url}")
	private String panFetchUrl;

	@Value("${abfl.email.verify.url}")
	private String emailVerifyUrl;
	
	@Value("${abfl.company.master.url}")
	private String companyMasterUrl;
	
	@Value("${abfl.netcore.email.url}")
	private String netCoreEmailUrl;

	@Value("${pl.mis.xlsx.file.name}")
	private String misFileName;
	
	@Value("${pl.netcore.from.email}")
	private String fromEmail;
	
	@Value("${pl.netcore.to.email}")
	private String toEmail;
	
	@Value("${pl.netcore.email.subject}")
	private String emailSubject;
	
	@Value("${pl.netcore.email.content}")
	private String emailContent;
	
	@Value("${pl.mis.days}")
	private String misDays;
	
	@Override
	public String getAccessToken() {
		return tokenService.getAccessToken();
	}
	
	@Override
	public String getNetCoreAccessToken() {
		return netCoreTokenService.getAccessToken();
	}
	
	@Override
	public CustomerDetails findByCustomerId(Long id) {
		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findById(id);
		if (!details.isPresent()) {
			throw new CustomException("2006"+ Constants.CUSTOMER_NOT_FOUND + id );
		}
		customerDetails = details.get();
		return customerDetails;
	}

	@Override
	public CustomerDetails findByMobileNumber(String mobileNumber) {
		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findByMobileNumber(mobileNumber);
		if (!details.isPresent()) {
			throw new CustomException("2006" + Constants.CUSTOMER_NOT_FOUND + mobileNumber);
		}
		customerDetails = details.get();
		return customerDetails;
	}

	@Override
	public CustomerDetails findByAccountId(String accountId) {
		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepository.findByAccountId(accountId);
		if (!details.isPresent()) {
			throw new CustomException("2006" + Constants.CUSTOMER_NOT_FOUND + accountId);
		}
		customerDetails = details.get();
		return customerDetails;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getPANCheck(PanCheckRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		PanCheckBaseResponse panResp = null;
		PLCustomerDto plCustomerDto = new PLCustomerDto();
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		/**
		 * Input request validation
		 */
		request = bizService.validatePANCheckRequest(request);
		try {
			if (request != null) {
				PanCheckRequestBuilder panCheckRequestBuilder = new PanCheckRequestBuilder();
				panCheckRequestBuilder.setPanNo(request.getPanNo());
				panCheckRequestBuilder.setAccountId(request.getLoanId());
				panCheckRequestBuilder.setDeclaredFirstName(request.getDeclaredFirstName());
				panCheckRequestBuilder.setDeclaredLastName(request.declaredLastName);
				panCheckRequestBuilder.setDeclaredMiddleName(request.getDeclaredMiddleName());
				panCheckRequestBuilder.setDob(request.getDob());
				accountId = request.getAccountId();
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_PAN_CHECK).accountId(accountId)
						.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(panUrl)
						.requestHeaders(getRequestHeaders(getAccessToken())).method(HttpMethod.POST).request(panCheckRequestBuilder)
						.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

				map = callExternalApi(commonRequest, PanCheckBaseResponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						panResp = (PanCheckBaseResponse) apiResponse.getBody();
						if (null != panResp) {
							plCustomerDto.setAccountId(request.getAccountId());
							plCustomerDto.setPannumber(request.getPanNo());
							plCustomerDto.setFirstname(panResp.getData().getFirstName());
							plCustomerDto.setMiddlename(panResp.getData().getMiddleName());
							plCustomerDto.setLastname(panResp.getData().getLastName());
							customerService.addCustomerToCache(plCustomerDto);
						}
						obj = panResp;
					} else {
						obj = apiResponse.getBody();
					}
				}
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					updateApiStatusByAccountId(findByAccountId(accountId), apiStatus, request.getLoanId());
				}if (map == null || map.isEmpty()) {
		            throw new ExternalException("2005", Constants.EXTERNAL_RESPONSE_EMPTY + map);
		        }
			} if (request == null) {
	            throw new CustomException("2007",Constants.REQUEST_BODY_EMPTY + request);
	        }
		}catch (CustomException e) {
			log.error("Error in get pan check: " + e.getMessage());
			throw e;
		}catch (HttpClientErrorException e) {
			log.error("Error in get pan check: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in get pan check:  " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			log.error("Exception while calling Pan check API: "+e.getMessage());		
			throw new InternalException("2016");
		}
			log.info(className + methodName + END);
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getPANNameCheck(PanNameCheckRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		PanNameCheckResponse panNameCheckResponse = null;
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		String basicConsent = null;
		/**
		 * Input request validation
		 */
		request = bizService.validatePANNameCheckRequest(request);
		PanNameCheckRequestBuilder panNameCheckRequestBuilder = new PanNameCheckRequestBuilder();
		try {
			if (request != null) {
				accountId = request.getApplicationId();
				basicConsent = null != request.getBasicConsent() && "Y".equalsIgnoreCase(request.getBasicConsent())
						? "Y"
						: "N";
				// Not applicable for external API
				panNameCheckRequestBuilder.setBasicConsent(null);
				Optional<PLCustomerDto> plCustomerDto = customerService.getCustomerFromCache(accountId);
				panNameCheckRequestBuilder.setTransactionId(generateTransactionId());
				panNameCheckRequestBuilder.setApplicationId(request.getLoanId());
				panNameCheckRequestBuilder.setName1(nameCheck(request.getName1()));
				panNameCheckRequestBuilder.setName2(nameCheck(request.getName2()));
				panNameCheckRequestBuilder.setProduct(request.getProduct());
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_PAN_NAME_CHECK)
						.accountId(accountId).profileId(EMPTY).requestId(EMPTY)
						.transactionId(request.getTransactionId()).url(panNameUrl)
						.requestHeaders(getRequestHeaders(getAccessToken())).method(HttpMethod.POST).request(panNameCheckRequestBuilder)
						.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

				map = callExternalApi(commonRequest, PanNameCheckResponse.class);

				CustomerDetails customerDetails = findByAccountId(accountId);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						panNameCheckResponse = (PanNameCheckResponse) apiResponse.getBody();
						// PL_JOURNEY_AUDIT - Insert
						if (null != panNameCheckResponse) {
							plCustomerDetailDto.setAccountId(accountId);
							plCustomerDetailDto.setLoanId(request.getLoanId());
							plCustomerDetailDto.setCustomerId(request.getCustomerId());
							plCustomerDetailDto.setBasicConsent(basicConsent);
							plCustomerDetailDto.setBasicConsentDatetime(new Timestamp(new Date().getTime()));
							plCustomerDetailDto.setAccntCreateDate(new Timestamp(new Date().getTime()));
							plCustomerDetailDto.setAccountId(accountId);
							plCustomerDetailDto.setMobilenumber(customerDetails.getMobileNumber());
							plCustomerDetailDto.setDateOfBirth(customerDetails.getDateOfBirth());
							plCustomerDetailDto.setGender(customerDetails.getGender());
							plCustomerDetailDto.setEmail(customerDetails.getEmailAddress());
							plCustomerDetailDto.setAppPlatform(DEFAULT_APP_PLATFORM);
							plCustomerDetailDto.setActive(Boolean.FALSE);
							plCustomerDetailDto.setCurrentScreen("PAN Card Page");
							plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, PL_PAN_NAME_CHECK, request.getLoanId());

							if (plCustomerDto.isPresent()) {
								plCustomerDto.get().setPanCheckFlag(Boolean.TRUE);
								customerService.addCustomerToCache(plCustomerDto.get());
							}
						}
						obj = panNameCheckResponse;
					} else {
						obj = apiResponse.getBody();
					}
				}
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					apiStatus.setRequestId(null != panNameCheckResponse ? panNameCheckResponse.getRequestId() : EMPTY);
					updateApiStatusByAccountId(findByAccountId(accountId), apiStatus, request.getLoanId());
				}if (map == null || map.isEmpty()) {
		            throw new ExternalException("2005", Constants.EXTERNAL_RESPONSE_EMPTY + map);
		        }
			} if (request == null) {
	            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
	        }
		} catch (CustomException e) {
			log.error("Error in get pan check: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in get pan name check: " + e.getResponseBodyAsString());
			apiResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in get pan name check:  " + e.getResponseBodyAsString());
			apiResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			throw e;
		} catch (Exception e) {
			log.error("Exception while calling Pan name check API: "+e.getMessage(),e );
		    apiResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		    throw new InternalException("2017");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> generateCCCID(GenerateCCCIDRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CCIDBaseResponse cccIdResp = null;
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateGcccIdRequest(request);
		try {
			if (request != null) {
				accountId = request.getAccountId();
				String[] arr = request.getFirstName().split(SPACE);
				GenerateCCCIDRequestBuilder builder = GenerateCCCIDRequestBuilder.builder().build();
				builder.setAccountId(request.getLoanId());
				builder.setFirstName(nameCheck(arr[0]));
				if (arr.length > 1) {
					builder.setLastName(nameCheck(arr[1]));
				} else {
					log.error(String.valueOf(HttpStatus.BAD_REQUEST.value()), " Last Name can not be empty",
							HttpStatus.BAD_REQUEST.getReasonPhrase());
					throw new InternalException("1000");
				}
				builder.setPanNo(request.getPanNo());
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_GENERATE_CCCID)
						.accountId(accountId).profileId(EMPTY).requestId(request.getPanNo()).transactionId(EMPTY)
						.url(cccIdUrl).requestHeaders(getRequestHeaders(getAccessToken())).method(HttpMethod.POST)
						.request(builder).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();
				map = callExternalApi(commonRequest, CCIDBaseResponse.class);

				CustomerDetails customerDetails = findByAccountId(accountId);

				if (null != customerDetails && null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						cccIdResp = (CCIDBaseResponse) apiResponse.getBody();

						if (null != cccIdResp && null != cccIdResp.getData()) {

							Optional<PLCustomerDto> custDto = customerService
									.getCustomerFromCache(request.getAccountId());
							if (custDto.isPresent()) {
								custDto.get().setCccId(cccIdResp.getData().getCccId());
								customerService.addCustomerToCache(custDto.get());
							}
							// PL_JOURNEY_AUDIT
							PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
							plCustomerDetailDto.setAccountId(accountId);
							plCustomerDetailDto.setCustomerId(request.getCustomerId());
							plCustomerDetailDto.setLoanId(request.getLoanId());
							plCustomerDetailDto.setApplicationId(cccIdResp.getData().getApplicationId());
							plCustomerDetailDto.setCccId(cccIdResp.getData().getCccId());
							plCustomerDetailDto
									.setFirstnameLastname(builder.getFirstName() + SPACE + builder.getLastName());
							plCustomerDetailDto.setPannumber(request.getPanNo());
							plCustomerDetailDto.setCurrentScreen("PAN Card Page");
							plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null, request.getLoanId());
						}
						obj = cccIdResp;
					} else {
						obj = apiResponse.getBody();
					}
				}
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					updateApiStatusByAccountId(findByAccountId(accountId), apiStatus, request.getLoanId());
				}if (map == null || map.isEmpty()) {
		            throw new ExternalException("2005", Constants.EXTERNAL_RESPONSE_EMPTY + map);
		        }
			}if (request == null) {
	            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
	        }
		} catch (CustomException e) {
			log.error("Error in get pan check: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in generateCCCID: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in generateCCCID:  " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			log.error("Exception while calling generateCCCID API: "+e.getMessage());
			throw new InternalException("2018");
		}
		log.info(className + methodName + END);
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> saveAddress(PLAddressRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		String code = "PL4304";
		PLAddressResponse response = new PLAddressResponse();
		CustomerBizService bizService = new CustomerBizService();
		Object obj = null;
		boolean flag = Boolean.FALSE;
		/**
		 * Input request validation
		 */
		request = bizService.validateAddressRequest(request);
		try {
			if (request != null) {
				CustomerDetails customerDetails = findByCustomerId(request.getCustomerId());
				if (null != customerDetails && null != customerDetails.getCustomerId()) {
					PLAddress address = plAddressService.saveOrUpdate(request);
					if (null != address) {
						response.setResponseStatus(SUCCESS);
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), response);
						flag = Boolean.TRUE;
					}else {
						throw new CustomException("PL4310");
					}
				}
				if (!flag) {
					code = "PL4305";
					obj = CommonUtil.getErrorResponse(env.getProperty(code));
				}
			}if (request == null) {
	            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
	        }
		}catch (CustomException e) {
			log.error("Error in get pan check: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in generateCCCID: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in generateCCCID:  " + e.getResponseBodyAsString());
			throw e;
		}  catch (Exception e) {
			log.error("Exception while calling saveAddress API: "+e.getMessage());
			throw new InternalException("2015");
		}
		log.info(className + methodName + END);
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> searchAddressList(String input) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4306";
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		List<String> list = new ArrayList<>();
		/**
		 * Input request validation
		 */
		if (input == null) {
            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + input);
        }
		input = bizService.validateSearchAddressRequest(input);
		try {
			/**
			 * External API Call
			 */
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(addressSearchUrl).queryParam(KEY, addressApiKey)
					.queryParam(INPUT, input).build();

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_SEARCH_ADDRESS).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(builder.toUriString())
					.requestHeaders(getRequestHeaders(getAccessToken())).method(HttpMethod.GET).code(code).request(null)
					.active(Boolean.FALSE).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, AddressResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					AddressResponse addressResponse = (AddressResponse) apiResponse.getBody();
					if (null != addressResponse && null != addressResponse.getPredictions()
							&& !addressResponse.getPredictions().isEmpty()) {
						list = addressResponse.getPredictions().stream().map(p -> p.getDescription()).sorted()
								.collect(Collectors.toList());
					}
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), list);
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}if (map == null || map.isEmpty()) {
	            throw new ExternalException("2005", Constants.EXTERNAL_RESPONSE_EMPTY + map);
	        }
		} catch (CustomException e) {
			log.error("Error in search Address List: " + e.getMessage());
			throw e;
		}catch (HttpClientErrorException e) {
			log.error("Error in search Address List: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in search Address List:  " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			log.error("Error while calling search Address List method: "+e.getMessage());
			throw new InternalException("2020");
		}
		log.info(className + methodName + END);
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> bankList() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		String code = "PL4301";
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		try {
			List<PLBank> list = bankRepository.findAll();
			if (null == list || list.isEmpty()) {
				code = "PL4303";
				throw new CustomException(code, Constants.RECORD_NOT_FOUND + list);
			} else {
				list.sort(Comparator.comparing(PLBank::getName, Comparator.nullsLast(Comparator.naturalOrder())));
			}
			obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), list);

		}catch (CustomException e) {
			log.error("Error in bank List: " + e.getMessage());
			throw e;
		}catch (HttpClientErrorException e) {
			log.error("Error in bank List: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in bank List:  " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception e) {
			log.error("Ëxception in bankList Method "+e.getMessage());
			throw new InternalException("2021");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> companyList(String employerName) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		CustomerBizService bizService = new CustomerBizService();
		String code = "PL4302";
		Object obj = null;
		List<PLCompanyDto> list = new ArrayList<>();
		List<PLCompanyDto> list1 = new ArrayList<>();
		try {
			list1 = companyCacheService.getCompanyListFromCache();

			if (!list1.isEmpty()) {

				list = bizService.searchCompanyList(list1, employerName);
			}
			if (null == list || list.isEmpty()) {
				code = "PL4303";
				throw new CustomException(code, Constants.RECORD_NOT_FOUND + employerName);
			}
			obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), list);

		}catch (CustomException e) {
			log.error("Error in company List: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in company List: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in company List:  " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			log.error("Exception in companyList method: "+e.getMessage());
			throw new InternalException("2022");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	private String nameCheck(String name) {
		String changedName = null;
		if (name.contains("null")) {
			changedName = name.replace("null", "");
		} else {
			return name;
		}
		return changedName;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> fetchPanDetails(PANRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4101";
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		/**
		 * Input request validation
		 */
		if (request == null) {
            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
        }
		request = bizService.validatePANRequest(request);
		try {
			if (request != null) {
				FetchPANRequest fetchPANRequest = new FetchPANRequest();
				fetchPANRequest.setPanNumber(request.getPanNumber());
				accountId = request.getAccountId();
				// Not applicable for external API
				fetchPANRequest.setAccountId(null);
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_PAN_TO_DOB).accountId(accountId)
						.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(panFetchUrl)
						.requestHeaders(getRequestHeadersForFetchPAN(getAccessToken())).method(HttpMethod.POST).code(code)
						.request(fetchPANRequest).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();
				map = callExternalApi(commonRequest, PANResponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					} else {
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					updateApiStatusByAccountId(findByAccountId(accountId), apiStatus, request.getLoanId());
				}if (map == null || map.isEmpty()) {
		            throw new ExternalException("2005", Constants.EXTERNAL_RESPONSE_EMPTY + map);
		        }
			}
		} catch (CustomException e) {
			log.error("Error in fetchPanDetails: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in fetchPanDetails: " + e.getResponseBodyAsString());
			apiResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in fetchPanDetails:  " + e.getResponseBodyAsString());
			apiResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			throw e;
		}  catch (Exception e) {
			log.error("Exception in fetchPanDetails Method: "+e.getMessage());
			throw new InternalException("2023");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> emailVerification(EmailVerifyRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4102";
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		/**
		 * Input request validation
		 */
		if (request == null) {
            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
        }
		request = bizService.validateEmailRequest(request);
		try {
			if (request != null) {
				accountId = request.getAccountId();
				// Not applicable for external API
				request.setAccountId(null);
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_EMAIL_VERIFICATION)
						.accountId(accountId).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(emailVerifyUrl)
						.requestHeaders(getRequestHeaders(getAccessToken())).method(HttpMethod.POST).code(code)
						.request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();
				map = callExternalApi(commonRequest, EmailVerifyResponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					} else {
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					updateApiStatusByAccountId(findByAccountId(accountId), apiStatus, "");
				}if (map == null || map.isEmpty()) {
		            throw new ExternalException("2005", Constants.EXTERNAL_RESPONSE_EMPTY + map);
		        }
			}
		} catch (CustomException e) {
			log.error("Error in emailVerification: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in emailVerification: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in emailVerification:  " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			log.error("Exception in emailVerification Method:  "+e.getMessage());
			throw new InternalException("2024");
		}
		log.info(className + methodName + END);
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> auditEvent(PLCustomerDetailRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		String code = "PL4307";
		ResponseEntity<Object> apiResponse = null;
		PLCustomerDetailsResponse response = new PLCustomerDetailsResponse();
		CustomerBizService bizService = new CustomerBizService();
		Object obj = null;
		boolean flag = Boolean.FALSE;
		String requestJsonObject = null;
		/**
		 * Input request validation
		 */
		if (request == null) {
            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
        }
		request = bizService.validatePLCustomerDetailRequest(request);
		try {
			if (request != null) {
				CustomerDetails customerDetails = findByAccountId(request.getAccountId());
				if (null != customerDetails && null != customerDetails.getCustomerId()) {
					requestJsonObject = mapper.writeValueAsString(request);
					log.info(className + methodName + "[API_REQUEST= " + requestJsonObject + "]");
					PLCustomerDetail detail = plCustomerDetailService.auditEvent(request);
					if (null != detail) {
						response.setResponseStatus(SUCCESS);
						response.setLoanId(detail.getLoanId());
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), response);
						flag = Boolean.TRUE;
					}
				}
				if (!flag) {
					code = "PL4305";
					obj = CommonUtil.getErrorResponse(env.getProperty(code));
				}
			}
		}catch (CustomException e) {
			log.error("Error in auditEvent: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in auditEvent: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in auditEvent:  " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			log.error("Exception in auditEvent method: "+e.getMessage());
			throw new InternalException("2025");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> auditEmpLead(EmployeeLeadsRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ResponseEntity<Object> apiResponse = null;
		String code = "PL4308";
		PLCustomerDetailsResponse response = new PLCustomerDetailsResponse();
		CustomerBizService bizService = new CustomerBizService();
		Object obj = null;
		boolean flag = Boolean.FALSE;
		/**
		 * Input request validation
		 */
		if (request == null) {
            throw new CustomException("2007", Constants.REQUEST_BODY_EMPTY + request);
        }
		request = bizService.validateEmployeeLeadsRequest(request);

		EmployeeLeads lead = new EmployeeLeads();
		try {
			if (request != null) {
				CustomerDetails customerDetails = findByCustomerId(request.getCustomerId());
				if (null != customerDetails && null != customerDetails.getCustomerId()) {
					EmployeeLeads leads = new EmployeeLeads();
					leads.setCustomerId(request.getCustomerId());
					leads.setJourney(request.getJourney());
					leads.setChannel(request.getChannel());
					leads.setPageName(request.getPageName());
					leads.setLobId(request.getLobId());
					leads.setUrlLink(request.getUrlLink());
					leads.setCreatedBy(CREATED_BY);
					leads.setCreatedDate(new Timestamp(new Date().getTime()));
					lead = employeeLeadsRepository.save(leads);
					if (null != lead) {
						response.setResponseStatus(SUCCESS);
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), response);
						flag = Boolean.TRUE;
					}
				}
				if (!flag) {
					code = "PL4305";
					obj = CommonUtil.getErrorResponse(env.getProperty(code));
				}
			}
		} catch (CustomException e) {
			log.error("Error in auditEmpLead: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in auditEmpLead: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in auditEmpLead:  " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception e) {
			log.error("Error in auditEmpLead method: "+e.getMessage());
			throw new InternalException("2026");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
	
	@Override
	public ResponseEntity<Object> accdetails(String accountId, String loanId, String customerId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + " BEGIN");
		AccdetailsResponse response =null;
		String exceptionString= null;
		ResponseEntity<Object> apiResponse = null;
		try {
			if (StringUtils.isBlank(accountId)) {
				exceptionString="Customer ID should not Null or empty";
				log.error("Customer ID should not Null or empty");
				throw new InternalException("2013",Constants.Customer_ID_EMPTY + accountId);
			}
			PLCustomerDetail customerDetails = pLCustomerDetailRepository.findByAccountIdAndLoanIdAndCustomerIdAndActive(accountId, loanId, customerId);
			if (Objects.isNull(customerDetails)) {
				exceptionString="Customer not found for account ID: " + accountId;

				log.error("Customer not found for account ID: " + accountId);
				throw new InternalException("2013",Constants.Customer_ID_EMPTY + accountId);
			}

			Date breOfferTime = customerDetails.getBreOffertime();
			if (Objects.isNull(breOfferTime)) {
				exceptionString="BreOfferTime not found for account ID: " + accountId;
				log.error("BreOfferTime not found for account ID: " + accountId);
				throw new InternalException("2014" + Constants.BREOFFERTIME_NOT_FOUND+accountId);
			}

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS000");
			String formattedTime = formatter.format(breOfferTime);
			response = new AccdetailsResponse();
			response.setBreOfferTime(formattedTime);
		}catch (CustomException e) {
			log.error("Error in accdetails: " + e.getMessage());
			throw e;
		}  catch (HttpClientErrorException e) {
			log.error("Error in accdetails: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in accdetails:  " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception e) {
			log.error("Error in accdetails method: "+e.getMessage());
			throw new InternalException("2027");
		/*	log.error("Error in auditEmpLead method: " + e.getMessage());
			if (StringUtils.isNotEmpty(exceptionString)) {
				throw new InternalException(exceptionString);
			} else {
				throw new InternalException(e.getMessage());
			}*/
		}
		log.info(className + methodName + " END");
		return ResponseEntity.ok(response);

	}

	@Override
	public ResponseEntity<Object> statusUpdate(String accountid) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + " BEGIN");

		CustomerBizService bizService = new CustomerBizService();

		accountid = bizService.accountIdRequest(accountid);

		try {
			if (accountid != null) {
				List<ApiStatus> apiStatusList = aPIStatusRepository.findByAccountIdAndStatu(accountid, "Success");

				if (!apiStatusList.isEmpty()) {
					for (ApiStatus status : apiStatusList) {
						status.setStatus("SOFT-REJECT");
						aPIStatusRepository.save(status);
					}
					return ResponseEntity.ok("Status updated successfully");
				} else {
					return ResponseEntity.notFound().build();
				}
			} else {
				return ResponseEntity.badRequest().body("Account id is null "+"{}"+accountid);
			}
		} catch (CustomException e) {
			log.error("Error in statusUpdate: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in statusUpdate: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in statusUpdate:  " + e.getResponseBodyAsString());
			throw e;
		}  catch (Exception e) {
			log.error(className + methodName + " Error: " + e.getMessage());
			throw new InternalException("2028");
			//return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ERROR_OCCURRED +"{}"+accountid);
		} finally {
			log.info(className + methodName + " END");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getCompanyMaster(CompanyMasterRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateCompanyMasterRequest(request);
		try {
			if (request != null) {
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_EMAIL_VERIFICATION)
						.accountId(EMPTY).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(companyMasterUrl)
						.requestHeaders(getRequestHeaders(getAccessToken())).method(HttpMethod.POST)
						.request(request).active(Boolean.FALSE).isAudit(Boolean.FALSE).build();
				map = callExternalApi(commonRequest, CompanyMasterResponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
						obj = apiResponse.getBody();
				}
			}
		} catch (CustomException e) {
			log.error("Error in getCompanyMaster: " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in getCompanyMaster: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in getCompanyMaster:  " + e.getResponseBodyAsString());
			throw e;
		}  catch (Exception e) {
			log.error(className + methodName + " Error: " + e.getMessage());
			throw new InternalException("2029");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> generatePLMIS() {
			String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
			log.info(className + methodName + BEGIN);

			ResponseEntity<Object> apiResponse = null;
			Object obj = null;
			Map<String, Object> map = null;
			try {
				List<PLMISReport> list = plCustomerDetailService.fetchMISList(Integer.parseInt(misDays));
				
				File file = ResourceUtils.getFile("classpath:" + misFileName);
				CommonUtil.fillData(file, list, "PL-MIS");
				try (FileInputStream inputStream = new FileInputStream(file)) {
					byte[] bytes = new byte[(int) file.length()];
					inputStream.read(bytes);
					PLMISRequest plmisRequest = constructMISRequest(CommonUtil.encodeBase64(bytes));
						/**
						 * External API Call
						 */
						ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_MIS_REPORT)
								.accountId(EMPTY).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(netCoreEmailUrl)
								.requestHeaders(getRequestHeaders(getNetCoreAccessToken())).method(HttpMethod.POST)
								.request(plmisRequest).active(Boolean.FALSE).isAudit(Boolean.FALSE).build();
						map = callExternalApi(commonRequest, PLMISResponse.class);
				}
				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
							obj = apiResponse.getBody();
					}
			}catch (CustomException e) {
				log.error("Error in generatePLMIS: " + e.getMessage());
				throw e;
			} catch (HttpClientErrorException e) {
				log.error("Error in generatePLMIS: " + e.getResponseBodyAsString());
				throw e;
			} catch (HttpServerErrorException e) {
				log.error("Error in generatePLMIS:  " + e.getResponseBodyAsString());
				throw e;
			}  catch (Exception e) {
				log.error(className + methodName + " Error: " + e.getMessage());
				throw new InternalException("2030");
			}
			log.info(className + methodName + END);

			return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}
	
	private PLMISRequest constructMISRequest(String data) {

		SimpleDateFormat sd = new SimpleDateFormat(DOB_FORMAT);
		EmailFrom emailFrom = EmailFrom.builder().email(fromEmail.split(HYPHEN)[1]).name(fromEmail.split(HYPHEN)[0])
				.build();
		List<Content> contents = new ArrayList<>();
		Content content = Content.builder().type("html").value(emailContent).build();
		contents.add(content);

		List<Attachment> attachments = new ArrayList<>();
		Attachment attachment = Attachment.builder().name(sd.format(new Date())+UNDER_SQUARE+misFileName).content(data).build();
		attachments.add(attachment);

		List<EmailTo> emailTos = new ArrayList<>();
		String[] arr = toEmail.split(COMMA);
		for (String str : arr) {
			EmailTo emailTo = EmailTo.builder().email(str.split(HYPHEN)[1]).name(str.split(HYPHEN)[0]).build();
			emailTos.add(emailTo);
		}
		List<Personalization> personalizations = new ArrayList<>();
		Personalization personalization = Personalization.builder().to(emailTos).build();
		personalizations.add(personalization);

		return PLMISRequest.builder().from(emailFrom).subject(MessageFormat.format(emailSubject, sd.format(new Date())))
				.content(contents).attachments(attachments).personalizations(personalizations).build();
	}
}
