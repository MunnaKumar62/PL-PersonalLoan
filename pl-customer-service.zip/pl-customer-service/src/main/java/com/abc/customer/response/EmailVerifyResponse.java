package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmailVerifyResponse {

	@JsonProperty("responseStatus")
	public String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	public EmailData data;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
