package com.abc.customer.dto.mis;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Attachment {

	@JsonProperty("name")
	public String name;

	@JsonProperty("content")
	public String content;
}
