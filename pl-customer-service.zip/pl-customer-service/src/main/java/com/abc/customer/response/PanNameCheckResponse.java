package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.abc.customer.model.APIError;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PanNameCheckResponse {

	@JsonProperty("Result")
	private String result;

	@JsonProperty("Cached")
	private String cached;

	@JsonProperty("Max Retry Exeeded")
	private String maxRetryExeeded;

	@JsonProperty("Request Id")
	private String requestId;

	private String responseStatus;

	@JsonProperty("error")
	private APIError error;

}
