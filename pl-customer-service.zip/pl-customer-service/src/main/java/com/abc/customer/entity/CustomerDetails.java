package com.abc.customer.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_customer")
public class CustomerDetails implements Serializable {

	private static final long serialVersionUID = 3944886206643636410L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long customerId;

	@Column(name = "firstname", length = 60)
	private String firstName;

	@Column(name = "lastname", length = 60)
	private String lastName;

	@Column(name = "dateofbirth")
	@Temporal(TemporalType.DATE)
	private LocalDate dateOfBirth;

	@Column(name = "gender", length = 1)
	private String gender;

	@Column(name = "mobilenumber", length = 20)
	@Pattern(regexp = "(^$|[0-9]{10})")
	private String mobileNumber;

	@Column(name = "email", length = 60)
	private String emailAddress;

	@Column(name = "pannumber", length = 20)
	@Pattern(regexp = "([A-Z]{5}[0-9]{4}[A-Z]{1})")
	private String panNumber;

	@Column(name = "aadhaarnumber", length = 20)
	private String aadhaarNumber;

	@Column(name = "createdby", length = 60)
	private String createdBy;

	@Column(name = "createddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modifiedby", length = 60)
	private String modifiedBy;

	@Column(name = "modifieddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "accountid")
	private String accountId;

}
