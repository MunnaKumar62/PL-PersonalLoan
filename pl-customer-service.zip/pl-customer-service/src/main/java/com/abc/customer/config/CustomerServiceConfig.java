package com.abc.customer.config;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.zalando.problem.ProblemModule;
import org.zalando.problem.validation.ConstraintViolationProblemModule;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class CustomerServiceConfig {

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplateBuilder().build();
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		objectMapper.setSerializationInclusion(Include.NON_EMPTY);
		objectMapper.registerModules(new ProblemModule(), new ConstraintViolationProblemModule());
		return objectMapper;
	}

	/*
	 * @Bean public CircuitBreakerConfig circuitBreakerConfig() {
	 * CircuitBreakerConfig circuitBreakerConfig =
	 * CircuitBreakerConfig.custom().failureRateThreshold(5)
	 * .waitDurationInOpenState(Duration.ofMillis(1000)).
	 * permittedNumberOfCallsInHalfOpenState(1)
	 * .slidingWindowSize(2).recordExceptions(IOException.class,
	 * TimeoutException.class) // add you exceptions // here!!! .build(); return
	 * circuitBreakerConfig; }
	 */
}
