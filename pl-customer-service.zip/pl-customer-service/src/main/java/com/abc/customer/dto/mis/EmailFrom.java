package com.abc.customer.dto.mis;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmailFrom {

	@JsonProperty("email")
	private String email;
	
	@JsonProperty("name")
	private String name;
	
}
