package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PanNameCheckRequestBuilder {

    @NotBlank
    private String name1;
    @NotBlank
    private String name2;
    private String transactionId;
    @NotBlank
    private String product;
    private String applicationId;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("basic_consent")
    private String basicConsent;
}