package com.abc.customer.response;

import org.springframework.http.ResponseEntity;

import com.google.auto.value.AutoValue.Builder;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class ApiResponse<T> {

	ResponseEntity<T> entity;
	ApiStatusResponse apiStatus;
}
