package com.abc.customer.request;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString
public class ApiCommonRequest {

	private String apiName;
	private String accountId;
	private String profileId;
	private String requestId;
	private String transactionId;
	private Boolean active;

	private String url;
	private HttpHeaders requestHeaders;
	private HttpMethod method;
	private String code;
	private Object request;

	@Default
	private boolean isAudit = false;

}
