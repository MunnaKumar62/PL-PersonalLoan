package com.abc.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.ApiStatus;

import io.lettuce.core.dynamic.annotation.Param;


@Repository
public interface APIStatusRepository extends JpaRepository<ApiStatus, Integer>,JpaSpecificationExecutor<ApiStatus> {
	
	ApiStatus findByApiName(String apiName);
	
	ApiStatus findByApiNameAndCustomerIdAndAccountId(String apiName,int customerId,String accountId);
	@Query("SELECT a FROM ApiStatus a WHERE a.apiName IN (:apiNames) AND a.accountId = :accountId ORDER BY a.id DESC")
	List<ApiStatus> findByApiNameInAndAccountIdOrderByIdDesc(@Param ("apiNames")List<String> apiNames, String accountId);
	
	List<ApiStatus> findByAccountId(String accountId);
		
	@Query("SELECT a FROM ApiStatus a WHERE a.status = :status AND a.accountId = :accountId AND (a.active = false OR a.active IS NULL)")
    List<ApiStatus> findByAccountIdAndStatu(String accountId, String status);
	}


