package com.abc.customer.constant;

public interface MessageConstants {

	public static final String STATUS_CODE_200 = "200";
	public static final String STATUS_CODE_500 = "500";
	public static final String BAD_REQUEST_400 = "400";
	public static final String STATUS_CODE_404 = "404";
	public static final String API_STATUS_200 = " Your Request is Succeeded";
	public static final String API_STATUS_500 = "Service temporarily unavailable";
	public static final String API_STATUS_404 = "Unable to process your request";
	public static final String EMPTY_REQUEST = "Request Body can not be empty";
	public static final String EMPTY_FIELD = "Field can not be empty";
	public static final String EMPTY_PARAM = "Parameter can not be empty";
	public static final String DATA_NOT_FOUND = "Data not found for ";
	//MY CHANGES
	public static final String PL_CUSTOMER_NOT_FOUND = "PL Customer Detail Data not found for ";
	public static final String PL_ADDRESS_NOT_FOUND = "PL address detail data not found for ";

}
