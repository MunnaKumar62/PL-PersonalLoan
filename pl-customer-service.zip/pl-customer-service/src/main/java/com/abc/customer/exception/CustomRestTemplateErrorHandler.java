package com.abc.customer.exception;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import com.abc.customer.response.ResponseStatusCode;


public class CustomRestTemplateErrorHandler implements ResponseErrorHandler{

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		// TODO Auto-generated method stub
		
	}

  /*  @Override
    public void handleError(ClientHttpResponse response) 
            throws IOException {

        if (response.getStatusCode().is4xxClientError() 
                || response.getStatusCode().is5xxServerError()) {

            try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(response.getBody()))) {
              String httpBodyResponse = reader.lines()
                        .collect(Collectors.joining(""));
              JSONObject jsonObject = new JSONObject(httpBodyResponse);
              // getting errors
              JSONArray listofErrors = (JSONArray) jsonObject.get("errors");
              JSONObject jObject = listofErrors.getJSONObject(0);  
              String errorMessage = (String) jObject.get("message");              
              throw new ApplicationException(errorMessage,HttpStatus.BAD_REQUEST.value(),ResponseStatusCode.ERROR.getCode());
            } catch (JSONException e) {
                throw new ApplicationException("There is some error at server side",HttpStatus.INTERNAL_SERVER_ERROR.value(),ResponseStatusCode.ERROR.getCode());
			}
        }
    }

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		return (
                ((HttpStatus) response.getStatusCode()).series() ==
                    HttpStatus.Series.CLIENT_ERROR 
                    
                || ((HttpStatus) response.getStatusCode()).series() == 
                    HttpStatus.Series.SERVER_ERROR
             );
	} */
}