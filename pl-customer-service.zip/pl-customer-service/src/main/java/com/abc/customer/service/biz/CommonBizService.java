package com.abc.customer.service.biz;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import io.swagger.annotations.Authorization;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.customer.constant.Constants;
import com.abc.customer.constant.ErrorConstant;
import com.abc.customer.entity.ApiStatus;
import com.abc.customer.entity.CustomerDetails;
import com.abc.customer.exception.CustomException;
import com.abc.customer.exception.InternalException;
import com.abc.customer.request.ApiCommonRequest;
import com.abc.customer.response.Error;
import com.abc.customer.response.ErrorResponse;
import com.abc.customer.service.ApiStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CommonBizService implements Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	protected Environment env;

	@Autowired
	protected ObjectMapper mapper;

	@Autowired
	protected ApiStatusService apiService;

	public ApiStatus saveApiResponse(ApiStatus apiStatus) {

		apiStatus.setJourney(PL_JOURNEY);
		apiStatus.setStatus(apiStatus.getStatus().toUpperCase());
		apiStatus.setCreatedBy(CREATED_BY);
		apiStatus.setCreatedDt(new Timestamp(new Date().getTime()));

		return apiService.savOrUpdateApiStatus(apiStatus);
	}

	public void updateApiStatusByAccountId(CustomerDetails customerDetails, ApiStatus apiStatus, String loanId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			if (null != customerDetails) {
				apiStatus.setLoanId(loanId);
				apiStatus.setCustomerId(customerDetails.getCustomerId());
				apiStatus.setModifiedBy(CREATED_BY);
				apiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
			}
			apiService.savOrUpdateApiStatus(apiStatus);

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}

	public HttpHeaders getTokenRequestHeaders(String authToken) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", "Basic " + authToken);

		return headers;
	}

	public HttpHeaders getRegulatoryRequestHeaders(String token, String apiKey) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(X_API_KEY, apiKey);
		headers.add(AUTH_TOKEN, token);

		return headers;
	}

	public HttpHeaders getRequestHeaders(String token) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTH_TOKEN, token);

		return headers;
	}

	public HttpHeaders getRequestHeadersForFetchPAN(String token) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTH_TOKEN, token);
		headers.add(SOURCE, SOURCE_TO_ABFL);
		return headers;
	}

	public String getPartnerErrorMessage(String partnerError) {

		String code = "PE0100";
		String partnerErrorMessage = code + env.getProperty(code);
		final String desc = "description";
		final String desc1 = "message";
		final String error = "error";

		if (!StringUtils.isBlank(partnerError)) {
			JSONObject errorResponse = new JSONObject(partnerError);
			if (errorResponse.has(error)) {
				JSONObject errorObj = errorResponse.getJSONObject(error);
				if (errorObj.has(desc)) {
					partnerErrorMessage = errorObj.getString(desc);
				} else if (errorObj.has(desc1)) {
					partnerErrorMessage = errorObj.getString(desc1);
				}

			} else {
				partnerErrorMessage = errorResponse.has(desc) ? errorResponse.getString(desc) : partnerErrorMessage;
			}
		}
		return partnerErrorMessage;
	}

	/**
	 * This method is to call external API and audit request & response in database
	 * 
	 * @param <T>
	 * @param commonRequest
	 * @param clazz
	 * @return
	 */
	public <T> Map<String, Object> callExternalApi(ApiCommonRequest commonRequest, Class<T> responseType) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		Map<String, Object> map = new HashMap<>();
		String requestJsonObject = null;
		String responseJsonObject = null;
		String status = ERROR;
		int statusCode = STATUS_CODE_400;
		boolean isValid = Boolean.TRUE;
		ResponseEntity<T> apiResponse = null;
		try {
			requestJsonObject = null != commonRequest.getRequest() ? mapper.writeValueAsString(commonRequest.getRequest()) : EMPTY;
			log.info(className + methodName + "[API_URL= " + commonRequest.getUrl() + "]");
			HttpEntity<Object> apiRequest = new HttpEntity<>(commonRequest.getRequest(), commonRequest.getRequestHeaders());
			log.info(className + methodName + "[API_REQUEST= " + requestJsonObject + "]");

			apiResponse = restTemplate.exchange(commonRequest.getUrl(), commonRequest.getMethod(), apiRequest, responseType);

			if (null != apiResponse && null != apiResponse.getBody()) {
				status = SUCCESS;
				responseJsonObject = mapper.writeValueAsString(apiResponse.getBody());
				log.info(className + methodName + "[API_RESPONSE= " + responseJsonObject + "]");
			}

			map.put(API_RESPONSE, apiResponse);
			statusCode = apiResponse.getStatusCode().value();
		}catch (HttpClientErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[HttpClientErrorException = " + ex.getMessage());
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();
			Error error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
					partnerErrorMessage);	
			String errorMessage = error.getDescription();
			String errorCode = ErrorConstant.ERROR_CODE_PREFIX_C+ error.getCode();
			String fullErrorMessage = errorCode + ": " + errorMessage;
			log.error("External Error :"+fullErrorMessage);
			map.put(API_RESPONSE, new ResponseEntity<>(
					new ErrorResponse(status, error, errorCode, errorMessage, ErrorConstant.CLIENT + error.getCode(),
							errorCode + ErrorConstant.COLON + errorMessage, ErrorConstant.TECHNICAL_ERROR),
					ex.getStatusCode()));

			statusCode = ex.getStatusCode().value();
		} catch (HttpServerErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[HttpServerErrorException= " + ex.getMessage());
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();
			Error error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
					partnerErrorMessage);
			String apiName = commonRequest.getApiName();	
			String errorMessage = error.getDescription();
			String errorCode = ErrorConstant.ERROR_CODE_PREFIX_S + error.getCode();
			String fullErrorMessage = errorCode + ": " + errorMessage;
			log.error("External Error :"+fullErrorMessage);
			map.put(API_RESPONSE, new ResponseEntity<>(
					new ErrorResponse(status, error, errorCode, errorMessage, ErrorConstant.SERVER + error.getCode(),
							errorCode + ErrorConstant.COLON + errorMessage, ErrorConstant.TECHNICAL_ERROR),
					ex.getStatusCode()));

			statusCode = ex.getStatusCode().value();

		} catch (Exception ex) {
			isValid = Boolean.FALSE;
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("2001");

		} finally {
			log.info(className + methodName + FINALLY_BLOCK + " API Status Code: " + statusCode);

			if (commonRequest.isAudit() && isValid) {
				ApiStatus apiStatus = saveApiResponse(ApiStatus.builder().apiName(commonRequest.getApiName()).accountId(commonRequest.getAccountId())
						.profileId(commonRequest.getProfileId()).requestId(commonRequest.getRequestId())
						.transactionId(commonRequest.getTransactionId()).requestJson(requestJsonObject).responseJson(responseJsonObject)
						.status(status).httpStatusCode(statusCode).active(commonRequest.getActive()).build());
				map.put(API_STATUS, apiStatus);
			}
		}

		return map;
	}

	public <T> boolean validateResponse(ResponseEntity<T> apiResponse) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		boolean isSuccess = Boolean.TRUE;
		String error = "error";
		String errors = "errors";
		try {
			if (null != apiResponse && null != apiResponse.getBody()) {
				String json = mapper.writeValueAsString(apiResponse.getBody());

				if (!StringUtils.isBlank(json)) {
					JSONObject errorResponse = new JSONObject(json);
					JSONObject errorObj = null;
					if (errorResponse.has(error)) {
						errorObj = errorResponse.getJSONObject(error);
					} else if (errorResponse.has(errors)) {
						errorObj = errorResponse.getJSONObject(errors);
					}
					if (null != errorObj) {
						isSuccess = Boolean.FALSE;
					}
				}
			}
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return isSuccess;
	}

	public static String generateTransactionId() {
		long random = 1000000000L + (long) (new Random().nextDouble() * 999999999L);
		return "TRNX" + random;
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}

}
