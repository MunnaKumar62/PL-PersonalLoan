package com.abc.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.PLBank;

@Repository
public interface BankRepository extends JpaRepository<PLBank, Long> {

}
