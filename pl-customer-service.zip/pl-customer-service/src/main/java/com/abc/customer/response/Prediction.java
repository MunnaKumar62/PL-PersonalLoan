package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Prediction {

	@JsonProperty("description")
	private String description;
}
