package com.abc.customer.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpResponse;
import com.abc.customer.entity.ApiStatus;
import com.abc.customer.manager.RestConnector;
import com.abc.customer.repository.APIStatusRepository;
import com.abc.customer.request.GenerateCCCIDRequest;
import com.abc.customer.request.GenerateCCCIDRequestBuilder;
import com.abc.customer.request.PanCheckRequest;
import com.abc.customer.request.PanNameCheckRequest;
import com.abc.customer.response.CCIDBaseResponse;
import com.abc.customer.response.PanCheckBaseResponse;
import com.abc.customer.response.PanNameCheckResponse;
import com.abc.customer.response.TokenResponse;

@Service
public class ABFLServiceProvider {

	@Autowired
	private RestConnector restConnector;

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${abfl.generatecccid.url}")
	private String cccIDURL;

	@Value("${abfl.verifypan.url}")
	private String panURL;

	@Value("${abfl.verifypanname.url}")
	private String panNameURL;

	public TokenResponse generateToken(HttpHeaders h) {
		return null;
		// return restConnector.postForEntity(TokenResponse.class, tokenUrl, h);
	}

	public CCIDBaseResponse generateCCCID(GenerateCCCIDRequestBuilder cccIDRequest, HttpHeaders h)  {

		return restConnector.postForEntity(CCIDBaseResponse.class, cccIDURL, cccIDRequest, h,
				cccIDRequest.getAccountId(), "GENERATE_CCCID");

	}

	public PanCheckBaseResponse panCheck(PanCheckRequest panRequest, HttpHeaders h)  {

		return restConnector.postForEntity(PanCheckBaseResponse.class, panURL, panRequest, h, panRequest.getAccountId(),
				"PAN_CHECK");

	}

	public PanNameCheckResponse panNameCheck(PanNameCheckRequest panNameRequest, HttpHeaders h)  {

		return restConnector.postForEntity(PanNameCheckResponse.class, panNameURL, panNameRequest, h,
				panNameRequest.getApplicationId(), "PAN_NAME_CHECK");

	}

}
