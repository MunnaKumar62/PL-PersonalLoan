package com.abc.customer.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class APIError {
    @JsonProperty("code")
    String errorCode;
    @JsonProperty("description")
    String errorDesc;
    @JsonProperty("errorType")
    String errorType;
    
}