package com.abc.customer.constant;

public interface Constants {

	public static final String ALL = "*";
	 
	public static final String API = "/api";
	
	public static final String ONE_APP_ABC = "/oneappabc";
	
	public static final String ADITYA_BIRLA = "/adityabirla";

	public static String VERSION = Constants.SLASH + "${pl.url.version}";

	public static final String PERSONAL_LOAN = "/personalloan";

	public static final String CUSTOMER_SERVICE = "/customerservice";
	
	public static final String TOKEN = "/token";

	public static final String PAN_CHECK = "/pancheck";

	public static final String PAN_NAME_CHECK = "/pannamecheck";

	public static final String GENERATE_CCID = "/generateccid";
	
	public static final String SAVE_ADDRESS = "/saveaddress";
	
	public static final String SEARCH_ADDRESS = "/searchaddress/{input}";

	public static final String PAN_TO_DOB = "/pantodob";
	
	public static final String EMAIL_VERIFICATION = "/emailverification";
	
	public static final String BANK_LIST = "/banklist";
	
	public static final String COMPANY_LIST = "/companylist/{employerName}";
	
	public static final String GET_COMPANY_MASTER = "/getcompanymaster";
	
	public static final String GENERATE_PL_MIS = "/generate-pl-mis";
	
	public static final String REGULATORY = "/regulatory";
	
	public static final String AUDIT_EVENT = "/auditevent";
	
	public static final String AUDIT_EMP_LEAD = "/auditemplead";

	public static final String KEY = "key";
	
	public static final String INPUT = "input";
	
	public static final String PL_JOURNEY = "PL";

	public static final String PL_AUTH_TOKEN = "AUTH_TOKEN";

	public static final String PL_PAN_TO_DOB = "PAN_TO_DOB";

	public static final String SOURCE = "Source";

	public static final String SOURCE_TO_ABFL = "source_b2c_abfl";

	public static final String GENERATE_LOAN_ID = "GENERATE_LOAN_ID";
	
	public static final String PL_EMAIL_VERIFICATION = "EMAIL_VERIFICATION";
	
	public static final String PL_GENERATE_CCCID = "GENERATE_CCCID";
	
	public static final String PL_PAN_CHECK = "PAN_CHECK";
	
	public static final String PL_PAN_NAME_CHECK = "PAN_NAME_CHECK";
	
	public static final String PL_SAVE_ADDRESS = "SAVE_ADDRESS";
	
	public static final String PL_SEARCH_ADDRESS = "SEARCH_ADDRESS";
	
	public static final String PL_MIS_REPORT = "PL_MIS_REPORT";
	
	public static final String ACCDETAILS="/accdetails/{accountid}/{loanid}/{customerid}";

	public static final String STATUSUPDATE="/statusUpdate/{accountid}";


	/**
	 * ********** Common Constants **********
	 */
	public static final String EMPTY = "";
	
	public static final String SPACE = " ";
	
	public static final String COMMA = ",";
	
	public static final String SLASH = "/";

	public static final String TILDA = "~";

	public static final String UNDER_SQUARE = "_";
	
	public static final String HYPHEN = "-";
	
	public static final String YES = "Y";
	
	public static final String NO = "N";

	public static final String DATE_FORMAT = "yyyy-MM-dd";

	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy hh:mm:ss a";
	
	public static final String DATE_TIME_FORMAT1 = "dd-MM-yyyy hh:mm:ss a";
	
	public static final String DATE_TIME_ZONE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	public static final String DOB_FORMAT = "dd-MM-yyyy";

	public static final String BEGIN = " Begin";

	public static final String END = " End";

	public static final String EXCEPTION = "[EXCEPTION]";

	public static final String FINALLY_BLOCK = "[FINALLY_BLOCK]";

	public static final String SUCCESS = "success";

	public static final String ERROR = "error";

	public static final String IN_PROGRESS = "in_progress";
	
	public static final String API_STATUS = "API_STATUS";
	
	public static final String API_RESPONSE = "API_RESPONSE";

	public static final String FULLY_DISBURSED = "LOAN_IS_FULLY_DISBURSED";

	public static final String DISBURSED = "DISBURSED";

	public static final int STATUS_CODE_400 = 400;

	public static final String CLIENT_ID = "client_id";

	public static final String SCOPE = "scope";

	public static final String GRANT_TYPE = "grant_type";

	public static final String AUTH_TOKEN = "auth-token";

	public static final String AUTHORIZATION = "Authorization";

	public static final String MOBILE_NUMBER = "mobileNumber";
	
	public static final String X_API_KEY = "X-API-KEY";

	public static final String CREATED_BY = "system";

	public static final String FILED_ACC_ID = "accountId";
	
	public static final String FILED_ACCT_ID = "accountid";
	
	public static final String FILED_CURR_SCR ="current_screen";
	
	public static final String FILED_CUST_ID = "customerId";
	
	public static final String FILED_CUSTOMER_ID = "customer_id";
	
	public static final String FILED_PAGE_NAME ="page_name";
	
	public static final String FILED_CHANNEL ="channel";
	
	public static final String FILED_JOURNEY ="journey";
	
	public static final String FILED_APPLICATION_ID = "applicationId";

	public static final String FILED_REQ_ID = "requestId";

	public static final String FILED_NUMBER = "panNumber";
	
	public static final String FILED_PAN_NO = "panNo";
	
	public static final String FILED_TASK = "task";
	
	public static final String FILED_EMAIL = "email";
	
	public static final String DEFAULT_APP_PLATFORM = "Mobile";
	
	public static final String FIELD_FIRST_NAME = "firstName";
	
	public static final String CUSTOMER_NOT_FOUND ="Customer not found for";
		
	public static final String  ERROR_OCCURRED="An error occurred while fetching account details";

    public static final String FILED_COMPANY = "company";

    public static final String LOCALE_MESSAGE_COUNTRYCODE = "IN";
    public static final String LOCALE_MESSAGE_ENGLISH = "en";
    public static final String GENERATE_TOKEN = "Generate Token";
    public static final String TECHNICAL_ERROR="technical error";
    //MY CHANGES
    //public static final String CUSTOMER_NOT_FOUND1 = "Customer not found for given: ";
    public static final String REQUEST_BODY_EMPTY = "Request body is empty";
    public static final String EXTERNAL_RESPONSE_EMPTY = "External API response is empty";
    public static final String RECORD_NOT_FOUND = "Data not found for";
    //public static final String RECORD_NOT_FOUND =PL4302=Company List retrieved successfully
    public static final String Customer_ID_EMPTY="Customer ID should not Null or empty";
    public static final String BREOFFERTIME_NOT_FOUND="BreOfferTime not found for account ID";
}
