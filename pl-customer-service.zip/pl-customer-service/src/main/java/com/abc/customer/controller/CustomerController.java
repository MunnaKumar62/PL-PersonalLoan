package com.abc.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.customer.constant.Constants;
import com.abc.customer.request.CompanyMasterRequest;
import com.abc.customer.request.EmailVerifyRequest;
import com.abc.customer.request.EmployeeLeadsRequest;
import com.abc.customer.request.GenerateCCCIDRequest;
import com.abc.customer.request.PANRequest;
import com.abc.customer.request.PLAddressRequest;
import com.abc.customer.request.PLCustomerDetailRequest;
import com.abc.customer.request.PanCheckRequest;
import com.abc.customer.request.PanNameCheckRequest;
import com.abc.customer.service.CustomerDetailsService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.API + Constants.ONE_APP_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION + Constants.PERSONAL_LOAN
		+ Constants.CUSTOMER_SERVICE)
@RequiredArgsConstructor
public class CustomerController extends BaseController {

	@Autowired
	private CustomerDetailsService service;
	
	@Value("${pl.mis.scheduler.enabled}")
	private String isMISSchEnabled;
	
	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	@GetMapping(TOKEN)
	public String getToken() {
		try {
			return service.getAccessToken();
		} catch (Exception e) {
			return "Error generating token: " + e.getMessage();
		}
	}

	/**
	 * Performs a PAN check using an external API based on the provided PanCheckRequest.
	 *
	 * @param request The PanCheckRequest containing details necessary for PAN verification.
	 * @return A ResponseEntity<Object> containing the API response for the PAN check.
	 */
	@PostMapping(PAN_CHECK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getPANCheck(@RequestBody PanCheckRequest request) {
		auditUrl();
		return service.getPANCheck(request);
	}

	/**
	 * Performs a PAN and Name check using an external API based on the provided PanNameCheckRequest.
	 *
	 * @param request The PanNameCheckRequest containing details necessary for PAN and Name verification.
	 * @return A ResponseEntity<Object> containing the API response for the PAN and Name check.
	 */
	@PostMapping(PAN_NAME_CHECK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getPANNameCheck(@RequestBody PanNameCheckRequest request) {
		auditUrl();
		return service.getPANNameCheck(request);
	}

	/**
	 * Generates a CCCID (Customer Credit Card ID) based on the provided GenerateCCCIDRequest.
	 *
	 * @param request The GenerateCCCIDRequest containing details necessary for CCCID generation.
	 * @return A ResponseEntity<Object> containing the API response for the CCCID generation.
	 */
	@PostMapping(GENERATE_CCID)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> generateCCCID(@RequestBody GenerateCCCIDRequest request) {
		auditUrl();
		return service.generateCCCID(request);
	}

	/**
	 * Saves or updates a customer address based on the provided PLAddressRequest.
	 *
	 * @param request The PLAddressRequest containing details necessary for address saving/updating.
	 * @return A ResponseEntity<Object> containing the API response for the address saving/updating operation.
	 */
	@PostMapping(SAVE_ADDRESS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> saveAddress(@RequestBody PLAddressRequest request) {
		auditUrl();
		return service.saveAddress(request);
	}
	
	/**
	 * Searches for a list of addresses based on the input string.
	 *
	 * @param input The input string used for searching addresses.
	 * @return A ResponseEntity<Object> containing the API response with the list of addresses.
	 */
	@GetMapping(SEARCH_ADDRESS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> searchAddress(@PathVariable String input) {
		auditUrl();
		return service.searchAddressList(input);
	}

	/**
	 * Retrieves a list of banks.
	 *
	 * @return A ResponseEntity<Object> containing the API response with the list of banks.
	 */
	@GetMapping(BANK_LIST)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> bankList() {
		auditUrl();
		return service.bankList();
	}

	/**
	 * Retrieves a list of companies filtered by employer name.
	 *
	 * @param employerName The name of the employer to search for.
	 * @return A ResponseEntity<Object> containing the API response with the list of companies.
	 */
	@GetMapping(COMPANY_LIST)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> companyList(@PathVariable String employerName) {
		auditUrl();
		return service.companyList(employerName);
	}

	/**
	 * Fetches PAN details based on the provided PANRequest.
	 *
	 * @param request The PANRequest containing necessary details for PAN fetching.
	 * @return A ResponseEntity<Object> containing the API response with PAN details.
	 */
	@PostMapping(PAN_TO_DOB)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> fetchPanDetails(@RequestBody PANRequest request) {
		auditUrl();
		return service.fetchPanDetails(request);
	}

	/**
	 * Verifies an email address based on the provided EmailVerifyRequest.
	 *
	 * @param request The EmailVerifyRequest containing necessary details for email verification.
	 * @return A ResponseEntity<Object> containing the API response with email verification details.
	 */
	@PostMapping(EMAIL_VERIFICATION)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> emailVerification(@RequestBody EmailVerifyRequest request) {
		auditUrl();
		return service.emailVerification(request);
	}
	
	/**
	 * Audits a customer detail event based on the provided PLCustomerDetailRequest.
	 *
	 * @param request The PLCustomerDetailRequest containing details for the audit event.
	 * @return A ResponseEntity<Object> containing the API response for the audit event.
	 */
	@PostMapping(AUDIT_EVENT)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> auditEvent(@RequestBody PLCustomerDetailRequest request) {
		auditUrl();
		return service.auditEvent(request);
	}
	
	/**
	 * 
	 * Retrieves account details for a given account ID.
	 * 
	 * @param request The account ID for which details are to be retrieved.
	 * @return A ResponseEntity<Object> containing the response entity with account
	 *         details,or an appropriate error response if the account details cannot be
	 *         retrieved.
	 */
	@PostMapping(AUDIT_EMP_LEAD)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> auditEmpLead(@RequestBody EmployeeLeadsRequest request) {
		auditUrl();
		return service.auditEmpLead(request);
	}
	
	/**
	 * Retrieves account details for a given account ID.
	 *
	 * @param accountid The account ID for which details are to be retrieved.
	 * @return A ResponseEntity<Object> containing the account details response.
	 */
	@GetMapping(ACCDETAILS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> accdetails(@PathVariable String accountid, @PathVariable String loanid, @PathVariable String customerid) {
		auditUrl();
		return service.accdetails(accountid, loanid, customerid);
	}
	
	/**
	 * Updates the status of API requests for a given account ID.
	 *
	 * @param accountid The account ID for which status needs to be updated.
	 * @return A ResponseEntity<Object> indicating the success or failure of the status update.
	 */
	@PostMapping(STATUSUPDATE)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> StatusUpdate(@PathVariable String accountid) {
		auditUrl();
		return service.statusUpdate(accountid);
	}
	
	/**
	 * Retrieves company master data from an external API.
	 *
	 * @param request The CompanyMasterRequest object containing necessary parameters.
	 * @return A ResponseEntity<Object> containing the API response for the company master data.
	 */
	@PostMapping(GET_COMPANY_MASTER)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getCompanyMaster(@RequestBody CompanyMasterRequest request) {
		auditUrl();
		return service.getCompanyMaster(request);
	}
	
	/**
	 * Generates PL-MIS report and sends it via an external API.
	 *
	 * @return A ResponseEntity<Object> containing the API response for the PL-MIS report generation.
	 */
	@PostMapping(GENERATE_PL_MIS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> generatePLMIS() {
		Object obj = null;
		if (null != isMISSchEnabled && isMISSchEnabled.equals(YES)) {
			return service.generatePLMIS();
		}else {
			obj = "PL MIS Scheduler is disabled";
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
	
}
