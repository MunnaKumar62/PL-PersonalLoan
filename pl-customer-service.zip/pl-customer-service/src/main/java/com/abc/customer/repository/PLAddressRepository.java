package com.abc.customer.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.PLAddress;

@Repository
public interface PLAddressRepository extends JpaRepository<PLAddress, Long> {

	@Query("SELECT a FROM PLAddress a WHERE a.addressId=(SELECT max(a.addressId) FROM PLAddress a WHERE a.customerId =:customerId and a.loanId =:loanId and a.accountId =:accountId and a.active= :active)")
	Optional<PLAddress> findByCustomerIdAndLoanIdAndAccountIdAndActive(Long customerId, String loanId, String accountId, Boolean active);

	@Query("SELECT a FROM PLAddress a WHERE a.addressId=(SELECT max(a.addressId) FROM PLAddress a WHERE a.customerId =:customerId and a.active= :active)")
	Optional<PLAddress> findByCustomerIdAndActive(Long customerId, Boolean active);
}
