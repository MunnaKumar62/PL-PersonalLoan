package com.abc.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.EmployeeLeads;

@Repository
public interface EmployeeLeadsRepository extends JpaRepository<EmployeeLeads, Long> {

}
