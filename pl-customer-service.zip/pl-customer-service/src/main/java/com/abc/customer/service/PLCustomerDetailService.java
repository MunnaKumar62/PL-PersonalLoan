package com.abc.customer.service;

import java.util.List;

import com.abc.customer.dto.PLCustomerDetailDto;
import com.abc.customer.dto.PLMISReport;
import com.abc.customer.entity.PLCustomerDetail;
import com.abc.customer.request.PLCustomerDetailRequest;

public interface PLCustomerDetailService {

	public String getAccessToken();

	public String generateToken();

	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto plCustomerDetailDto, String serviceName, String loanId);
	
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail);
	
	public PLCustomerDetail findByAccountIdAndActive(String accountId, String loanId, Boolean active);

	public PLCustomerDetail findByAccountIdAndLoanIdAndActiveAndCustomerId(String accountId, String loanId, Boolean active, Long customerId);

	public PLCustomerDetail findByAccountId(String accountId);

	public PLCustomerDetail auditEvent(PLCustomerDetailRequest request);
	
	public List<PLMISReport> fetchMISList(int days);

}
