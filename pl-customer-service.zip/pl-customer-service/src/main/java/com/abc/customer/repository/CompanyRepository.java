package com.abc.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.PLCompany;

@Repository
public interface CompanyRepository extends JpaRepository<PLCompany, Long> {

}
