package com.abc.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@PropertySource({"classpath:message.properties"})
@EnableScheduling
@OpenAPIDefinition(servers={@Server(url="${swagger.default.server.url}", description="Default Server URL")}, info=@Info(title="PL-Customer Service"))
public class CustomerInfoApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {

		return application.sources(CustomerInfoApplication.class);
	}

	public static void main(String[] args) {

		SpringApplication.run(CustomerInfoApplication.class, args);
	}

}
