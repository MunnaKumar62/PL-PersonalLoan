package com.abc.customer.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PanNameCheckRequest {
	
	@NotBlank
	private String name1;
	@NotBlank
	private String name2;
	private String transactionId;
	@NotBlank
	private String product;
	private String applicationId;
	private String loanId;
	private Long customerId;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("basic_consent")
	private String basicConsent;
	

}
