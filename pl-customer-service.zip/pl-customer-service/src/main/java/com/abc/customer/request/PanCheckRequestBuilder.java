package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PanCheckRequestBuilder {

    @JsonProperty("panNo")
    public String panNo;

    @JsonProperty("accountId")
    public String accountId;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("declared_first_name")
    public String declaredFirstName;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("declared_last_name")
    public String declaredLastName;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("declared_middle_name")
    public String declaredMiddleName;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("dob")
    public String dob;
}