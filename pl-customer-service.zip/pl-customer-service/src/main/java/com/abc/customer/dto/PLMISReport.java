package com.abc.customer.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PLMISReport {

	private PLCustomerDetailDto plCustomerDetailDto;
	
	private PLAddressDto plAddressDto;
	
	private LoanOfferDetailsDto loanOfferDetailsDto; 
	
	private Date modifiedDate;
	
}
