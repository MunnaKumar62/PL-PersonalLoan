package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PANRequest {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("panNumber")
	private String panNumber;

	@JsonProperty("loanId")
	private String loanId;

	@JsonProperty("customerId")
	private Long customerId;

}
