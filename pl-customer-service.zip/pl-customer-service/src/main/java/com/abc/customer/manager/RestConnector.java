package com.abc.customer.manager;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.abc.customer.cache.CustomerCacheService;
import com.abc.customer.entity.ApiStatus;
import com.abc.customer.exception.CustomException;
import com.abc.customer.repository.APIStatusRepository;
import com.abc.customer.service.ABFLServiceProvider;

import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class RestConnector {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private ObjectMapper objectMapper;
	
	
	@Autowired
	APIStatusRepository apiStatusRespo;

	public <T> T getForEntity(Class<T> clazz, String url, Object... uriVariables) {
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
			JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
			return readValue(response, javaType);
		} catch (HttpClientErrorException exception) {
			if (exception.getStatusCode() == HttpStatus.NOT_FOUND) {
				log.info("No data found {}", url);
			} else {
				log.info("rest client exception", exception.getMessage());
			}
		}
		return null;
	}

	public <T> List<T> getForList(Class<T> clazz, String url, Object... uriVariables) {
		try {
			ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, uriVariables);
			CollectionType collectionType = objectMapper.getTypeFactory().constructCollectionType(List.class, clazz);
			return readValue(response, collectionType);
		} catch (HttpClientErrorException exception) {
			if (exception.getStatusCode() == HttpStatus.NOT_FOUND) {
				log.info("No data found {}", url);
			} else {
				log.info("rest client exception", exception.getMessage());
			}
		}
		return null;
	}

	public <T, R> T postForEntity(Class<T> clazz, String url, R body, HttpHeaders h,String accountId, String requestName, Object... uriVariables)  {
		HttpEntity<R> request = new HttpEntity<>(body, h);
		try {
			
			ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class, uriVariables);
			JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
			return readValue(response, javaType);
		}catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {	
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				saveRequest(body ,ex.getResponseBodyAsString(), requestName, accountId);
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description") : "Partner Issue";
				}
			}
			log.info("PL-customerservice-HttpClientErrorException=" + ex.getResponseBodyAsString());
			throw new CustomException(code,description,errorType);
		} catch (Exception e) {
			System.out.println("pl-Rest-connector-Exception=" + e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}
	

	
	

	public <T, R> T putForEntity(Class<T> clazz, String url, R body, Object... uriVariables) {
		HttpEntity<R> request = new HttpEntity<>(body);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class,
				uriVariables);
		JavaType javaType = objectMapper.getTypeFactory().constructType(clazz);
		return readValue(response, javaType);
	}

	public void delete(String url, Object... uriVariables) {
		try {
			restTemplate.delete(url, uriVariables);
		} catch (RestClientException exception) {
			log.info(exception.getMessage());
		}
	}
	
	
	public ApiStatus saveRequest(Object callBackRequest , String callbackResponse, String apiName, String accountId) {
		String jsonObject = null;
		try {
			jsonObject = objectMapper.writeValueAsString(callBackRequest);
		
		//String jsonObjectResponse = objectMapper.writeValueAsString(callbackResponse);
		ApiStatus apiStatusRequest = ApiStatus.builder()
				.apiName(apiName)
				.accountId(accountId)				
				//.profileId(callBackRequest.getUniqueId())
				.journey("PL")
				.requestJson(jsonObject)
				.responseJson(callbackResponse)
				.status("ERROR")
				.build();
		ApiStatus apiStatus= apiStatusRespo.save(apiStatusRequest);
		return apiStatus;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/*public ApiStatus saveResponse(String callBackResponse, String apiName, String accountId) throws Exception{
		//String jsonObject = objectMapper.writeValueAsString(callBackResponse);
		ApiStatus apiStatusRequest = ApiStatus.builder()
				.apiName(apiName)
				.accountId(accountId)				
				.journey("PL")
				.responseJson(callBackResponse)
				.created_Date(new Date())
				.build();
		ApiStatus apiStatus= apiStatusRespo.save(apiStatusRequest);
		return apiStatus;
	} */
	private <T> T readValue(ResponseEntity<String> response, JavaType javaType) {
		T result = null;
		//if (response.getStatusCode() == HttpStatus.OK || response.getStatusCode() == HttpStatus.CREATED) {
			try {
				result = objectMapper.readValue(response.getBody(), javaType);
			} catch (IOException e) {
				log.info(e.getMessage());
			}
		//} else {
			//log.info("No data found {}", response.getStatusCode());
		//}
		return result;
	}
}
