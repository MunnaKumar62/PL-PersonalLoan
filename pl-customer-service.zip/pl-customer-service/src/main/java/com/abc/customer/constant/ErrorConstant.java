package com.abc.customer.constant;

public interface ErrorConstant {
	
	public final static String   RECORD_NOT_FOUND="Record not found for given : ";
	public final static String CLIENT="C";
	public final static String SERVER="S";
	public final static String TECHNICAL_ERROR="Technical Error";
	public final static String BUSINESS_ERROR="Business Error";
	public final static String ERROR_CODE_PREFIX_C="PL-EE-C" ;
	public final static String ERROR_CODE_PREFIX_S="PL-EE-S" ;
	public final static String COLON=": " ;

}
