package com.abc.customer.response;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.abc.customer.constant.Constants;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldErrorResponse {

	@JsonProperty("timestamp")
	private String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT));
	
	@JsonProperty("status")
	private String status;

	@JsonProperty("path")
	private String path;

	@JsonProperty("errors")
	private List<FieldError> errors;

}
