package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PLAddressRequest {

	@JsonProperty("addressId")
	private Long addressId;

	@JsonProperty("customerId")
	private Long customerId;

	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("loanId")
	private String loanId;

	@JsonProperty("addressLineOne")
	private String addressLineOne;

	@JsonProperty("addressLineTwo")
	private String addressLineTwo;

	@JsonProperty("city")
	private String city;

	@JsonProperty("landmark")
	private String landmark;

	@JsonProperty("pincode")
	private String pincode;

	@JsonProperty("state")
	private String state;

	@JsonProperty("orgAddressLineOne")
	private String orgAddressLineOne;

	@JsonProperty("orgAddressLineTwo")
	private String orgAddressLineTwo;

	@JsonProperty("orgCity")
	private String orgCity;

	@JsonProperty("orgState")
	private String orgState;

	@JsonProperty("orgPincode")
	private String orgPincode;

	@JsonProperty("orgEmail")
	private String orgEmail;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("active")
	private Boolean active;

}
