package com.abc.customer.service.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.abc.customer.entity.*;
import com.abc.customer.exception.CustomException;
import com.abc.customer.exception.InternalException;
import com.abc.customer.repository.CustomerRepository;
import com.abc.customer.request.ApiCommonRequest;
import com.abc.customer.request.GetLoanIDRequest;
import com.abc.customer.response.PANResponse;
import com.abc.customer.service.TokenService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import com.abc.customer.constant.Constants;
import com.abc.customer.constant.MessageConstants;
import com.abc.customer.dto.LoanOfferDetailsDto;
import com.abc.customer.dto.PLAddressDto;
import com.abc.customer.dto.PLCustomerDetailDto;
import com.abc.customer.dto.PLMISReport;
import com.abc.customer.repository.LoanOfferDetailsRepository;
import com.abc.customer.repository.PLCustomerDetailRepository;
import com.abc.customer.request.PLCustomerDetailRequest;
import com.abc.customer.service.PLAddressService;
import com.abc.customer.service.PLCustomerDetailService;
import com.abc.customer.service.biz.CommonBizService;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
public class PLCustomerDetailServiceImpl extends CommonBizService implements PLCustomerDetailService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	PLCustomerDetailRepository detailRepository;
	
	@Autowired
	LoanOfferDetailsRepository loanOfferDetailsRepository ;
	
	@Autowired
	private PLAddressService plAddressService;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private CustomerRepository customerRepository;

	@Value("${abc.getloanid.url}")
	private String loanidUrl;

	@Autowired
	RestTemplate restTemplate;

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${pl.token.scope}")
	private String scope;

	@Value("${pl.token.grant_type}")
	private String grantType;

	@Value("${pl.token.auth}")
	private String authToken;

	@Value("${pl.token.client_id}")
	private String clientId;

	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public String getAccessToken() {
		return tokenService.getAccessToken();
	}

	@Override
	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto tmp, String serviceName, String loanId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		
		/**
		 * Get Last updated record from t_pl_customer_detail table by accountId &
		 * active=false
		 */
		 PLCustomerDetail detail = findByAccountIdAndLoanIdAndActiveAndCustomerId(tmp.getAccountId(), loanId, Boolean.FALSE, tmp.getCustomerId());
		if (null == detail && !isEmptyOrNull(serviceName) && PL_PAN_NAME_CHECK.equalsIgnoreCase(serviceName)) {
			log.info(className + methodName + "[INITIATING NEW PL JOURNEY ... ...]");
			detail = new PLCustomerDetail();
			detail.setCreatedBy(CREATED_BY);
			detail.setCreatedDate(new Timestamp(new Date().getTime()));
		}
		if(null!= detail) {
			log.info(className + methodName + "[PLCustomerDetail: "+ detail.toString()+"]");
			detail = mergeDetails(tmp, detail);
			savOrUpdateCustomerDetails(detail);	
		}
		return detail;
	}

	@Override
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail) {

		return detailRepository.save(plCustomerDetail);
	}

	@Override
	public PLCustomerDetail findByAccountIdAndActive(String accountId, String loanId, Boolean active) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountIdAndActive(accountId, loanId, active);
		if (details.isPresent()) {
			customerDetail = details.get();
		}else {
			throw new CustomException("2031" + MessageConstants.PL_CUSTOMER_NOT_FOUND + details);
		}
		return customerDetail;
	}

	@Override
	public PLCustomerDetail findByAccountIdAndLoanIdAndActiveAndCustomerId(String accountId, String loanId, Boolean active, Long customerId) {

		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findLatestByAccountIdAndLoanIdAndCustomerIdAndActive(accountId, loanId, customerId, active);
		if (details.isPresent()) {
			customerDetail = details.get();
		}else {
			throw new CustomException("2031" + MessageConstants.PL_CUSTOMER_NOT_FOUND + details);
		}
		return customerDetail;
	}
	
	private PLCustomerDetail mergeDetails(PLCustomerDetailDto tmp, PLCustomerDetail detail) {
		
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		
		try {
			detail.setAccntCreateDate(null!=tmp.getAccntCreateDate()?tmp.getAccntCreateDate():detail.getAccntCreateDate());
			detail.setAccountId(tmp.getAccountId());
			detail.setApplicationId(!isEmptyOrNull(tmp.getApplicationId())?tmp.getApplicationId():detail.getApplicationId());
			detail.setTransactionId(!isEmptyOrNull(tmp.getTransactionId())?tmp.getTransactionId():detail.getTransactionId());
			detail.setCccId(!isEmptyOrNull(tmp.getCccId())?tmp.getCccId():detail.getCccId());
			detail.setMobilenumber(!isEmptyOrNull(tmp.getMobilenumber())?tmp.getMobilenumber():detail.getMobilenumber());
			detail.setCreditScore(!isEmptyOrNull(tmp.getCreditScore())?tmp.getCreditScore():detail.getCreditScore());
			detail.setLoanPurpose(!isEmptyOrNull(tmp.getLoanPurpose())?tmp.getLoanPurpose():detail.getLoanPurpose());
			detail.setFirstnameLastname(!isEmptyOrNull(tmp.getFirstnameLastname())?tmp.getFirstnameLastname():detail.getFirstnameLastname());
			detail.setPannumber(!isEmptyOrNull(tmp.getPannumber())?tmp.getPannumber():detail.getPannumber());
			detail.setDateOfBirth(null!=tmp.getDateOfBirth()?tmp.getDateOfBirth():detail.getDateOfBirth());
			detail.setGender(!isEmptyOrNull(tmp.getGender())?tmp.getGender():detail.getGender());
			detail.setEmail(!isEmptyOrNull(tmp.getEmail())?tmp.getEmail():detail.getEmail());
			detail.setWorkEmail(!isEmptyOrNull(tmp.getWorkEmail())?tmp.getWorkEmail():detail.getWorkEmail());
			detail.setWorkemailAddedDate(null!=tmp.getWorkemailAddedDate()?tmp.getWorkemailAddedDate():detail.getWorkemailAddedDate());
			detail.setBreloanAmount(null!=tmp.getBreloanAmount()?tmp.getBreloanAmount():detail.getBreloanAmount());
			detail.setBreroi(null!=tmp.getBreroi()?tmp.getBreroi():detail.getBreroi());
			detail.setBreOffertime(null!=tmp.getBreOffertime()?tmp.getBreOffertime():detail.getBreOffertime());
			detail.setBreRejectReason(!isEmptyOrNull(tmp.getBreRejectReason())?tmp.getBreRejectReason():detail.getBreRejectReason());
			detail.setCeStatus(!isEmptyOrNull(tmp.getCeStatus())?tmp.getCeStatus():detail.getCeStatus());
			detail.setBre2loanAmount(null!=tmp.getBre2loanAmount()?tmp.getBre2loanAmount():detail.getBre2loanAmount());
			detail.setBre2roi(null!=tmp.getBre2roi()?tmp.getBre2roi():detail.getBre2roi());
			detail.setBre2Offertime(null!=tmp.getBre2Offertime()?tmp.getBre2Offertime():detail.getBre2Offertime());
			detail.setBre2RejectReason(!isEmptyOrNull(tmp.getBre2RejectReason())?tmp.getBre2RejectReason():detail.getBre2RejectReason());
			detail.setCe2Status(!isEmptyOrNull(tmp.getCe2Status())?tmp.getCe2Status():detail.getCe2Status());
			detail.setEmandateStatus(!isEmptyOrNull(tmp.getEmandateStatus())?tmp.getEmandateStatus():detail.getEmandateStatus());
			detail.setEmanDatetime(null!=tmp.getEmanDatetime()?tmp.getEmanDatetime():detail.getEmanDatetime());
			detail.setDigilockerConsent(!isEmptyOrNull(tmp.getDigilockerConsent())?tmp.getDigilockerConsent():detail.getDigilockerConsent());
			detail.setDigilockerConsentDatetime(null!=tmp.getDigilockerConsentDatetime()?tmp.getDigilockerConsentDatetime():detail.getDigilockerConsentDatetime());
			detail.setDigilockerStatus(!isEmptyOrNull(tmp.getDigilockerStatus())?tmp.getDigilockerStatus():detail.getDigilockerStatus());
			detail.setDigilockerTime(null!=tmp.getDigilockerTime()?tmp.getDigilockerTime():detail.getDigilockerTime());
			detail.setUkycStatus(!isEmptyOrNull(tmp.getUkycStatus())?tmp.getUkycStatus():detail.getUkycStatus());
			detail.setUkycTime(null!=tmp.getUkycTime()?tmp.getUkycTime():detail.getUkycTime());
			detail.setCurrentScreen(!isEmptyOrNull(tmp.getCurrentScreen())?tmp.getCurrentScreen():detail.getCurrentScreen());
			detail.setAppPlatform(!isEmptyOrNull(tmp.getAppPlatform())?tmp.getAppPlatform():detail.getAppPlatform());
			detail.setBasicConsent(!isEmptyOrNull(tmp.getBasicConsent())?tmp.getBasicConsent():detail.getBasicConsent());
			detail.setBasicConsentDatetime(null!=tmp.getBasicConsentDatetime()?tmp.getBasicConsentDatetime():detail.getBasicConsentDatetime());
			detail.setBankConsent(!isEmptyOrNull(tmp.getBankConsent())?tmp.getBankConsent():detail.getBankConsent());
			detail.setBankConsentDatetime(null!=tmp.getBankConsentDatetime()?tmp.getBankConsentDatetime():detail.getBankConsentDatetime());
			detail.setKycAddressConsent(!isEmptyOrNull(tmp.getKycAddressConsent())?tmp.getKycAddressConsent():detail.getKycAddressConsent());
			detail.setKycAddressConsentDatetime(null!=tmp.getKycAddressConsentDatetime()?tmp.getKycAddressConsentDatetime():detail.getKycAddressConsentDatetime());
			detail.setUkycAddressConsent(!isEmptyOrNull(tmp.getUkycAddressConsent())?tmp.getUkycAddressConsent():detail.getUkycAddressConsent());
			detail.setUkycAddressConsentDatetime(null!=tmp.getUkycAddressConsentDatetime()?tmp.getUkycAddressConsentDatetime():detail.getUkycAddressConsentDatetime());
			detail.setBankaccountId(!isEmptyOrNull(tmp.getBankaccountId())?tmp.getBankaccountId():detail.getBankaccountId());	
			detail.setPennydropStatus(!isEmptyOrNull(tmp.getPennydropStatus())?tmp.getPennydropStatus():detail.getPennydropStatus());
			detail.setBankDetailValidation(!isEmptyOrNull(tmp.getBankDetailValidation())?tmp.getBankDetailValidation():detail.getBankDetailValidation());
			detail.setDigisignConsent(!isEmptyOrNull(tmp.getDigisignConsent())?tmp.getDigisignConsent():detail.getDigisignConsent());
			detail.setDigisignConsentDatetime(null!=tmp.getDigisignConsentDatetime()?tmp.getDigisignConsentDatetime():detail.getDigisignConsentDatetime());
			detail.setActive(null!=tmp.getActive()?tmp.getActive():detail.getActive());
			detail.setModifiedBy(CREATED_BY);
			detail.setModifiedDate(new Timestamp(new Date().getTime()));
			detail.setSalaried(null!=tmp.getSalaried()?tmp.getSalaried():detail.getSalaried());
			detail.setSelfEmployed(null!=tmp.getSelfEmployed()?tmp.getSelfEmployed():detail.getSelfEmployed());
			detail.setLoanAmount(null!=tmp.getLoanAmount()?tmp.getLoanAmount():detail.getLoanAmount());
			detail.setMonthlyIncome(null!=tmp.getMonthlyIncome()?tmp.getMonthlyIncome():detail.getMonthlyIncome());
			detail.setWorkAddress(!isEmptyOrNull(tmp.getWorkAddress())?tmp.getWorkAddress():detail.getWorkAddress());
			detail.setTenure(null!=tmp.getTenure()?tmp.getTenure():detail.getTenure());
			detail.setUkycInit(!isEmptyOrNull(tmp.getUkycInit())?tmp.getUkycInit():detail.getUkycInit());
			detail.setKycType(!isEmptyOrNull(tmp.getKycType())?tmp.getKycType():detail.getKycType());
			detail.setUkycInitTime(null!=tmp.getUkycInitTime()?tmp.getUkycInitTime():detail.getUkycInitTime());
			detail.setLeadId(!isEmptyOrNull(tmp.getLeadId())?tmp.getLeadId():detail.getLeadId());

			detail.setA8ApplicationStatus(!isEmptyOrNull(tmp.getA8ApplicationStatus()) ? tmp.getA8ApplicationStatus():detail.getA8ApplicationStatus());
			detail.setA8CallbackResp(!isEmptyOrNull(tmp.getA8CallbackResp()) ? tmp.getA8CallbackResp():detail.getA8CallbackResp());
			detail.setA8VideoPdStatus(!isEmptyOrNull(tmp.getA8VideoPdStatus()) ? tmp.getA8VideoPdStatus():detail.getA8VideoPdStatus());
			detail.setA8FlgUpdFrom(!isEmptyOrNull(tmp.getA8FlgUpdFrom()) ? tmp.getA8FlgUpdFrom():detail.getA8FlgUpdFrom());
			detail.setA8ProcessInstanceId(!isEmptyOrNull(tmp.getA8ProcessInstanceId()) ? tmp.getA8ProcessInstanceId():detail.getA8ProcessInstanceId());
			detail.setPrevA8CeStatus(!isEmptyOrNull(tmp.getPrevA8CeStatus()) ? tmp.getPrevA8CeStatus():detail.getPrevA8CeStatus());
			detail.setA8FiStatus(!isEmptyOrNull(tmp.getA8FiStatus()) ? tmp.getA8FiStatus() : detail.getA8FiStatus());
			detail.setA8SanctionDetails(!isEmptyOrNull(tmp.getA8SanctionDetails()) ? tmp.getA8SanctionDetails():detail.getA8SanctionDetails());

			detail.setProfileid(!isEmptyOrNull(tmp.getProfileid())?tmp.getProfileid():detail.getProfileid());
			detail.setIncomeVerifyTxnid(!isEmptyOrNull(tmp.getIncomeVerifyTxnid())?tmp.getIncomeVerifyTxnid():detail.getIncomeVerifyTxnid());
			detail.setCeStart(!isEmptyOrNull(tmp.getCeStart())?tmp.getCeStart():detail.getCeStart());
			detail.setCeStartDatetime(null!=tmp.getCeStartDatetime()?tmp.getCeStartDatetime():detail.getCeStartDatetime());
			detail.setCe2Start(!isEmptyOrNull(tmp.getCe2Start())?tmp.getCe2Start():detail.getCe2Start());
			detail.setCe2StartDatetime(null!=tmp.getCe2StartDatetime()?tmp.getCe2StartDatetime():detail.getCe2StartDatetime());
			detail.setDigilockerStart(!isEmptyOrNull(tmp.getDigilockerStart())?tmp.getDigilockerStart():detail.getDigilockerStart());
			detail.setDigilockerStartDatetime(null!=tmp.getDigilockerStartDatetime()?tmp.getDigilockerStartDatetime():detail.getDigilockerStartDatetime());
			detail.setPersonalDetailsComplete(!isEmptyOrNull(tmp.getPersonalDetailsComplete())?tmp.getPersonalDetailsComplete():detail.getPersonalDetailsComplete());
			detail.setPersonalDetailsCompleteDatetime(null!=tmp.getPersonalDetailsCompleteDatetime()?tmp.getPersonalDetailsCompleteDatetime():detail.getPersonalDetailsCompleteDatetime());
			detail.setWorkDetailsStatus(!isEmptyOrNull(tmp.getWorkDetailsStatus())?tmp.getWorkDetailsStatus():detail.getWorkDetailsStatus());
			detail.setWorkDetailsStatusDatetime(null!=tmp.getWorkDetailsStatusDatetime()?tmp.getWorkDetailsStatusDatetime():detail.getWorkDetailsStatusDatetime());
			detail.setContactRefComplete(!isEmptyOrNull(tmp.getContactRefComplete())?tmp.getContactRefComplete():detail.getContactRefComplete());
			detail.setContactRefCompleteDatetime(null!=tmp.getContactRefCompleteDatetime()?tmp.getContactRefCompleteDatetime():detail.getContactRefCompleteDatetime());
			detail.setContactRefName1(!isEmptyOrNull(tmp.getContactRefName1())?tmp.getContactRefName1():detail.getContactRefName1());
			detail.setContactRefName2(!isEmptyOrNull(tmp.getContactRefName2())?tmp.getContactRefName2():detail.getContactRefName2());
			detail.setContactRefMob1(!isEmptyOrNull(tmp.getContactRefMob1())?tmp.getContactRefMob1():detail.getContactRefMob1());
			detail.setContactRefMob2(!isEmptyOrNull(tmp.getContactRefMob2())?tmp.getContactRefMob2():detail.getContactRefMob2());
			detail.setFinalLoanComplete(!isEmptyOrNull(tmp.getFinalLoanComplete())?tmp.getFinalLoanComplete():detail.getFinalLoanComplete());
			detail.setFinalLoanCompleteDatetime(null!=tmp.getFinalLoanCompleteDatetime()?tmp.getFinalLoanCompleteDatetime():detail.getFinalLoanCompleteDatetime());
			detail.setLoanId(!isEmptyOrNull(tmp.getLoanId())?tmp.getLoanId():detail.getLoanId());
			detail.setCustomerId(null!=tmp.getCustomerId()?tmp.getCustomerId():detail.getCustomerId());
		
		}catch (CustomException e) {
			log.info("Error in mergeDetails API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in mergeDetails API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in mergeDetails API: " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("2032");
		}
		return detail;
	}

	@Override
	public PLCustomerDetail findByAccountId(String accountId) {
		PLCustomerDetail customerDetail = null;
		Optional<PLCustomerDetail> details = detailRepository.findByAccountId(accountId);
		if (details.isPresent()) {
			customerDetail = details.get();
		}else {
			throw new CustomException("2031" + MessageConstants.PL_CUSTOMER_NOT_FOUND + details);
		}
		return customerDetail;
	}

	@Override
	public PLCustomerDetail auditEvent(PLCustomerDetailRequest request) {
		/**
		 * Get Last updated record from t_pl_customer_detail table by accountId &
		 * active=false
		 */
		PLCustomerDetail detail = null;
		detail = findByAccountIdAndActive(request.getAccountId(), request.getLoanId(), Boolean.FALSE);
		Map<String, String> map = new HashMap<String, String>();
		if (null == detail) {
			detail = new PLCustomerDetail();
			detail.setAccntCreateDate(new Timestamp(new Date().getTime()));
			detail.setActive(Boolean.FALSE);
			detail.setCreatedBy(CREATED_BY);
			detail.setSalaried(Boolean.FALSE);
			detail.setSelfEmployed(Boolean.FALSE);
			detail.setCreatedDate(new Timestamp(new Date().getTime()));
			GetLoanIDRequest getLoanIDRequest = new GetLoanIDRequest();
			getLoanIDRequest.setCustomerId(request.getCustomerId());
			getLoanIDRequest.setLobId("PL");
			getLoanIDRequest.setAccountId(request.getAccountId());
			CustomerDetails customerDetails = new CustomerDetails();
			Optional<CustomerDetails> details = customerRepository.findByAccountId(request.getAccountId());
			if (details.isPresent()) {
				customerDetails = details.get();
			}

			String loanidUrlFinal = "";
			String lobId = Constants.PL_JOURNEY;
			loanidUrlFinal = loanidUrl + "?customerId="+request.getCustomerId()+"&accountId="+request.getAccountId()+"&lobId="+lobId;
			ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
			HttpEntity<Object> headers = new HttpEntity<>(getLoanIDRequest, getRequestHeaders(generateToken()));
			apiResponse = restTemplate.exchange(loanidUrlFinal, HttpMethod.GET, headers, Object.class);
			System.out.println(apiResponse.getBody());
			map = (Map<String, String>) apiResponse.getBody();
		}

		detail = mergeRequestDetails(request, detail, map.get("loanId"));
		savOrUpdateCustomerDetails(detail);
		return detail;
	}

	@Override
	public String generateToken() {
		TokenResponse tokenResp = null;
		try {
			log.info("Generate Token Start");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam("client_id", clientId)
					.queryParam("scope", scope).queryParam("grant_type", grantType).build();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			headers.add("Authorization", "Basic " + authToken);

			HttpEntity<Object> request = new HttpEntity<>(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					request, String.class);

			tokenResp = objectMapper.readValue(responseEntity.getBody(), TokenResponse.class);

			if (Objects.isNull(tokenResp) || Objects.isNull(tokenResp.getAccessToken())) {

				throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
						// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
						HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

			}

			log.info("Token " + tokenResp.getAccessToken());
			log.info("Generate Token End");
		}catch (CustomException e) {
			log.info("Error in generateToken API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in generateToken API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in generateToken API: " + e.getResponseBodyAsString());
			throw e;
		} catch (Exception e) {
			//throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
					// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
			throw new InternalException("2033");	
		}

		return tokenResp.getAccessToken();
	}
	
	private PLCustomerDetail mergeRequestDetails(PLCustomerDetailRequest tmp, PLCustomerDetail detail, String loanId) {
		
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		
		try {
			detail.setAccntCreateDate(null!=tmp.getAccntCreateDate()?tmp.getAccntCreateDate():detail.getAccntCreateDate());
			detail.setAccountId(tmp.getAccountId());
			detail.setApplicationId(!isEmptyOrNull(tmp.getApplicationId())?tmp.getApplicationId():detail.getApplicationId());
			detail.setTransactionId(!isEmptyOrNull(tmp.getTransactionId())?tmp.getTransactionId():detail.getTransactionId());
			detail.setCccId(!isEmptyOrNull(tmp.getCccId())?tmp.getCccId():detail.getCccId());
			detail.setMobilenumber(!isEmptyOrNull(tmp.getMobilenumber())?tmp.getMobilenumber():detail.getMobilenumber());
			detail.setCreditScore(!isEmptyOrNull(tmp.getCreditScore())?tmp.getCreditScore():detail.getCreditScore());
			detail.setLoanPurpose(!isEmptyOrNull(tmp.getLoanPurpose())?tmp.getLoanPurpose():detail.getLoanPurpose());
			detail.setFirstnameLastname(!isEmptyOrNull(tmp.getFirstnameLastname())?tmp.getFirstnameLastname():detail.getFirstnameLastname());
			detail.setPannumber(!isEmptyOrNull(tmp.getPannumber())?tmp.getPannumber():detail.getPannumber());
			detail.setDateOfBirth(!isEmptyOrNull(tmp.getDateOfBirth())?LocalDate.parse(tmp.getDateOfBirth(), DateTimeFormatter.ofPattern(DATE_FORMAT)):detail.getDateOfBirth());
			detail.setGender(!isEmptyOrNull(tmp.getGender())?tmp.getGender():detail.getGender());
			detail.setEmail(!isEmptyOrNull(tmp.getEmail())?tmp.getEmail():detail.getEmail());
			detail.setWorkEmail(!isEmptyOrNull(tmp.getWorkEmail())?tmp.getWorkEmail():detail.getWorkEmail());
			detail.setWorkemailAddedDate(!isEmptyOrNull(tmp.getWorkemailAddedDate())?formatDateToIST(tmp.getWorkemailAddedDate()):detail.getWorkemailAddedDate());
			detail.setBreloanAmount(null!=tmp.getBreloanAmount()?tmp.getBreloanAmount():detail.getBreloanAmount());
			detail.setBreroi(null!=tmp.getBreroi()?tmp.getBreroi():detail.getBreroi());
			detail.setBreOffertime(null!=tmp.getBreOffertime()?tmp.getBreOffertime():detail.getBreOffertime());
			detail.setBreRejectReason(!isEmptyOrNull(tmp.getBreRejectReason())?tmp.getBreRejectReason():detail.getBreRejectReason());
			detail.setCeStatus(!isEmptyOrNull(tmp.getCeStatus())?tmp.getCeStatus():detail.getCeStatus());
			detail.setBre2loanAmount(null!=tmp.getBre2loanAmount()?tmp.getBre2loanAmount():detail.getBre2loanAmount());
			detail.setBre2roi(null!=tmp.getBre2roi()?tmp.getBre2roi():detail.getBre2roi());
			detail.setBre2Offertime(null!=tmp.getBre2Offertime()?tmp.getBre2Offertime():detail.getBre2Offertime());
			detail.setBre2RejectReason(!isEmptyOrNull(tmp.getBre2RejectReason())?tmp.getBre2RejectReason():detail.getBre2RejectReason());
			detail.setCe2Status(!isEmptyOrNull(tmp.getCe2Status())?tmp.getCe2Status():detail.getCe2Status());
			detail.setEmandateStatus(!isEmptyOrNull(tmp.getEmandateStatus())?tmp.getEmandateStatus():detail.getEmandateStatus());
			detail.setEmanDatetime(null!=tmp.getEmanDatetime()?tmp.getEmanDatetime():detail.getEmanDatetime());
			detail.setDigilockerConsent(!isEmptyOrNull(tmp.getDigilockerConsent())?tmp.getDigilockerConsent():detail.getDigilockerConsent());
			detail.setDigilockerConsentDatetime(null!=tmp.getDigilockerConsentDatetime()?tmp.getDigilockerConsentDatetime():detail.getDigilockerConsentDatetime());
			detail.setDigilockerStatus(!isEmptyOrNull(tmp.getDigilockerStatus())?tmp.getDigilockerStatus():detail.getDigilockerStatus());
			detail.setDigilockerTime(null!=tmp.getDigilockerTime()?tmp.getDigilockerTime():detail.getDigilockerTime());
			detail.setUkycStatus(!isEmptyOrNull(tmp.getUkycStatus())?tmp.getUkycStatus():detail.getUkycStatus());
			detail.setUkycTime(null!=tmp.getUkycTime()?tmp.getUkycTime():detail.getUkycTime());
			detail.setCurrentScreen(!isEmptyOrNull(tmp.getCurrentScreen())?tmp.getCurrentScreen():detail.getCurrentScreen());
			detail.setAppPlatform(!isEmptyOrNull(tmp.getAppPlatform())?tmp.getAppPlatform():detail.getAppPlatform());
			detail.setBasicConsent(!isEmptyOrNull(tmp.getBasicConsent())?tmp.getBasicConsent():detail.getBasicConsent());
			detail.setBasicConsentDatetime(!isEmptyOrNull(tmp.getBasicConsentDatetime())?formatDateToIST(tmp.getBasicConsentDatetime()):detail.getBasicConsentDatetime());
			detail.setBankConsent(!isEmptyOrNull(tmp.getBankConsent())?tmp.getBankConsent():detail.getBankConsent());
			detail.setBankConsentDatetime(null!=tmp.getBankConsentDatetime()?tmp.getBankConsentDatetime():detail.getBankConsentDatetime());
			detail.setKycAddressConsent(!isEmptyOrNull(tmp.getKycAddressConsent())?tmp.getKycAddressConsent():detail.getKycAddressConsent());
			detail.setKycAddressConsentDatetime(null!=tmp.getKycAddressConsentDatetime()?tmp.getKycAddressConsentDatetime():detail.getKycAddressConsentDatetime());
			detail.setUkycAddressConsent(!isEmptyOrNull(tmp.getUkycAddressConsent())?tmp.getUkycAddressConsent():detail.getUkycAddressConsent());
			detail.setUkycAddressConsentDatetime(null!=tmp.getUkycAddressConsentDatetime()?tmp.getUkycAddressConsentDatetime():detail.getUkycAddressConsentDatetime());
			detail.setBankaccountId(!isEmptyOrNull(tmp.getBankaccountId())?tmp.getBankaccountId():detail.getBankaccountId());	
			detail.setPennydropStatus(!isEmptyOrNull(tmp.getPennydropStatus())?tmp.getPennydropStatus():detail.getPennydropStatus());
			detail.setBankDetailValidation(!isEmptyOrNull(tmp.getBankDetailValidation())?tmp.getBankDetailValidation():detail.getBankDetailValidation());
			detail.setDigisignConsent(!isEmptyOrNull(tmp.getDigisignConsent())?tmp.getDigisignConsent():detail.getDigisignConsent());
			detail.setDigisignConsentDatetime(null!=tmp.getDigisignConsentDatetime()?tmp.getDigisignConsentDatetime():detail.getDigisignConsentDatetime());
			detail.setActive(null!=tmp.getActive()?tmp.getActive():detail.getActive());
			detail.setModifiedBy(CREATED_BY);
			detail.setModifiedDate(new Timestamp(new Date().getTime()));
			detail.setSalaried(null!=tmp.getSalaried()?tmp.getSalaried():detail.getSalaried());
			detail.setSelfEmployed(null!=tmp.getSelfEmployed()?tmp.getSelfEmployed():detail.getSelfEmployed());
			detail.setLoanAmount(null!=tmp.getLoanAmount()?tmp.getLoanAmount():detail.getLoanAmount());
			detail.setMonthlyIncome(null!=tmp.getMonthlyIncome()?tmp.getMonthlyIncome():detail.getMonthlyIncome());
			detail.setWorkAddress(!isEmptyOrNull(tmp.getWorkAddress())?tmp.getWorkAddress():detail.getWorkAddress());
			detail.setTenure(null!=tmp.getTenure()?tmp.getTenure():detail.getTenure());
			detail.setUkycInit(!isEmptyOrNull(tmp.getUkycInit())?tmp.getUkycInit():detail.getUkycInit());
			detail.setKycType(!isEmptyOrNull(tmp.getKycType())?tmp.getKycType():detail.getKycType());
			detail.setUkycInitTime(null!=tmp.getUkycInitTime()?tmp.getUkycInitTime():detail.getUkycInitTime());
			detail.setLeadId(!isEmptyOrNull(tmp.getLeadId())?tmp.getLeadId():detail.getLeadId());

			detail.setA8ApplicationStatus(!isEmptyOrNull(tmp.getA8ApplicationStatus()) ? tmp.getA8ApplicationStatus():detail.getA8ApplicationStatus());
			detail.setA8CallbackResp(!isEmptyOrNull(tmp.getA8CallbackResp()) ? tmp.getA8CallbackResp():detail.getA8CallbackResp());
			detail.setA8VideoPdStatus(!isEmptyOrNull(tmp.getA8VideoPdStatus()) ? tmp.getA8VideoPdStatus():detail.getA8VideoPdStatus());
			detail.setA8FlgUpdFrom(!isEmptyOrNull(tmp.getA8FlgUpdFrom()) ? tmp.getA8FlgUpdFrom():detail.getA8FlgUpdFrom());
			detail.setA8ProcessInstanceId(!isEmptyOrNull(tmp.getA8ProcessInstanceId()) ? tmp.getA8ProcessInstanceId():detail.getA8ProcessInstanceId());
			detail.setPrevA8CeStatus(!isEmptyOrNull(tmp.getPrevA8CeStatus()) ? tmp.getPrevA8CeStatus():detail.getPrevA8CeStatus());
			detail.setA8FiStatus(!isEmptyOrNull(tmp.getA8FiStatus()) ? tmp.getA8FiStatus() : detail.getA8FiStatus());
			detail.setA8SanctionDetails(!isEmptyOrNull(tmp.getA8SanctionDetails()) ? tmp.getA8SanctionDetails():detail.getA8SanctionDetails());

			detail.setProfileid(!isEmptyOrNull(tmp.getProfileid())?tmp.getProfileid():detail.getProfileid());
			detail.setIncomeVerifyTxnid(!isEmptyOrNull(tmp.getIncomeVerifyTxnid())?tmp.getIncomeVerifyTxnid():detail.getIncomeVerifyTxnid());
			detail.setCeStart(!isEmptyOrNull(tmp.getCeStart())?tmp.getCeStart():detail.getCeStart());
			detail.setCeStartDatetime(null!=tmp.getCeStartDatetime()?tmp.getCeStartDatetime():detail.getCeStartDatetime());
			detail.setCe2Start(!isEmptyOrNull(tmp.getCe2Start())?tmp.getCe2Start():detail.getCe2Start());
			detail.setCe2StartDatetime(null!=tmp.getCe2StartDatetime()?tmp.getCe2StartDatetime():detail.getCe2StartDatetime());
			detail.setDigilockerStart(!isEmptyOrNull(tmp.getDigilockerStart())?tmp.getDigilockerStart():detail.getDigilockerStart());
			detail.setDigilockerStartDatetime(null!=tmp.getDigilockerStartDatetime()?tmp.getDigilockerStartDatetime():detail.getDigilockerStartDatetime());
			detail.setPersonalDetailsComplete(!isEmptyOrNull(tmp.getPersonalDetailsComplete())?tmp.getPersonalDetailsComplete():detail.getPersonalDetailsComplete());
			detail.setPersonalDetailsCompleteDatetime(!isEmptyOrNull(tmp.getPersonalDetailsCompleteDatetime())?formatDateToIST(tmp.getPersonalDetailsCompleteDatetime()):detail.getPersonalDetailsCompleteDatetime());
			detail.setWorkDetailsStatus(!isEmptyOrNull(tmp.getWorkDetailsStatus())?tmp.getWorkDetailsStatus():detail.getWorkDetailsStatus());
			detail.setWorkDetailsStatusDatetime(!isEmptyOrNull(tmp.getWorkDetailsStatusDatetime())?formatDateToIST(tmp.getWorkDetailsStatusDatetime()):detail.getWorkDetailsStatusDatetime());
			detail.setContactRefComplete(!isEmptyOrNull(tmp.getContactRefComplete())?tmp.getContactRefComplete():detail.getContactRefComplete());
			detail.setContactRefCompleteDatetime(!isEmptyOrNull(tmp.getContactRefCompleteDatetime())?formatDateToIST(tmp.getContactRefCompleteDatetime()):detail.getContactRefCompleteDatetime());
			detail.setContactRefName1(!isEmptyOrNull(tmp.getContactRefName1())?tmp.getContactRefName1():detail.getContactRefName1());
			detail.setContactRefName2(!isEmptyOrNull(tmp.getContactRefName2())?tmp.getContactRefName2():detail.getContactRefName2());
			detail.setContactRefMob1(!isEmptyOrNull(tmp.getContactRefMob1())?tmp.getContactRefMob1():detail.getContactRefMob1());
			detail.setContactRefMob2(!isEmptyOrNull(tmp.getContactRefMob2())?tmp.getContactRefMob2():detail.getContactRefMob2());
			detail.setFinalLoanComplete(!isEmptyOrNull(tmp.getFinalLoanComplete())?tmp.getFinalLoanComplete():detail.getFinalLoanComplete());
			detail.setFinalLoanCompleteDatetime(null!=tmp.getFinalLoanCompleteDatetime()?tmp.getFinalLoanCompleteDatetime():detail.getFinalLoanCompleteDatetime());
			detail.setOrganizationName(!isEmptyOrNull(tmp.getOrganizationName())?tmp.getOrganizationName():detail.getOrganizationName());
			detail.setJourneyType(!isEmptyOrNull(tmp.getJourneyType())?tmp.getJourneyType():detail.getJourneyType());
			detail.setMandateMethod(!isEmptyOrNull(tmp.getMandateMethod())?tmp.getMandateMethod():detail.getMandateMethod());
			detail.setLoanId(!isEmptyOrNull(loanId)?loanId:detail.getLoanId());
			detail.setCustomerId(null != tmp.getCustomerId()?tmp.getCustomerId():detail.getCustomerId());
		}catch (CustomException e) {
			log.info("Error in mergeRequestDetails API " + e.getMessage());
			throw e;
		} catch (HttpClientErrorException e) {
			log.error("Error in mergeRequestDetails API: " + e.getResponseBodyAsString());
			throw e;
		} catch (HttpServerErrorException e) {
			log.error("Error in mergeRequestDetails API: " + e.getResponseBodyAsString());
			throw e;
		}catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("2034");
		}
		return detail;
	}

	@Override
	public List<PLMISReport> fetchMISList(int days){
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		
		List<PLMISReport> reports = new ArrayList<>();
		List<PLCustomerDetail> list = null;
		SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd 00:00:00.000");
		Calendar cal = Calendar.getInstance();
		Date today = cal.getTime();
		cal.add(Calendar.DAY_OF_YEAR, -days);
		Date datedays = cal.getTime();
		try {
			log.info(className + methodName + "[From Date: " + sd.parse(sd.format(datedays)) + "- To Date: " + today + "]");
			
			boolean[] arr = {Boolean.TRUE, Boolean.FALSE};
			
			for (boolean flag : arr) {
				list = detailRepository.findByActiveAndModifiedDateBetween(flag, sd.parse(sd.format(datedays)),
						sd.parse(sd.format(today)));
				for (PLCustomerDetail detail : list) {
				PLMISReport report = new PLMISReport();
				PLCustomerDetailDto detailDto = new PLCustomerDetailDto();
				LoanOfferDetailsDto offerDetailsDto = new LoanOfferDetailsDto();
				PLAddressDto addressDto = new PLAddressDto();
				
				BeanUtils.copyProperties(detail, detailDto);
				report.setPlCustomerDetailDto(detailDto);
				report.setModifiedDate(detail.getModifiedDate());
				LoanOfferDetails offerDetails =	null;
				if (flag) {
					offerDetails = loanOfferDetailsRepository.findLatestByAccountIdAndDisburalStatus(detail.getAccountId());
				} else {
					offerDetails = loanOfferDetailsRepository.findLatestByAccountId(detail.getAccountId());
				}
				if(null != offerDetails) {
					BeanUtils.copyProperties(offerDetails, offerDetailsDto);
					report.setLoanOfferDetailsDto(offerDetailsDto);	
					PLAddress address = plAddressService.findByCustomerIdAndActive(offerDetails.getCustomerid(), flag);
					if(null != address) {
					BeanUtils.copyProperties(address, addressDto);
					report.setPlAddressDto(addressDto);
					}
				}
				
				reports.add(report);
			}
		}

		Comparator<PLMISReport> comparator = (c1, c2) -> c1.getPlCustomerDetailDto().getModifiedDate()
				.compareTo(c2.getPlCustomerDetailDto().getModifiedDate());
		reports.sort(Collections.reverseOrder(comparator));
		
	}catch (CustomException e) {
		log.info("Error in fetchMISList API " + e.getMessage());
		throw e;
	} catch (HttpClientErrorException e) {
		log.error("Error in fetchMISList API: " + e.getResponseBodyAsString());
		throw e;
	} catch (HttpServerErrorException e) {
		log.error("Error in fetchMISList API: " + e.getResponseBodyAsString());
		throw e;
	} catch (ParseException e) {
			e.printStackTrace();
	} catch (Exception e) {
			log.info("Error in fetchMISList API: :" + e.getMessage());
			throw new InternalException("2035comp");
		}
		return reports;
	}

	public static Date formatDateToIST(String date) {
		Date convertedDate = null;
		try {
			TimeZone zone = TimeZone.getTimeZone("IST");
			SimpleDateFormat sourceFormat = new SimpleDateFormat(DATE_TIME_ZONE_FORMAT);
			sourceFormat.setTimeZone(zone);
			convertedDate = sourceFormat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return convertedDate;
	}
	public static void main(String[] args) {
		System.out.println(formatDateToIST("2024-05-31T14:29:10.058Z"));
	}
}
