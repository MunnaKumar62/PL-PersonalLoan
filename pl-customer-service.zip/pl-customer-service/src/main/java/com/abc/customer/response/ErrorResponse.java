package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	private Error error;

	private String errorCode;
	private String errorMessage;
	private String code;
	private String message;
	private String errorType;

}
