package com.abc.customer.response;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.abc.customer.constant.Constants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SuccessResponse {

	@JsonProperty("timestamp")
	private String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT));

	@JsonProperty("status")
	private String status;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("code")
	private String code;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("message")
	private String message;

	@JsonProperty("data")
	private Object data;

}
