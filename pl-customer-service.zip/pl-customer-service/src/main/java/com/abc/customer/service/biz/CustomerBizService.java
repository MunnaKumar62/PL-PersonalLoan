package com.abc.customer.service.biz;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abc.customer.constant.Constants;
import com.abc.customer.constant.MessageConstants;
import com.abc.customer.dto.PLCompanyDto;
import com.abc.customer.exception.InternalException;
import com.abc.customer.request.CompanyMasterRequest;
import com.abc.customer.request.EmailVerifyRequest;
import com.abc.customer.request.EmployeeLeadsRequest;
import com.abc.customer.request.GenerateCCCIDRequest;
import com.abc.customer.request.PANRequest;
import com.abc.customer.request.PLAddressRequest;
import com.abc.customer.request.PLCustomerDetailRequest;
import com.abc.customer.request.PanCheckRequest;
import com.abc.customer.request.PanNameCheckRequest;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CustomerBizService implements Constants, MessageConstants {

	public PanCheckRequest validatePANCheckRequest(PanCheckRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getPanNo())) {
				msg = FILED_PAN_NO + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}

	public PanNameCheckRequest validatePANNameCheckRequest(PanNameCheckRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getApplicationId())) {
				msg = FILED_APPLICATION_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}

	public PANRequest validatePANRequest(PANRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getPanNumber())) {
				msg = FILED_NUMBER + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}

	public EmailVerifyRequest validateEmailRequest(EmailVerifyRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (StringUtils.isBlank(request.getAccountId())) {
			msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
		} else if (StringUtils.isBlank(request.getEmail())) {
			msg = FILED_EMAIL + TILDA + EMPTY_FIELD;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}

	public GenerateCCCIDRequest validateGcccIdRequest(GenerateCCCIDRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (StringUtils.isBlank(request.getAccountId())) {
			msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
		} else if (StringUtils.isBlank(request.getFirstName())) {
			msg = FIELD_FIRST_NAME + TILDA + EMPTY_FIELD;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}

	public PLAddressRequest validateAddressRequest(PLAddressRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (null == request.getCustomerId()) {
				msg = FILED_CUST_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}

	public String validateSearchAddressRequest(String input) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (StringUtils.isBlank(input)) {
			msg = INPUT + TILDA + EMPTY_PARAM;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return input;
	}

	public List<String> apiNameList(String whiteListedServices) {

		List<String> list = new ArrayList<>();
		if (!StringUtils.isBlank(whiteListedServices)) {
			String[] arr = whiteListedServices.split(COMMA);
			if (arr.length > 1) {
				for (String str : arr) {
					str = str.trim();
					list.add(str);
				}
			}
		}
		return list;
	}

	public List<PLCompanyDto> searchCompanyList(List<PLCompanyDto> list, String employerName) {

		//list.stream().forEach(p -> System.out.print(p));
		
		List<PLCompanyDto> list1 = list.stream()
				.filter(p -> null != p.getEmployerName()&& p.getEmployerName().toUpperCase().startsWith(employerName.toUpperCase()))
				.collect(Collectors.toList());

		return (null != list1 && !list1.isEmpty()) ? list1 : List.of();
	}
	
	public PLCustomerDetailRequest validatePLCustomerDetailRequest(PLCustomerDetailRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACCT_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getCurrentScreen())) {
				msg = FILED_CURR_SCR + TILDA + EMPTY_FIELD;
			}else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}
	
	public EmployeeLeadsRequest validateEmployeeLeadsRequest(EmployeeLeadsRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (null== request.getCustomerId()) {
				msg = FILED_CUSTOMER_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getJourney())) {
				msg = FILED_JOURNEY + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getChannel())) {
				msg = FILED_CHANNEL + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getPageName())) {
				msg = FILED_PAGE_NAME + TILDA + EMPTY_FIELD;
			}else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}
	
	public String accountIdRequest(String accountId) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != accountId) {
			if (StringUtils.isBlank(accountId)) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return accountId;
	}

	public CompanyMasterRequest validateCompanyMasterRequest(CompanyMasterRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (StringUtils.isBlank(request.getCompany())) {
			msg = FILED_COMPANY + TILDA + EMPTY_FIELD;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			log.error(msg);
			throw new InternalException("1002",msg);
		}
		return request;
	}
	

}
