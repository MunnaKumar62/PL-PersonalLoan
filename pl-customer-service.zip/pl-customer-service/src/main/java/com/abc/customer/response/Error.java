package com.abc.customer.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Error {

	private String code;
	private String errorType;
	private String description;

}
