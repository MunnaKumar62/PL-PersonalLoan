package com.abc.customer.exception;

public class GcpStorageException extends RuntimeException{

    private int statusCode;
    private String errorCode;

    public GcpStorageException(String message) {
        super(message);
    }

    public GcpStorageException(String message,int statusCode,String errorCode) {
        super(message);
        this.statusCode = statusCode;
        this.errorCode = errorCode;
    }

}
