package com.abc.customer.exception;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExceptionResponse {

	private Integer code;
	private String reason;
	private String errorCode;
	private String errorMessage;
	private String message;
	private String errorType;

}
