package com.abc.customer.request;

import java.util.Date;

import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PLCustomerDetailRequest {

	@JsonProperty("customer_detail_id")
	private Long customerDetailId;

	@JsonProperty("accnt_create_date")
	private Date accntCreateDate;

	@JsonProperty("accountid")
	private String accountId;

	@JsonProperty("customerId")
	private Long customerId;

	@JsonProperty("loanId")
	private String loanId;

	@JsonProperty("applicationid")
	private String applicationId;

	@JsonProperty("transactionid")
	private String transactionId;

	@JsonProperty("cccid")
	private String cccId;

	@JsonProperty("mobilenumber")
	private String mobilenumber;

	@JsonProperty("credit_score")
	private String creditScore;

	@JsonProperty("loan_purpose")
	private String loanPurpose;

	@JsonProperty("firstname_lastname")
	private String firstnameLastname;

	@JsonProperty("pannumber")
	private String pannumber;

	@JsonProperty("dob")
	private String dateOfBirth;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("email")
	private String email;

	@JsonProperty("work_email")
	private String workEmail;

	@JsonProperty("workemail_added_date")
	private String workemailAddedDate;

	@JsonProperty("breloan_amount")
	private Double breloanAmount;

	@JsonProperty("breroi")
	private Double breroi;

	@JsonProperty("bre_offertime")
	private Date breOffertime;

	@JsonProperty("bre_reject_reason")
	private String breRejectReason;

	@JsonProperty("ce_status")
	private String ceStatus;

	@JsonProperty("bre2loan_amount")
	private Double bre2loanAmount;

	@JsonProperty("bre2roi")
	private Double bre2roi;

	@JsonProperty("bre2_offertime")
	private Date bre2Offertime;

	@JsonProperty("bre2_reject_reason")
	private String bre2RejectReason;

	@JsonProperty("ce_2_status")
	private String ce2Status;

	@JsonProperty("emandate_status")
	private String emandateStatus;

	@JsonProperty("eman_datetime")
	private Date emanDatetime;

	@JsonProperty("ckyc_status")
	private String ckycStatus;

	@JsonProperty("ckyctime")
	private Date ckyctime;

	@JsonProperty("digilocker_consent")
	private String digilockerConsent;

	@JsonProperty("digilocker_consent_datetime")
	private Date digilockerConsentDatetime;

	@JsonProperty("digilocker_status")
	private String digilockerStatus;

	@JsonProperty("digilocker_time")
	private Date digilockerTime;

	@JsonProperty("ukyc_status")
	private String ukycStatus;

	@JsonProperty("ukyc_time")
	private Date ukycTime;

	@JsonProperty("current_screen")
	private String currentScreen;

	@JsonProperty("app_platform")
	private String appPlatform;

	@JsonProperty("basic_consent")
	private String basicConsent;

	@JsonProperty("basic_consent_datetime")
	private String basicConsentDatetime;

	@JsonProperty("bank_consent")
	private String bankConsent;

	@JsonProperty("bank_consent_datetime")
	private Date bankConsentDatetime;

	@JsonProperty("kyc_address_consent")
	private String kycAddressConsent;

	@JsonProperty("kyc_address_consent_datetime")
	private Date kycAddressConsentDatetime;

	@JsonProperty("ukyc_address_consent")
	private String ukycAddressConsent;

	@JsonProperty("ukyc_address_consent_datetime")
	private Date ukycAddressConsentDatetime;

	@JsonProperty("bankaccount_id")
	private String bankaccountId;

	@JsonProperty("pennydrop_status")
	private String pennydropStatus;

	@JsonProperty("bank_detail_validation")
	private String bankDetailValidation;

	@JsonProperty("docusign_consent")
	private String digisignConsent;

	@JsonProperty("docusign_consent_datetime")
	private Date digisignConsentDatetime;

	@JsonProperty("active")
	private Boolean active;

	@JsonProperty("created_by")
	private String createdBy;

	@JsonProperty("created_date")
	private Date createdDate;

	@JsonProperty("modified_by")
	private String modifiedBy;

	@JsonProperty("modified_date")
	@UpdateTimestamp
	private Date modifiedDate;

	@JsonProperty("salaried")
	private Boolean salaried;

	@JsonProperty("self_employed")
	private Boolean selfEmployed;

	@JsonProperty("loan_amount")
	private Double loanAmount;

	@JsonProperty("monthly_income")
	private Double monthlyIncome;

	@JsonProperty("work_address")
	private String workAddress;

	@JsonProperty("tenure")
	private Integer tenure;

	@JsonProperty("ukyc_init")
	private String ukycInit;

	@JsonProperty("kyc_type")
	private String kycType;

	@JsonProperty("ukyc_init_time")
	private Date ukycInitTime;

	@JsonProperty("a8_application_status")
	private String a8ApplicationStatus;

	@JsonProperty("a8_callback_resp")
	private String a8CallbackResp;

	@JsonProperty("a8_video_pd_status")
	private String a8VideoPdStatus;

	@JsonProperty("a8_flg_upd_from")
	private String a8FlgUpdFrom;

	@JsonProperty("a8_process_instance_id")
	private String a8ProcessInstanceId;

	@JsonProperty("prev_a8_ce_status")
	private String prevA8CeStatus;

	@JsonProperty("a8_fi_status")
	private String a8FiStatus;

	@JsonProperty("a8_sanction_details")
	private String a8SanctionDetails;

	@JsonProperty("lead_id")
	private String leadId;

	@JsonProperty("profileid")
	private String profileid;

	@JsonProperty("income_verify_txnid")
	private String incomeVerifyTxnid;

	@JsonProperty("ce_start")
	private String ceStart;

	@JsonProperty("ce_start_datetime")
	private Date ceStartDatetime;

	@JsonProperty("ce_2_start")
	private String ce2Start;

	@JsonProperty("ce_2Start_datetime")
	private Date ce2StartDatetime;

	@JsonProperty("digilocker_start")
	private String digilockerStart;

	@JsonProperty("digilocker_start_datetime")
	private Date digilockerStartDatetime;

	@JsonProperty("personal_details_complete")
	private String personalDetailsComplete;

	@JsonProperty("personal_details_complete_datetime")
	private String personalDetailsCompleteDatetime;

	@JsonProperty("work_details_status")
	private String workDetailsStatus;

	@JsonProperty("work_details_status_datetime")
	private String workDetailsStatusDatetime;

	@JsonProperty("contact_ref_complete")
	private String contactRefComplete;

	@JsonProperty("contact_ref_complete_datetime")
	private String contactRefCompleteDatetime;

	@JsonProperty("contact_ref_name1")
	private String contactRefName1;

	@JsonProperty("contact_ref_name2")
	private String contactRefName2;

	@JsonProperty("contact_ref_mob1")
	private String contactRefMob1;

	@JsonProperty("contact_ref_mob2")
	private String contactRefMob2;

	@JsonProperty("final_loan_complete")
	private String finalLoanComplete;

	@JsonProperty("final_loan_complete_datetime")
	private Date finalLoanCompleteDatetime;
	
	@JsonProperty("organization_name")
	private String organizationName;

	@JsonProperty("journey_type")
	private String journeyType;

	@JsonProperty("mandate_method")
	private String mandateMethod;
	
}
