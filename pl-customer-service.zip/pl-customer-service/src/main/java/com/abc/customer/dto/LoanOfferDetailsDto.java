package com.abc.customer.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanOfferDetailsDto {

	private Double loanOfferId;

	private Double loanAmount;

	private Boolean isAvailCoupons = false;

	private Integer tenure;

	private Double rateOfInterest;

	private Double monthlyEmi;

	private Double creditedAmount;

	private String emiDate;

	private long customerid;
	
	private LocalDateTime offerDate;

	private Double processingFee;

	private Double stampDutyCharges;

	private Double interest;

	private Double repaymentAmount;
	
	private Double apr;
	
	private Boolean active;

	private String loanNo;

	private String accountId;

	private String loanType;

	private String bankaccountdtlId;

	private String utrno;

	private String uniqueId;

	private String disburalStatus;

	private LocalDateTime loanDisbursalDate;

	private String loanDisbursalStart;

	private LocalDateTime loanDisbursalStartDatetime;

}
