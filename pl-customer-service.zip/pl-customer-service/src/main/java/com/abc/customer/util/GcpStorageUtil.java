package com.abc.customer.util;

import com.google.api.gax.paging.Page;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/*@Component
public class GcpStorageUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(GcpStorageUtil.class);

    @Value("${gcp.bucket.id}")
    private String bucketName;
    @Autowired
    private Storage storage;

    public Blob uploadFile(String fileData, String filePath) throws IOException {
        try {
            BlobId blobId = BlobId.of(bucketName, filePath);
            BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
            InputStream targetStream = new ByteArrayInputStream(fileData.getBytes());
            targetStream.close();
            Blob bolb = storage.createFrom(blobInfo, targetStream);
            LOGGER.info("File uploaded to bucket " + bucketName + " as " + filePath);
            return bolb;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public Page<Blob> getFileByPath(String filePath) throws IOException {
        try {
            Page<Blob> blobs =
                    storage.list(
                            bucketName,
                            Storage.BlobListOption.prefix(filePath),
                            Storage.BlobListOption.currentDirectory());
            LOGGER.info("Files in bucket " + bucketName + " at locaton " + filePath);
            return blobs;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
} */
