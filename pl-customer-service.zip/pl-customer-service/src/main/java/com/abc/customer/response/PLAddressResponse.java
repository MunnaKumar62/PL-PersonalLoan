package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PLAddressResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;

}
