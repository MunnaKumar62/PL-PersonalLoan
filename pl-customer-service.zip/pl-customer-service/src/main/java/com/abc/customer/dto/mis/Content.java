package com.abc.customer.dto.mis;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Content {

	@JsonProperty("type")
	public String type;
	
	@JsonProperty("value")
	public String value;
	
}
