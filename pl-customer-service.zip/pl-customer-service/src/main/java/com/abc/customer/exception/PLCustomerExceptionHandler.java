package com.abc.customer.exception;


import com.google.gson.JsonParseException;

import org.hibernate.TypeMismatchException;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponseException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abc.customer.response.ServiceProviderErrorResponse;
import com.abc.customer.util.CommonUtil;

import io.micrometer.common.lang.Nullable;

import com.abc.customer.model.ErrorResponse;
import com.abc.customer.response.FieldErrorResponse;
import com.abc.customer.response.Response;
import com.abc.customer.response.ResponseStatusCode;

//@RestControllerAdvice
public class PLCustomerExceptionHandler {

	/*@ExceptionHandler(Exception.class)
	public Response<Object> handleException1(Exception ex, WebRequest request) {
		return new Response<>(ex.getLocalizedMessage(), HttpStatus.BAD_REQUEST.value(),
				ResponseStatusCode.ERROR.getCode());
	}


	@ExceptionHandler(GcpStorageException.class)
	public Response<Object> hadleGcpStorageException(Exception ex, WebRequest request) {
		return new Response<>(ex.getLocalizedMessage(), HttpStatus.BAD_REQUEST.value(),
				ResponseStatusCode.ERROR.getCode());
	}
	
	@ExceptionHandler(CustomException.class)
	@Nullable
	public ResponseEntity<Object> customExceptionHandler(CustomException ex, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		//WebRequest request = null;
		FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, HttpStatus.PARTIAL_CONTENT, request);
		return new ResponseEntity<>(errorResponse, headers, HttpStatus.PARTIAL_CONTENT);
	}

	@ExceptionHandler({ HttpRequestMethodNotSupportedException.class, HttpMediaTypeNotSupportedException.class,
			HttpMediaTypeNotAcceptableException.class, MissingPathVariableException.class,
			MissingServletRequestParameterException.class, MissingServletRequestPartException.class,
			ServletRequestBindingException.class, MethodArgumentNotValidException.class, NoHandlerFoundException.class,
			AsyncRequestTimeoutException.class, ErrorResponseException.class, ConversionNotSupportedException.class,
			TypeMismatchException.class, HttpMessageNotReadableException.class, HttpMessageNotWritableException.class,
			BindException.class })
	@Nullable
	public final ResponseEntity<Object> handleException(Exception ex, WebRequest request) throws Exception {
		if (ex instanceof HttpRequestMethodNotSupportedException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());
		} else if (ex instanceof HttpMediaTypeNotSupportedException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof HttpMediaTypeNotAcceptableException subEx) {
			ErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MissingPathVariableException subEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MissingServletRequestParameterException subEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MissingServletRequestPartException subEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof ServletRequestBindingException subEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof MethodArgumentNotValidException subEx) {
		
			BindingResult result = subEx.getBindingResult();
			List<FieldError> fieldErrors = result.getFieldErrors();
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(fieldErrors, subEx.getHeaders(),
					subEx.getStatusCode(), request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		} else if (ex instanceof NoHandlerFoundException subEx) {

			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getStatusCode());

		} else if (ex instanceof AsyncRequestTimeoutException subEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getStatusCode());

		} else if (ex instanceof ErrorResponseException subEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, subEx.getHeaders(), subEx.getStatusCode(),
					request);
			return new ResponseEntity<>(errorResponse, subEx.getHeaders(), subEx.getStatusCode());

		}

		// Lower level exceptions, and exceptions used symmetrically on client and
		// server
		HttpHeaders headers = new HttpHeaders();
		if (ex instanceof ConversionNotSupportedException theEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.INTERNAL_SERVER_ERROR,
					request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (ex instanceof TypeMismatchException theEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_GATEWAY, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);
		} else if (ex instanceof HttpMessageNotReadableException theEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_REQUEST, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);
		} else if (ex instanceof HttpMessageNotWritableException theEx) {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.INTERNAL_SERVER_ERROR,
					request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.INTERNAL_SERVER_ERROR);
		} else if (ex instanceof BindException theEx) {

			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_REQUEST, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);

		} else {
			FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, headers, HttpStatus.BAD_REQUEST, request);
			return new ResponseEntity<>(errorResponse, headers, HttpStatus.BAD_REQUEST);

		}
	} */
}
