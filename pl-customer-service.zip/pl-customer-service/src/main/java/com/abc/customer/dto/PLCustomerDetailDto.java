package com.abc.customer.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PLCustomerDetailDto {

	private Long customerDetailId;

	private Date accntCreateDate;

	private String accountId;

	private Long customerId;

	private String loanId;

	private String applicationId;

	private String transactionId;

	private String cccId;

	private String mobilenumber;

	private String creditScore;

	private String loanPurpose;

	private String firstnameLastname;

	private String pannumber;

	private LocalDate dateOfBirth;

	private String gender;

	private String email;

	private String workEmail;

	private Date workemailAddedDate;

	private Double breloanAmount;

	private Double breroi;

	private Date breOffertime;

	private String breRejectReason;

	private String ceStatus;

	private Double bre2loanAmount;

	private Double bre2roi;

	private Date bre2Offertime;

	private String bre2RejectReason;

	private String ce2Status;

	private String emandateStatus;

	private Date emanDatetime;

	private String ckycStatus;

	private Date ckyctime;

	private String digilockerConsent;

	private Date digilockerConsentDatetime;

	private String digilockerStatus;

	private Date digilockerTime;

	private String ukycStatus;

	private Date ukycTime;

	private String currentScreen;

	private String appPlatform;

	private String basicConsent;

	private Date basicConsentDatetime;

	private String bankConsent;

	private Date bankConsentDatetime;

	private String kycAddressConsent;

	private Date kycAddressConsentDatetime;

	private String ukycAddressConsent;

	private Date ukycAddressConsentDatetime;

	private String bankaccountId;

	private String pennydropStatus;

	private String bankDetailValidation;

	private String digisignConsent;

	private Date digisignConsentDatetime;

	private Boolean active;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;
	
	private String a8ApplicationStatus;

	private String a8CallbackResp;

	private String a8VideoPdStatus;

	private String a8FlgUpdFrom;

	private String a8ProcessInstanceId;

	private String prevA8CeStatus;

	private String a8FiStatus;

	private String a8SanctionDetails;

	private String ukycInit;
	
	private String kycType;

	private Date ukycInitTime;
	
	private Boolean  salaried;
	
	private Boolean selfEmployed;
	
	private Double loanAmount;
	
	private Double monthlyIncome;
	
	private String workAddress;
	
	private Integer tenure;
	
	private String leadId;
	
	private String profileid;
	
	private String incomeVerifyTxnid;
	
	private String ceStart;
		
	private Date ceStartDatetime;
	
	private String ce2Start;
		
	private Date ce2StartDatetime;

	private String digilockerStart;
		
	private Date digilockerStartDatetime;

	private String personalDetailsComplete;
		
	private Date personalDetailsCompleteDatetime;

	private String workDetailsStatus;
		
	private Date workDetailsStatusDatetime;

	private String contactRefComplete;
		
	private Date contactRefCompleteDatetime;

	private String contactRefName1;

	private String contactRefName2;

	private String contactRefMob1;

	private String contactRefMob2;
		
	private String finalLoanComplete;
		
	private Date finalLoanCompleteDatetime;
	
	private String decisionEngineRejectReason;
	
	private String breSubRejectReason;
	
	private String bre2SubRejectReason;
}
