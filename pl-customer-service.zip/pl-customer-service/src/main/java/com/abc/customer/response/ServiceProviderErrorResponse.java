package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceProviderErrorResponse<T> {

	private String message;
	private T data;
	private String code;
	private String description;
	private String errorType;

	public ServiceProviderErrorResponse(String message, String code, String description, String errorType) {
		if(errorType != null) {
		if (errorType.equalsIgnoreCase("INTERNAL_API_FAILED_TO_RESPOND")) {
			this.message = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";
		} else {
			this.message = message;
		}
		}else {
			this.message = message;
		}

		this.code = code;
		this.description = description;
		this.errorType = errorType;

	}

}
