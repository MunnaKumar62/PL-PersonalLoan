package com.abc.customer.service;

import com.abc.customer.entity.PLAddress;
import com.abc.customer.request.PLAddressRequest;

public interface PLAddressService {

	public PLAddress findByCustomerIdAndActive(Long customerId, Boolean active);

	public PLAddress findByCustomerIdAndLoanIdAndAccountIdActive(Long customerId, String loanId, String accountId, Boolean active);

	public PLAddress saveOrUpdate(PLAddressRequest request);
}
