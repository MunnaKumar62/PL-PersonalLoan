package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PanCheckResponse {
	
	private String panId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String statusCode;
	private String panTitle;
	private String lastUpdateDate;
	private String panStatus;
	private String responseTimeStamp;
	

}
