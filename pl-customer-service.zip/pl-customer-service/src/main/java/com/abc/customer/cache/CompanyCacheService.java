package com.abc.customer.cache;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.customer.dto.PLCompanyDto;
import com.abc.customer.entity.PLCompany;
import com.abc.customer.repository.CompanyRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CompanyCacheService {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	private static final String COMPANY_CACHE = "PLCompany";
	private static final String CACHE_PARAM = "employerName";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	CompanyRepository companyRepository;

	public List<PLCompanyDto> getCompanyListFromCache() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		List<PLCompanyDto> list = null;
		log.info(className + methodName + "BEGIN");
		try {
			String jsonInput = redisCacheProvider.getData(COMPANY_CACHE, CACHE_PARAM);
			log.info(className + methodName + "[COMPANY_CACHE]"+jsonInput);
			if (StringUtils.isNotBlank(jsonInput)) {
				list = mapper.readValue(jsonInput, new TypeReference<List<PLCompanyDto>>() {
				});
			}
			log.info(className + methodName + "[LIST_SIZE]"+list.size());
			if (null == list || list.isEmpty()) {
				log.info(className + methodName + "[Reading from Database]");
				list = readFromDatabase();
			}
			log.info(className + methodName + "END");
		} catch (Exception ex) {
			log.error(className + methodName + "[EXCEPTION]" + "[" + ex.getMessage() + "]");
			list = readFromDatabase();
		}
		
		return list;
	}

	public void addCompanyListToCache(List<PLCompanyDto> list) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			redisCacheProvider.addData(COMPANY_CACHE, CACHE_PARAM, mapper.writeValueAsString(list));

		} catch (Exception ex) {
			log.error(className + methodName + "[EXCEPTION]" + "[" + ex.getMessage() + "]");
		}
	}
	
	public List<PLCompanyDto> readFromDatabase() {
		
		List<PLCompany> list1 = companyRepository.findAll();

		List<PLCompanyDto> list = list1.stream()
				.map(p -> PLCompanyDto.builder().companyId(p.getCompanyId()).employerId(p.getEmployerId())
						.employerName(p.getEmployerName()).emplyerCategory(p.getEmplyerCategory()).build())
				.collect(Collectors.toList());

		addCompanyListToCache(list);
		
		return list;
		
	}
}
