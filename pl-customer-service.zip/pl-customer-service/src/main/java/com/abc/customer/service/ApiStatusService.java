package com.abc.customer.service;

import com.abc.customer.entity.ApiStatus;

public interface ApiStatusService {

	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus);
	
}
