package com.abc.customer.response;

import com.abc.customer.dto.mis.PLMISData;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.auto.value.AutoValue.Builder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PLMISResponse {

	@JsonProperty("data")
	public PLMISData data;
	
	@JsonProperty("message")
	public String message;
	
	@JsonProperty("status")
	public String status;
	
}
