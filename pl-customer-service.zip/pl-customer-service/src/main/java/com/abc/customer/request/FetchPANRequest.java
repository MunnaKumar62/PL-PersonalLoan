package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FetchPANRequest {

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("panNumber")
    private String panNumber;
}