/*
 * Copyright Avaya Inc., All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 *
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 *
 * Some third-party source code components may have  been modified from their
 * original versions by Avaya Inc.
 *
 * The modifications are Copyright Avaya Inc., All Rights Reserved.
 */

package com.abc.customer.exception;

public class FileParseException extends Exception {

    
	private static final long serialVersionUID = 7384352212176513802L;

	public FileParseException(String errorCode) {
        super();
    }

    public FileParseException(String errorCode, Throwable e) {
        super(errorCode, e);
    }
}
