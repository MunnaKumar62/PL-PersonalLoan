package com.abc.customer.response;

import com.abc.customer.dto.pan.Result;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.auto.value.AutoValue.Builder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PANResponse {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("result")
	public Result result;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
