package com.abc.customer.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AddressResponse {

	@JsonProperty("predictions")
	public List<Prediction> predictions;

}
