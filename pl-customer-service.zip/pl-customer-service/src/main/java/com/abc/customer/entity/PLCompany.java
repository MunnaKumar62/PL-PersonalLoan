package com.abc.customer.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_pl_company_list")
public class PLCompany {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "plcompany_id")
	private Integer companyId;

	@Column(name = "employer_id")
	private String employerId;

	@Column(name = "employer_name")
	private String employerName;

	@Column(name = "employer_catg")
	private String emplyerCategory;

}
