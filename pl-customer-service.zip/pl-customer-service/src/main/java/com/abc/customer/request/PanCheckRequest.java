package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PanCheckRequest {
	
	@JsonProperty("panNo")
	public String panNo;
	
	@JsonProperty("accountId")
	public String accountId;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("declared_first_name")
	public String declaredFirstName;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("declared_last_name")
	public String declaredLastName;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("declared_middle_name")
	public String declaredMiddleName;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("dob")
	public String dob;

	@JsonProperty("loanId")
	private String loanId;

	@JsonProperty("customerId")
	private Long customerId;

}
