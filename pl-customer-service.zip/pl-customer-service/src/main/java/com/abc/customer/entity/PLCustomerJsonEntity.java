package com.abc.customer.entity;

import java.time.LocalDateTime;
import java.util.Date;

import org.hibernate.annotations.CurrentTimestamp;

import org.hibernate.annotations.JdbcType;

import org.hibernate.annotations.Type;

import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.util.JSONPObject;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.Lob;

import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;

import lombok.Builder;

import lombok.Getter;

import lombok.NoArgsConstructor;

import lombok.Setter;

@Entity

@JsonIgnoreProperties(ignoreUnknown = true)

@JsonInclude(Include.NON_EMPTY)

@NoArgsConstructor

@AllArgsConstructor

@Builder

@Getter

@Setter

@Table(name = "t_pl_customerjson")

public class PLCustomerJsonEntity {

	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Integer customerjson_id;

	@Column(name = "customerid")

	private int customerId;

	@Column(name = "accountid")

	private String accountId;

	@Column(name = "customerjson", columnDefinition = "json")

	@Lob

	private String customerJson;


	@Column(name = "createdby",length = 50)
	private String createdBy;

	 
	@Column(name = "createddate")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modifiedby",length = 50)
	private String modifiedBy;
	 
	@JsonDeserialize(using = DateHandler.class)
	@Column(name = "modifieddate")
	private LocalDateTime modifiedDate;


	@Column(name = "active",length = 5)
	private String active;


}
