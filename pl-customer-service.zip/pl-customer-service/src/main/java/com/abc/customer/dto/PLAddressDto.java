package com.abc.customer.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PLAddressDto {

	private Long addressId;

	private Long customerId;

	private String addressLineOne;

	private String addressLineTwo;

	private String city;

	private String landmark;

	private String pincode;

	private String state;

	private String orgAddressLineOne;

	private String orgAddressLineTwo;

	private String orgCity;

	private String orgState;

	private String orgPincode;

	private String orgEmail;

	private Boolean active;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;
}
