package com.abc.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.LoanOfferDetails;

@Repository
public interface LoanOfferDetailsRepository extends JpaRepository<LoanOfferDetails, Long> {

	@Query(value = "SELECT b.loan_offer_id,b.loanamount,b.rateof_interest,b.customer_id,b.account_id,b.unique_id,"
			+ "b.disbursal_status,b.loan_disbursal_date,b.loan_disbursal_start,b.loan_disbursal_start_datetime "
			+ "FROM t_pl_customer_detail a, t_pl_loan_offer_details b " 
			+ "WHERE b.loan_disbursal_start='Y' "
			+ "AND b.disbursal_status in('INITIATED','IN_PROGRESS') " 
			+ "AND b.unique_id is not null "
			+ "AND a.active=false " 
			+ "AND a.accountid=b.account_id", nativeQuery = true)
	public List<LoanOfferDetails> getPendingDisbursals();

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE account_id = :accountId "
			+ "AND disbursal_status = 'DISBURSED' "
			+ "AND loan_disbursal_start='Y' "
			+ "ORDER BY loan_offer_id DESC LIMIT 1 ", nativeQuery = true)
	public LoanOfferDetails findLatestByAccountIdAndDisburalStatus(@Param("accountId") String accountId);
	
	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE account_id = :accountId "
			+ "AND (disbursal_status IS NULL OR disbursal_status <> 'DISBURSED') "
			+ "ORDER BY loan_offer_id DESC LIMIT 1 ", nativeQuery = true)
	public LoanOfferDetails findLatestByAccountId(@Param("accountId") String accountId);
}
