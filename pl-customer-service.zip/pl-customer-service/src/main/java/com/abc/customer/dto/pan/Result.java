package com.abc.customer.dto.pan;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Result {

	@JsonProperty("name")
	public String name;

	@JsonProperty("dob")
	public String dob;

	@JsonProperty("firstName")
	public String firstName;

	@JsonProperty("middleName")
	public String middleName;

	@JsonProperty("lastName")
	public String lastName;

	@JsonProperty("panStatus")
	public String panStatus;

}
