package com.abc.customer.service.impl;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.customer.constant.Constants;
import com.abc.customer.entity.ApiStatus;
import com.abc.customer.repository.APIStatusRepository;
import com.abc.customer.service.ApiStatusService;

@Service
public class ApiStatusServiceImpl implements ApiStatusService, Constants {

	@Autowired
	APIStatusRepository apiStatusRepo;

	@Override
	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus) {

		return apiStatusRepo.save(apiStatus);
	}

	public LocalDateTime convertToLocalDateTimeViaInstant(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	public LocalDateTime convertToLocalDateTime(Date dateToConvert) {
		return Instant.ofEpochMilli(dateToConvert.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

}
