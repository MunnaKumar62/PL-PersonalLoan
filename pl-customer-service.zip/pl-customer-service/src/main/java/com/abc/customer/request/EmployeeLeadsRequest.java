package com.abc.customer.request;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class EmployeeLeadsRequest {

	@JsonProperty("customer_id")
	private Long customerId;

	@JsonProperty("journey")
	private String journey;

	@JsonProperty("lob_id")
	private String lobId;

	@JsonProperty("page_name")
	private String pageName;

	@JsonProperty("channel")
	private String channel;
	
	@JsonProperty("url_link")
	private String urlLink;

}
