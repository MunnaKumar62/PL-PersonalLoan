package com.abc.customer.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class GenerateCCCIDRequest {
	
	@NotBlank
	private String accountId;
	@NotBlank
	private String firstName;
	@NotBlank
	private String panNo;
	@NotBlank
	private String loanId;
	@NotBlank
	private Long customerId;
	
	

}
