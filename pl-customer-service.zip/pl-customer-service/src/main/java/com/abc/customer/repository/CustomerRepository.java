package com.abc.customer.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.CustomerDetails;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerDetails, Long> {

	Optional<CustomerDetails> findByMobileNumber(String mobileNumber);
	
	Optional<CustomerDetails> findByAccountId(String accountId);
}
