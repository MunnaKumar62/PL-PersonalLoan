package com.abc.customer.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PLCustomerDetailsResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonProperty("loanId")
	private String loanId;

}
