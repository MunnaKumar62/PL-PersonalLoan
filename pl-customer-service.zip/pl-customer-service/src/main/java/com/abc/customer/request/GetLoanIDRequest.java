package com.abc.customer.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetLoanIDRequest {

    @JsonProperty("customerId")
    private Long customerId;

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("lobId")
    private String lobId;
}