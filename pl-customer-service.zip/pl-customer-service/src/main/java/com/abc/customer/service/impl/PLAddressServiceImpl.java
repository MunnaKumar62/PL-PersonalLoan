package com.abc.customer.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.customer.constant.Constants;
import com.abc.customer.constant.MessageConstants;
import com.abc.customer.entity.PLAddress;
import com.abc.customer.exception.CustomException;
import com.abc.customer.repository.PLAddressRepository;
import com.abc.customer.request.PLAddressRequest;
import com.abc.customer.service.PLAddressService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PLAddressServiceImpl implements PLAddressService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";
	
	@Autowired
	PLAddressRepository plAddressRepository;

	@Override
	public PLAddress findByCustomerIdAndActive(Long customerId, Boolean active) {
		PLAddress plAddress = null;
		Optional<PLAddress> details = plAddressRepository.findByCustomerIdAndActive(customerId, active);
		if (details.isPresent()) {
			plAddress = details.get();
		}else {
			throw new CustomException("2036" + MessageConstants.PL_ADDRESS_NOT_FOUND + details);
		}
		return plAddress;
	}

	@Override
	public PLAddress findByCustomerIdAndLoanIdAndAccountIdActive(Long customerId, String loanId, String accountId,  Boolean active) {

		PLAddress plAddress = null;
		Optional<PLAddress> details = plAddressRepository.findByCustomerIdAndLoanIdAndAccountIdAndActive(customerId, loanId, accountId, active);
		if (details.isPresent()) {
			plAddress = details.get();
		}else {
			throw new CustomException("2036" + MessageConstants.PL_ADDRESS_NOT_FOUND + details);
		}
		return plAddress;
	}

	@Override
	public PLAddress saveOrUpdate(PLAddressRequest plAddressRequest) {

		PLAddress address = null;
		if (null != plAddressRequest) {
			address = mergeAddressRequest(plAddressRequest, findByCustomerIdAndLoanIdAndAccountIdActive(plAddressRequest.getCustomerId(), plAddressRequest.getLoanId(), plAddressRequest.getAccountId(),  Boolean.FALSE));
			if (null != address) {
				address = plAddressRepository.save(address);
				log.info(className + "[Address: " + address.toString() + "]");
			}
		}else {
			throw new CustomException("1001" + MessageConstants.EMPTY_REQUEST + plAddressRequest);
		}
		return address;
	}

	private PLAddress mergeAddressRequest(PLAddressRequest source, PLAddress dest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		if (null == dest) {
			log.info(className + methodName + "[FOUND AS NEW ADDRESS DETAILS ... ...]");
			dest = new PLAddress();
			dest.setCustomerId(source.getCustomerId());
			dest.setLoanId(source.getLoanId());
			dest.setAccountId(source.getAccountId());
			dest.setActive(Boolean.FALSE);
			dest.setCreatedBy(CREATED_BY);
			dest.setCreatedDate(new Timestamp(new Date().getTime()));
		} else {
			log.info(className + methodName + "[UPDATING ADDRESS DETAILS ... ...]");
		}
		dest.setAddressLineOne(!isEmptyOrNull(source.getAddressLineOne()) ? source.getAddressLineOne() : dest.getAddressLineOne());
		dest.setAddressLineTwo(!isEmptyOrNull(source.getAddressLineTwo()) ? source.getAddressLineTwo() : dest.getAddressLineTwo());
		dest.setCity(!isEmptyOrNull(source.getCity()) ? source.getCity() : dest.getCity());
		dest.setLandmark(!isEmptyOrNull(source.getLandmark()) ? source.getLandmark() : dest.getLandmark());
		dest.setPincode(!isEmptyOrNull(source.getPincode()) ? source.getPincode() : dest.getPincode());
		dest.setState(!isEmptyOrNull(source.getState()) ? source.getState() : dest.getState());
		dest.setOrgAddressLineOne(!isEmptyOrNull(source.getOrgAddressLineOne()) ? source.getOrgAddressLineOne(): dest.getOrgAddressLineOne());
		dest.setOrgAddressLineTwo(!isEmptyOrNull(source.getOrgAddressLineTwo()) ? source.getOrgAddressLineTwo(): dest.getOrgAddressLineTwo());
		dest.setOrgCity(!isEmptyOrNull(source.getOrgCity()) ? source.getOrgCity() : dest.getOrgCity());
		dest.setOrgState(!isEmptyOrNull(source.getOrgState()) ? source.getOrgState() : dest.getOrgState());
		dest.setOrgPincode(!isEmptyOrNull(source.getOrgPincode()) ? source.getOrgPincode() : dest.getOrgPincode());
		dest.setOrgEmail(!isEmptyOrNull(source.getOrgEmail()) ? source.getOrgEmail() : dest.getOrgEmail());
		dest.setModifiedBy(CREATED_BY);
		dest.setModifiedDate(new Timestamp(new Date().getTime()));
		return dest;
	}
	
	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
}
