package com.abc.customer.response;

public enum ResponseStatusCode {

    SUCCESS(2002, "SUCCESS"),
    ERROR(2001, "ERROR"),
    RECORD_SAVED(2000, "Record Saved Successfully"),
    INVALID_REQUEST(2003, "Invalid Request"),
    RECORD_NOT_FOUND(2004,"UserId not foumd"),
    INTERNAL_SERVER_ERROR(2005, "Internal Server Error"),
    GCP_STORAGE_ERROR(2006, "GCP Data Storage Error"),
    ABFL_ERROR(2007, "Error Getting ABFL Response"),
    FAILED_TO_FETCH_CUSTOMER_OBJECT( 1020, "Failed to Get Customer with Given AccountID "),
	FAILED_TO_GET_API_RESPONSE(1012,"Failed to get API Response" ),
	FAILED_TO_GET_TOKEN(1020,"Failed to get Token From External API" ),
	
	TOKEN_NOT_AVAILABLE(1021 , "Token is not Available in Cache" ),
	USER_UNAUTHORIZED(1017 ,"Failed to get API Response, User Unthorized" ),
    AUTH_TOKEN_ERROR(2008, "Error Getting Authentication Token.");

    private String value;
    private int code;


    private ResponseStatusCode(int code) {
        this.code = code;
    }

    private ResponseStatusCode(String value) {
        this.value = value;
    }

    private ResponseStatusCode(int code, String value) {
        this.value = value;
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public String getCode() {
        return "pl-" + this.code;
    }

    public static ResponseStatusCode getResponseStatusCode(String cValue) {
        for (ResponseStatusCode cEnum : values()) {
            if (cEnum.getValue().equalsIgnoreCase(cValue)) {
                return cEnum;
            }
        }
        return null;
    }

}
