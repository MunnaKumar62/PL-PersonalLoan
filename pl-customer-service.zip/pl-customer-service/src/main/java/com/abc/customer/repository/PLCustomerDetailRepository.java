package com.abc.customer.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.customer.entity.PLCustomerDetail;

@Repository
public interface PLCustomerDetailRepository extends JpaRepository<PLCustomerDetail, Long> {

    @Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndActive(String accountId, String loanId, Boolean active);

    @Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId= :customerId and a.active= :active)")
    Optional<PLCustomerDetail> findLatestByAccountIdAndLoanIdAndCustomerIdAndActive(String accountId, String loanId, Long customerId, Boolean active);
    
    @Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId)")
	Optional<PLCustomerDetail> findByAccountId(String accountId);
    
    @Query("SELECT a FROM PLCustomerDetail a WHERE a.accountId = :accountId AND  (a.active = false OR a.active IS NULL)")
    PLCustomerDetail findByAccountIdAndActive(@Param("accountId") String accountId);

    @Query("SELECT a FROM PLCustomerDetail a WHERE a.accountId = :accountId AND a.loanId = :loanId AND a.customerId = :customerId AND  (a.active = false OR a.active IS NULL)")
    PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdAndActive(@Param("accountId") String accountId, @Param("loanId") String loanId, @Param("customerId") String customerId);

	List<PLCustomerDetail> findByActiveAndModifiedDateBetween(Boolean active, Date startDate, Date endDate);

}
