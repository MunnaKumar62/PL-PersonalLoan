package com.abc.customer.service;


import org.springframework.web.multipart.MultipartFile;

import com.abc.customer.entity.InputFile;

import java.util.List;

public interface FileService {

    List<InputFile> uploadFiles(MultipartFile[] files);
}
