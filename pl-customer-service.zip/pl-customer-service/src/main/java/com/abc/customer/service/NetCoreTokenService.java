package com.abc.customer.service;

import org.springframework.http.ResponseEntity;

public interface NetCoreTokenService {

	public String getAccessToken();

	public ResponseEntity<Object> callTokenApi();
}
