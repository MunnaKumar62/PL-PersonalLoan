package com.abc.customer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PLCompanyDto {

	@JsonProperty("companyId")
	private Integer companyId;

	@JsonProperty("employerId")
	private String employerId;

	@JsonProperty("employerName")
	private String employerName;

	@JsonProperty("emplyerCategory")
	private String emplyerCategory;
}
