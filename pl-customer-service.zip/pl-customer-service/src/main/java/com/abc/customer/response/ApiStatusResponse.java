package com.abc.customer.response;

import java.util.Date;

import com.abc.customer.constant.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@ToString
@JsonInclude(Include.NON_EMPTY)
public class ApiStatusResponse {

	@JsonProperty("apiName")
	private String apiName;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("requestJson")
	private String requestJson;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("responseJson")
	private String responseJson;

	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("createdDate")
	private Date createdDate;
	
	@JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("updatedDate")
	private Date updatedDate;

}
