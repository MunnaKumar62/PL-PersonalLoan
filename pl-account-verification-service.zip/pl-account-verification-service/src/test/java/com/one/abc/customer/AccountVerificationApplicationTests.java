package com.one.abc.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
