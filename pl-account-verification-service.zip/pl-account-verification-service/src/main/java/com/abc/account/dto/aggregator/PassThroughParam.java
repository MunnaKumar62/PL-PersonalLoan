package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PassThroughParam {

	@JsonProperty("data")
	public ConsentReqData data;
	
	@JsonProperty("target")
	public String target;
}
