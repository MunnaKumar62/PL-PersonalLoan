package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BreRequest {
	@JsonProperty("applicationId")
	private String applicationId;

	@JsonProperty("loanAmount")
	private String loanAmount;

	@JsonProperty("companyName")
	private String companyName;

	@JsonProperty("salaried")
	private boolean salaried;
	
	@JsonProperty("income")
	private String income;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("perfiosInputJson")
	private Object perfiosInputJson;
}
