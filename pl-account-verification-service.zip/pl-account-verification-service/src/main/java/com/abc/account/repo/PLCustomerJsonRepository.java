package com.abc.account.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.account.entity.PLCustomerJsonEntity;

@Repository
public interface PLCustomerJsonRepository extends JpaRepository<PLCustomerJsonEntity, Integer> {

	PLCustomerJsonEntity findByAccountId(String accountId);
}
