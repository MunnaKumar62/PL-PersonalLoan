package com.abc.account.dto.plprefio;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AccountXn {
    @JsonProperty("accountNo")
    private String accountNo;

    @JsonProperty("accountType")
    private String accountType;

    @JsonProperty("ifscCode")
    private String ifscCode;

    @JsonProperty("micrCode")
    private String micrCode;

    @JsonProperty("location")
    private String location;

    @JsonProperty("xns")
    private List<Xn> xns;

}
