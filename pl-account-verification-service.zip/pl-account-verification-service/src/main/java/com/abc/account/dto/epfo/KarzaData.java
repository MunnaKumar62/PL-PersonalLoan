package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KarzaData {

	@JsonProperty("description")
	public Description description;

	@JsonProperty("karza_final_response")
	public KarzaFinalResponse karzaFinalResponse;
}
