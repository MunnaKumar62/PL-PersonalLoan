package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerNote {

	@JsonProperty("notes_key_1")
	private String notesKey1;
	
	@JsonProperty("notes_key_2")
	private String notesKey2;
}
