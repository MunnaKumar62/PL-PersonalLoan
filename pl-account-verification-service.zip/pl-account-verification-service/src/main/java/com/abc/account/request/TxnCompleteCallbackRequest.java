package com.abc.account.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TxnCompleteCallbackRequest {

	private String perfiosTransactionId;
	private String clientTransactionId;
	private String status;
	private String errorCode;
	private String errorMessage;
}
