package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VPARequestBuilder {

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("accountid")
    private String accountId;

    @JsonProperty("vpa")
    private String vpa;
}