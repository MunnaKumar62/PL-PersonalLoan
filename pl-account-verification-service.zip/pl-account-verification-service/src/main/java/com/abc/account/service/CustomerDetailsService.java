package com.abc.account.service;

import com.abc.account.entity.CustomerDetails;

public interface CustomerDetailsService {

	CustomerDetails findByCustomerId(Long id);
	
	CustomerDetails findByMobileNumber(String mobileNumber);

	CustomerDetails findByAccountId(String accountId);
	

}
