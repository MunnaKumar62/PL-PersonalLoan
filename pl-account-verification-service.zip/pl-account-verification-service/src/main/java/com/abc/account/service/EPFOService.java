package com.abc.account.service;

import com.abc.account.request.*;
import org.springframework.http.ResponseEntity;

import com.abc.account.constant.Constants;

public interface EPFOService extends Constants {

	public ResponseEntity<Object> epfoSilentCheck(EPFORequest request, String token);
    
	public ResponseEntity<Object> getSendOtp(SendOtpRequest request, String accessToken);

	public ResponseEntity<Object> getVerifyOtp(VerifyOtpRequest request, String accessToken);

	public ResponseEntity<Object> getEpfoVerificationOtp(EmployeeEpfoRequest request, String accessToken);

	public ResponseEntity<Object> getEpfoVerificationASync(EmployeeEpfoRequest request, String accessToken);

	public ResponseEntity<Object> getEpfoPollingApi(EpfoPollingRequest request, String accessToken);

}