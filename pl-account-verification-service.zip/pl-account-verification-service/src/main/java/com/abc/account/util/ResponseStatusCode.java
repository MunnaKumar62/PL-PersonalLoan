package com.abc.account.util;

public enum ResponseStatusCode {

    SUCCESS(2002, "SUCCESS"),
    ERROR(2001, "ERROR"),
    RECORD_SAVED(2000, "Record Saved Successfully"),
    INVALID_REQUEST(2003, "Invalid Request"),
    RECORD_NOT_FOUND(2004,"UserId not foumd"),
    INTERNAL_SERVER_ERROR(2005, "Internal Server Error"),
    GCP_STORAGE_ERROR(2006, "GCP Data Storage Error"),
    ABFL_ERROR(2007, "Error Getting ABFL Response"),
    AUTH_TOKEN_ERROR(2008, "Error Getting Authentication Token."),
	FAILED_TO_GET_TOKEN(2009, "Failed to get Access Token");

    private String value;
    private int code;


    private ResponseStatusCode(int code) {
        this.code = code;
    }

    private ResponseStatusCode(String value) {
        this.value = value;
    }

    private ResponseStatusCode(int code, String value) {
        this.value = value;
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public String getCode() {
        return "PL-" + this.code;
    }

    public static ResponseStatusCode getResponseStatusCode(String cValue) {
        for (ResponseStatusCode cEnum : values()) {
            if (cEnum.getValue().equalsIgnoreCase(cValue)) {
                return cEnum;
            }
        }
        return null;
    }

}

