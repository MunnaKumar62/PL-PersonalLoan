package com.abc.account.response;

import lombok.Data;

@Data
public class Accounts {

	  
          private String fiType;
          private String fipId;
          private String accType;
          private String linkRefNumber;
          private String maskedAccNumber;
          private String status;
      }
  

