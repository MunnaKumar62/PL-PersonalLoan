package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@lombok.Data
@Builder
public class Data {

	@JsonProperty("IBLRefNo")
	private String iBLRefNo;
	
	@JsonProperty("CustomerRefNo")
	private String customerRefNo;
	
	@JsonProperty("StatusDesc")
	private String statusDesc;
	
	@JsonProperty("TranType")
	private String tranType;
	
	@JsonProperty("Amount")
	private String amount;
	
	@JsonProperty("StatusCode")
	private String statusCode;

}
