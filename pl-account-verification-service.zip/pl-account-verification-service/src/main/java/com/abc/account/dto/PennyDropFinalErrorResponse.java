package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@lombok.Data
@Builder
public class PennyDropFinalErrorResponse {

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("error")
    private Error error;

    @JsonProperty("responseStatus")
    public String responseStatus;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("errorCode")
    public String errorCode;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("errorMessage")
    public String errorMessage;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("code")
    public String code;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("message")
    public String message;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("errorType")
    public String errorType;
}