package com.abc.account.response;

import com.abc.account.dto.plprefio.InstitutionResponse;

import lombok.Data;

@Data
public class InstitutionsResponse {
	    private InstitutionResponse institutions;
	}
