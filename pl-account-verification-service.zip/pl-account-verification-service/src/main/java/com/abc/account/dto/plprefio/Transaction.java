package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class Transaction {

	@JsonProperty("status")
	public String status;

	@JsonProperty("errorCode")
	public String errorCode;

	@JsonProperty("reportAvailable")
	public boolean reportAvailable;

	@JsonProperty("clientTransactionId")
	public String clientTransactionId;

	@JsonProperty("perfiosTransactionId")
	public String perfiosTransactionId;
}
