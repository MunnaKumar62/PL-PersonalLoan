package com.abc.account.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

import com.abc.account.dto.EPFOPollingResponse;
import com.abc.account.dto.PLCustomerDetailDto;
import com.abc.account.request.*;
import com.abc.account.response.*;
import com.abc.account.service.PLCustomerDetailService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.abc.account.constant.Constants;
import com.abc.account.entity.ApiStatus;
import com.abc.account.service.CustomerDetailsService;
import com.abc.account.service.EPFOService;
import com.abc.account.service.biz.CommonBizService;
import com.abc.account.service.biz.EPFOBizService;
import com.abc.account.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EPFOServiceImpl extends CommonBizService implements EPFOService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;

	@Autowired
	CustomerDetailsService customerDetailsService;

	@Value("${abfl.epfo.silentcheck.url}")
	private String epfoUrl;
	
	@Value("${abfl.epfo.sendOtp.url}")
	private String sendOtpUrl;
	
	@Value("${abfl.epfo.verifyotp.url}")
	private String verifyotpUrl;
	
	@Value("${abfl.epfo.employmentverification.url}")
	private String employmentverificationUrl;

	@Value("${abfl.epfo.employmentverification.async.url}")
	private String employmentVerificationAsyncUrl;

	@Value("${abfl.epfo.employmentverification.polling.url}")
	private String employmentVerificationPollingUrl;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	PLCustomerDetailService plCustomerDetailService;
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> epfoSilentCheck(EPFORequest request, String token) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL3101";
		EPFOBizService bizService = new EPFOBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateEPFORequest(request);
		if (request != null) {
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_EPFO_SILENT_CHECK).accountId(EMPTY)
					.profileId(request.getEmployeeName()).requestId(request.getEmployerName())
					.transactionId(request.getMobile()).url(epfoUrl).requestHeaders(getRequestHeaders(token))
					.method(HttpMethod.POST).request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, EPFOResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
						updateApiStatus(customerDetailsService.findByMobileNumber(request.getMobile())
								, apiStatus
						        , ""
						        , 0L);
					}
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getSendOtp(SendOtpRequest request, String accessToken) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL3102";
		EPFOBizService bizService = new EPFOBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validatesendotpRequest(request);
		if (request != null) {
			/**
			 * External API Call
			 */
			SendOtpRequestBuilder sendOtpRequestBuilder = new SendOtpRequestBuilder();
			sendOtpRequestBuilder.setMode(request.getMode());
			sendOtpRequestBuilder.setPurpose(request.getPurpose());
			sendOtpRequestBuilder.setApplicationId(request.getLoanId());
			sendOtpRequestBuilder.setMobileNumber(request.getMobileNumber());
			sendOtpRequestBuilder.setEmailId(request.getEmailId());
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_SEND_OTP_COMBINED).accountId(request.getApplicationId())
					.profileId(request.getEmailId()).requestId(request.getApplicationId())
					.transactionId(request.getMobileNumber()).url(sendOtpUrl)
					.requestHeaders(getRequestHeaders(accessToken)).method(HttpMethod.POST).request(sendOtpRequestBuilder)
					.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, SendOtpResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					}
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByAccountId(request.getApplicationId())
						, apiStatus, request.getLoanId(), request.getCustomerId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getVerifyOtp(VerifyOtpRequest request, String accessToken) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL3103";
		EPFOBizService bizService = new EPFOBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		/**
		 * Input request validation
		 */
		request = bizService.validateVerifyOtpRequest(request);
		if (request != null) {
			/**
			 * External API Call
			 */
			VerifyOtpRequestBuilder verifyOtpRequestBuilder = new VerifyOtpRequestBuilder();
			verifyOtpRequestBuilder.setOtp(request.getOtp());
			verifyOtpRequestBuilder.setMode(request.getMode());
			verifyOtpRequestBuilder.setPurpose(request.getPurpose());
			verifyOtpRequestBuilder.setEmailId(request.getEmailId());
			verifyOtpRequestBuilder.setMobileNumber(request.getMobileNumber());
			verifyOtpRequestBuilder.setApplicationId(request.getLoanId());

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_VERIFY_OTP_COMBINED).accountId(request.getApplicationId())
					.profileId(request.getEmailId()).requestId(request.getApplicationId())
					.transactionId(request.getMobileNumber()).url(verifyotpUrl)
					.requestHeaders(getRequestHeaders(accessToken)).method(HttpMethod.POST).request(verifyOtpRequestBuilder)
					.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, VerifyOtpResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					plCustomerDetailDto.setAccountId(request.getApplicationId());
					plCustomerDetailDto.setLoanId(request.getLoanId());
					plCustomerDetailDto.setCustomerId(request.getCustomerId());
					updateEpfoOtpDetails(apiResponse, plCustomerDetailDto);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					}
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByAccountId(request.getApplicationId())
						, apiStatus, request.getLoanId(), request.getCustomerId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getEpfoVerificationOtp(EmployeeEpfoRequest request, String accessToken) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL3104";
		EPFOBizService bizService = new EPFOBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateEpfoVerificationRequest(request);
		if (request != null) {
			/**
			 * External API Call
			 */
			EmployeeEpfoRequestBuilder employeeEpfoRequestBuilder = new EmployeeEpfoRequestBuilder();
			employeeEpfoRequestBuilder.setEmployeeName(request.getEmployeeName());
			employeeEpfoRequestBuilder.setPdf(request.getPdf());
			employeeEpfoRequestBuilder.setEmailId(request.getEmailId());
			employeeEpfoRequestBuilder.setMobile(request.getMobile());
			employeeEpfoRequestBuilder.setEmployerName(request.getEmployerName());
			employeeEpfoRequestBuilder.setAccountId(request.getLoanId());

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_EMPLOYEE_VERIFICATION_SYCN)
					.accountId(request.getAccountId()).profileId(request.getEmployeeName()).requestId(EMPTY)
					.transactionId(request.getMobile()).url(employmentverificationUrl)
					.requestHeaders(getRequestHeaders(accessToken)).method(HttpMethod.POST).request(employeeEpfoRequestBuilder)
					.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, EmployeeResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					}
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByAccountId(request.getAccountId())
						, apiStatus, request.getLoanId(), request.getCustomerId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getEpfoVerificationASync(EmployeeEpfoRequest request, String accessToken) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL3104";
		EPFOBizService bizService = new EPFOBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateEpfoVerificationRequest(request);
		if (request != null) {
			/**
			 * External API Call
			 */
			EmployeeEpfoRequestBuilder employeeEpfoRequestBuilder = new EmployeeEpfoRequestBuilder();
			employeeEpfoRequestBuilder.setEmployeeName(request.getEmployeeName());
			employeeEpfoRequestBuilder.setPdf(request.getPdf());
			employeeEpfoRequestBuilder.setEmailId(request.getEmailId());
			employeeEpfoRequestBuilder.setMobile(request.getMobile());
			employeeEpfoRequestBuilder.setEmployerName(request.getEmployerName());
			employeeEpfoRequestBuilder.setAccountId(request.getLoanId());

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_EMPLOYEE_VERIFICATION_ASYNC)
					.accountId(request.getAccountId()).profileId(request.getEmployeeName()).requestId(EMPTY)
					.transactionId(request.getMobile()).url(employmentVerificationAsyncUrl)
					.requestHeaders(getRequestHeaders(accessToken)).method(HttpMethod.POST).request(employeeEpfoRequestBuilder)
					.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, EmployeeResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					}
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByAccountId(request.getAccountId())
						, apiStatus, request.getLoanId(), request.getCustomerId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getEpfoPollingApi(EpfoPollingRequest epfoPollingRequest, String accessToken) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL3104";
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		EmployeeResponse epfoResponse = null;
		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		if (epfoPollingRequest != null) {
			/**
			 * External API Call
			 */
			EpfoPollingRequestBuilder epfoPollingRequestBuilder = new EpfoPollingRequestBuilder();
			epfoPollingRequestBuilder.setAccountId(epfoPollingRequest.getLoanId());

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(EPFO_POLLING)
					.accountId(epfoPollingRequest.getAccountId())
					.url(employmentVerificationPollingUrl)
					.requestHeaders(getRequestHeaders(accessToken)).method(HttpMethod.POST).request(epfoPollingRequestBuilder)
					.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, EmployeeResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (null != apiResponse && null != apiResponse.getBody()) {
					plCustomerDetailDto.setAccountId(epfoPollingRequest.getAccountId());
					plCustomerDetailDto.setLoanId(epfoPollingRequest.getLoanId());
					plCustomerDetailDto.setCustomerId(epfoPollingRequest.getCustomerId());
					if (validateResponse(apiResponse)) {
						epfoResponse = (EmployeeResponse) apiResponse.getBody();
						if (null != epfoResponse
								&& APISTATUS_SUCCESS.equalsIgnoreCase(epfoResponse.getResponseStatus())) {
							if(epfoResponse.getData() != null
									&& epfoResponse.getData().getEpfoCheck() != null
									&& epfoResponse.getData().getEpfo_otp_required() != null) {
								plCustomerDetailDto.setEpfoCheck(epfoResponse.getData().getEpfoCheck());
								plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
							}
						}
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					}else{
						updateEpfoCheckErrorDetails(apiResponse, plCustomerDetailDto);
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByAccountId(epfoPollingRequest.getAccountId())
						, apiStatus, epfoPollingRequest.getLoanId(), epfoPollingRequest.getCustomerId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	private void updateEpfoCheckErrorDetails(ResponseEntity<Object> apiResponse, PLCustomerDetailDto plCustomerDetailDto) {

		String json = null;
		Boolean epfoCheck = false;
		Boolean epfoOtpRequired = false;
		try {
			json = mapper.writeValueAsString(apiResponse.getBody());
			if (!StringUtils.isBlank(json)) {
				JSONObject jsonResponse = new JSONObject(json);
				JSONObject errorObj = null;
				if (jsonResponse.has("error")) {
					errorObj = jsonResponse.getJSONObject("error");
					if (errorObj.has("epfoCheck") && errorObj.has("epfo_otp_required")) {
						epfoCheck = errorObj.getBoolean("epfoCheck");
						epfoOtpRequired = errorObj.getBoolean("epfo_otp_required");
						if (epfoCheck != null && epfoOtpRequired != null) {
							plCustomerDetailDto.setEpfoCheck(epfoCheck);
							plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
						}
					}
				}
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

	}

	private void updateEpfoOtpDetails(ResponseEntity<Object> apiResponse, PLCustomerDetailDto plCustomerDetailDto) {

		String json = null;
		String status = "";
		try {
			json = mapper.writeValueAsString(apiResponse.getBody());
			if (!StringUtils.isBlank(json)) {
				JSONObject jsonResponse = new JSONObject(json);
				JSONObject errorObj = null;
				if (jsonResponse.has("data")) {
					errorObj = jsonResponse.getJSONObject("data");
					if (errorObj.has("status")) {
						status = errorObj.getString("status");
						if (StringUtils.isNotEmpty(status) && status.equals(Constants.VERIFIED)) {
							plCustomerDetailDto.setEpfoOtpRequired(Boolean.TRUE);
							plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
						}
					}
				}
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

	}


}
