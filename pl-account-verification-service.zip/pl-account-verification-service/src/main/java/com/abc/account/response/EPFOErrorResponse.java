package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class EPFOErrorResponse {

    @JsonProperty("responseStatus")
    private String responseStatus;

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    private EPFOError error;

    private String errorCode;
    private String errorMessage;
    private String code;
    private String reason;
    private String message;
    private String errorType;
}