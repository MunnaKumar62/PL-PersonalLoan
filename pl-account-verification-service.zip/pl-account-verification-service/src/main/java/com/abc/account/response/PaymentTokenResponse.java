package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PaymentTokenResponse {

	@JsonProperty("id")
	private String id;

	@JsonProperty("entity")
	private String entity;

	@JsonProperty("amount")
	private int amount;

	@JsonProperty("currency")
	private String currency;

	@JsonProperty("status")
	private String status;

	@JsonProperty("order_id")
	private String orderId;

	@JsonProperty("invoice_id")
	private String invoiceId;

	@JsonProperty("international")
	private boolean international;

	@JsonProperty("method")
	private String method;

	@JsonProperty("amount_refunded")
	private int amountRefunded;

	@JsonProperty("refund_status")
	private Object refundStatus;

	@JsonProperty("captured")
	private boolean captured;

	@JsonProperty("description")
	private Object description;

	@JsonProperty("card_id")
	private Object cardId;

	@JsonProperty("bank")
	private String bank;

	@JsonProperty("wallet")
	private Object wallet;

	@JsonProperty("vpa")
	private Object vpa;

	@JsonProperty("email")
	private String email;

	@JsonProperty("contact")
	private String contact;

	@JsonProperty("customer_id")
	private String customerId;

	@JsonProperty("token_id")
	private String tokenId;

	@JsonProperty("notes")
	private Notes notes;

	@JsonProperty("fee")
	private int fee;

	@JsonProperty("tax")
	private int tax;

	@JsonProperty("error_code")
	private Object errorCode;

	@JsonProperty("error_description")
	private Object errorDescription;

	@JsonProperty("error_source")
	private Object errorSource;

	@JsonProperty("error_step")
	private Object errorStep;

	@JsonProperty("error_reason")
	private Object errorReason;

	@JsonProperty("acquirer_data")
	private AcquirerData acquirerData;

	@JsonProperty("upi")
	private UPI upi;
	
	@JsonProperty("created_at")
	private int createdAt;


}
