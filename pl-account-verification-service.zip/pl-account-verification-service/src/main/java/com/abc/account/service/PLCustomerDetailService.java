package com.abc.account.service;

import com.abc.account.dto.PLCustomerDetailDto;
import com.abc.account.entity.PLCustomerDetail;

public interface PLCustomerDetailService {

	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto plCustomerDetailDto, PLCustomerDetail details);
	
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail);
	
	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdAndActive(String accountId, String loanId, Long customerId, Boolean active);
}
