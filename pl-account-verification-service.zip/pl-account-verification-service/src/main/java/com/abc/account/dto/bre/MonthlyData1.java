package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class MonthlyData1{
    private double utilizationOn20th;
    private double totalDebitAsPerStmt;
    private int cashWithdrawalCount;
    private double creditsAfterDeduction;
    private double avgOverdrawnAmount;
    private double utilizationOn25th;
    private double outwChqReturn;
    private double avgEODBalOn5th10th15th20th25th30th;
    private int emiBounceCount;
    private int countOfEMIPaid;
    private double debitSummationAfterDeduction;
    private int techInwardBounces;
    private double cashWithdrawalPercent;
    private double inwardBouncePercent;
    private String monthName;
    private double creditSummation;
    private double debitsAfterDeduction;
    private double creditSummationAfterDeduction;
    private double avgEODBalOn5th15th25th;
    private double utilizationOn5th;
    private double avgUtilizationOn5th10th15th20th25th30th;
    private double outwardBouncePercent;
    private int nonTechInwardBounces;
    private double sumOfLoanEMIPaid;
    private double utilizationOn15th;
    private double limitUtilization;
    private double debitsAsPerStmt;
    private double totalCreditAfterDeduction;
    private double nonBusinessCreditsValue;
    private double businessCreditsValue;
    private double totalDebitAfterDeduction;
    private double totalCreditAsPerStmt;
    private double avgOverdrawnAsPercentOfLimit;
    private double cashWithdrawalAmount;
    private double creditsAsPerStmt;
    private double avgUtilizationOn5th15th25th;
    private double utilizationOn10th;
    private double inwPaymentReturn;
    private double peakUtilization;
    private double utilizationOn30th;
}