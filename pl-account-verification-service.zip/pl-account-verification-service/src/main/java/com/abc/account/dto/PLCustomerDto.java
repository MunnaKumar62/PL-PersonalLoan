package com.abc.account.dto;


import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
@SuperBuilder
public class PLCustomerDto implements Serializable{
	
        private static final long serialVersionUID = 1L;

		private String id;

        private String accountId;

        private String transactionId;

        private String applicationId;

        private String cccId;

        private String mobileNumber;

        private String firstname;

        private String lastname;

        private String dateofbirth;

        private String loantype;

        private String pannumber;

        private String aadhaarnumber;

        private String email;

        private String gender;

        private Boolean panCheckFlag;

        private Address address;
}
