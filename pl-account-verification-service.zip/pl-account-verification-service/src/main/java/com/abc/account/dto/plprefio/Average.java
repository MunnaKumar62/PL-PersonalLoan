package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Average {
    @JsonProperty("bal1")
    private double bal1;

    @JsonProperty("bal10")
    private double bal10;

    @JsonProperty("bal15")
    private double bal15;

    @JsonProperty("bal20")
    private double bal20;

    @JsonProperty("bal25")
    private double bal25;

    @JsonProperty("bal30")
    private double bal30;

    @JsonProperty("bal5")
    private double bal5;

    @JsonProperty("balAvg")
    private double balAvg;

    @JsonProperty("balMax")
    private double balMax;

    @JsonProperty("balMin")
    private double balMin;

    @JsonProperty("cashDeposits")
    private int cashDeposits;

    @JsonProperty("cashWithdrawals")
    private int cashWithdrawals;

    @JsonProperty("chqDeposits")
    private int chqDeposits;

    @JsonProperty("chqIssues")
    private int chqIssues;

    @JsonProperty("credits")
    private int credits;

    @JsonProperty("creditsSC")
    private int creditsSC;

    @JsonProperty("creditsSelf")
    private int creditsSelf;

    @JsonProperty("debits")
    private int debits;

    @JsonProperty("debitsSC")
    private int debitsSC;

    @JsonProperty("debitsSelf")
    private int debitsSelf;

    @JsonProperty("dpLimit")
    private double dpLimit;

    @JsonProperty("emiEcsLoanIssues")
    private int emiEcsLoanIssues;

    @JsonProperty("emiOrLoans")
    private int emiOrLoans;

    @JsonProperty("intraDayClearedBouncesNonTechnical")
    private int intraDayClearedBouncesNonTechnical;

    @JsonProperty("intraDayClearedBouncesTechnical")
    private int intraDayClearedBouncesTechnical;

    @JsonProperty("inwBounceNonTechnical")
    private int inwBounceNonTechnical;

    @JsonProperty("inwBounces")
    private int inwBounces;

    @JsonProperty("inwBounceTechnical")
    private int inwBounceTechnical;

    @JsonProperty("inwChqBounces")
    private int inwChqBounces;

    @JsonProperty("inwEMIBounces")
    private int inwEMIBounces;

    @JsonProperty("outwBounces")
    private int outwBounces;

    @JsonProperty("outwChqBounces")
    private int outwChqBounces;

    @JsonProperty("overdrawnAmount")
    private double overdrawnAmount;

    @JsonProperty("overdrawnDays")
    private int overdrawnDays;

    @JsonProperty("samePartyCredits")
    private int samePartyCredits;

    @JsonProperty("samePartyCreditsSC")
    private int samePartyCreditsSC;

    @JsonProperty("samePartyCreditsSelf")
    private int samePartyCreditsSelf;

    @JsonProperty("samePartyDebits")
    private int samePartyDebits;

    @JsonProperty("samePartyDebitsSC")
    private int samePartyDebitsSC;

    @JsonProperty("samePartyDebitsSelf")
    private int samePartyDebitsSelf;

    @JsonProperty("selfSisterUpiDebits")
    private int selfSisterUpiDebits;

    @JsonProperty("snLimit")
    private double snLimit;

    @JsonProperty("totalCashDeposit")
    private double totalCashDeposit;

    @JsonProperty("totalCashWithdrawal")
    private double totalCashWithdrawal;

    @JsonProperty("totalChqDeposit")
    private double totalChqDeposit;

    @JsonProperty("totalChqIssue")
    private double totalChqIssue;

    @JsonProperty("totalCredit")
    private double totalCredit;

    @JsonProperty("totalCreditSC")
    private double totalCreditSC;

    @JsonProperty("totalCreditSelf")
    private double totalCreditSelf;

    @JsonProperty("totalDebit")
    private double totalDebit;

    @JsonProperty("totalDebitSC")
    private double totalDebitSC;

    @JsonProperty("totalDebitSelf")
    private double totalDebitSelf;

    @JsonProperty("totalEmiEcsLoanIssue")
    private double totalEmiEcsLoanIssue;

    @JsonProperty("totalEmiOrLoan")
    private double totalEmiOrLoan;

    @JsonProperty("totalInterestCharged")
    private double totalInterestCharged;

    @JsonProperty("totalInvIncome")
    private double totalInvIncome;

    @JsonProperty("totalInwBounce")
    private double totalInwBounce;

    @JsonProperty("totalInwBounceNonTechnical")
    private double totalInwBounceNonTechnical;

    @JsonProperty("totalInwChqBounce")
    private double totalInwChqBounce;

    @JsonProperty("totalLoanDisbursal")
    private double totalLoanDisbursal;

    @JsonProperty("totalOutwBounce")
    private double totalOutwBounce;

    @JsonProperty("totalOutwChqBounce")
    private double totalOutwChqBounce;

    @JsonProperty("totalPenalCharge")
    private double totalPenalCharge;

    @JsonProperty("totalSalary")
    private double totalSalary;

    @JsonProperty("totalSamePartyCredit")
    private double totalSamePartyCredit;

    @JsonProperty("totalSamePartyCreditSC")
    private double totalSamePartyCreditSC;

    @JsonProperty("totalSamePartyCreditSelf")
    private double totalSamePartyCreditSelf;

    @JsonProperty("totalSamePartyDebit")
    private double totalSamePartyDebit;

    @JsonProperty("totalSamePartyDebitSC")
    private double totalSamePartyDebitSC;

    @JsonProperty("totalSamePartyDebitSelf")
    private double totalSamePartyDebitSelf;

}