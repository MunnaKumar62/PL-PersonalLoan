package com.abc.account.dto.bre;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class AdditionalRelatedPartyDetails{
    @JsonProperty("RelatedPartyData1") 
    private List<RelatedPartyData1> relatedPartyData1;
}
