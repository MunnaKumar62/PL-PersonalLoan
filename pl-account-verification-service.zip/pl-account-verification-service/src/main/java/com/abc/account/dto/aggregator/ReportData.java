package com.abc.account.dto.aggregator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportData {

	@JsonProperty("customerInfo")
	private CustomerInfo customerInfo;

	@JsonProperty("accountAnalysis")
	private List<AccountAnalysis> accountAnalysis;

	@JsonProperty("combinedAccountXns")
	private List<CombinedAccountXns> combinedAccountXns;

	@JsonProperty("combinedMonthlyDetails")
	private List<CombinedMonthlyDetails> combinedMonthlyDetails;

	@JsonProperty("combinedSundayXns")
	private List<CombinedSundayXns> combinedSundayXns;

	@JsonProperty("combinedBusinessCreditXns")
	private List<CombinedBusinessCreditXns> combinedBusinessCreditXns;

	@JsonProperty("accountXns")
	private List<AccountXns> accountXns;

	@JsonProperty("AdditionalMonthlyDetails")
	private AdditionalMonthlyDetails additionalMonthlyDetails;

	@JsonProperty("AdditionalRelatedPartyDetails")
	private AdditionalRelatedPartyDetails additionalRelatedPartyDetails;
}
