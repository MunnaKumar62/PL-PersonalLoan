package com.abc.account.request;

import com.abc.account.dto.plprefio.InteractivePayload;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class InteractiveLinkRequest {
	@JsonProperty("payload")
	private InteractivePayload payload;
	
	@JsonInclude(value=Include.NON_NULL)
	@JsonProperty("accountId")
	private String accountId;
	

}
