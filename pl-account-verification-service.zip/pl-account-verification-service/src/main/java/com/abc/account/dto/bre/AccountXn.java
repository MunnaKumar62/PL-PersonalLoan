package com.abc.account.dto.bre;

import java.util.List;

import lombok.Data;
@Data
public class AccountXn {
	private String accountType;
	private String ifscCode;
	private List<Xn> xns;
	private String location;
	private String micrCode;
	private String accountNo;

}
