package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonPropertyOrder({ "errorCode", "message", "errorType" })
public class AdditionalDetailsErrors {
	
	private String errorCode;
	private String message;
	private String errorType;
}
