package com.abc.account.dto.plprefio;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AdditionalMonthlyDetails{
    @JsonProperty("MonthlyData1") 
    private List<MonthlyData1> monthlyData1;
}
