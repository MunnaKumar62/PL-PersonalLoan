package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AcquirerData {

	@JsonProperty("rrn")
	private String rrn;

	@JsonProperty("upi_transaction_id")
	private String upiTransactionId;
}
