package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class PersonalInfo{
    public String email;
    public String name;
    public String mobile;
    public String landline;
    public String address;
    public String pan;
}