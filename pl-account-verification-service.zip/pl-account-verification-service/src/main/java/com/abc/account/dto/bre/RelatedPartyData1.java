package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class RelatedPartyData1{
    private double netDebitOrCredit;
    private double totalDebitsPercent;
    private String monthName;
    private double totalDebits;
    private int noOfCredits;
    private double credits;
    private int noOfDebits;
    private double debits;
    private double totalCredits;
    private double totalCreditsPercent;
}
