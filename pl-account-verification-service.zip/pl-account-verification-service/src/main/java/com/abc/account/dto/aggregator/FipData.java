package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
public class FipData {

	@JsonProperty("id")
	private String id;

	@JsonProperty("name")
	private String name;

	@JsonProperty("code")
	private String code;

	@JsonProperty("handle")
	private String handle;

	@JsonProperty("baseURL")
	private String baseURL;

	@JsonProperty("webviewURL")
	private String webviewURL;

}
