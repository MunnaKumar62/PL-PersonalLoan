package com.abc.account.dto.aggregator;

import java.util.Date;

import com.abc.account.constant.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Xns {

	@JsonProperty("date")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_FORMAT)
	private Date date;

	@JsonProperty("chqNo")
	private String chqNo;

	@JsonProperty("narration")
	private String narration;

	@JsonProperty("amount")
	private int amount;

	@JsonProperty("category")
	private String category;

	@JsonProperty("balance")
	private double balance;
}
