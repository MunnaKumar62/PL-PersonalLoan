package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EstInfo {

	@JsonProperty("address")
	public String address;

	@JsonProperty("contactNo")
	public String contactNo;

	@JsonProperty("emailId")
	public String emailId;

	@JsonProperty("estId")
	public String estId;
}
