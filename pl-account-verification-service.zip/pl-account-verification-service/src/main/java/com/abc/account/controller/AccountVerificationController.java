package com.abc.account.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.dto.BankAccountDetailsRequest;
import com.abc.account.dto.NameMatchRequest;
import com.abc.account.service.AccountVerificationService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@Tag(name = "Account Verification API")
@RequestMapping(Constants.API + Constants.ONE_APP_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION
		+ Constants.PERSONAL_LOAN + Constants.ACCOUNT_VERIFICATION)
@RequiredArgsConstructor
public class AccountVerificationController extends BaseController {

	private final AccountVerificationService service;
	
	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}
	

	/**
	 * This API is used to call the external api to verify the IFSC Code and account details of customer.
	 * @param bankAccountDetails request object contains the accountId, IFSCCode, email, bankName, bankBranch, clientData, accountNumber
	 *                           nameMatchType, accountHolderName, allowPartialMatch, useCombinedSolution.
	 * @return Response object contains the data, responseStatus and Cached flag.
	 */
	@PostMapping(PENNY_DROP)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> initiatePennyDrop(@RequestBody BankAccountDetailsRequest bankAccountDetails) {
		auditUrl();
		return service.initiatePennyDrop(bankAccountDetails);
	}

	/**
	 * This API is used to call external api to check the valid name of customer.
	 * @param nameMatchRequest request object contains the name1, name2, transactionId, product, applicationId.
	 * @return Response Object contains the Result and Request Id and Max Retry Exceeded.
	 */
	@PostMapping(NAME_CHECK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getNameCheckWithBank(@RequestBody NameMatchRequest nameMatchRequest) {
		auditUrl();
		return service.callNameCheckWithBankApi(nameMatchRequest);
	}

	/**
	 * This API is used to call external api to check the valid the IFSC code of customer.
	 * @param ifscCode
	 * @return Response object contains the contact, address, country details.
	 * @throws Exception - If any external api client exception or server exception.
	 */
	@GetMapping(IFSC_CHECK)
	private ResponseEntity<?> ifscValidation(@RequestParam String ifscCode) throws Exception {
		return service.validateIfsc(ifscCode);

	}
	 
}
