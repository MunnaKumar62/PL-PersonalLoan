package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class EmiEcsLoanDatesDetail{
    private int max;
    private String monthName;
    private int count;
    private int mode;
    private int min;
    private int avg;
}