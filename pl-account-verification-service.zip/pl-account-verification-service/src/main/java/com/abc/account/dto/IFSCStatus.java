package com.abc.account.dto;

import lombok.Data;

@Data
public class IFSCStatus {
	private long statusCode;
	private String name;
	private String message;
	private long status;

}
