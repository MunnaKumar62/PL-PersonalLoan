package com.abc.account.service.biz;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.abc.account.constant.MessageConstants;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.account.constant.Constants;
import com.abc.account.constant.PlPrefiosConstant;
import com.abc.account.entity.ApiStatus;
import com.abc.account.entity.CustomerDetails;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.InternalException;
import com.abc.account.model.RetryConfg;
import com.abc.account.request.ApiCommonRequest;
import com.abc.account.response.Error;
import com.abc.account.response.ErrorResponse;
import com.abc.account.service.ApiStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CommonBizService implements Constants, PlPrefiosConstant {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private ApiStatusService apiService;

	public ApiStatus saveApiResponse(ApiStatus apiStatus, ApiStatus existApiStatus) {

		if (null != existApiStatus && null != existApiStatus.getId()) {
			existApiStatus.setProfileId(apiStatus.getProfileId());
			existApiStatus.setRequestId(apiStatus.getRequestId());
			existApiStatus.setTransactionId(apiStatus.getTransactionId());
			existApiStatus.setAccountId(apiStatus.getAccountId());
			existApiStatus.setRequestJson(apiStatus.getRequestJson());
			existApiStatus.setResponseJson(apiStatus.getResponseJson());
			existApiStatus.setStatus(apiStatus.getStatus().toUpperCase());
			existApiStatus.setModifiedBy(CREATED_BY);
			existApiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
		} else {
			existApiStatus = apiStatus;
			existApiStatus.setStatus(existApiStatus.getStatus().toUpperCase());
			existApiStatus.setJourney(PL_JOURNEY);
			existApiStatus.setCreatedBy(CREATED_BY);
			existApiStatus.setCreatedDt(new Timestamp(new Date().getTime()));
		}

		return apiService.savOrUpdateApiStatus(existApiStatus);
	}

	public void updateApiStatus(CustomerDetails customerDetails, ApiStatus apiStatus
										, String loanId
										, Long customerId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			if (null != customerDetails) {
				apiStatus.setAccountId(isEmptyOrNull(apiStatus.getAccountId()) ? customerDetails.getAccountId()
						: apiStatus.getAccountId());
				apiStatus.setLoanId(loanId);
				apiStatus.setCustomerId(customerId);
				apiStatus.setModifiedBy(CREATED_BY);
				apiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
				apiService.savOrUpdateApiStatus(apiStatus);
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}

	public HttpHeaders getTokenRequestHeaders(String authToken) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", "Basic " + authToken);

		return headers;
	}

	public HttpHeaders getRequestHeaders(String token) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTH_TOKEN, token);

		return headers;
	}

	public HttpHeaders createInstitutionsHeaders(String token, String date, String content, String signature)
			throws InvalidKeyException, NoSuchAlgorithmException, SignatureException, UnsupportedEncodingException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(X_PERFIOS_DATE, date);
		headers.set(X_PERFIOS_ALGORITHM, X_PERFIOS_RSA_SHA256);
		headers.set(X_PERFIOS_CONTENT, content);
		headers.set(AUTH_TOKEN, token);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.set(X_PERFIOS_SIGNED_HEADERS, X_PERFIOS_CONTENT_DATE);
		headers.set(X_PERFIOS_SIGNATURE, signature);
		headers.setCacheControl(NO_CACHE);
		
		log.info(X_PERFIOS_ALGORITHM + " : " + X_PERFIOS_RSA_SHA256);
		log.info(X_PERFIOS_CONTENT + " : " + content);
		log.info(X_PERFIOS_DATE + " : " + date);
		log.info(X_PERFIOS_SIGNATURE + " : " + signature);
		log.info(AUTH_TOKEN + " : " + token);
		log.info(X_PERFIOS_SIGNED_HEADERS + " : " + X_PERFIOS_CONTENT_DATE);
		
		return headers;
	}

	public HttpHeaders createIntractiveHeaders(String token, String content, String date, String signature) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.set(X_PERFIOS_ALGORITHM, X_PERFIOS_RSA_SHA256);
		headers.set(X_PERFIOS_CONTENT, content);
		headers.set(X_PERFIOS_DATE, date);
		headers.set(X_PERFIOS_SIGNATURE, signature);
		headers.set(AUTH_TOKEN, token);
		headers.set(X_PERFIOS_SIGNED_HEADERS, X_PERFIOS_CONTENT_DATE);

		log.info(X_PERFIOS_ALGORITHM + " : " + X_PERFIOS_RSA_SHA256);
		log.info(X_PERFIOS_CONTENT + " : " + content);
		log.info(X_PERFIOS_DATE + " : " + date);
		log.info(X_PERFIOS_SIGNATURE + " : " + signature);
		log.info(AUTH_TOKEN + " : " + token);
		log.info(X_PERFIOS_SIGNED_HEADERS + " : " + X_PERFIOS_CONTENT_DATE);

		return headers;
	}

	public HttpHeaders retrieveReportHttpHeaders(String token, String payload, String signature, String xPerfiosDate) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(X_PERFIOS_DATE, xPerfiosDate);
		headers.add(X_PERFIOS_ALGORITHM, X_PERFIOS_RSA_SHA256);
		headers.add(X_PERFIOS_CONTENT, payload);
		headers.add(X_PERFIOS_SIGNATURE, signature);
		headers.add(X_PERFIOS_SIGNED_HEADERS, X_PERFIOS_CONTENT_DATE);
		headers.add("Accept", "application/json");
		headers.setCacheControl(NO_CACHE);
		headers.add(AUTH_TOKEN, token);

		log.info(X_PERFIOS_ALGORITHM + " : " + X_PERFIOS_RSA_SHA256);
		log.info(X_PERFIOS_CONTENT + " : " + payload);
		log.info(X_PERFIOS_DATE + " : " + xPerfiosDate);
		log.info(X_PERFIOS_SIGNATURE + " : " + signature);
		log.info(AUTH_TOKEN + " : " + token);
		log.info(X_PERFIOS_SIGNED_HEADERS + " : " + X_PERFIOS_CONTENT_DATE);

		return headers;
	}
	
	public String getPartnerErrorMessage(String partnerError) {

	    String code = "PE0100";
	    String partnerErrorMessage = code + env.getProperty(code);
	    final String desc = "description";
	    final String desc1 = "message";
	    final String error = "error";

	    if (!StringUtils.isBlank(partnerError)) {
	        JSONObject errorResponse = new JSONObject(partnerError);
	        if (errorResponse.has(error)) {
	            boolean flag = false;
	            JSONObject errorObj = null;
	            if (isValidJson(errorResponse.get(error).toString())) {
	                errorObj = errorResponse.getJSONObject(error);
	                if (errorObj.has(desc)) {
	                    if (!isValidJson(errorObj.get(desc).toString())) {
	                        partnerErrorMessage = errorObj.getString(desc);
	                    } else {
	                        flag = true;
	                    }
	                } else if (errorObj.has(desc1)) {
	                    if (!isValidJson(errorObj.get(desc1).toString())) {
	                        partnerErrorMessage = errorObj.getString(desc1);
	                    } else {
	                        flag = true;
	                    }
	                } else {
	                    flag = true;
	                }
	                if (flag) {
	                    partnerErrorMessage = ERROR_ + errorObj.toString();
	                }
	            } else {
	                partnerErrorMessage = errorResponse.has(error) ? errorResponse.getString(error) : partnerErrorMessage;
	            }
	        } else {
	            partnerErrorMessage = errorResponse.has(desc) ? errorResponse.getString(desc) : partnerErrorMessage;
	        }
	    }
	    return partnerErrorMessage;
	}
	

	/**
	 * This method is to call external API and audit request & response in database
	 * 
	 * @param <T>
	 * @param commonRequest
	 * @param clazz
	 * @return
	 */
	public <T> Map<String, Object> callExternalApi(ApiCommonRequest commonRequest, Class<T> responseType) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		Map<String, Object> map = new HashMap<>();
		String requestJsonObject = null;
		String responseJsonObject = null;
		String status = ERROR;
		int statusCode = STATUS_CODE_400;
		boolean isValid = Boolean.TRUE;
		ResponseEntity<T> apiResponse = null;
		try {
			requestJsonObject = null != commonRequest.getRequest()
					? mapper.writeValueAsString(commonRequest.getRequest())
					: null;
			log.info(className + methodName + "[API_URL= " + commonRequest.getUrl() + "]");
			HttpEntity<Object> apiRequest = new HttpEntity<>(commonRequest.getRequest(),
					commonRequest.getRequestHeaders());
			log.info(className + methodName + "[API_REQUEST= " + requestJsonObject + "]");

			apiResponse = restTemplate.exchange(commonRequest.getUrl(), commonRequest.getMethod(), apiRequest,
					responseType);

			if (null != apiResponse && null != apiResponse.getBody()) {
				status = SUCCESS;
				responseJsonObject = mapper.writeValueAsString(apiResponse.getBody());
				log.info(className + methodName + "[API_RESPONSE= " + responseJsonObject + "]");
			}
			map.put(API_RESPONSE, apiResponse);
			statusCode = apiResponse.getStatusCode().value();

		} catch (HttpClientErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			if(ex.getMessage().contains(MessageConstants.MAX_RETRY_MESSAGE)){
				throw new InternalException("1009");
			}
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();
			String reason = null;
			Object error = null;
			try {
				if (!isEmptyOrNull(partnerErrorMessage) && partnerErrorMessage.startsWith(ERROR_)) {
					error = mapper.readValue(partnerErrorMessage.replace(ERROR_, EMPTY), Object.class);
				} else {
					error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
							partnerErrorMessage);
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			if (ex.getResponseBodyAsString().contains("Endpoint request timed out")) {
				reason = "Endpoint request timed out";
			} else {
				reason = partnerErrorMessage;
			}
			// Error error = new Error(String.valueOf(ex.getStatusCode().value()),
			// ex.getStatusText(),
			// partnerErrorMessage);
			String apiName = commonRequest.getApiName();
			String errorCode = "PL-EE-C" + ex.getStatusCode().value();
			String errorType = ERROR_TYPE_TECHNICAL;
			// String message = "Error while calling external API " + apiName;

			map.put(API_RESPONSE,
					new ResponseEntity<>(new ErrorResponse(status, error, errorCode, partnerErrorMessage,
							"C" + ex.getStatusCode().value(), reason, errorCode + ": " + partnerErrorMessage,
							errorType), ex.getStatusCode()));

			statusCode = ex.getStatusCode().value();

		} catch (HttpServerErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			if(ex.getMessage().contains(MessageConstants.MAX_RETRY_MESSAGE)){
				throw new InternalException("1009");
			}
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();
			Object error = null;
			String reason = null;
			try {
				if (!isEmptyOrNull(partnerErrorMessage) && partnerErrorMessage.startsWith(ERROR_)) {
					error = mapper.readValue(partnerErrorMessage.replace(ERROR_, EMPTY), Object.class);
				} else {
					error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
							partnerErrorMessage);
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			if (ex.getResponseBodyAsString().contains("Endpoint request timed out")) {
				reason = "Endpoint request timed out";
			} else {
				reason = partnerErrorMessage;
			}
			// Error error = new Error(String.valueOf(ex.getStatusCode().value()),
			// ex.getStatusText(),
			// partnerErrorMessage);
			String apiName = commonRequest.getApiName();
			// String message = "Error while calling external API " + apiName;
			String errorCode = "PL-EE-S" + ex.getStatusCode().value();
			String errorType = ERROR_TYPE_TECHNICAL;

			map.put(API_RESPONSE,
					new ResponseEntity<>(new ErrorResponse(status, error, errorCode, partnerErrorMessage,
							"S" + ex.getStatusCode().value(), reason, errorCode + ": " + partnerErrorMessage,
							errorType), ex.getStatusCode()));

			statusCode = ex.getStatusCode().value();

		} catch (Exception ex) {
			isValid = Boolean.FALSE;
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException(ex.getMessage());

		} finally {
			if (commonRequest.isAudit() && isValid) {
				ApiStatus apiStatus = saveApiResponse(ApiStatus.builder().apiName(commonRequest.getApiName())
						.accountId(commonRequest.getAccountId()).profileId(commonRequest.getProfileId())
						.requestId(commonRequest.getRequestId()).transactionId(commonRequest.getTransactionId())
						.requestJson(requestJsonObject).responseJson(responseJsonObject).status(status)
						.httpStatusCode(statusCode).active(commonRequest.getActive()).build(),
						commonRequest.getApiStatus());
				map.put(API_STATUS, apiStatus);
			}
		}

		return map;
	}

	public <T> boolean validateResponse(ResponseEntity<T> apiResponse) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		boolean isSuccess = Boolean.TRUE;
		String error = "error";
		String errors = "errors";
		try {
			if (null != apiResponse && null != apiResponse.getBody()) {
				String json = mapper.writeValueAsString(apiResponse.getBody());

				if (!StringUtils.isBlank(json)) {
					JSONObject errorResponse = new JSONObject(json);
					JSONObject errorObj = null;
					if (errorResponse.has(error)) {
						errorObj = errorResponse.getJSONObject(error);
					} else if (errorResponse.has(errors)) {
						errorObj = errorResponse.getJSONObject(errors);
					}
					if (null != errorObj) {
						isSuccess = Boolean.FALSE;
					}
				}
			}
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return isSuccess;
	}

	public RetryTemplate createRetryTemplate(int maxAttempts, long backOffPeriod) {

		RetryTemplate retryTemplate = new RetryTemplate();
		// Fixed delay of XX seconds between retries
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		fixedBackOffPolicy.setBackOffPeriod(backOffPeriod);
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy);

		// Retry only XX times
		SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
		retryPolicy.setMaxAttempts(maxAttempts);
		retryTemplate.setRetryPolicy(retryPolicy);

		return retryTemplate;
	}

	public List<RetryConfg> getRetryConfig(String value) {

		int maxAttempts = 1;
		List<RetryConfg> list = new ArrayList<>();
		if (!isEmptyOrNull(value) && value.contains(Constants.TILDA)) {
			String[] arr1 = value.trim().split(Constants.TILDA);
			for (String str : arr1) {
				if (!isEmptyOrNull(str) && str.contains(Constants.UNDER_SQUARE)) {
					String[] arr2 = str.split(Constants.UNDER_SQUARE);
					maxAttempts = null != arr2[0] ? Integer.parseInt(arr2[0]) : maxAttempts;
					list.add(new RetryConfg(maxAttempts, calculateWaitDuration(arr2[1])));
				}
			}
		} else if (!isEmptyOrNull(value) && value.contains(Constants.UNDER_SQUARE)) {
			String[] arr2 = value.trim().split(Constants.UNDER_SQUARE);
			maxAttempts = null != arr2[0] ? Integer.parseInt(arr2[0]) : maxAttempts;
			list.add(new RetryConfg(maxAttempts, calculateWaitDuration(arr2[1])));
		} else {
			list.add(new RetryConfg(maxAttempts, 1000L));
		}

		return list;
	}

	public static long calculateWaitDuration(String str) {

		long waitDuration = 1000L;

		try {
			boolean flag = isNumeric(str);
			if (flag) {
				// default seconds
				waitDuration = Integer.parseInt(str) * waitDuration;
			} else if (str.length() > 1) {
				String loadFactor = str.substring(0, str.length() - 1);
				char format = str.charAt(str.length() - 1);
				if (format == 's') {
					// seconds
					waitDuration = Integer.parseInt(loadFactor) * waitDuration;
				} else if (format == 'm') {
					// minutes
					waitDuration = Integer.parseInt(loadFactor) * (60 * waitDuration);
				}
			}
		} catch (NumberFormatException e) {
			return waitDuration;
		}
		return waitDuration;
	}

	private static boolean isNumeric(String s) {
		// match a number with optional '-' and decimal.
		return s.matches("-?\\d+(\\.\\d+)?");
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}

	public boolean isValidJson(String json) {
		try {
			new JSONObject(json);
		} catch (JSONException e) {
			return false;
		}
		return true;
	}
}
