package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Account {

	@JsonProperty("fiType")
	private String fiType;
	@JsonProperty("fipId")
	private String fipId;
	@JsonProperty("accType")
	private String accType;
	@JsonProperty("linkRefNumber")
	private String linkRefNumber;
	@JsonProperty("maskedAccNumber")
	private String maskedAccNumber;
	@JsonProperty("status")
	private String status;
}
