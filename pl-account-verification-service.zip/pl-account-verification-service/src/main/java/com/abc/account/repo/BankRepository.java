package com.abc.account.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.account.entity.PLBank;


@Repository
public interface BankRepository extends JpaRepository<PLBank, Long> {
	
	public Optional<PLBank> findByName(String name);

}
