package com.abc.account.response;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Data{
    public Boolean epfoCheck;
    public Boolean epfo_otp_required;
}


