package com.abc.account.dto.bre;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BrePollingData {

	@JsonProperty("digitalIndex")
	public String digitalIndex;
	@JsonProperty("scrub_date")
	public String scrubDate;
	@JsonProperty("shop_address")
	public String shopAddress;
	@JsonProperty("avg_3tenure_gmv")
	public String avg3tenureGmv;
	@JsonProperty("uc_multiplier")
	public String ucMultiplier;
	@JsonProperty("bureau_creditpotenial_rp")
	public String bureauCreditpotenialRp;
	@JsonProperty("city_tier")
	public String cityTier;
	@JsonProperty("City_category")
	public String cityCategory;
	@JsonProperty("bureau_attempts")
	public int bureauAttempts;
	@JsonProperty("city_tiering")
	public String cityTiering;
	@JsonProperty("order_rto_per")
	public String orderRtoPer;
	@JsonProperty("final_limit")
	public String finalLimit;
	@JsonProperty("applicantType")
	public String applicantType;
	@JsonProperty("offer_validity_line")
	public String offerValidityLine;
	@JsonProperty("kycSource")
	public Object kycSource;
	@JsonProperty("avg_cl_rp")
	public String avgClRp;
	@JsonProperty("emi")
	public String emi;
	@JsonProperty("Mode_of_Salary_Identification")
	public String modeOfSalaryIdentification;
	@JsonProperty("nfi_value")
	public String nfiValue;
	@JsonProperty("cibil_file_path")
	public Object cibilFilePath;
	@JsonProperty("roi")
	private Double roi = 0.00;
	@JsonProperty("hunter_product")
	public String hunterProduct;
	@JsonProperty("nfi_multiplier")
	public String nfiMultiplier;
	@JsonProperty("product_variant")
	public String productVariant;
	@JsonProperty("tpv_multiplier")
	public String tpvMultiplier;
	@JsonProperty("bureau_dob")
	public String bureauDob;
	@JsonProperty("other_input_data")
	public String otherInputData;
	@JsonProperty("CIBIL_CIR_json")
	public String cIBILCIRJson;
	@JsonProperty("requested_tenure")
	public int requestedTenure;
	@JsonProperty("vintage_type")
	public String vintageType;
	@JsonProperty("loan_amount")
	public String loanAmount;
	@JsonProperty("tpv_value")
	public String tpvValue;
	@JsonProperty("average_bank_balance")
	public String averageBankBalance;
	@JsonProperty("Gst_bucket_based_limit")
	public String gstBucketBasedLimit;
	@JsonProperty("bureauSegment")
	public String bureauSegment;
	@JsonProperty("partner_application_id")
	public String partnerApplicationId;
	@JsonProperty("brand_endorsement")
	public String brandEndorsement;
	@JsonProperty("trade_count")
	public String tradeCount;
	@JsonProperty("borrower_category")
	public String borrowerCategory;
	@JsonProperty("kyc_address")
	public String kycAddress;
	@JsonProperty("isPreapproved")
	public boolean isPreapproved;
	@JsonProperty("hunter_score")
	public int hunterScore;
	@JsonProperty("min_tenure")
	public String minTenure;
	@JsonProperty("token_id")
	public String tokenId;
	@JsonProperty("aadhaar_digilocker_profile_id")
	public String aadhaarDigilockerProfileId;
	@JsonProperty("age")
	public String age;
	@JsonProperty("mobiScoreModel")
	public String mobiScoreModel;
	@JsonProperty("Risk_category")
	public String riskCategory;
	@JsonProperty("loan_type")
	public String loanType;
	@JsonProperty("last_ce_executed_task")
	public String lastCeExecutedTask;
	@JsonProperty("gst_limit")
	public String gstLimit;
	@JsonProperty("customer_id")
	public String customerId;
	@JsonProperty("custCategory")
	public String custCategory;
	@JsonProperty("Bank_Statement_Analyzed")
	public String bankStatementAnalyzed;
	@JsonProperty("entitydetails")
	public Entitydetails entitydetails;
	@JsonProperty("decision_timestamp")
	public String decisionTimestamp;
	@JsonProperty("Risk_Segment")
	public String riskSegment;
	@JsonProperty("order_id")
	public String orderId;
	@JsonProperty("entrance_type")
	public String entranceType;
	@JsonProperty("bre2_requested_loan_amount")
	public String bre2RequestedLoanAmount;
	@JsonProperty("total_emi")
	public String totalEmi;
	@JsonProperty("Annual_Household_income")
	public String annualHouseholdIncome;
	@JsonProperty("annual_turnover")
	public String annualTurnover;
	@JsonProperty("order_return_per")
	public String orderReturnPer;
	@JsonProperty("ccPolicyEligibility")
	public String ccPolicyEligibility;
	@JsonProperty("pl_leadid")
	public String plLeadid;
	@JsonProperty("application_id")
	public String applicationId;
	@JsonProperty("maxDisbursedAmount")
	public String maxDisbursedAmount;
	@JsonProperty("hunter_category")
	public String hunterCategory;
	@JsonProperty("current_limit")
	public String currentLimit;
	@JsonProperty("bureau_report_fetch")
	public String bureauReportFetch;
	@JsonProperty("hunter_match_count")
	public int hunterMatchCount;
	@JsonProperty("bank_limit")
	public String bankLimit;
	@JsonProperty("requested_loan_amount_r2_line")
	public String requestedLoanAmountR2Line;
	@JsonProperty("last_updated_at")
	public String lastUpdatedAt;
	@JsonProperty("approved_loan_amount")
	public Double approvedLoanAmount=0.00;
	@JsonProperty("customer_category")
	public String customerCategory;
	@JsonProperty("hunter_final_result")
	public String hunterFinalResult;
	@JsonProperty("aadhaar_digilocker_reference_id")
	public String aadhaarDigilockerReferenceId;
	@JsonProperty("nameboard_type")
	public String nameboardType;
	@JsonProperty("income")
	public String income;
	@JsonProperty("min_loan_amount")
	public String minLoanAmount;
	@JsonProperty("salaried")
	public boolean salaried;
	@JsonProperty("token_status")
	public String tokenStatus;
	@JsonProperty("partner_journey_id")
	public String partnerJourneyId;
	@JsonProperty("updated_timestamp")
	public String updatedTimestamp;
	@JsonProperty("limit_gmv")
	public String limitGmv;
	@JsonProperty("company_doi")
	public String companyDoi;
	@JsonProperty("spend_category_max_limit")
	public String spendCategoryMaxLimit;
	@JsonProperty("max_aging_dues")
	public String maxAgingDues;
	@JsonProperty("created_timestamp")
	public String createdTimestamp;
	@JsonProperty("geo_tagging")
	public String geoTagging;
	@JsonProperty("ce_2_callback_status_code")
	public String ce2CallbackStatusCode;
	@JsonProperty("employerCategory")
	public String employerCategory;
	@JsonProperty("bureau_creditpotenial_daemi")
	public String bureauCreditpotenialDaemi;
	@JsonProperty("bureau_limit")
	public String bureauLimit;
	@JsonProperty("max_requested_loan_amount")
	public int maxRequestedLoanAmount;
	@JsonProperty("loan_assessment_parameters")
	public String loanAssessmentParameters;
	@JsonProperty("tenure_ontime_payment")
	public String tenureOntimePayment;
	@JsonProperty("isAbc")
	public boolean isAbc;
	@JsonProperty("local_address")
	public String localAddress;
	@JsonProperty("partner_bureau_score")
	public String partnerBureauScore;
	@JsonProperty("nsdl_timestamp")
	public String nsdlTimestamp;
	@JsonProperty("avg_6tenure_gst")
	public String avg6tenureGst;
	@JsonProperty("requested_loan_amount")
	public int requestedLoanAmount;
	@JsonProperty("lk_score")
	public String lkScore;
	@JsonProperty("aadhaar_digilocker_capture_link")
	public String aadhaarDigilockerCaptureLink;
	@JsonProperty("ccc_request_id")
	public String cccRequestId;
	@JsonProperty("Customer_segment")
	public String customerSegment;
	@JsonProperty("hunter_identifier")
	public String hunterIdentifier;
	@JsonProperty("aadhaar_digilocker_capture_expires_at")
	public Object aadhaarDigilockerCaptureExpiresAt;
	@JsonProperty("pincodeTier")
	public String pincodeTier;
	@JsonProperty("risk_offer_code")
	public String riskOfferCode;
	@JsonProperty("preapprovedAmount")
	public int preapprovedAmount;
	@JsonProperty("max_tenure")
	public String maxTenure;
	@JsonProperty("bank_limit_avg_monthly_debits")
	public String bankLimitAvgMonthlyDebits;
	@JsonProperty("stage1_created_timestamp")
	public int stage1CreatedTimestamp;

	@JsonProperty("tenure")
	public String tenure;
	@JsonProperty("employmentType")
	public String employmentType;
	@JsonProperty("store_location")
	public String storeLocation;
	@JsonProperty("mobile_number")
	public String mobileNumber;
	@JsonProperty("pan")
	public String pan;
	@JsonProperty("companyName")
	public String companyName;
	@JsonProperty("companyCategory")
	public String companyCategory;
	@JsonProperty("cccId")
	public String cccId;
	@JsonProperty("company_name")
	public String company_name;
	@JsonProperty("company_category")
	public String company_category;
	@JsonProperty("ccc_id")
	public String ccc_id;

	@JsonProperty("a8_application_status")
	public String a8ApplicationStatus;
	@JsonProperty("a8_callback_resp")
	public String a8CallbackResp;
	@JsonProperty("a8_video_pd_status")
	public String a8VideoPdStatus;
	@JsonProperty("a8_flg_upd_from")
	public String a8FlgUpdFrom;
	@JsonProperty("a8_process_instance_id")
	public String a8ProcessInstanceId;
	@JsonProperty("a8_fi_status")
	public String a8FiStatus;
	@JsonProperty("prev_a8_ce_status")
	public String prevA8CeStatus;
	@JsonProperty("a8_sanctionDetails")
	public A8SanctionDetails a8SanctionDetails;

	
	@JsonProperty("ce_status")
	public String ceStatus;
	@JsonProperty("ce_callback_message")
	public String ceCallbackMessage;
	@JsonProperty("ce_callback_status_code")
	public String ceCallbackStatusCode;
	
	@JsonProperty("ce_2_status")
	public String ce2Status;
	@JsonProperty("ce_2_callback_message")
	public String ce2CallbackMessage;
	
	@JsonProperty("first_min_tenure")
	public String firstMinTenure;
	@JsonProperty("first_max_tenure")
	public String firstMaxTenure;
	@JsonProperty("first_loan_amount")
	public String firstLoanAmount;
	@JsonProperty("first_roi")
	public String firstRoi;
	@JsonProperty("first_tenure")
	public String firstTenure;
	@JsonProperty("first_emi")
	public String firstEmi;
	@JsonProperty("first_offer_validity_line")
	public String firstOfferValidityLine;

	@JsonProperty("second_min_tenure")
	public String secondMinTenure;
	@JsonProperty("second_max_tenure")
	public String secondMaxTenure;
	@JsonProperty("second_loan_amount")
	public String secondLoanAmount;
	@JsonProperty("second_min_loan_amount")
	public String secondMinLoanAmount;
	@JsonProperty("second_approved_loan_amount")
	public String secondApprovedLoanAmount;
	@JsonProperty("second_roi")
	public String secondRoi;
	@JsonProperty("second_tenure")
	public String secondTenure;
	@JsonProperty("second_emi")
	public String secondEmi;
}
