package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RecurringDetails {

	@JsonProperty("status")
	private String status;
	
	@JsonProperty("failure_reason")
	private String failureReason;
}
