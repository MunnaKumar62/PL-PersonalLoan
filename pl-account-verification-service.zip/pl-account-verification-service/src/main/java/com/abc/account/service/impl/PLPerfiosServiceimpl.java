package com.abc.account.service.impl;

import java.security.Security;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.constant.PlPrefiosConstant;
import com.abc.account.constant.PrefiosPEMConstant;
import com.abc.account.dto.PLCustomerDetailDto;
import com.abc.account.dto.plprefio.Transaction;
import com.abc.account.entity.ApiStatus;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.InternalException;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.request.ApiCommonRequest;
import com.abc.account.request.InteractiveLinkRequest;
import com.abc.account.request.TxnCompleteCallbackRequest;
import com.abc.account.response.InstitutionsResponse;
import com.abc.account.response.InteractiveLinkReponse;
import com.abc.account.response.PerfiosTransactionStatusResponse;
import com.abc.account.service.CustomerDetailsService;
import com.abc.account.service.PLCustomerDetailService;
import com.abc.account.service.PLPerfiosService;
import com.abc.account.service.TokenService;
import com.abc.account.service.biz.AccountAggregatorBizService;
import com.abc.account.service.biz.CommonBizService;
import com.abc.account.util.CommonUtil;
import com.abc.account.util.PerfiosUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PLPerfiosServiceimpl extends CommonBizService
		implements PLPerfiosService, PrefiosPEMConstant, PlPrefiosConstant, MessageConstants, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Value("${abfl.perfios.env}")
	private String perfEnv;

	@Value("${abfl.perfios.host}")
	private String hostDomain;

	@Value("${abfl.perfios.listinstitutions.url}")
	private String listinstitutionsUrl;

	@Value("${abfl.perfios.signature.baseurl}")
	private String signatureBaseUrl;

	@Value("${abfl.perfios.createinteractivelink.url}")
	private String createinteractivelinkUrl;

	@Value("${abfl.perfios.retrievereport.url}")
	private String retrievereportUrl;

	@Value("${abfl.perfios.txnstatus.url}")
	private String txnStatusUrl;
	
	@Value("${abfl.prod.perfios.host}")
	private String prodHostDomain;

	@Value("${abfl.prod.perfios.listinstitutions.url}")
	private String prodListinstitutionsUrl;

	@Value("${abfl.prod.perfios.createinteractivelink.url}")
	private String prodCreateinteractivelinkUrl;

	@Value("${abfl.prod.perfios.retrievereport.url}")
	private String prodRetrievereportUrl;

	@Value("${abfl.prod.perfios.txnstatus.url}")
	private String prodTxnStatusUrl;
	
	@Autowired
	PLCustomerDetailService plCustomerDetailService;

	@Autowired
	private Environment env;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private APIStatusRepository apiStatusRepository;

	@Autowired
	private CustomerDetailsService customerDetailsService;

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getInstitution(String dataSource, String processingType) {

		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4100";
		PerfiosUtil perfiosUtil = new PerfiosUtil();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String xPerfiosDate = perfiosUtil.getCurrentDate();

		try {
			String payload = EMPTY;
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(PROD.equals(perfEnv) ? prodListinstitutionsUrl : listinstitutionsUrl)
					.queryParam(PARAM1, dataSource).queryParam(PARAM2, processingType).build();
			String signature = perfiosUtil.listInstitutionSignature(signatureBaseUrl + "/institutions", payload,
					xPerfiosDate, dataSource, processingType, PROD.equals(perfEnv) ? prodHostDomain : hostDomain,
					perfEnv);
			HttpHeaders headers = createInstitutionsHeaders(getTokenByEnv(), xPerfiosDate,
					perfiosUtil.getSHA256(payload), signature);

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_LIST_INSTITUTIONS).accountId(EMPTY)
					.url(builder.toUriString()).requestHeaders(headers).method(HttpMethod.GET).isAudit(Boolean.TRUE)
					.request(null).build();

			map = callExternalApi(commonRequest, InstitutionsResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> createInteractiveLink(InteractiveLinkRequest request) {

		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4101";
		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		PerfiosUtil perfiosUtil = new PerfiosUtil();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		InteractiveLinkReponse response = null;
		Map<String, Object> map = null;
		String accountId = null;
		String requestJsonObject = null;
		String xPerfiosDate = perfiosUtil.getCurrentDate();

		/**
		 * Input request validation
		 */
		request = bizService.createIntractiveValidation(request);
		try {
			if (request != null) {
				accountId = request.getAccountId();
				// Not applicable for external API
				request.setAccountId(null);

				requestJsonObject = mapper.writeValueAsString(request);
				// Request signature
				String signature = perfiosUtil.craeteInteractiveLinkSignature(
						signatureBaseUrl + "/ephemeral-transaction-links", requestJsonObject, xPerfiosDate,
						PROD.equals(perfEnv) ? prodHostDomain : hostDomain, perfEnv);
				HttpHeaders headers = createIntractiveHeaders(getTokenByEnv(),
						perfiosUtil.getSHA256(requestJsonObject), xPerfiosDate, signature);

				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_CREATE_INTERACTIVE_LINK)
						.accountId(accountId).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY)
						.url(PROD.equals(perfEnv)?prodCreateinteractivelinkUrl:createinteractivelinkUrl).requestHeaders(headers).method(HttpMethod.POST).request(requestJsonObject)
						.active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

				map = callExternalApi(commonRequest, InteractiveLinkReponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
						if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
							ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
							if (null != apiResponse && null != apiResponse.getBody()) {
								response = (InteractiveLinkReponse) apiResponse.getBody();
								// PL_JOURNEY_AUDIT
								if (null != response && null != response.getTransactionLink()) {
										PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
										plCustomerDetailDto.setAccountId(accountId);
										plCustomerDetailDto.setIncomeVerifyTxnid(response.getTransactionLink().getPerfiosTransactionId());
										plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
								}
								apiStatus.setTransactionId(null != response
										&& null != response.getTransactionLink().getPerfiosTransactionId()
												? response.getTransactionLink().getPerfiosTransactionId()
												: EMPTY);
							}
							updateApiStatus(customerDetailsService.findByAccountId(accountId), apiStatus,
												"", 0L);
						}
					} else {
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
				log.info(className + methodName + END);
			}
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getTransactionStatus(String txnid) {

		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4102";
		PerfiosUtil perfiosUtil = new PerfiosUtil();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		boolean isApiCallReq = Boolean.TRUE;
		PerfiosTransactionStatusResponse statusResponse = null;
		String xPerfiosDate = perfiosUtil.getCurrentDate();
		String accountId = null;
		String responseJson = null;

		// Get Interactive Link and accountId
		accountId = apiStatusRepository.findAccountIdByTransactionIdAndApiNameAndActive(txnid, PL_CREATE_INTERACTIVE_LINK,
				Boolean.FALSE);
		if (!isEmptyOrNull(accountId)) {
			try {
				// Get Transaction if exist
				responseJson = apiStatusRepository.findResponseJsonByTransactionIdAndApiNameAndActive(txnid, PL_IB_TXN_STATUS,
						Boolean.FALSE);

				if (!isEmptyOrNull(responseJson)) {
					statusResponse = mapper.readValue(responseJson,	PerfiosTransactionStatusResponse.class);
					List<Transaction> tmpList = statusResponse.getTransactions().getTransaction();
					for (Transaction transaction : tmpList) {
						if (txnid.equals(transaction.getPerfiosTransactionId())
								&& !isEmptyOrNull(transaction.getStatus()) && (COMPLETED.equals(transaction.getStatus())
										|| REJECTED.equals(transaction.getStatus()))) {
							isApiCallReq = Boolean.FALSE;
						}
					}
				}
				if (isApiCallReq) {
					String payload = EMPTY;
					String signature = perfiosUtil.transactionStatusSignature(
							signatureBaseUrl + "/transactions/" + txnid + "/status", payload, xPerfiosDate, PROD.equals(perfEnv)?prodHostDomain:hostDomain,
							perfEnv);
					HttpHeaders headers = retrieveReportHttpHeaders(getTokenByEnv(),
							perfiosUtil.getSHA256(payload), signature, xPerfiosDate);

					ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_IB_TXN_STATUS)
							.accountId(accountId).profileId(EMPTY).requestId(txnid).transactionId(txnid)
							.url(PROD.equals(perfEnv)?(prodTxnStatusUrl + txnid):(txnStatusUrl + txnid)).requestHeaders(headers).method(HttpMethod.GET).request(null)
							.active(Boolean.FALSE).isAudit(Boolean.TRUE).apiStatus(null).build();

					map = callExternalApi(commonRequest, PerfiosTransactionStatusResponse.class);

					if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
						if (validateResponse(apiResponse)) {
							obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
						} else {
							obj = CommonUtil.getErrorResponse(apiResponse.getBody());
						}
					}
				} else {
					log.info(className + methodName + " Fetching Data From DB");
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), statusResponse);
				}
			} catch (Exception ex) {
				log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			}
		} else {
			throw new InternalException("1004");
		}

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getRetrieveReport(String txnid) {

		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL4103";
		PerfiosUtil perfiosUtil = new PerfiosUtil();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		ApiStatus apiStatus1 = null;
		String xPerfiosDate = perfiosUtil.getCurrentDate();
		String accountId = null;

		try {
			// Get Interactive Link and accountId
			accountId = apiStatusRepository.findAccountIdByTransactionIdAndApiNameAndActive(txnid, PL_CREATE_INTERACTIVE_LINK,
					Boolean.FALSE);
			if (!isEmptyOrNull(accountId)) {
				// Get Retrieve Report if exist
				//apiStatus1 = apiStatusRepository.findByTransactionIdAndApiNameAndActive(txnid, PL_RETRIVE_REPORT,
					//	Boolean.FALSE);
				String payload = EMPTY;
				String signature = perfiosUtil.retrieveReportSignature(
						signatureBaseUrl + "/transactions/" + txnid + "/reports", payload, xPerfiosDate, PROD.equals(perfEnv)?prodHostDomain:hostDomain,
						perfEnv);
				UriComponents builder = UriComponentsBuilder
						.fromHttpUrl(
								PROD.equals(perfEnv) ? (prodRetrievereportUrl + txnid) : (retrievereportUrl + txnid))
						.queryParam(QUERY_PARAM, REPORT_FORMAT).build();
				HttpHeaders headers = retrieveReportHttpHeaders(getTokenByEnv(),
						perfiosUtil.getSHA256(payload), signature, xPerfiosDate);

				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_RETRIVE_REPORT)
						.accountId(accountId).profileId(EMPTY).requestId(txnid).transactionId(txnid)
						.url(builder.toUriString()).requestHeaders(headers).method(HttpMethod.GET).request(null)
						.active(Boolean.FALSE).isAudit(Boolean.TRUE).apiStatus(apiStatus1).build();

				map = callExternalApi(commonRequest, Object.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					} else {
						obj = CommonUtil.getErrorResponse(apiResponse.getBody());
					}
				}
			} else {
				throw new InternalException("1004");
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getTxnCompleteCallback(String callbackType, TxnCompleteCallbackRequest request ) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		String responseJsonObject1 = null;
		Object obj = null;
		final String code = "PL4104";
		List<Transaction> list = new ArrayList<>();

		if (null == request) {
			throw new CustomException(EMPTY_REQUEST);
		}else if (isEmptyOrNull(callbackType) || !"TRANSACTION_COMPLETE".equals(callbackType)) {
			throw new CustomException(X_PERFIOS_CALLBACK_TYPE + HYPHEN + callbackType + HYPHEN + INVALID_HEADER);
		} else if (null != request && isEmptyOrNull(request.getPerfiosTransactionId())) {
			throw new CustomException(FILED_PERF_TXNID + TILDA + EMPTY_PARAM);
		} else if (null != request && isEmptyOrNull(request.getStatus())) {
			throw new CustomException(FILED_STATUS + TILDA + EMPTY_PARAM);
		} else {
			// Get Transaction if exist
			apiStatus = apiStatusRepository.findByTransactionIdAndApiNameAndActive(request.getPerfiosTransactionId(),
					PL_IB_TXN_STATUS, Boolean.FALSE);
			if (apiStatus == null) {
				throw new InternalException("1002");
			} else {
				try {
					requestJsonObject = mapper.writeValueAsString(request);
					PerfiosTransactionStatusResponse statusResponse = mapper.readValue(apiStatus.getResponseJson(),
							PerfiosTransactionStatusResponse.class);
					List<Transaction> tmpList = statusResponse.getTransactions().getTransaction();
					for (Transaction transaction : tmpList) {
						if (request.getPerfiosTransactionId().equals(transaction.getPerfiosTransactionId())) {
							transaction.setStatus(request.getStatus());
							transaction.setErrorCode(request.getErrorCode());
							transaction.setClientTransactionId(request.getClientTransactionId());
						}
						list.add(transaction);
					}
					statusResponse.getTransactions().setTransaction(list);
					responseJsonObject1 = mapper.writeValueAsString(statusResponse);
					apiStatus.setResponseJson(responseJsonObject1);
					apiStatusRepository.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), null);
					responseJsonObject = mapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_IB_TXN_CALL_BACK).accountId(apiStatus.getAccountId())
							.profileId(EMPTY).requestId(request.getClientTransactionId()).transactionId(request.getPerfiosTransactionId())
							.requestJson(requestJsonObject).responseJson(responseJsonObject).status(SUCCESS)
							.httpStatusCode(HttpStatus.OK.value()).active(Boolean.FALSE).build(), null);

				} catch (JsonProcessingException ex) {
					log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
				}
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	public String getTokenByEnv() {

		String token = null;
		if (null != perfEnv && PROD.equals(perfEnv)) {
			token = tokenService.getProdAccessToken();
		} else {
			token = tokenService.getAccessToken();
		}
		return token;
	}

}
