package com.abc.account.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.abc.account.entity.LoanOfferDetails;





public interface LoanRepository extends JpaRepository<LoanOfferDetails, Double>{
	
	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE created_date = (SELECT MAX(created_date) FROM t_pl_loan_offer_details WHERE account_id = :accountId)",nativeQuery = true)
	public LoanOfferDetails getLoanOfferDetailsByAccountId(@Param("accountId") String accountId);

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE created_date = (SELECT MAX(created_date) FROM t_pl_loan_offer_details WHERE account_id = :accountId and loan_id = :loanId and customer_id = :customerId)",nativeQuery = true)
	public LoanOfferDetails getLoanOfferDetailsByAccountIdAndLoanIdAndCustomerId(@Param("accountId") String accountId, @Param("loanId") String loanId, @Param("customerId") Long customerId);

}
