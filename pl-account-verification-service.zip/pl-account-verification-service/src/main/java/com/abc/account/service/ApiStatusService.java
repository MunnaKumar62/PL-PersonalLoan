package com.abc.account.service;

import com.abc.account.entity.ApiStatus;

public interface ApiStatusService {

	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName, Boolean active);

	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus);
	
	public ApiStatus findByTransactionIdAndApiName(String transactionId, String apiName, Boolean active);
}
