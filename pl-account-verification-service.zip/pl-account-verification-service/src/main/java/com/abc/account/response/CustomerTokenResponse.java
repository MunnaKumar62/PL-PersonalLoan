package com.abc.account.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CustomerTokenResponse {

	@JsonProperty("entity")
	private String entity;
	
	@JsonProperty("count")
	private int count;
	
	@JsonProperty("items")
	private List<Item> items;

}
