package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ReportGenerationResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private Object data;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;

}
