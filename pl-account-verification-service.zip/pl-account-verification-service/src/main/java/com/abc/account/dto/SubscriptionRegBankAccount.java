package com.abc.account.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SubscriptionRegBankAccount {

	@Schema(name="bank_name",example = "")
	public String bank_name="";
	@Schema(name="account_number",example = "12345678")
	public String account_number;
	
	@Schema(name="ifsc_code",example = "BARB0TREASU")
	public String ifsc_code;
	
	@Schema(name="beneficiary_name",example = "ABC")
	public String beneficiary_name;
	
}
