package com.abc.account.request;

import lombok.Data;

@Data
public class EssentialsPenny{
    private String beneficiaryMobile;
    private String beneficiaryAccount;
    private String beneficiaryName;
    private String beneficiaryIFSC;
    private String nameMatchScore;
    private String nameFuzzy;
}


