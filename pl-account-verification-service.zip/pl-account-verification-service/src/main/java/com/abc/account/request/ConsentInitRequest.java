package com.abc.account.request;

import java.util.List;

import com.abc.account.dto.aggregator.PassThroughParam;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ConsentInitRequest {

	@JsonProperty("applicationId")
	public String applicationId;

	@JsonProperty("returnURL")
	public String returnURL;

	@JsonProperty("mobileNumber")
	public String mobileNumber;

	@JsonProperty("panNumber")
	public String panNumber;

	@JsonProperty("fiTypes")
	public List<String> fiTypes;

	@JsonProperty("fipIds")
	public List<String> fipIds;

	@JsonProperty("profileId")
	public String profileId;

	@JsonProperty("passThroughParams")
	public List<PassThroughParam> passThroughParams;
}
