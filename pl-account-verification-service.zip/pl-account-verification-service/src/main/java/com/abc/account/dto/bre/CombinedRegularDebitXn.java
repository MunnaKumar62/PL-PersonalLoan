package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class CombinedRegularDebitXn {
	private String bank;
	private String category;
	private double balance;
	private int slNo;
	private String accNo;
	private double amount;
	private String narration;
	private String date;
	private String chqNo;
	private int groupNo;

}
