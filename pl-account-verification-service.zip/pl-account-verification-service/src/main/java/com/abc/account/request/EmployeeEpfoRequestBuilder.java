package com.abc.account.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
public class EmployeeEpfoRequestBuilder {

    @NotBlank(message = "Employer name is required")
    @Size(min = 3, max = 255, message = "Employer name must be between 3 and 255 characters")
    @Pattern(regexp = "^[A-Za-z0-9._+-,\\s+]+$", message = "Employer name must only contain letters, numbers, and some special characters")
    private String employerName;

    @NotBlank(message = "Employee name is required")
    @Size(min = 3, max = 50, message = "Employee name must be between 3 and 50 characters")
    @Pattern(regexp = "^[A-Za-z0-9._+-,\\s+]+$", message = "Employee name must only contain letters, numbers, and some special characters")
    private String employeeName;

    @NotBlank(message = "Mobile number is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Invalid mobile number format")
    private String mobile;

    @NotNull(message = "PDF field is required")
    private Boolean pdf;

    @NotBlank(message = "Account ID is required")
    private String accountId;

    //	@NotBlank(message = "emailId is required")
    @Pattern(regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$", message = "Invalid email format")
    private String emailId;
}