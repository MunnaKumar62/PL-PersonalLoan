package com.abc.account.request;

import lombok.Data;

@Data
public class AdditionalDetail {

	private String accountId;
    private String loanId;
    private String tokenId;
    private String orderId;
    private String customerId;
    private Long abfCustomerId;
    private String tokenStatus;
	
	
}
