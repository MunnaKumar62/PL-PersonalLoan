package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Match {

	@JsonProperty("name")
	public String name;

	@JsonProperty("confidence")
	public Double confidence;

	@JsonProperty("estId")
	public String estId;

	@JsonProperty("epfHistory")
	public Object epfHistory;
}
