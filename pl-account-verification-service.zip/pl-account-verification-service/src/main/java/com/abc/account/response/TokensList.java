package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TokensList {

	@JsonProperty("tokenid")
	private String tokenid;

	@JsonProperty("customerTokenStatus")
	private String customerTokenStatus;

}
