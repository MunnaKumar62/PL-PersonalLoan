package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailParameters {

	@JsonProperty("isValid")
	public String isValid;

	@JsonProperty("person")
	public Person person;

	@JsonProperty("organization")
	public Organization organization;

	@JsonProperty("alerts")
	public Boolean alerts;
}
