package com.abc.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class EMandatePollResponse {

	private String responseStatus;
	private EMandatePollData data;
	private EMandatePollError error;	

}
/*
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
class EMandatePollError {
	
	public String code;
	public String description;
	public String errorType;

	JSONObject toJSON() {
		JSONObject jo = new JSONObject();
		jo.put("code", code);
		jo.put("description", description);
		jo.put("errorType", errorType);
		return jo;
	}
}*/

/*@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
class EMandatePollData {
	
	

	JSONObject toJSON() {
		JSONObject jo = new JSONObject();
		jo.put("code", code);
		jo.put("description", description);
		jo.put("razorpayCustid", razorpayCustid);
		jo.put("tokenId", tokenId);
		jo.put("tokenStatus", tokenStatus);
		jo.put("failureReason", failureReason);
		jo.put("mrnNo", mrnNo);
		return jo;
	}*/

