package com.abc.account.response;

import lombok.Data;

@Data
public class ConsentData {

	private String redirectURL;
	private String requestId;
	private String qrcode;

}
