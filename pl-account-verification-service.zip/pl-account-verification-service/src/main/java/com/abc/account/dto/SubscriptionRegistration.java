package com.abc.account.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SubscriptionRegistration {
	@Builder.Default
	@Schema(name="method",example = "emandate")
	public String method="emandate";
	
	@Builder.Default
	@Schema(name="auth_type",example = "")
	public String auth_type="";
	
	public SubscriptionRegBankAccount bank_account;
	
}
