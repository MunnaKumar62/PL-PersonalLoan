package com.abc.account.service;

import org.springframework.http.ResponseEntity;

public interface TokenService {

	public String getAccessToken();

	public ResponseEntity<Object> callTokenApi();
	
	public String getProdAccessToken();

	public ResponseEntity<Object> callProdTokenApi();
}
