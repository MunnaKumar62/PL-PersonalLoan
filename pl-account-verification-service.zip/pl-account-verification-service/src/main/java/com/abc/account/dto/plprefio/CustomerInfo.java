package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data

public class CustomerInfo {
    @JsonProperty("name")
    private String name;

    @JsonProperty("address")
    private String address;

    @JsonProperty("landline")
    private String landline;

    @JsonProperty("mobile")
    private String mobile;

    @JsonProperty("email")
    private String email;

    @JsonProperty("pan")
    private String pan;

    @JsonProperty("perfiosTransactionId")
    private String perfiosTransactionId;

    @JsonProperty("customerTransactionId")
    private String customerTransactionId;

    @JsonProperty("bank")
    private String bank;

    @JsonProperty("instId")
    private int instId;

}