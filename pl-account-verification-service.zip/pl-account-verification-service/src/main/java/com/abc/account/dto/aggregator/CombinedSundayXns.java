package com.abc.account.dto.aggregator;

import java.util.Date;

import com.abc.account.constant.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CombinedSundayXns {

	@JsonProperty("slNo")
	private int slNo;

	@JsonProperty("date")
	@JsonFormat(pattern = Constants.DATE_FORMAT, shape = JsonFormat.Shape.STRING)
	private Date date;

	@JsonProperty("chqNo")
	private String chqNo;

	@JsonProperty("narration")
	private String narration;

	@JsonProperty("amount")
	private int amount;

	@JsonProperty("category")
	private String category;

	@JsonProperty("balance")
	private double balance;

	@JsonProperty("bank")
	private String bank;

	@JsonProperty("accNo")
	private String accNo;
}
