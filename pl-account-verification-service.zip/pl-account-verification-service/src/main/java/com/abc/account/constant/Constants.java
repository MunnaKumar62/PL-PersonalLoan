package com.abc.account.constant;

public interface Constants {

	/**
	 * ********** End points **********
	 */
	public static final String ALL = "*";

	public static final String API = "/api";

	public static final String ONE_APP_ABC = "/oneappabc";

	public static final String ADITYA_BIRLA = "/adityabirla";

	public static final String VERSION = Constants.SLASH + "${pl.url.version}";

	public static final String PERSONAL_LOAN = "/personalloan";

	public static final String ACCOUNT_VERIFICATION = "/accountverification";

	public static final String CUSTOMER = "/customer";

	public static final String ADMIN = "/admin";

	public static final String PL = "/pl";

	public static final String ACCOUNT_AGGREGATOR = "/accountaggregator";
	
	public static final String PERFIOS = "/perfios";

	public static final String REPORT_GENERATION = "/reportgeneration";

	public static final String FIP_LIST = "/fiplist";

	public static final String AA_TRAN_STATUS = "/transactionstatus";

	public static final String CONSENT_INIT = "/consentinit";

	public static final String EPFO = "/epfo";

	public static final String EPFO_SILENT_CHECK = "/epfosilentcheck";
	
	public static final String SEND_OTP_COMBINED = "/sendotpcombined";
	
	public static final String VERIFY_OTP_COMBINED = "/verifyotpcombined";
	
	public static final String EMPLOYMENT_VERIFICATION = "/employmentverificationsync";

	public static final String EMPLOYMENT_VERIFICATION_ASYNC = "/empVerificationAsync";

	public static final String EPFO_POLLING_ASYNC = "/epfoPolling";

	public static final String CREATE_CUSTOMER = "/createcustomer";

	public static final String CREATE_ORDER = "/createorder";

	public static final String PAYMENTS = "/payments";
	
	public static final String UPI_PAYMENTS = "/upipayments";
	
	public static final String VALIDATE_VPA = "/ValidateVPA";

	public static final String PENNY_DROP = "/pennydrop";
	
	public static final String NAME_CHECK = "/namematch";

	public static final String IFSC_CHECK = "/ifscvalidation";

	public static final String BANK_LIST = "/banklist";

	public static final String ADD_BANK = "/addbank";

	public static final String SEARCH_BANK_LIST = "/searchbanklist/{input}";

	public static final String BRE2 = "/bre2";

	public static final String BRE2_DETAILS = "/bre2details/{accountId}";

	public static final String BRE2_CALLBACK = "/bre2callback";

	public static final String RETRIVE_REPORT = "/retrievereport/{txnid}";

	public static final String CREATE_INTERACTIVE_LINK = "/createinteractivelink";
	
	public static final String IB_TRAN_STATUS = "/transactionstatus/{txnid}";
	
	public static final String LIST_INSTITUTIONS = "/institutions";
	
	public static final String CONSENT_CALLBACK = "/consentcallback";
	
	public static final String REPORT_GENERATION_CALLBACK = "/reportgenerationcallback";
	
	public static final String TXN_COMPLETE_CALLBACK = "/txncompletecallback";

	public static final String PL_JOURNEY = "PL";

	public static final String PL_AUTH_TOKEN = "AUTH_TOKEN";

	public static final String PL_E_MANDATE = "E_MANDATE";

	public static final String PL_E_MANDATE_POLLING = "E_MANDATE_POLLING";

	public static final String PL_E_MANDATE_CALLBACK = "E_MANDATE_CALLBACK";

	public static final String PL_REPORT_GENERATION = "REPORT_GENERATION";

	public static final String PL_FIP_LIST = "FIP_LIST";
	
	public static final String PL_LIST_INSTITUTIONS = "LIST_INSTITUTIONS";

	public static final String PL_AA_TXN_STATUS = "AA_TXN_STATUS";

	public static final String PL_CONSENT_INIT = "CONSENT_INIT";

	public static final String PL_EPFO_SILENT_CHECK = "EPFO_SILENT_CHECK";

	public static final String PL_CREATE_CUSTOMER = "CREATE_CUSTOMER";

	public static final String PL_CREATE_ORDER = "CREATE_ORDER";

	public static final String PL_TOKEN_BY_PAYMENT_ID = "TOKEN_BY_PAYMENT_ID";
	
	public static final String PL_TOKEN_BY_UPI_PAYMENT_ID = "TOKEN_BY_UPI_PAYMENT_ID";

	public static final String PL_TOKEN_BY_CUST_ID = "TOKEN_BY_CUST_ID";
	
	public static final String PL_VALIDATE_VPA = "VALIDATE_VPA";

	public static final String PL_PENNY_DROP = "PENNY_DROP";

	public static final String PL_NAME_CHECK = "NAME_CHECK";

	public static final String PL_IFSC_CHECK = "IFSC_CHECK";

	public static final String PL_PAN_NAME_CHECK = "PAN_NAME_CHECK";

	public static final String PL_BRE2 = "BRE2";

	public static final String PL_BRE2_POLLING = "BRE2_POLLING";

	public static final String PL_BRE2_CALLBACK = "BRE2_CALLBACK";

	public static final String PL_RETRIVE_REPORT = "RETRIVE_REPORT";
	
	public static final String PL_IB_TXN_STATUS = "IB_TXN_STATUS";
	
	public static final String PL_CREATE_INTERACTIVE_LINK = "CREATE_INTERACTIVE_LINK";
	
	public static final String PL_CONSENT_CALL_BACK = "CONSENT_CALL_BACK";
	
	public static final String PL_REPORT_GENERATION_CALL_BACK = "REPORT_GENERATION_CALL_BACK";
	
	public static final String PL_IB_TXN_CALL_BACK = "IB_TXN_CALL_BACK";
	
	public static final String PL_SEND_OTP_COMBINED="SEND_OTP_COMBINED";
	
	public static final String PL_VERIFY_OTP_COMBINED="verify_OTP_COMBINED";
	
	public static final String PL_EMPLOYEE_VERIFICATION_SYCN="EMPLOYEE_VERIFICATION_SYCN";

	public static final String PL_EMPLOYEE_VERIFICATION_ASYNC="EMPLOYEE_VERIFICATION_ASYNC";

	public static final String EPFO_POLLING="EPFO_POLLING";
	/**
	 * ********** Common Constants **********
	 */
	public static final String EMPTY = "";

	public static final String SLASH = "/";

	public static final String TILDA = "~";
	
	public static final String HYPHEN = "-";

	public static final String UNDER_SQUARE = "_";

	public static final String DATE_FORMAT = "yyyy-MM-dd";

	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy hh:mm:ss a";

	public static final String DOB_FORMAT = "dd-MM-yyyy";

	public static final String BEGIN = " Begin";

	public static final String END = " End";

	public static final String EXCEPTION = "[EXCEPTION] ";

	public static final String FINALLY_BLOCK = "[FINALLY_BLOCK] ";
	
	public static final String SIGNATURE = "[SIGNATURE] ";

	public static final String TRUE = "True";

	public static final String FALSE = "False";

	public static final String SUCCESS = "success";

	public static final String APISTATUS_ERROR = "ERROR";

	public static final String APISTATUS_SUCCESS = "SUCCESS";

	public static final String ERROR = "error";

	public static final String ERROR_ = "ERROR_";
	
	public static final String COMPLETED = "COMPLETED";
	
	public static final String CONSENT_REJECTED = "CONSENT_REJECTED";
	
	public static final String REJECTED = "REJECTED";

	public static final String IN_PROGRESS = "in_progress";

	public static final String INPROGRESS = "In Progress";

	public static final String API_STATUS = "API_STATUS";

	public static final String API_RESPONSE = "API_RESPONSE";

	public static final String FULLY_DISBURSED = "LOAN_IS_FULLY_DISBURSED";

	public static final String DISBURSED = "DISBURSED";

	public static final int STATUS_CODE_400 = 400;

	public static final String CLIENT_ID = "client_id";

	public static final String SCOPE = "scope";

	public static final String GRANT_TYPE = "grant_type";

	public static final String AUTH_TOKEN = "auth-token";
	
	public static final String X_PERFIOS_CALLBACK_TYPE = "X-Perfios-Callback-Type";

	public static final String CREATED_BY = "system";

	public static final String FILED_ACC_ID = "accountId";

	public static final String FILED_ACCOUNT_ID = "account_id";

	public static final String FILED_TXN_ID = "txnId";

	public static final String FILED_APPLICATION_ID = "applicationId";

	public static final String FILED_LOAN_AMOUNT = "loanAmount";

	public static final String FILED_SALARIED = "salaried";

	public static final String FILED_COMPANY_NAME = "companyName";

	public static final String FILED_MOB_NO = "mobileNumber";

	public static final String FILED_PAN_NUM = "panNumber";

	public static final String FILED_PFOFILE_ID = "profileId";

	public static final String FILED_ACC_NUM = "accountNumber";

	public static final String FILED_IFSC_CODE = "IFSCCode";

	public static final String FILED_REQ_ID = "requestId";
	
	public static final String FILED_PERF_TXNID = "perfiosTransactionId";
	
	public static final String FILED_STATUS = "status";
	
	public static final String FILED_PROCESSING_TYPE = "processingType";

	public static final String FILED_EMPLOYER_NAME = "employerName";

	public static final String FILED_EMPLOYEE_NAME = "employeeName";

	public static final String FILED_MOBILE = "mobile";

	public static final String FILED_CONTACT = "contact";
	
	public static final String FILED_EMAIL = "email";

	public static final String FILED_METHOD = "method";
	
	public static final String FILED_TOKEN = "token";
	
	public static final String FILED_BANK_ACCOUNT = "bank_account";
	
	public static final String FILED_ACCOUNT_NUMBER = "account_number";
	
	public static final String FILED_BENE_NAME = "beneficiary_name";
	
	public static final String FILED_IFSC = "ifsc_code";
	
	public static final String UPI = "upi";
	
	public static final String EMANDATE = "emandate";
	
	public static final String FILED_CUSTOMER_ID = "customer_id";

	public static final String FILED_CUSTOMERID = "customerId";

	public static final String FILED_PAYMENT_ID = "pymentId";

	public static final String FILED_TOKEN_ID = "tokenId";

	public static final String FILED_RAZP_CUST_ID = "razorpayCustid";
	
	public static final String FILED_VPA = "vpa";

	public static final String X_API_KEY = "X_API_KEY";

	public static final String NETBANKING_FETCH = "NETBANKING_FETCH";

	public static final String INDIA = ", India";

	public static final String TRUE_STR = "TRUE";

	public static final String FALSE_STR = "FALSE";

	public static final String FILED_NAME = "name";

	public static final String FILED_FULL_NAME = "fullname";

	public static final String FILED_AA_AVAIL = "aa_available";

	public static final String FILED_NB_AVAIL = "netbanking_available";

	public static final String FILED_LOGO_URL = "logo_url";
	
	public static final String PROD = "PROD";
	
	public static final String LOCALE_MESSAGE_COUNTRYCODE = "IN";

	public static final String LOCALE_MESSAGE_ENGLISH = "en";
	
    public static final String FIELD_APPLICATION_ID = "applicationId";
	
	public static final String FIELD_EMAIL_ID = "email";
	
	public static final String FIELD_MOBILE_NUMBER = "mobileNumber";
	
	public static final String FIELD_MODE = "mode";
	
	public static final String FIELD_PURPOSE = "purpose";
	
	public static final String FIELD_OTP ="otp";
	
	public static final String ERROR_TYPE_BUSINESS = "Business Error";
	public static final String ERROR_TYPE_TECHNICAL = "Technical Error";

	public static final String VERIFIED = "VERIFIED";


}
