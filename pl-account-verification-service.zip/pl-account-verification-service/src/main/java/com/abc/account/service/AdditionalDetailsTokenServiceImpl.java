package com.abc.account.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.account.util.AdditionalDetailsErrorResponseUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
@Service
public class AdditionalDetailsTokenServiceImpl implements AdditionalDetailsTokenService {
	private final RestTemplate restTemplate;
	private final AdditionalDetailsErrorResponseUtil additionalDetailsErrorResponseUtil;

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${abfl.toke.grant_type}")
	private String grantType;

	@Value("${abfl.token.client_id}")
	private String clientId;

	@Value("${abfl.token.scope}")
	private String scope;

	@Value("${abfl.token.auth}")
	private String authToken;

	public ResponseEntity<Object> generateToken() throws Exception {
		log.info("Start of Generate Token Method in Token Service...");
		ResponseEntity<Object> responseEntity = null;
		UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl)
				.queryParam("client_id", clientId).queryParam("scope", scope)
				.queryParam("grant_type", grantType).build();
		log.debug("URI :: " + builder);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", "Basic " + authToken);
		HttpEntity<Object> request = new HttpEntity<>(headers);
		log.debug("HttpEntity :: " + request);

		try {
			responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request, Object.class);
			log.debug("Response of Token :: " + responseEntity.toString());
			return responseEntity;
		} catch (HttpStatusCodeException ex) {
			log.error("ERROR :: " + ex.getMessage());
			return new ResponseEntity<>(additionalDetailsErrorResponseUtil.internalServerErrorPartnerResponse(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}