package com.abc.account.response;

import lombok.Data;

@Data

public class TransactionLink {

	private String expires;
	private String perfiosTransactionId;
	private String url;

}
