package com.abc.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.request.InteractiveLinkRequest;
import com.abc.account.request.TxnCompleteCallbackRequest;
import com.abc.account.service.PLPerfiosService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.API + Constants.ONE_APP_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION
		+ Constants.PERSONAL_LOAN + Constants.PERFIOS)

public class PLPerfiosController extends BaseController {

	@Autowired
	private PLPerfiosService perfiosService;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	/**
	 * Retrieves institution data based on the specified data source and processing type.
	 * Utilizes Perfios APIs to fetch institution information, handles authentication,
	 * and processes the response to return a {@link ResponseEntity} containing success
	 * details or error information.
	 *
	 * @param dataSource The data source for which institution information is requested.
	 * @param processingType The processing type for which institution information is requested.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either
	 *         success details or error information based on the institution data retrieval.
	 */
	@GetMapping(LIST_INSTITUTIONS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	private ResponseEntity<Object> getInstitution(
			@RequestParam(value = "dataSource", required = true) String dataSource,
			@RequestParam(value = "processingType", required = true) String processingType) throws Exception {

		return perfiosService.getInstitution(dataSource, processingType);
	}

	/**
	 * Initiates the creation of an interactive link for ephemeral transaction based
	 * on the provided {@link InteractiveLinkRequest}.
	 *
	 * Validates the input request, constructs necessary headers and signature for
	 * authentication, makes an external API call to create the interactive link,
	 * and processes the response to return a {@link ResponseEntity} containing
	 * success details or error information.
	 *
	 * @param request The {@link InteractiveLinkRequest} object containing details
	 *                required for creating the interactive link.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing
	 *         either success details or error information based on the interactive
	 *         link creation operation.
	 */
	@PostMapping(CREATE_INTERACTIVE_LINK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	private ResponseEntity<Object> createInteractiveLink(@RequestBody InteractiveLinkRequest request) throws Exception {

		return perfiosService.createInteractiveLink(request);
	}

	/**
	 * Retrieves the transaction status for a given transaction ID from Perfios.
	 *
	 * Validates the input transaction ID, checks if the transaction status is already available
	 * in the database to avoid redundant API calls, constructs necessary headers and signature for
	 * authentication, makes an external API call to fetch the transaction status if necessary,
	 * and processes the response to return a {@link ResponseEntity} containing either success details
	 * or error information based on the transaction status retrieval operation.
	 *
	 * @param txnid The transaction ID for which the status needs to be retrieved.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either success details
	 *         or error information based on the transaction status retrieval operation.
	 */
	@GetMapping(IB_TRAN_STATUS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	private ResponseEntity<Object> getTransactionStatus(@PathVariable String txnid) {

		return perfiosService.getTransactionStatus(txnid);
	}

	/**
	 * Initiates the retrieval of reports for a given transaction ID from Perfios.
	 *
	 * Validates the input transaction ID, retrieves necessary authentication details and headers,
	 * makes an external API call to retrieve reports, and processes the response to return a
	 * {@link ResponseEntity} containing either success details or error information based on
	 * the report retrieval operation.
	 *
	 * @param txnid The transaction ID for which the reports need to be retrieved.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either success details
	 *         or error information based on the report retrieval operation.
	 */
	@GetMapping(RETRIVE_REPORT)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getRetrieveReport(@PathVariable String txnid) {

		return perfiosService.getRetrieveReport(txnid);
	}

	/**
	 * Handles the callback from Perfios indicating the completion of a transaction.
	 * Validates the callback type and request parameters, retrieves and updates the transaction status,
	 * and logs the callback details in the database.
	 *
	 * @param callbackType The type of callback received, should be "TRANSACTION_COMPLETE".
	 * @param request      The {@link TxnCompleteCallbackRequest} containing callback details.
	 * @return A {@link ResponseEntity} indicating the success or failure of processing the callback.
	 * @throws Exception If the request is invalid or if there are errors in processing.
	 */
	@PostMapping(TXN_COMPLETE_CALLBACK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	private ResponseEntity<Object> getTxnCompleteCallback(@RequestHeader(X_PERFIOS_CALLBACK_TYPE) String callbackType,
			@RequestBody TxnCompleteCallbackRequest request) throws Exception {

		return perfiosService.getTxnCompleteCallback(callbackType, request);
	}

}
