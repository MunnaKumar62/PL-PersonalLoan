package com.abc.account.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class EPFOError {

    private String code;
    private String errorType;
    private String description;
    private Boolean epfoCheck;
    private Boolean epfo_otp_required;
}