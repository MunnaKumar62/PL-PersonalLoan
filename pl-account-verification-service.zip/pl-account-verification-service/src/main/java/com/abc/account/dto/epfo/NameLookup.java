package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NameLookup {

	@JsonProperty("organizationName")
	public String organizationName;

	@JsonProperty("epfHistory")
	public List<EpfHistory> epfHistory;

	@JsonProperty("estInfo")
	public List<EstInfo> estInfo;

	@JsonProperty("matches")
	public List<Match> matches;

	@JsonProperty("isNameExact")
	public Boolean isNameExact;

	@JsonProperty("isEmployed")
	public Boolean isEmployed;

	@JsonProperty("isRecent")
	public Boolean isRecent;

	@JsonProperty("isNameUnique")
	public Boolean isNameUnique;

	@JsonProperty("employeeName")
	public String employeeName;
}
