package com.abc.account.util;

import java.util.Objects;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.http.HttpStatus;

import org.springframework.stereotype.Component;

import com.abc.account.constant.ExceptionConstant;
import com.abc.account.dto.PLCustomerDto;
import com.abc.account.entity.PLCustomerJsonEntity;
import com.abc.account.exception.UserException;
import com.abc.account.model.Error;
import com.abc.account.repo.PLCustomerJsonRepository;
import com.abc.account.repo.RedisCustomerRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CustomerManager {

	@Autowired
	private RedisCustomerRepository redisCustomerRepository;

	@Autowired
	private ObjectMapper objectMapper;

	Gson gsonResponse = new Gson();

	public static UserException generateCustomerException(Exception e, HttpStatus httpStatus) {
		e.printStackTrace();
		Error error = new Error();
		// error.setCode(e.getMessage());
		error.setMessage(e.getMessage());
		error.setError(httpStatus.name());
		return new UserException(error, httpStatus);
	}

	public void saveToCache(PLCustomerDto cusDto) {

		redisCustomerRepository.save(cusDto);

		System.out.println("plCustomerJson: ");
	}

	public PLCustomerDto getFromCache(String accountId) throws JsonMappingException, JsonProcessingException {
		
		return redisCustomerRepository.findByAccountId(accountId);

	}

}
