package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CombinedTransferFromToIGXn {
    @JsonProperty("slNo")
    private int slNo;

    @JsonProperty("date")
    private String date;

    @JsonProperty("chqNo")
    private String chqNo;

    @JsonProperty("narration")
    private String narration;

    @JsonProperty("amount")
    private double amount;

    @JsonProperty("category")
    private String category;

    @JsonProperty("balance")
    private double balance;

    @JsonProperty("bank")
    private String bank;

    @JsonProperty("accNo")
    private String accNo;

}