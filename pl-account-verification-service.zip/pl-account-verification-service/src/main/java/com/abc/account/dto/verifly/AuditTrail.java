package com.abc.account.dto.verifly;

import java.util.Date;

import lombok.Data;
@Data
public class AuditTrail{
    public String nature;
    public String value;
    public Date timestamp;
}
