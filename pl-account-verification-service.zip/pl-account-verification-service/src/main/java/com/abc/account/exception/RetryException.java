package com.abc.account.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class RetryException extends Exception {

	private static final long serialVersionUID = 1L;

	private String message;

	private Object obj;
}
