package com.abc.account.dto.plprefio;

import lombok.Data;

@Data
public class Institution{
    private int id;
    private String institutionType;
    private String name;
}
