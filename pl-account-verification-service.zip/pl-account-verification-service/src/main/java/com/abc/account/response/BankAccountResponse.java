package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class BankAccountResponse {

	 @JsonProperty("ifsc")
	 public String ifsc;

	 @JsonProperty("name")
	 public String name;
	 
	 @JsonProperty("bank_name")
	 public String bankName;
	 
	 @JsonProperty("account_type")
	 public String accountType;
	 
	 @JsonProperty("account_number")
	 public String accountNumber;
	 
	 @JsonProperty("beneficiary_email")
	 public String beneficiaryEmail;
	 
	 @JsonProperty("beneficiary_mobile")
	 public String beneficiaryMobile;
 
}
