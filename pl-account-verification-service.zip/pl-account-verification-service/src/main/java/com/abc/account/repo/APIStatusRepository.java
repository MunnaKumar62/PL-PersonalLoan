package com.abc.account.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.account.entity.ApiStatus;


@Repository
public interface APIStatusRepository extends JpaRepository<ApiStatus, Integer>,JpaSpecificationExecutor<ApiStatus> {
	
	ApiStatus findByApiNameAndCustomerIdAndAccountId(String apiName,int customerId,String accountId);
	
	@Query("SELECT a FROM ApiStatus a WHERE a.requestId=:requestId and a.apiName=:apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByRequestIdAndApiName(@Param("requestId")String requestId, @Param("apiName") String apiName);
	
	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	ApiStatus findByAccountIdAndApiNameAndActive(String accountId, String apiName, Boolean active);
	
	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	String findByResponseJsonAndApiNameAndActive(String accountId, String apiName, Boolean active);

	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' and a.requestId =:requestId and a.transactionId= :transactionId and a.active= :active order by a.id desc limit 1")
	String findPennyDropDetails(String accountId, String apiName, String requestId, String transactionId, Boolean active);
	
	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.apiName= :apiName and a.status ='SUCCESS' and a.requestId =:requestId and a.transactionId= :transactionId and a.active= :active order by a.id desc limit 1")
	String findTokenDetails(String apiName, String requestId, String transactionId, Boolean active);
	
	@Query("SELECT a FROM ApiStatus a WHERE a.transactionId =:transactionId and a.apiName= :apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	ApiStatus findByTransactionIdAndApiNameAndActive(String transactionId, String apiName, Boolean active);
	
	@Query("SELECT a.accountId FROM ApiStatus a WHERE a.transactionId =:transactionId and a.apiName= :apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	String findAccountIdByTransactionIdAndApiNameAndActive(String transactionId, String apiName, Boolean active);

	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.transactionId =:transactionId and a.apiName= :apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	String findResponseJsonByTransactionIdAndApiNameAndActive(String transactionId, String apiName, Boolean active);
	
	@Query("SELECT a.responseJson FROM ApiStatus a WHERE a.accountId =:accountId and a.requestId=:requestId and a.apiName=:apiName and a.status ='SUCCESS' and a.active= :active order by a.id desc limit 1")
	String findByRequestIdAndApiNameAndAccountId(String accountId, String requestId, String apiName, Boolean active);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId and a.apiName= :apiName and a.requestJson LIKE %:accountNo% and a.requestJson LIKE %:ifscCode% and a.active= :active order by a.id desc limit 1")
	ApiStatus findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndAccountNoAndIfscCodeAndActive(String accountId, String loanId, Long customerId, String apiName, String accountNo, String ifscCode, Boolean active);
}
