package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WhoisInfo {

	@JsonProperty("ageYear")
	public Double ageYear;

	@JsonProperty("creationDate")
	public String creationDate;

	@JsonProperty("expirationDate")
	public String expirationDate;

	@JsonProperty("updateDate")
	public String updateDate;

	@JsonProperty("expired")
	public Boolean expired;

	@JsonProperty("whoisEmailDomainMatch")
	public List<Object> whoisEmailDomainMatch;

	@JsonProperty("whoisEmailMatch")
	public List<Object> whoisEmailMatch;

	@JsonProperty("whoisIndvName")
	public List<Object> whoisIndvName;

	@JsonProperty("whoisOrgName")
	public List<WhoisOrgName> whoisOrgName;

}
