package com.abc.account.response;

import lombok.Data;

@Data
public class CustomerNotesResponse {

	private String note_key_1;
	private String note_key_2;

}
