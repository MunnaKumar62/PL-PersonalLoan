package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class IncomeXn{
    private double amountVariation;
    private double balance;
    private String mode;
    private String month;
    private double amount;
    private String chqNo;
    private String date;
    private String narration;
    private String category;

}
