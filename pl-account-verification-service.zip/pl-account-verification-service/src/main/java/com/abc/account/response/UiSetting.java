package com.abc.account.response;

import lombok.Data;

@Data
public class UiSetting {

	 private String labelsConfirmPassword;
	 private String labelsPassword;
	 private String labelsUserId;
	 private Boolean requiresSecondaryPassword;
}
