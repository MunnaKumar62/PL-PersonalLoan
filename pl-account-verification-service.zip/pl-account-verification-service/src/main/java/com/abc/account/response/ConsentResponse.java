package com.abc.account.response;

import lombok.Data;

@Data
public class ConsentResponse {

	private String responseStatus;
	private ConsentData data;
	
}
