package com.abc.account.response;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class VerifyData {
	public String status;

}
