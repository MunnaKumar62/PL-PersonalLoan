package com.abc.account.response;

import com.abc.account.dto.epfo.KarzaData;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class EPFOResponse {

	@JsonProperty("responseStatus")
	public String responseStatus;

	@JsonProperty("data")
	public KarzaData data;
}
