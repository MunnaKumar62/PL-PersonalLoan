package com.abc.account.response;

import lombok.Data;

@Data
public class InteractiveLinkReponse {

	private TransactionLink transactionLink;

}
