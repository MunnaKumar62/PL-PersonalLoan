package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class SummaryInfo{
    private String accNo;
    private Total total;
    private String instName;
    private int fullMonthCount;
    private Average average;
    private String accType;
}
