package com.abc.account.entity;

import java.time.LocalDate;
import java.util.Date;

import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "t_pl_customer_detail")
public class PLCustomerDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_detail_id")
	private Long customerDetailId;

	@Column(name = "accnt_create_date")
	private Date accntCreateDate;

	@Column(name = "accountid")
	private String accountId;

	@Column(name = "loan_id")
	private String loanId;

	@Column(name = "customer_id")
	private Long customerId;

	@Column(name = "applicationid")
	private String applicationId;

	@Column(name = "transactionid")
	private String transactionId;

	@Column(name = "cccid")
	private String cccId;

	@Column(name = "mobilenumber")
	private String mobilenumber;

	@Column(name = "credit_score")
	private String creditScore;

	@Column(name = "loan_purpose")
	private String loanPurpose;

	@Column(name = "firstname_lastname")
	private String firstnameLastname;

	@Column(name = "pannumber")
	private String pannumber;

	@Column(name = "date_of_birth")
	@Temporal(TemporalType.DATE)
	private LocalDate dateOfBirth;

	@Column(name = "gender")
	private String gender;

	@Column(name = "email")
	private String email;

	@Column(name = "work_email")
	private String workEmail;

	@Column(name = "workemail_added_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date workemailAddedDate;

	@Column(name = "breloan_amount")
	private Double breloanAmount;

	@Column(name = "breroi")
	private Double breroi;

	@Column(name = "bre_offertime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date breOffertime;

	@Column(name = "bre_reject_reason")
	private String breRejectReason;

	@Column(name = "ce_status")
	private String ceStatus;

	@Column(name = "bre2loan_amount")
	private Double bre2loanAmount;

	@Column(name = "bre2roi")
	private Double bre2roi;

	@Column(name = "bre2_offertime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date bre2Offertime;

	@Column(name = "bre2_reject_reason")
	private String bre2RejectReason;

	@Column(name = "ce_2_status")
	private String ce2Status;

	@Column(name = "emandate_status")
	private String emandateStatus;

	@Column(name = "eman_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date emanDatetime;

	@Column(name = "digilocker_consent")
	private String digilockerConsent;

	@Column(name = "digilocker_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digilockerConsentDatetime;

	@Column(name = "digilocker_status")
	private String digilockerStatus;

	@Column(name = "digilocker_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digilockerTime;

	@Column(name = "ukyc_status")
	private String ukycStatus;

	@Column(name = "ukyc_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ukycTime;

	@Column(name = "current_screen")
	private String currentScreen;

	@Column(name = "app_platform")
	private String appPlatform;

	@Column(name = "basic_consent")
	private String basicConsent;

	@Column(name = "basic_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date basicConsentDatetime;

	@Column(name = "bank_consent")
	private String bankConsent;

	@Column(name = "bank_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date bankConsentDatetime;

	@Column(name = "kyc_address_consent")
	private String kycAddressConsent;

	@Column(name = "kyc_address_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date kycAddressConsentDatetime;

	@Column(name = "ukyc_address_consent")
	private String ukycAddressConsent;

	@Column(name = "ukyc_address_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ukycAddressConsentDatetime;

	@Column(name = "bankaccount_id")
	private String bankaccountId;

	@Column(name = "pennydrop_status")
	private String pennydropStatus;

	@Column(name = "bank_detail_validation")
	private String bankDetailValidation;

	@Column(name = "docusign_consent")
	private String digisignConsent;

	@Column(name = "docusign_consent_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digisignConsentDatetime;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "a8_application_status")
	private String a8ApplicationStatus;

	@Column(name = "a8_callback_resp")
	private String a8CallbackResp;

	@Column(name = "a8_video_pd_status")
	private String a8VideoPdStatus;

	@Column(name = "a8_flg_upd_from")
	private String a8FlgUpdFrom;

	@Column(name = "a8_process_instance_id")
	private String a8ProcessInstanceId;

	@Column(name = "prev_a8_ce_status")
	private String prevA8CeStatus;

	@Column(name = "a8_fi_status")
	private String a8FiStatus;

	@Column(name = "a8_sanction_details")
	private String a8SanctionDetails;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	@UpdateTimestamp
	private Date modifiedDate;

	@Column(name = "salaried")
	private Boolean salaried;

	@Column(name = "self_employed")
	private Boolean selfEmployed;

	@Column(name = "loan_amount")
	private Double loanAmount;

	@Column(name = "monthly_income")
	private Double monthlyIncome;

	@Column(name = "work_address")
	private String workAddress;

	@Column(name = "tenure")
	private Integer tenure;

	@Column(name = "lead_id")
	private String leadId;

	@Column(name = "ukyc_init")
	private String ukycInit;

	@Column(name = "kyc_type")
	private String kycType;

	@Column(name = "ukyc_init_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ukycInitTime;

	@Column(name = "profileid")
	private String profileid;

	@Column(name = "income_verify_txnid")
	private String incomeVerifyTxnid;

	@Column(name = "ce_start")
	private String ceStart;

	@Column(name = "ce_start_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ceStartDatetime;

	@Column(name = "ce_2_start")
	private String ce2Start;

	@Column(name = "ce_2_start_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date ce2StartDatetime;

	@Column(name = "digilocker_start")
	private String digilockerStart;

	@Column(name = "digilocker_start_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date digilockerStartDatetime;

	@Column(name = "personal_details_complete")
	private String personalDetailsComplete;

	@Column(name = "personal_details_complete_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date personalDetailsCompleteDatetime;

	@Column(name = "work_details_status")
	private String workDetailsStatus;

	@Column(name = "work_details_status_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date workDetailsStatusDatetime;

	@Column(name = "contact_ref_complete")
	private String contactRefComplete;

	@Column(name = "contact_ref_complete_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date contactRefCompleteDatetime;

	@Column(name = "contact_ref_name1")
	private String contactRefName1;

	@Column(name = "contact_ref_name2")
	private String contactRefName2;

	@Column(name = "contact_ref_mob1")
	private String contactRefMob1;

	@Column(name = "contact_ref_mob2")
	private String contactRefMob2;

	@Column(name = "final_loan_complete")
	private String finalLoanComplete;

	@Column(name = "final_loan_complete_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date finalLoanCompleteDatetime;

	@Column(name = "epfocheck")
	private Boolean epfocheck;

	@Column(name = "epfo_otp_req")
	private Boolean epfo_otp_req;
}
