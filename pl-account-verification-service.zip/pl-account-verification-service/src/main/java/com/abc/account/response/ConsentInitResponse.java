package com.abc.account.response;

import com.abc.account.dto.aggregator.ConsentResData;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
public class ConsentInitResponse {

	@JsonProperty("responseStatus")
	private String responseStatus;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private ConsentResData data;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
