package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class EMILOANXn{
    private double balance;
    private double amount;
    private String chqNo;
    private String date;
    private String narration;
    private String category;
}
