package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UPI {

	@JsonProperty("vpa")
	private String vpa;
}
