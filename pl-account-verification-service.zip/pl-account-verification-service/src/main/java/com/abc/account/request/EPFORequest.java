package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class EPFORequest {

	@JsonProperty("employerName")
	public String employerName;

	@JsonProperty("employeeName")
	public String employeeName;

	@JsonProperty("mobile")
	public String mobile;

	@JsonProperty("emailId")
	public String emailId;

}
