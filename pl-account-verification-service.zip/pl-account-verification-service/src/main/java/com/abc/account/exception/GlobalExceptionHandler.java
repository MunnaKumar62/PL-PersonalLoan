package com.abc.account.exception;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.abc.account.constant.Constants;
import com.abc.account.response.FieldErrorResponse;
import com.abc.account.util.CommonUtil;
import com.abc.account.util.Message;

import io.micrometer.common.lang.Nullable;
import lombok.extern.log4j.Log4j2;

@RestControllerAdvice
@Log4j2
public class GlobalExceptionHandler {

	@Value("${spring.application.name}")
	private String sourceName;

	@Autowired
	private Message message;

	@Value("${api.service.code}")
	private String serviceCode;

	@Value("${external.errorcode.prefix}")
	private String externalErrorCodePrefix;

	@Value("${internal.errorcode.prefix}")
	private String internalErrorCodePrefix;

	@Value("${business.errorcode.prefix}")
	private String businessErrorCodePrefix;

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, List<String>>> handleValidationErrors(MethodArgumentNotValidException ex) {

		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(FieldError::getDefaultMessage)
				.collect(Collectors.toList());
		return new ResponseEntity<>(getErrorsMap(errors), new HttpHeaders(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CustomException.class)
	@Nullable
	public ResponseEntity<Object> customExceptionHandler(Exception ex) {
		HttpHeaders headers = new HttpHeaders();
		WebRequest request = null;
		FieldErrorResponse errorResponse = CommonUtil.getErrorResponse(ex, HttpStatus.PARTIAL_CONTENT, request);
		return new ResponseEntity<>(errorResponse, headers, HttpStatus.PARTIAL_CONTENT);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Map<String, List<String>>> handleGeneralExceptions(Exception ex) {
		List<String> errors = Collections.singletonList(ex.getMessage());
		return new ResponseEntity<>(getErrorsMap(errors), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(RuntimeException.class)
	public final ResponseEntity<Map<String, List<String>>> handleRuntimeExceptions(RuntimeException ex) {
		List<String> errors = Collections.singletonList(ex.getMessage());
		return new ResponseEntity<>(getErrorsMap(errors), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private Map<String, List<String>> getErrorsMap(List<String> errors) {
		Map<String, List<String>> errorResponse = new HashMap<>();
		errorResponse.put("errors", errors);
		return errorResponse;
	}

	@ResponseStatus(HttpStatus.PARTIAL_CONTENT)
	@ExceptionHandler(InternalException.class)
	public @ResponseBody ExceptionResponse handleInternalException(InternalException ex) {
		String errorCode = serviceCode + "-" + internalErrorCodePrefix + "-" + ex.getErrorCode();
		String errorMessage;
		if (ex.getErrorMessage() == null) {
			errorMessage = message.getMessage(ex.getErrorCode());

		} else {
			errorMessage = message.getMessage(ex.getErrorCode()) + ex.getErrorMessage();

		}
		log.info(errorMessage);
		String errorType;
		String[] errorMessageParts = errorMessage.split("-");
		if (errorMessageParts.length > 1) {
			errorType = errorMessageParts[0].equalsIgnoreCase("BE") ? Constants.ERROR_TYPE_BUSINESS
					: Constants.ERROR_TYPE_TECHNICAL;
			errorCode = errorMessageParts[0].equalsIgnoreCase("BE") ? serviceCode + "-" + businessErrorCodePrefix + "-" + ex.getErrorCode()
					: errorCode;
			errorMessage = errorMessageParts[1];
		} else {
			errorType = Constants.ERROR_TYPE_TECHNICAL;
		}
		log.info(errorMessageParts[0]);
		String fullErrorMessage = errorCode + ": " + errorMessage;
		log.error("Internal Error : "+fullErrorMessage);
		return ExceptionResponse.builder().code(null != ex.getCode() ? ex.getCode() : 500)
				.reason(null != ex.getReason() ? ex.getReason() : errorMessage).errorCode(errorCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(errorType).build();
	}

}
