package com.abc.account.service.biz;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.exception.InternalException;
import com.abc.account.request.EPFORequest;
import com.abc.account.request.EmployeeEpfoRequest;
import com.abc.account.request.SendOtpRequest;
import com.abc.account.request.VerifyOtpRequest;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class EPFOBizService implements Constants, MessageConstants {

	public EPFORequest validateEPFORequest(EPFORequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getEmployerName())) {
				msg = FILED_EMPLOYER_NAME + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getEmployeeName())) {
				msg = FILED_EMPLOYEE_NAME + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getMobile())) {
				msg = FILED_MOBILE + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info("Error due to "+msg);
			throw new InternalException("1000",msg);		}
		return request;
	}

	public SendOtpRequest validatesendotpRequest(SendOtpRequest request) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
	        if (StringUtils.isBlank(request.getApplicationId())) {
	            msg = FIELD_APPLICATION_ID + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getEmailId())) {
	            msg = FIELD_EMAIL_ID + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getMobileNumber())) {
	            msg = FIELD_MOBILE_NUMBER + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getMode())) {
	            msg = FIELD_MODE + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getPurpose())) {
	            msg = FIELD_PURPOSE + TILDA + EMPTY_FIELD;
	        }
	        else {
	            flag = Boolean.FALSE;
	        }
		}
		if (flag) {
			log.info("Error due to "+msg);
			throw new InternalException("1000",msg);		}
		return request;
	}
	
	public VerifyOtpRequest validateVerifyOtpRequest(VerifyOtpRequest request) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
	        if (StringUtils.isBlank(request.getApplicationId())) {
	            msg = FIELD_APPLICATION_ID + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getEmailId())) {
	            msg = FIELD_EMAIL_ID + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getMobileNumber())) {
	            msg = FIELD_MOBILE_NUMBER + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getMode())) {
	            msg = FIELD_MODE + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(request.getPurpose())) {
	            msg = FIELD_PURPOSE + TILDA + EMPTY_FIELD;
	        } else if (StringUtils.isBlank(String.valueOf(request.getOtp()))) {
	            msg = FIELD_OTP + TILDA + EMPTY_FIELD;
	        }
	        else {
	            flag = Boolean.FALSE;
	        }
		}
		if (flag) {
			log.info("Error due to "+msg);
			throw new InternalException("1000",msg);		}
		return request;
	}

	public EmployeeEpfoRequest validateEpfoVerificationRequest(EmployeeEpfoRequest request) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACCOUNT_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getEmployeeName())) {
				msg = FILED_NAME + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getMobile())) {
				msg = FIELD_MOBILE_NUMBER + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getEmployerName())) {
				msg = FILED_COMPANY_NAME + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info("Error due to "+msg);
			throw new InternalException("1000",msg);		}
		return request;
	}

}
