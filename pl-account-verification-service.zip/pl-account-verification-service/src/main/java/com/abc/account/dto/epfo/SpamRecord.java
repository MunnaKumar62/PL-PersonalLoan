package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SpamRecord {

	@JsonProperty("spamEmail")
	public Boolean spamEmail;

	@JsonProperty("reportCount")
	public Integer reportCount;

	@JsonProperty("ipBlacklist")
	public Boolean ipBlacklist;
}
