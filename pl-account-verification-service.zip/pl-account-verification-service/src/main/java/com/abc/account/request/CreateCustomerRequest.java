package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateCustomerRequest {

    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    @JsonProperty("accountid")
    private String accountId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("email")
    private String email;

    @JsonProperty("contact")
    private String contact;

    @JsonProperty("fail_existing")
    private String failExisting;

    @JsonProperty("notes")
    private CustomerNote notes;
}