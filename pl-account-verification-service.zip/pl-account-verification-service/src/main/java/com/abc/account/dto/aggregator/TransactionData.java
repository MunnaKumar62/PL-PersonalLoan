package com.abc.account.dto.aggregator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransactionData {

	@JsonProperty("status")
	private String status;
	
	@JsonProperty("success")
	private boolean success;
	
	@JsonProperty("accounts")
	private List<Account> accounts;
	
	@JsonProperty("errorCode")
	private String errorCode;
	
	@JsonProperty("txnId")
	private String txnId;
}
