package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PersonalInfo {

	@JsonProperty("name")
	private String name;

	@JsonProperty("pan")
	private String pan;

	@JsonProperty("email")
	private String email;

	@JsonProperty("address")
	private String address;

	@JsonProperty("mobile")
	private String mobile;

	@JsonProperty("landline")
	private String landline;

}
