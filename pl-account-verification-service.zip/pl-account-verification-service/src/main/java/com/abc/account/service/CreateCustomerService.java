package com.abc.account.service;

import org.springframework.http.ResponseEntity;

import com.abc.account.request.CreateCustomer;
import com.abc.account.request.CreateOrder;
import com.abc.account.request.VPARequest;

public interface CreateCustomerService {

	ResponseEntity<Object> createCustomer(CreateCustomer createCustomer);

	ResponseEntity<Object> createOrder(CreateOrder createOrder);

	ResponseEntity<Object> fetchTokenStatus(String paymentId, String customerId, String accountId, String loanId, Long abfCustomerId);

	ResponseEntity<Object> fetchTokenByPaymentId(String paymentId, String customerId, String accountId, String loanId, Long abfCustomerId);

	ResponseEntity<Object> fetchTokenByCustId(String paymentId, String customerId, String accountId, String loanId, Long abfCustomerId);

	ResponseEntity<Object> validateVPA(VPARequest vpaRequest);

	ResponseEntity<Object> fetchUPITokenStatus(String paymentId, String accountId, String loanId, Long customerId);

}
