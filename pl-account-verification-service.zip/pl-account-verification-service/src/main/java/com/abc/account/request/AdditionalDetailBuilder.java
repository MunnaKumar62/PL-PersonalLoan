package com.abc.account.request;

import lombok.Data;

@Data
public class AdditionalDetailBuilder {

    private String accountId;
    private String  tokenId;
    private String  orderId;
    private String  customerId;
    private String  tokenStatus;
}