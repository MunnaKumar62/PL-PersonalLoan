package com.abc.account.service;

import org.springframework.http.ResponseEntity;

import com.abc.account.request.AdditionalDetail;
import com.abc.account.request.AdditionalDetailsRequest;

public interface PLAdditionalDetailsService {
	public ResponseEntity<Object> sendAdditionalDetails(AdditionalDetailsRequest request) throws Exception;
	public ResponseEntity<Object> sendAdditionalDetail(AdditionalDetail additionalDetail) throws Exception;
}
