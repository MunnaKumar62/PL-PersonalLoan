package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class EODBalance{
    private double balance;
    private String date;
}