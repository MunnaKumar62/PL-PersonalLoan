package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class CombinedMonthlyDetail {
	private String startDate;
	private String monthName;

}
