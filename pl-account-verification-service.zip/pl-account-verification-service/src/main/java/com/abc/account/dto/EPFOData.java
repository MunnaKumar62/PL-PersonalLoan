package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@lombok.Data
@Builder
public class EPFOData {

    @JsonProperty("epfoCheck")
    private Boolean epfoCheck;

    @JsonProperty("epfo_otp_required")
    private Boolean epfo_otp_required;
}