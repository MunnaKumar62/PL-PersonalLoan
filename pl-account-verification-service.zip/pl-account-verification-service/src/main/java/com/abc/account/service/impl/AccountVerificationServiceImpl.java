package com.abc.account.service.impl;

import java.sql.Timestamp;
import java.util.*;

import com.abc.account.constant.ErrorConstant;
import com.abc.account.dto.*;
import com.abc.account.dto.Error;
import org.apache.commons.lang3.time.DateUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.entity.ApiStatus;
import com.abc.account.entity.BankAccountDetails;
import com.abc.account.entity.CustomerDetails;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.InternalException;
import com.abc.account.exception.RetryException;
import com.abc.account.model.RetryConfg;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.repo.BankAccountDetailsRepository;
import com.abc.account.request.ApiCommonRequest;
import com.abc.account.service.AccountVerificationService;
import com.abc.account.service.CustomerDetailsService;
import com.abc.account.service.PLCustomerDetailService;
import com.abc.account.service.TokenService;
import com.abc.account.service.biz.AccountVerificationBizService;
import com.abc.account.service.biz.CommonBizService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class AccountVerificationServiceImpl extends CommonBizService
        implements AccountVerificationService, Constants, MessageConstants {

    private final String className = "[" + this.getClass().getSimpleName() + "]";

    @Value("${abfl.pennydrop.url}")
    private String pennyDropUrl;

    @Value("${abfl.namematch.url}")
    private String nameMatchUrl;

    @Value("${abfl.ifsc.validation}")
    private String ifscValidationUrl;

    @Value("${pl.retry.namecheckdetails}")
    private String nameCheckRetryConfig;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    TokenService tokenService;

    @Autowired
    APIStatusRepository apiStatusRepository;

    @Autowired
    BankAccountDetailsRepository bankAccountDetailsRepo;

    @Autowired
    CustomerDetailsService customerDetailsService;

    @Autowired
    PLCustomerDetailService plCustomerDetailService;

    @Override
    public ResponseEntity<Object> initiatePennyDrop(BankAccountDetailsRequest request) {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

        PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
        ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
        AccountVerificationBizService bizService = new AccountVerificationBizService();
        PennyDropResponse pennyDropResponse = null;
        Object obj = null;
        boolean flag = Boolean.FALSE;
        try {
            /**
             * Input request validation
             */
            request = bizService.validatePennyDropRequest(request);

            BankAccountDetailsRequestBuilder bankAccountDetailsRequestBuilder = new BankAccountDetailsRequestBuilder();
            bankAccountDetailsRequestBuilder.setAccountHolderName(request.getAccountHolderName());
            bankAccountDetailsRequestBuilder.setBankBranch(request.getBankBranch());
            bankAccountDetailsRequestBuilder.setAccountNumber(request.getAccountNumber());
            bankAccountDetailsRequestBuilder.setBankName(request.getBankName());
            bankAccountDetailsRequestBuilder.setClientData(request.getClientData());
            bankAccountDetailsRequestBuilder.setIFSCCode(request.getIFSCCode());
            bankAccountDetailsRequestBuilder.setEmail(request.getEmail());
            bankAccountDetailsRequestBuilder.setBankConsent(request.getBankConsent());
            bankAccountDetailsRequestBuilder.setNameMatchType(request.getNameMatchType());
            bankAccountDetailsRequestBuilder.setAllowPartialMatch(request.isAllowPartialMatch());
            bankAccountDetailsRequestBuilder.setAccountId(request.getLoanId());
            ClientData clientData = new ClientData();
            clientData.setCaseId(request.getClientData().getCaseId());
            bankAccountDetailsRequestBuilder.setClientData(clientData);

            String accountId = request.getAccountId();
            String accountNum = request.getAccountNumber();
            String ifscCode = request.getIFSCCode();
            String bankConsent = null != request.getBankConsent() && "Y".equalsIgnoreCase(request.getBankConsent()) ? "Y" : "N";
            request.setBankConsent(null);
            bankAccountDetailsRequestBuilder.setBankConsent(request.getBankConsent());
            boolean maxRetryFlag = true;
            Date updatedDate;
            String responseStatus = "";
            JSONObject jsonObject = null;
            ApiStatus apiStatus = apiStatusRepository.findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndAccountNoAndIfscCodeAndActive(accountId, request.getLoanId(), request.getCustomerId(), "PENNY_DROP", accountNum, ifscCode, Boolean.FALSE);
            if(Objects.nonNull(apiStatus)) {
                jsonObject = new JSONObject(apiStatus.getResponseJson());
            }
            if (Objects.nonNull(jsonObject) &&
                    jsonObject.has("responseStatus") &&
                    !jsonObject.isNull("responseStatus")) {
                responseStatus = jsonObject.getString("responseStatus");
            }
            if (Objects.nonNull(apiStatus)
                    && apiStatus.getStatus().equalsIgnoreCase(Constants.APISTATUS_ERROR)
                    && responseStatus.equalsIgnoreCase(Constants.APISTATUS_ERROR)) {
                if (apiStatus.getResponseJson().contains(MessageConstants.MAX_RETRY_MESSAGE)) {
                    updatedDate = DateUtils.addHours(apiStatus.getCreatedDt(), 24);
                    if (apiStatus.getCreatedDt().before(updatedDate)) {
                        maxRetryFlag = false;
                        throw new InternalException("1009");
                    }
                }

            } else if (Objects.nonNull(apiStatus)
                        && apiStatus.getStatus().equalsIgnoreCase(Constants.APISTATUS_SUCCESS)
                        && responseStatus.equalsIgnoreCase(Constants.APISTATUS_SUCCESS)) {
                maxRetryFlag = false;
                pennyDropResponse = objectMapper.readValue(apiStatus.getResponseJson(), PennyDropResponse.class);
                obj = pennyDropResponse;
            }
            if (Boolean.TRUE.equals(maxRetryFlag)) {
                // If not present then call PENNY_DROP api
                apiResponse = callPennyDropApi(request, bankAccountDetailsRequestBuilder);

                if (validateResponse(apiResponse)) {
                    if (null != apiResponse && null != apiResponse.getBody()) {
                        pennyDropResponse = (PennyDropResponse) apiResponse.getBody();
                        if (null != pennyDropResponse
                                && SUCCESS.equalsIgnoreCase(pennyDropResponse.getResponseStatus())) {
                            flag = Boolean.TRUE;
                        }
                    }
                    obj = pennyDropResponse;
                } else {
                    obj = apiResponse.getBody();
                }
                if (flag) {
                    CustomerDetails customerDetails = customerDetailsService.findByAccountId(accountId);
                    if (null != customerDetails) {
                        plCustomerDetailDto.setBankaccountId(accountNum);
                        Long customerId = customerDetails.getCustomerId();
                        BankAccountDetails bankAccountDetail = null;
                        Optional<BankAccountDetails> bankAccountDetails = bankAccountDetailsRepo
                                .findByCustomerIdAndAccountIdAndLoanIdAndActive(customerId, request.getAccountId(), request.getLoanId(), Boolean.FALSE);

                        if (bankAccountDetails.isPresent()) {
                            bankAccountDetail = bankAccountDetails.get();
                        } else {
                            bankAccountDetail = new BankAccountDetails();
                        }
                        bankAccountDetail.setCustomerId(customerId);
                        bankAccountDetail.setAccountId(accountId);
                        bankAccountDetail.setLoanId(request.getLoanId());
                        bankAccountDetail.setCustomerId(request.getCustomerId());
                        bankAccountDetail.setAccountNumber(accountNum);
                        bankAccountDetail.setAccountName(request.getAccountHolderName());
                        bankAccountDetail.setIfscCode(ifscCode);
                        bankAccountDetail.setBankName(request.getBankName());
                        bankAccountDetailsRepo.save(bankAccountDetail);
                    }
                    //PL_JOURNEY_AUDIT
                    if (null != pennyDropResponse) {
                        plCustomerDetailDto.setAccountId(request.getAccountId());
                        plCustomerDetailDto.setLoanId(request.getLoanId());
                        plCustomerDetailDto.setCustomerId(request.getCustomerId());
                        plCustomerDetailDto.setPennydropStatus(SUCCESS.equalsIgnoreCase(pennyDropResponse.getResponseStatus()) ? "Y" : "N");
                        plCustomerDetailDto.setBankConsent(bankConsent);
                        plCustomerDetailDto.setBankConsentDatetime(new Timestamp(new Date().getTime()));
                        plCustomerDetailDto.setMobilenumber(customerDetails.getMobileNumber());
                        plCustomerDetailDto.setDateOfBirth(customerDetails.getDateOfBirth());
                        plCustomerDetailDto.setGender(customerDetails.getGender());
                        plCustomerDetailDto.setEmail(customerDetails.getEmailAddress());
                        plCustomerDetailDto.setCurrentScreen("Bank Account Verification Page");
                        plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
                    }
                }
            }
        } catch (InternalException e) {
            log.error("INTERNAL "+ "CODE " + e.getCode() + "ERROR CODE"  +e.getErrorCode());
            log.error(className + methodName + "INTERNAL" + EXCEPTION + "[" + e.getMessage() + "]");
            throw new InternalException(e.getErrorCode());
        } catch (Exception ex) {
            log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
        }

        return new ResponseEntity<>(obj, apiResponse.getStatusCode());
    }

    @Override
    public NameMatchResponse callNameCheckWithBank(NameMatchRequest namecheckRequest)
            throws RetryException, CustomException {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

        NameMatchResponse response = null;
        CommonBizService bizService = new CommonBizService();
        List<RetryConfg> configList = bizService.getRetryConfig(nameCheckRetryConfig);
        log.info(className + methodName + " Retry Configuration: " + nameCheckRetryConfig);
        for (RetryConfg confg : configList) {
            try {
                // External Api with Retry
                response = getNameCheckWithBankRetry(namecheckRequest, confg.getMaxAttempts(), confg.getDelay());
                // Stop processing
                if (null != response && !isEmptyOrNull(response.getResult())
                        && TRUE.equalsIgnoreCase(response.getResult())) {
                    break;
                }
            } catch (CustomException | RetryException | InternalException ex) {
                log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
            }
        }
        return response;
    }

    public NameMatchResponse getNameCheckWithBankRetry(NameMatchRequest namecheckRequest, int maxAttempts,
                                                       long backOffPeriod) throws RetryException, CustomException {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

        CommonBizService bizService = new CommonBizService();
        RetryTemplate retryTemplate = bizService.createRetryTemplate(maxAttempts, backOffPeriod);

        RetryCallback<NameMatchResponse, RetryException> retryCallback = context -> {
            // Call External Api
            ResponseEntity<Object> apiResponse = callNameCheckWithBankApi(namecheckRequest);

            NameMatchResponse response = (NameMatchResponse) apiResponse.getBody();
            log.info(className + methodName + " Count:: " + context.getRetryCount());

            if (null != response && !isEmptyOrNull(response.getResult()) && !TRUE.equalsIgnoreCase(response.getResult())
                    && !response.isMaxRetryExeeded()) {
                log.info(className + methodName + " Result: " + response.getResult() + "]");
                throw new RetryException(response.getResult(), response.getRequestId());

            } else {
                log.info(className + methodName + " ResponseStatus Changed To " + response.getResult());
            }

            return response;
        };

        RecoveryCallback<NameMatchResponse> recoveryCallback = context -> {
            log.info(className + methodName + " Recovery action taken");
            return new NameMatchResponse(FALSE);
        };

        return retryTemplate.execute(retryCallback, recoveryCallback);
    }

    public ResponseEntity<Object> getNameCheckWithBank(NameMatchRequest request) {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

        NameMatchResponse nameMatchResponse = null;
        ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
        ApiStatus apiStatus = null;
        String jsonResponse = null;
        Object obj = null;
        boolean flag = Boolean.FALSE;

        // Check whether NAME_CHECK exist in DB
        jsonResponse = apiStatusRepository.findByResponseJsonAndApiNameAndActive(request.getApplicationId(),
                PL_NAME_CHECK, Boolean.FALSE);
        if (!isEmptyOrNull(jsonResponse)) {
            log.info(className + methodName + " NAME_CHECK record is exist: " + jsonResponse);
            jsonResponse = null != apiStatus ? apiStatus.getResponseJson() : "";
            if (!isEmptyOrNull(jsonResponse)) {
                try {
                    nameMatchResponse = objectMapper.readValue(jsonResponse, NameMatchResponse.class);
                    if (null != nameMatchResponse && !TRUE.equalsIgnoreCase(nameMatchResponse.getResult())
                            && !nameMatchResponse.isMaxRetryExeeded()) {
                        flag = Boolean.TRUE;
                    }
                } catch (JsonProcessingException ex) {
                    log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
                }
            }
            obj = nameMatchResponse;
        } else {
            flag = Boolean.TRUE;
        }
        if (flag) {
            // Call NAME_CHECK Api
            apiResponse = callNameCheckWithBankApi(request);
            if (validateResponse(apiResponse)) {
                nameMatchResponse = (NameMatchResponse) apiResponse.getBody();
                obj = nameMatchResponse;
            } else {
                obj = apiResponse.getBody();
            }
        }

        return new ResponseEntity<>(obj, apiResponse.getStatusCode());
    }

    @SuppressWarnings("unchecked")
    @Override
    public ResponseEntity<Object> callPennyDropApi(BankAccountDetailsRequest request, BankAccountDetailsRequestBuilder bankAccountDetailsRequestBuilder) {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
        log.info(className + methodName + BEGIN);

        PennyDropResponse pennyDropResponse = null;
        ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
        Map<String, Object> map = null;
        AccountVerificationBizService bizService = new AccountVerificationBizService();
        Object obj = null;
        /**
         * Input request validation
         */
        request = bizService.validatePennyDropRequest(request);
        if (request != null) {
            /**
             * External API Call
             */
            ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_PENNY_DROP)
                    .accountId(request.getAccountId()).profileId(EMPTY).requestId(request.getAccountNumber())
                    .transactionId(request.getIFSCCode()).url(pennyDropUrl)
                    .requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
                    .request(bankAccountDetailsRequestBuilder).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

            map = callExternalApi(commonRequest, PennyDropResponse.class);

            if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
                apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
                if (validateResponse(apiResponse)) {
                    if (null != apiResponse && null != apiResponse.getBody()) {
                        pennyDropResponse = (PennyDropResponse) apiResponse.getBody();
                        if (null != pennyDropResponse && null != pennyDropResponse.getData() && null != map
                                && !map.isEmpty() && null != map.get(API_STATUS)) {
                            ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
                            updateApiStatus(customerDetailsService.findByAccountId(request.getAccountId()), apiStatus, request.getLoanId(), request.getCustomerId());
                        }
                    }
                    obj = pennyDropResponse;
                } else {
                    obj = apiResponse.getBody();
                }
            }
        }
        log.info(className + methodName + END);

        return new ResponseEntity<>(obj, apiResponse.getStatusCode());
    }

    @SuppressWarnings("unchecked")
    @Override
    public ResponseEntity<Object> callNameCheckWithBankApi(NameMatchRequest request) {
        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
        log.info(className + methodName + BEGIN);

        PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
        ApiStatus apiStatus = null;
        NameMatchResponse nameMatchResponse = null;
        ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
        Map<String, Object> map = null;
        AccountVerificationBizService bizService = new AccountVerificationBizService();
        Object obj = null;
        /**
         * Input request validation
         */
        request = bizService.validateNameCheckRequest(request);

        if (request != null) {
            /**
             * External API Call
             */
            NameMatchRequestBuilder nameMatchRequestBuilder = new NameMatchRequestBuilder();
            nameMatchRequestBuilder.setName2(request.getName2());
            nameMatchRequestBuilder.setName1(request.getName1());
            nameMatchRequestBuilder.setProduct(request.getProduct());
            nameMatchRequestBuilder.setTransactionId(request.getTransactionId());
            nameMatchRequestBuilder.setApplicationId(request.getLoanId());
            ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_NAME_CHECK)
                    .accountId(request.getApplicationId()).profileId(EMPTY).requestId(EMPTY)
                    .transactionId(request.getTransactionId()).url(nameMatchUrl)
                    .requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
                    .request(nameMatchRequestBuilder).active(Boolean.FALSE).isAudit(Boolean.TRUE).apiStatus(null).build();

            map = callExternalApi(commonRequest, NameMatchResponse.class);

            if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
                apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);

                if (validateResponse(apiResponse)) {
                    if (null != apiResponse && null != apiResponse.getBody()) {
                        nameMatchResponse = (NameMatchResponse) apiResponse.getBody();
                        //PL_JOURNEY_AUDIT
                        if (null != nameMatchResponse && null != nameMatchResponse.getResult()) {
                            plCustomerDetailDto.setAccountId(request.getApplicationId());
                            plCustomerDetailDto.setLoanId(request.getLoanId());
                            plCustomerDetailDto.setCustomerId(request.getCustomerId());
                            plCustomerDetailDto.setBankDetailValidation(TRUE.equalsIgnoreCase(nameMatchResponse.getResult()) ? "Y" : "N");
                            plCustomerDetailDto.setCurrentScreen("Bank Account Verification Page");
                            plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
                        }
                        if (null != nameMatchResponse && null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
                            apiStatus = (ApiStatus) map.get(API_STATUS);
                            try {
                                apiStatus.setResponseJson(objectMapper.writeValueAsString(nameMatchResponse));
                            } catch (JsonProcessingException ex) {
                                log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
                            }
                            updateApiStatus(customerDetailsService.findByAccountId(request.getApplicationId()),
                                    apiStatus, request.getLoanId(), request.getCustomerId());
                        }
                    }
                    obj = nameMatchResponse;
                } else {
                    obj = apiResponse.getBody();
                }
            }
        }
        log.info(className + methodName + END);

        return new ResponseEntity<>(obj, apiResponse.getStatusCode());
    }

    @SuppressWarnings("unchecked")
    @Override
    public ResponseEntity<Object> validateIfsc(String ifscCode) {

        String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
        log.info(className + methodName + BEGIN);

        IFSCResponse iFSCResponse = null;
        ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
        Map<String, Object> map = null;
        AccountVerificationBizService bizService = new AccountVerificationBizService();
        Object obj = null;
        /**
         * Input request validation
         */
        ifscCode = bizService.validateIfscRequest(ifscCode);
        IFSCRequest ifscReq = new IFSCRequest();
        ifscReq.setTask("ifscCode");
        Essentials essentials = new Essentials();
        essentials.setIfscCode(ifscCode);
        ifscReq.setEssentials(essentials);
        /**
         * External API Call
         */
        ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_IFSC_CHECK).accountId(EMPTY)
                .profileId(EMPTY).requestId(EMPTY).transactionId(ifscCode).url(ifscValidationUrl)
                .requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
                .request(ifscReq).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

        map = callExternalApi(commonRequest, IFSCResponse.class);

        if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
            apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
            if (validateResponse(apiResponse) && null != apiResponse && null != apiResponse.getBody()) {
                iFSCResponse = (IFSCResponse) apiResponse.getBody();

                obj = iFSCResponse;
            } else {
                obj = apiResponse.getBody();
            }
        }
        log.info(className + methodName + END);

        return new ResponseEntity<>(obj, apiResponse.getStatusCode());
    }

}
