package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Xn {
    @JsonProperty("date")
    private String date;

    @JsonProperty("chqNo")
    private String chqNo;

    @JsonProperty("narration")
    private String narration;

    @JsonProperty("amount")
    private double amount;

    @JsonProperty("category")
    private String category;

    @JsonProperty("balance")
    private double balance;

}
