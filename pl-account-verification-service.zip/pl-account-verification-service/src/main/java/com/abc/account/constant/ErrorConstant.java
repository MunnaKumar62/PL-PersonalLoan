package com.abc.account.constant;

public interface ErrorConstant {
	
	public final static String   RECORD_NOT_FOUND="Record not found for given : ";

	public final static String BAD_REQUEST="Bad Request";

	public final static String BAD_REQUEST_CODE="400";

}
