package com.abc.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.request.CreateCustomer;
import com.abc.account.request.CreateOrder;
import com.abc.account.request.VPARequest;
import com.abc.account.service.CreateCustomerService;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.API + Constants.ONE_APP_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION
		+ Constants.PERSONAL_LOAN + Constants.CUSTOMER)
public class CustomerController extends BaseController {

	@Autowired
	CreateCustomerService service;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	/**
	 * Creates a customer entity by sending a request to an external API.
	 * This method validates and processes a {@link CreateCustomer} request object,
	 * makes an external API call, and handles the response and status updates
	 * accordingly.
	 * @param createCustomer The {@link CreateCustomer} object containing the details of the customer to be created.
	 * @return A {@link ResponseEntity} wrapping the API response, typically indicating the success or failure
	 *         of the customer creation process.
	 * @throws Exception If there's an issue with the HTTP request or response, or during decryption.
	 */
	@PostMapping(CREATE_CUSTOMER)
	public ResponseEntity<Object> createCustomer(@RequestBody CreateCustomer createCustomer) {
		auditUrl();
		return service.createCustomer(createCustomer);
	}

	/**
	 * Creates an order by sending a request to an external API.
	 * This method validates and processes a {@link CreateOrder} request object,
	 * prepares the request payload based on the specified payment method (e.g., UPI or others),
	 * makes an external API call, and handles the response and status updates
	 * accordingly.
	 * 
	 * @param createOrder The {@link CreateOrder} object containing the details of the order to be created.
	 * @return A {@link ResponseEntity} wrapping the API response
	 * @throws Exception If there's an issue with the HTTP request or response
	 */
	@PostMapping(CREATE_ORDER)
	public ResponseEntity<Object> createOrder(@RequestBody CreateOrder createOrder) {
		auditUrl();
		return service.createOrder(createOrder);
	}

	/**
	 * Fetches the status of a token associated with a payment and customer ID.
	 * This method retrieves token information from external APIs based on the provided
	 * payment ID, customer ID, and account ID. It constructs a {@link TokensList} object
	 * containing details such as token status and ID, and returns it wrapped in a {@link ResponseEntity}.
	 * 
	 * @param paymentId The payment ID associated with the token.
	 * @param customerId The customer ID associated with the token.
	 * @param accountId The account ID used for fetching token information.
	 */
	@GetMapping(PAYMENTS)
	public ResponseEntity<Object> fetchTokenStatus(@RequestParam String paymentId, @RequestParam String customerId, @RequestParam String accountId, @RequestParam String loanId, @RequestParam Long abfCustomerId) {
		auditUrl();
		return service.fetchTokenStatus(paymentId, customerId, accountId, loanId, abfCustomerId);
	}
	
	/**
	 * Validates a Virtual Payment Address (VPA) by sending a request to an external API.
	 * This method validates and processes a {@link VPARequest} object,
	 * makes an external API call to validate the VPA, and handles the response
	 * accordingly.
	 * 
	 * @param vpaRequest The {@link VPARequest} object containing the VPA to be validated.
	 * @return A {@link ResponseEntity} wrapping the API response, typically indicating the success or failure
	 *         of the VPA validation process.
	 */
	@PostMapping(VALIDATE_VPA)
	public ResponseEntity<Object> validateVPA(@RequestBody VPARequest vpaRequest) {
		auditUrl();
		return service.validateVPA(vpaRequest);
	}
	
	/**
	 * Fetches the status of a UPI token associated with a payment ID.
	 * This method validates the payment ID, constructs an API request to fetch
	 * token information from an external API, and handles the response accordingly.
	 * 
	 * @param paymentId The payment ID associated with the UPI token.
	 * @param accountId The account ID used for fetching token information.
	 * @return A {@link ResponseEntity} wrapping the API response, typically indicating the success or failure
	 *         of the UPI token status retrieval process.
	 */
	@GetMapping(UPI_PAYMENTS)
	public ResponseEntity<Object> fetchUPITokenStatus(@RequestParam String paymentId
			, @RequestParam(required = false) String accountId
			, @RequestParam(required = true) String loanId
			, @RequestParam(required = true) Long customerId) {
		auditUrl();
		return service.fetchUPITokenStatus(paymentId, accountId, loanId, customerId);
	}
}
