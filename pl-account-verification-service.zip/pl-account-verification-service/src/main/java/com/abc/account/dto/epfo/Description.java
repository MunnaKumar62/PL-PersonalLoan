package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Description {

	@JsonProperty("karza_epf_history_employer")
	public List<Object> karzaEpfHistoryEmployer;
	@JsonProperty("karza_epf_history")
	public List<Object> karzaEpfHistory;
	@JsonProperty("karza_conditions")
	public KarzaConditions karzaConditions;
}
