package com.abc.account.util;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.WebRequest;

import com.abc.account.constant.Constants;
import com.abc.account.response.FieldError;
import com.abc.account.response.FieldErrorResponse;
import com.abc.account.response.SuccessResponse;

@Component
public class CommonUtil {

	public static SuccessResponse getSuccessResponse(String code, String message, Object data) {

		SuccessResponse successResponse = new SuccessResponse();
		successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.SUCCESS);
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}
	
	public static SuccessResponse getErrorResponse(Object data) {
		SuccessResponse successResponse = new SuccessResponse();
		successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.ERROR);
		successResponse.setData(data);
		return successResponse;
	}

	public static FieldErrorResponse getErrorResponse(Exception ex, HttpStatusCode status, WebRequest request) {
		List<FieldError> errorsList = new ArrayList<>();
		String[] arr = new String[2];
		String errorCode = "PL" + "2" + status.value();
		String msg = ex.getMessage();
		arr = null != msg && msg.contains(Constants.TILDA) ? msg.split(Constants.TILDA) : arr;

		String fieldName = !isNullorBlank(arr[0]) ? arr[0] : Constants.EMPTY;
		String message = !isNullorBlank(arr[1]) ? arr[1] : msg;
		String path = null != request ? request.getContextPath() : Constants.EMPTY;
		getErrorList(errorCode, fieldName, message, errorsList);

		return getErrorMessage(path, errorsList);
	}

	public static FieldErrorResponse getErrorMessage(String path, List<FieldError> errorList) {
		FieldErrorResponse errorMessage = new FieldErrorResponse();
		errorMessage.setTimestamp(LocalDateTime.now());
		errorMessage.setStatus(Constants.ERROR);
		errorMessage.setPath(path);
		errorMessage.setErrors(errorList);
		return errorMessage;
	}

	public static void getErrorList(String errorCode, String fieldName, String message, List<FieldError> errorList) {
		FieldError errors = new FieldError(errorCode, fieldName, message);
		errorList.add(errors);
	}

	public static boolean isNullorBlank(String str) {
		return (null == str || str.isBlank());
	}
	
	public static int getDifferenceDays(Date d1, Date d2) {
	    long diff = d2.getTime() - d1.getTime();
	    return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}
}
