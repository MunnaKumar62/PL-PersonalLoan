package com.abc.account.dto;

import lombok.Data;

@Data
public class IFSCError {
  IFSCStatus error;
}
