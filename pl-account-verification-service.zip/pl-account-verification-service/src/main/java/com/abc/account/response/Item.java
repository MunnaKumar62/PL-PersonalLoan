package com.abc.account.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Item {

	@JsonProperty("id")
	public String id;

	@JsonProperty("entity")
	public String entity;

	@JsonProperty("token")
	public String token;

	@JsonProperty("bank")
	public String bank;

	@JsonProperty("wallet")
	public Object wallet;

	@JsonProperty("method")
	public String method;

	@JsonProperty("recurring")
	public boolean recurring;

	@JsonProperty("recurring_details")
	public RecurringDetails recurringDetails;

	@JsonProperty("auth_type")
	public String authType;

	@JsonProperty("mrn")
	public Object mrn;

	@JsonProperty("used_at")
	public int usedAt;

	@JsonProperty("created_at")
	public int createdAt;

	@JsonProperty("bank_details")
	public BankDetails bankDetails;

	@JsonProperty("max_amount")
	public int maxAmount;

	@JsonProperty("expired_at")
	public Long expiredAt;

	@JsonProperty("notes")
	public List<Object> notes;

	@JsonProperty("error_description")
	public Object errorDescription;

	@JsonProperty("dcc_enabled")
	public boolean dccEnabled;
}
