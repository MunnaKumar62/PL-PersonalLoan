package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UanLookup {

	@JsonProperty("currentEmployer")
	public Object currentEmployer;

	@JsonProperty("matchScore")
	public Double matchScore;

	@JsonProperty("result")
	public Boolean result;

	@JsonProperty("uanNameMatch")
	public Boolean uanNameMatch;
}
