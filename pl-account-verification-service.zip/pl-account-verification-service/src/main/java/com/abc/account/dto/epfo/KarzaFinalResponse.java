package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KarzaFinalResponse {

	@JsonProperty("result")
	public Result result;

	@JsonProperty("request_id")
	public String requestId;

	@JsonProperty("status-code")
	public String statusCode;
}
