package com.abc.account.service;

import org.springframework.http.ResponseEntity;

import com.abc.account.constant.Constants;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.RetryException;
import com.abc.account.request.AAConsentCallbackRequest;
import com.abc.account.request.BreCallbackRequest;
import com.abc.account.request.BreRequest;
import com.abc.account.request.ConsentInitRequest;
import com.abc.account.request.PLBankRequest;
import com.abc.account.request.ReportGenerationCallbackRequest;
import com.abc.account.request.ReportGenerationRequest;
import com.abc.account.request.TransactionStatusRequest;
import com.abc.account.response.Bre2PollingResponse;

public interface AccountAggregatorService extends Constants {

	public ResponseEntity<Object> getFipList();

	public ResponseEntity<Object> bankList();

	public ResponseEntity<Object> addBank(PLBankRequest request);

	public ResponseEntity<Object> searchBankList(String input);

	public ResponseEntity<Object> consentInit(ConsentInitRequest request);

	public ResponseEntity<Object> getTransactionStatus(TransactionStatusRequest reportGenerationRequest);

	public ResponseEntity<Object> consentcallback(AAConsentCallbackRequest request);

	public ResponseEntity<Object> getReportGeneration(ReportGenerationRequest reportGenerationRequest);

	public ResponseEntity<Object> initiateBRE2(BreRequest breRequest);

	public ResponseEntity<Object> callBRE2Api(BreRequest breRequest);

	public ResponseEntity<Object> getBRE2PollingStatus(String accountId);

	public ResponseEntity<Object> callBRE2PollingApi(String accountId);

	public Bre2PollingResponse callBRE2PollingStatus(String accountId) throws RetryException, CustomException;

	public ResponseEntity<Object> callBRE2Callback(BreCallbackRequest breCallbackRequest);

	public ResponseEntity<Object> reportGenerationCallback(ReportGenerationCallbackRequest request);

}