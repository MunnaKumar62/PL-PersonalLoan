package com.abc.account.dto;

import lombok.Data;

@Data
public class IFSCResponse {
		 Essentials essentials;
		 private String id;
		 private String patronId;
		 private String task;
		 Result result;
}

