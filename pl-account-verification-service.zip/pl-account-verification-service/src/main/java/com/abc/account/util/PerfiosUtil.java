package com.abc.account.util;

import static java.lang.Integer.toHexString;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import org.bouncycastle.openssl.PEMReader;
import org.springframework.http.HttpMethod;

import com.abc.account.constant.Constants;
import com.abc.account.constant.PlPrefiosConstant;
import com.abc.account.constant.PrefiosPEMConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PerfiosUtil implements PlPrefiosConstant, PrefiosPEMConstant, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	public String getSHA256(String a) {
		return DigestUtils.sha256Hex(a);
	}

	public String encrypt(String raw, PrivateKey k, PublicKey k2) {
		String encoded = null;
		try {
			Signature privateSignature = Signature.getInstance(PlPrefiosConstant.ENCRYPTION_ALGO);
			privateSignature.initSign(k);
			privateSignature.update(raw.getBytes("UTF-8"));
			byte[] signature = privateSignature.sign();
			encoded = Hex.encodeHexString(signature);
			privateSignature.initVerify(k2);
			privateSignature.update(raw.getBytes("UTF-8"));
			privateSignature.verify(signature);
		} catch (Exception e) {
			log.error(className + "[encrypt]" + EXCEPTION + e.getMessage());
		}
		return encoded;
	}

	public PrivateKey buildPrivateKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PrivateKey pKey = null;
		try {
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPrivate();
		} catch (IOException i) {
			i.printStackTrace();
		}
		return pKey;
	}

	public PublicKey buildPublicKey(String privateKeySerialized) {
		StringReader reader = new StringReader(privateKeySerialized);
		PublicKey pKey = null;
		try {
			PEMReader pemReader = new PEMReader(reader);
			KeyPair keyPair = (KeyPair) pemReader.readObject();
			pKey = keyPair.getPublic();
		} catch (IOException i) {
			i.printStackTrace();
		}
		return pKey;
	}

	public String getCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();
		String time = dtf.format(now);
		return time.subSequence(0, 8) + "T" + time.subSequence(8, 14) + "Z";
	}

	private String uriEncode(final CharSequence input) {

		final StringBuilder result = new StringBuilder();
		for (int i = 0; i < input.length(); i++) {
			final char ch = input.charAt(i);
			if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_'
					|| ch == '-' || ch == '~' || ch == '.' || ch == '/') {
				result.append(ch);
			} else {
				result.append(toHexString(ch));
			}
		}
		return result.toString();
	}

	public String listInstitutionSignature(String URL, String payload, String xPerfiosDate, String dataSource,
			String processingType, String host, String perfEnv) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		String signature = null;
		try {
			String uriEncodedQuery = uriEncode(PARAM1) + "=" + uriEncode(dataSource) + "&" + uriEncode(PARAM2) + "="
					+ uriEncode(processingType);
			String sha256Payload = getSHA256(payload);
			String canonicalRequest = HttpMethod.GET + "\n"

					+ uriEncode(URL) + "\n"

					+ uriEncodedQuery + "\n"

					+ X_PERFIOS_SIGN_HOST_PARAM + host + "\n"

					+ X_PERFIOS_SIGN_CONTENT_SHA256_PARAM + sha256Payload + "\n"

					+ X_PERFIOS_SIGN_DATE_PARAM + xPerfiosDate + "\n"

					+ X_PERFIOS_CONTENT_DATE + "\n" + sha256Payload;

			String stringToSign = X_PERFIOS_RSA_SHA256 + "\n" + xPerfiosDate + "\n" + getSHA256(canonicalRequest);
			String checksum = getSHA256(stringToSign);
			String privateKey = !isEmptyOrNull(perfEnv) && PROD.equalsIgnoreCase(perfEnv) ? PROD_PRIVATE_KEY
					: UAT_PRIVATE_KEY;
			signature = encrypt(checksum, buildPrivateKey(privateKey), buildPublicKey(privateKey));
			log.error(className + methodName + SIGNATURE + signature);
		} catch (Exception e) {
			log.error(className + methodName + EXCEPTION + e.getMessage());
		}
		return signature;
	}

	public String craeteInteractiveLinkSignature(String url, String payload, String xPerfiosDate, String host,
			String perfEnv) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		String signature = null;
		try {
			String uriEncodedQuery = EMPTY;
			String sha256Payload = getSHA256(payload);
			String canonicalRequest = HttpMethod.POST + "\n"

					+ uriEncode(url) + "\n"

					+ uriEncodedQuery + "\n"

					+ X_PERFIOS_SIGN_HOST_PARAM + host + "\n"

					+ X_PERFIOS_SIGN_CONTENT_SHA256_PARAM + sha256Payload + "\n"

					+ X_PERFIOS_SIGN_DATE_PARAM + xPerfiosDate + "\n"

					+ X_PERFIOS_CONTENT_DATE + "\n" + sha256Payload;

			String stringToSign = X_PERFIOS_RSA_SHA256 + "\n" + xPerfiosDate + "\n" + getSHA256(canonicalRequest);
			String checksum = getSHA256(stringToSign);
			String privateKey = !isEmptyOrNull(perfEnv) && PROD.equalsIgnoreCase(perfEnv) ? PROD_PRIVATE_KEY
					: UAT_PRIVATE_KEY;
			signature = encrypt(checksum, buildPrivateKey(privateKey), buildPublicKey(privateKey));
			log.error(className + methodName + SIGNATURE + signature);
		} catch (Exception e) {
			log.error(className + methodName + EXCEPTION + e.getMessage());
		}
		return signature;
	}

	public String retrieveReportSignature(String url, String payload, String xPerfiosDate, String host,
			String perfEnv) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		String signature = null;
		try {
			String uriEncodedQuery = uriEncode(QUERY_PARAM) + "=" + uriEncode(REPORT_FORMAT);
			String sha256Payload = getSHA256(payload);
			String canonicalRequest = HttpMethod.GET + "\n"

					+ uriEncode(url) + "\n"

					+ uriEncodedQuery + "\n"

					+ X_PERFIOS_SIGN_HOST_PARAM + host + "\n"

					+ X_PERFIOS_SIGN_CONTENT_SHA256_PARAM + sha256Payload + "\n"

					+ X_PERFIOS_SIGN_DATE_PARAM + xPerfiosDate + "\n"

					+ X_PERFIOS_CONTENT_DATE + "\n" + sha256Payload;

			String stringToSign = X_PERFIOS_RSA_SHA256 + "\n" + xPerfiosDate + "\n" + getSHA256(canonicalRequest);
			String checksum = getSHA256(stringToSign);
			String privateKey = !isEmptyOrNull(perfEnv) && PROD.equalsIgnoreCase(perfEnv) ? PROD_PRIVATE_KEY
					: UAT_PRIVATE_KEY;
			signature = encrypt(checksum, buildPrivateKey(privateKey), buildPublicKey(privateKey));
			log.error(className + methodName + SIGNATURE + signature);
		} catch (Exception e) {
			log.error(className + methodName + EXCEPTION + e.getMessage());
		}
		return signature;
	}

	public String transactionStatusSignature(String url, String payload, String xPerfiosDate, String host,
			String perfEnv) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		String signature = null;
		try {
			String uriEncodedQuery = EMPTY;
			String sha256Payload = getSHA256(payload);
			String canonicalRequest = HttpMethod.GET + "\n"

					+ uriEncode(url) + "\n"

					+ uriEncodedQuery + "\n"

					+ X_PERFIOS_SIGN_HOST_PARAM + host + "\n"

					+ X_PERFIOS_SIGN_CONTENT_SHA256_PARAM + sha256Payload + "\n"

					+ X_PERFIOS_SIGN_DATE_PARAM + xPerfiosDate + "\n"

					+ X_PERFIOS_CONTENT_DATE + "\n" + sha256Payload;

			String stringToSign = X_PERFIOS_RSA_SHA256 + "\n" + xPerfiosDate + "\n" + getSHA256(canonicalRequest);
			String checksum = getSHA256(stringToSign);
			String privateKey = !isEmptyOrNull(perfEnv) && PROD.equalsIgnoreCase(perfEnv) ? PROD_PRIVATE_KEY
					: UAT_PRIVATE_KEY;
			signature = encrypt(checksum, buildPrivateKey(privateKey), buildPublicKey(privateKey));
			log.info(className + methodName + SIGNATURE + signature);
		} catch (Exception e) {
			log.error(className + methodName + EXCEPTION + e.getMessage());
		}
		return signature;
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
}