package com.abc.account.dto;

import lombok.Data;

@Data
public class Result {

	private String bankName;
	private String address;
	private String state;
	private String district;
	private String branch;
	private String contact;
	private String ifscCode;
	private String micrCode;
	SplitAddress splitAddress;
}
