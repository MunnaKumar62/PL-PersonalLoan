package com.abc.account.request;

import lombok.Data;

@Data
public class VerifyOtpRequest {
	private String applicationId;
	private String loanId;
	private Long customerId;
	private String emailId;
	private String mobileNumber;
	private String mode;
	private String purpose;
	private String otp;

}
