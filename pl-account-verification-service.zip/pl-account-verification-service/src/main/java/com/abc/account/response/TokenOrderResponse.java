package com.abc.account.response;

import com.abc.account.request.CustomerNote;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TokenOrderResponse {

     @JsonProperty("notes")
     public CustomerNote notes;

     @JsonProperty("method")
     public String method;
     
     @JsonProperty("currency")
     public String currency;
     
     @JsonProperty("auth_type")
     public String authType;
     
     @JsonProperty("expire_at")
     public String expireAt;
     
     @JsonProperty("max_amount")
     public int maxAmount;
     
     @JsonProperty("bank_account")
     public BankAccountResponse bankAccount;
    
}
