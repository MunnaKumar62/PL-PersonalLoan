package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class Total{
    private double totalSalary;
    private double balAvg;
    private int cashWithdrawals;
    private double totalOutwChqBounce;
    private int outwBounces;
    private double totalSamePartyDebitSelf;
    private int outwChqBounces;
    private int samePartyCreditsSelf;
    private int debitsSC;
    private double totalChqIssue;
    private int inwBounces;
    private double overdrawnAmount;
    private double totalDebitSelf;
    private int creditsSelf;
    private int overdrawnDays;
    private double bal10;
    private double totalInvIncome;
    private double totalCashDeposit;
    private double balMin;
    private int chqDeposits;
    private double dpLimit;
    private double totalPenalCharge;
    private int chqIssues;
    private double bal30;
    private int samePartyCreditsSC;
    private int samePartyDebitsSC;
    private double totalSamePartyCredit;
    private int emiEcsLoanIssues;
    private int samePartyDebits;
    private int creditsSC;
    private int debitsSelf;
    private int inwBounceNonTechnical;
    private double bal15;
    private int samePartyDebitsSelf;
    private double totalOutwBounce;
    private double balMax;
    private double totalSamePartyCreditSelf;
    private double totalCreditSC;
    private double totalInwBounce;
    private double totalInwBounceNonTechnical;
    private int debits;
    private double totalSamePartyCreditSC;
    private int selfSisterUpiDebits;
    private int credits;
    private double bal5;
    private double totalCreditSelf;
    private double totalInwChqBounce;
    private double bal1;
    private int cashDeposits;
    private int inwEMIBounces;
    private double totalEmiEcsLoanIssue;
    private double totalEmiOrLoan;
    private double bal25;
    private double bal20;
    private double totalSamePartyDebitSC;
    private double totalInterestCharged;
    private double totalLoanDisbursal;
    private int intraDayClearedBouncesTechnical;
    private double totalCashWithdrawal;
    private double totalCredit;
    private int intraDayClearedBouncesNonTechnical;
    private int inwBounceTechnical;
    private int emiOrLoans;
    private double totalSamePartyDebit;
    private int inwChqBounces;
    private double snLimit;
    private int samePartyCredits;
    private double totalDebitSC;
    private double totalChqDeposit;
    private double totalDebit;
}


