package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class BankDetails {

	@JsonProperty("beneficiary_name")
	private String beneficiaryName;

	@JsonProperty("account_number")
	private String accountNumber;

	@JsonProperty("ifsc")
	private String ifsc;

	@JsonProperty("account_type")
	private String accountType;
}
