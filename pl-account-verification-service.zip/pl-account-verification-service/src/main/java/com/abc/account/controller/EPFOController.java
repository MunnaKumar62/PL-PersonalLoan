
package com.abc.account.controller;

import com.abc.account.request.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.service.EPFOService;
import com.abc.account.service.TokenService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@Tag(name = "EPFO Silent Check API")
@RequestMapping(Constants.API + Constants.VERSION + Constants.PERSONAL_LOAN + Constants.EPFO)
public class EPFOController extends BaseController {

	@Autowired
	private EPFOService epfoService;

	@Autowired
	private TokenService tokenService;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	/**
	 * Performs a silent check operation with EPFO Validates the input request,
	 * makes an external API call to EPFO, and processes the response to return a
	 * ResponseEntity containing either success or error response based on the API
	 * call outcome.
	 *
	 * @param request The {@link EPFORequest} object containing EPFO request
	 *                details.
	 * @param request The authentication token used for API request headers.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing
	 *         either success details or error information based on the EPFO API
	 *         response.
	 */
	@PostMapping(EPFO_SILENT_CHECK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getRawData(@RequestBody EPFORequest request) {
		auditUrl();
		return epfoService.epfoSilentCheck(request, tokenService.getAccessToken());
	}
	
	/**
	 * Initiates the process to send OTP (One-Time Password) using the provided
	 * {@link SendOtpRequest} and access token for authentication. Validates the
	 * input request, makes an external API call to send OTP, and processes the
	 * response to return a {@link ResponseEntity} containing either success details
	 * or error information based on the OTP sending operation.
	 *
	 * @param request     The {@link SendOtpRequest} object containing details
	 *                    required for OTP sending.
	 * @param request The authentication token used for API request headers.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing
	 *         either success details or error information based on the OTP sending
	 *         operation.
	 */
	@PostMapping(SEND_OTP_COMBINED)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getSendOtp(@RequestBody SendOtpRequest request) {
		auditUrl();
		return epfoService.getSendOtp(request, tokenService.getAccessToken());
	}

	/**
	 * Initiates the process to verify OTP (One-Time Password) using the provided
	 * {@link VerifyOtpRequest} and access token for authentication.
	 *
	 * Validates the input request, makes an external API call to verify OTP, and
	 * processes the response to return a {@link ResponseEntity} containing either
	 * success details or error information based on the OTP verification operation.
	 *
	 * @param request The {@link VerifyOtpRequest} object containing details
	 *                required for OTP verification.
	 * @param request The authentication token used for API request headers.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either
	 *         success details or error information based on the OTP verification operation.
	 */
	@PostMapping(VERIFY_OTP_COMBINED)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getVerifyOtp(@RequestBody VerifyOtpRequest request) {
		auditUrl();
		return epfoService.getVerifyOtp(request, tokenService.getAccessToken());
	}

	/**
	 * Initiates the process to verify employment details using the provided {@link EmployeeEpfoRequest}
	 * and access token for authentication.
	 *
	 * Validates the input request, makes an external API call to verify employment details,
	 * and processes the response to return a {@link ResponseEntity} containing either success details
	 * or error information based on the employment verification operation.
	 *
	 * @param request The {@link EmployeeEpfoRequest} object containing details required for employment verification.
	 * @param request The authentication token used for API request headers.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either success details
	 *         or error information based on the employment verification operation.
	 */
	@PostMapping(EMPLOYMENT_VERIFICATION)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getEpfoVerificationOtp(@RequestBody EmployeeEpfoRequest request) {
		auditUrl();
		return epfoService.getEpfoVerificationOtp(request, tokenService.getAccessToken());
	}

	/**
	 * Initiates the process to verify employment details using the provided {@link EmployeeEpfoRequest}
	 * and access token for authentication.
	 *
	 * Validates the input request, makes an external API call to verify employment details,
	 * and processes the response to return a {@link ResponseEntity} containing either success details
	 * or error information based on the employment verification operation.
	 *
	 * @param request The {@link EmployeeEpfoRequest} object containing details required for employment verification.
	 * @param request The authentication token used for API request headers.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either success details
	 *         or error information based on the employment verification operation.
	 */
	@PostMapping(EMPLOYMENT_VERIFICATION_ASYNC)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getEpfoVerificationASync(@RequestBody EmployeeEpfoRequest request) {
		auditUrl();
		return epfoService.getEpfoVerificationASync(request, tokenService.getAccessToken());
	}

	/**
	 * Initiates the process to verify employment details using the provided {@link EmployeeEpfoRequest}
	 * and access token for authentication.
	 *
	 * Validates the input request, makes an external API call to verify employment details,
	 * and processes the response to return a {@link ResponseEntity} containing either success details
	 * or error information based on the employment verification operation.
	 *
	 * @param request The {@link EmployeeEpfoRequest} object containing details required for employment verification.
	 * @param request The authentication token used for API request headers.
	 * @return A {@link ResponseEntity} with an {@link Object} response containing either success details
	 *         or error information based on the employment verification operation.
	 */
	@PostMapping(EPFO_POLLING_ASYNC)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getEpfoPollingApi(@RequestBody EpfoPollingRequest request) {
		auditUrl();
		return epfoService.getEpfoPollingApi(request, tokenService.getAccessToken());
	}
	
}
