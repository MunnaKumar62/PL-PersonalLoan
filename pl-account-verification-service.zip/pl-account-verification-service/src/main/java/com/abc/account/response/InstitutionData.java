package com.abc.account.response;

import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.Data;

@Data
public class InstitutionData {

	
       private String  id;
       private String institutionType;
       private String  name;
        private Boolean netBankingLinked;
        private  UiSetting uiSetting;
         
     
   }
	
	
	

