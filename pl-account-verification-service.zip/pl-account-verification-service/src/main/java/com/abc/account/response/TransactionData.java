package com.abc.account.response;

import java.util.List;

import lombok.Data;

@Data
public class TransactionData {

	private String status;
	private Boolean success;
	private List<Accounts> accounts;

	private String errorCode;
	private String txnId;

}
