package com.abc.account.dto.plprefio;

import lombok.Data;

@Data
public class SummaryInfo{
    public String accNo;
    public Total total;
    public String instName;
    public int fullMonthCount;
    public Average average;
    public String accType;
}