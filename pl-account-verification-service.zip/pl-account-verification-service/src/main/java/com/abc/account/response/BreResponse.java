package com.abc.account.response;

import com.abc.account.dto.bre.BreCallbackData;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BreResponse {
	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
