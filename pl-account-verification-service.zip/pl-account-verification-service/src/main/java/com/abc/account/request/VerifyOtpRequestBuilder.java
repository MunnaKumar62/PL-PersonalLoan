package com.abc.account.request;

import lombok.Data;

@Data
public class VerifyOtpRequestBuilder {
    private String applicationId;
    private String emailId;
    private String mobileNumber;
    private String mode;
    private String purpose;
    private String otp;
}