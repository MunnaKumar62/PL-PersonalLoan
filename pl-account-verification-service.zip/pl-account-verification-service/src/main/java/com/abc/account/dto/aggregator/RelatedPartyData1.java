package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RelatedPartyData1 {

	@JsonProperty("monthName")
	private String monthName;

	@JsonProperty("noOfDebits")
	private int noOfDebits;

	@JsonProperty("debits")
	private int debits;

	@JsonProperty("totalDebits")
	private int totalDebits;

	@JsonProperty("totalDebitsPercent")
	private int totalDebitsPercent;

	@JsonProperty("noOfCredits")
	private int noOfCredits;

	@JsonProperty("credits")
	private int credits;

	@JsonProperty("totalCredits")
	private int totalCredits;

	@JsonProperty("totalCreditsPercent")
	private int totalCreditsPercent;

	@JsonProperty("netDebitOrCredit")
	private int netDebitOrCredit;
}
