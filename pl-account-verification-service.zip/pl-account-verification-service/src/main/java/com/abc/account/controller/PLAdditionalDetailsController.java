package com.abc.account.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.request.AdditionalDetail;
import com.abc.account.request.AdditionalDetailsRequest;
import com.abc.account.service.PLAdditionalDetailsService;
import com.abc.account.service.PLAdditionalDetailsServiceImpl;
import com.abc.account.util.AdditionalDetailsErrorResponseUtil;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.API + Constants.VERSION + Constants.PL)
@Tag(name = "API's for Personal Loan - Additional work details")
@RequiredArgsConstructor
public class PLAdditionalDetailsController {
	private final PLAdditionalDetailsService additionalDetailsService;
	private final AdditionalDetailsErrorResponseUtil additionalDetailsErrorResponseUtil;
	
	/**
	 * Processes and sends additional details for a loan application. This method
	 * initiates the process by generating an access token, setting up HTTP headers,
	 * and making a POST request to the specified additional details URL. It updates
	 * the loan offer details based on the provided
	 * {@link AdditionalDetailsRequest}, saves the API status, and logs customer
	 * details for audit purposes. Upon successful processing, it returns a success
	 * response containing the status of the additional details submission.
	 * @param request The {@link AdditionalDetailsRequest} containing the additional
	 *                details to be processed.
	 * @return A {@link ResponseEntity} containing either a success response
	 *          or an error message if
	 *         processing fails.
	 */
	@Operation(summary = "API to Send Personal Loan - Additional work details.", description = "")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successfully Sent Personal Loan - Additional work details."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@PostMapping("/additionalWorkDetails")
	public ResponseEntity<Object> sendAdditionalDetails(@RequestBody AdditionalDetailsRequest request)
			throws Exception {
		log.info("Start of sendAdditionalDetails Method in Controller...");
		try {
			return additionalDetailsService.sendAdditionalDetails(request);

		} catch (Exception e) {
			log.error("ERROR :: " + e.getMessage());
			return new ResponseEntity<>(additionalDetailsErrorResponseUtil.internalServerErrorPartnerResponse(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	/**
	 * Processes and sends additional details for a customer. This method initiates
	 * the process by generating an access token, setting up HTTP headers, and
	 * making a POST request to the specified additional details URL using the
	 * provided {@link AdditionalDetail}. It captures the response status, updates
	 * customer details for audit purposes, and logs the API status in the database.
	 * Upon successful processing, it returns a success response
	 * containing the status of the
	 * additional details submission.
	 * @param additionalDetail The {@link AdditionalDetail} object containing the
	 *                         additional details to be processed.
	 * @return A {@link ResponseEntity} containing either a success response
	 *          or an error message if
	 *         processing fails.
	 * @throws Exception If there are errors in processing the additional details.
	 */
	@Operation(summary = "API to Send Personal Loan - Additional work details.", description = "")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successfully Sent Personal Loan - Additional work details."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@PostMapping("/additionalEmandateDetails")
	public ResponseEntity<Object> sendAdditionalDetail(@RequestBody AdditionalDetail additionalDetail)
			throws Exception {
		log.info("Start of sendAdditionalDetails Method in Controller...");
		try {
			return additionalDetailsService.sendAdditionalDetail(additionalDetail);

		} catch (Exception e) {
			log.error("ERROR :: " + e.getMessage());
			return new ResponseEntity<>(additionalDetailsErrorResponseUtil.internalServerErrorPartnerResponse(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
}
