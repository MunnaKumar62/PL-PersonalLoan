package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class NameMatchResponse {

	
	public NameMatchResponse(String result) {
		super();
		this.result = result;
	}

	@JsonProperty("Result")
	public String result;

	@JsonProperty("Cached")
	public boolean cached;

	@JsonProperty("Max Retry Exeeded")
	public boolean maxRetryExeeded;

	@JsonProperty("Request Id")
	public String requestId;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;

}
