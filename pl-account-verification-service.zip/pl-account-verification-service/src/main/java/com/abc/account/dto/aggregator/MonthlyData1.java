package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MonthlyData1 {

	@JsonProperty("monthName")
	private String monthName;

	@JsonProperty("creditsAsPerStmt")
	private int creditsAsPerStmt;

	@JsonProperty("totalCreditAsPerStmt")
	private int totalCreditAsPerStmt;

	@JsonProperty("debitsAsPerStmt")
	private int debitsAsPerStmt;

	@JsonProperty("totalDebitAsPerStmt")
	private int totalDebitAsPerStmt;

	@JsonProperty("avgEODBalOn5th15th25th")
	private double avgEODBalOn5th15th25th;

	@JsonProperty("avgEODBalOn5th10th15th20th25th30th")
	private double avgEODBalOn5th10th15th20th25th30th;

	@JsonProperty("utilizationOn5th")
	private int utilizationOn5th;

	@JsonProperty("utilizationOn10th")
	private int utilizationOn10th;

	@JsonProperty("utilizationOn15th")
	private int utilizationOn15th;

	@JsonProperty("utilizationOn20th")
	private int utilizationOn20th;

	@JsonProperty("utilizationOn25th")
	private int utilizationOn25th;

	@JsonProperty("utilizationOn30th")
	private int utilizationOn30th;

	@JsonProperty("avgUtilizationOn5th15th25th")
	private int avgUtilizationOn5th15th25th;

	@JsonProperty("avgUtilizationOn5th10th15th20th25th30th")
	private int avgUtilizationOn5th10th15th20th25th30th;

	@JsonProperty("limitUtilization")
	private int limitUtilization;

	@JsonProperty("creditSummation")
	private int creditSummation;

	@JsonProperty("creditSummationAfterDeduction")
	private int creditSummationAfterDeduction;

	@JsonProperty("debitSummationAfterDeduction")
	private int debitSummationAfterDeduction;

	@JsonProperty("avgOverdrawnAsPercentOfLimit")
	private int avgOverdrawnAsPercentOfLimit;

	@JsonProperty("peakUtilization")
	private int peakUtilization;

	@JsonProperty("creditsAfterDeduction")
	private int creditsAfterDeduction;

	@JsonProperty("totalCreditAfterDeduction")
	private int totalCreditAfterDeduction;

	@JsonProperty("debitsAfterDeduction")
	private int debitsAfterDeduction;

	@JsonProperty("totalDebitAfterDeduction")
	private int totalDebitAfterDeduction;

	@JsonProperty("avgOverdrawnAmount")
	private int avgOverdrawnAmount;

	@JsonProperty("inwPaymentReturn")
	private int inwPaymentReturn;

	@JsonProperty("outwChqReturn")
	private int outwChqReturn;

	@JsonProperty("businessCreditsValue")
	private int businessCreditsValue;

	@JsonProperty("nonBusinessCreditsValue")
	private int nonBusinessCreditsValue;

	@JsonProperty("techInwardBounces")
	private int techInwardBounces;

	@JsonProperty("nonTechInwardBounces")
	private int nonTechInwardBounces;

	@JsonProperty("inwardBouncePercent")
	private int inwardBouncePercent;

	@JsonProperty("sumOfLoanEMIPaid")
	private int sumOfLoanEMIPaid;

	@JsonProperty("countOfEMIPaid")
	private int countOfEMIPaid;

	@JsonProperty("outwardBouncePercent")
	private int outwardBouncePercent;

	@JsonProperty("cashWithdrawalCount")
	private int cashWithdrawalCount;

	@JsonProperty("cashWithdrawalAmount")
	private int cashWithdrawalAmount;

	@JsonProperty("cashWithdrawalPercent")
	private int cashWithdrawalPercent;

	@JsonProperty("emiBounceCount")
	private int emiBounceCount;

}
