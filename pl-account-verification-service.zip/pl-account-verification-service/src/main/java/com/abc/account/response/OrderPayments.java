package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class OrderPayments {

	@JsonProperty("count")
	public int count;

	@JsonProperty("entity")
	public String entity;

	@JsonProperty("items")
	private String[] items;

}
