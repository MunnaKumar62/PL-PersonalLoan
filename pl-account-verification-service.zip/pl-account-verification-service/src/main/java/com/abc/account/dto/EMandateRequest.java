package com.abc.account.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class EMandateRequest {
	
    @Schema(name="customer",example = "CustomerDetails")
	public EMandateRequestCustomer customer;
    
	@Builder.Default
	@Schema(name="type",example = "link")
	public String type="link";
	
	@Builder.Default
	@Schema(name="email_notify",example = "0")
	public int email_notify=0;
	
	@Builder.Default
	@NotEmpty(message = "Account ID cannot be Empty")
	@Schema(name="accountId",example = "UPSELLXXXXXXXXX")
	public String accountId="";
	
	@Builder.Default
	@Schema(name="sms_notify",example = "0")
	public int sms_notify=0;
	
	@Builder.Default
	@Schema(name="description",example = "ABFL")
	public String description="ABFL";
	
	@Builder.Default
	@Schema(name="currency",example = "INR")
	public String currency="INR";
	
	@Schema(name="amount",example = "0")
	public int amount;
	
	public SubscriptionRegistration subscription_registration;
	

}

