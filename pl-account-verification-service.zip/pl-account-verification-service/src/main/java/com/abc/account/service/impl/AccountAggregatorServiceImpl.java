package com.abc.account.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import com.abc.account.cache.BankCacheService;
import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.dto.PLBankDto;
import com.abc.account.dto.PLCustomerDetailDto;
import com.abc.account.dto.aggregator.FipData;
import com.abc.account.dto.aggregator.TransactionData;
import com.abc.account.dto.bre.BrePollingData;
import com.abc.account.dto.plprefio.Institution;
import com.abc.account.entity.ApiStatus;
import com.abc.account.entity.PLBank;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.InternalException;
import com.abc.account.exception.RetryException;
import com.abc.account.model.RetryConfg;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.repo.BankRepository;
import com.abc.account.request.AAConsentCallbackRequest;
import com.abc.account.request.ApiCommonRequest;
import com.abc.account.request.BreCallbackRequest;
import com.abc.account.request.BrePollingRequest;
import com.abc.account.request.BreRequest;
import com.abc.account.request.ConsentInitRequest;
import com.abc.account.request.PLBankRequest;
import com.abc.account.request.ReportGenerationCallbackRequest;
import com.abc.account.request.ReportGenerationRequest;
import com.abc.account.request.TransactionStatusRequest;
import com.abc.account.response.Bre2PollingResponse;
import com.abc.account.response.BreResponse;
import com.abc.account.response.ConsentInitResponse;
import com.abc.account.response.FipResponse;
import com.abc.account.response.InstitutionsResponse;
import com.abc.account.response.ReportGenerationResponse;
import com.abc.account.response.SuccessResponse;
import com.abc.account.response.TransactionStatusResponse;
import com.abc.account.service.AccountAggregatorService;
import com.abc.account.service.CustomerDetailsService;
import com.abc.account.service.PLCustomerDetailService;
import com.abc.account.service.PLPerfiosService;
import com.abc.account.service.TokenService;
import com.abc.account.service.biz.AccountAggregatorBizService;
import com.abc.account.service.biz.CommonBizService;
import com.abc.account.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AccountAggregatorServiceImpl extends CommonBizService
		implements AccountAggregatorService, Constants, MessageConstants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;
	
	@Value("${abfl.perfios.env}")
	private String perfEnv;

	@Autowired
	private BankCacheService bankCacheService;

	@Autowired
	CustomerDetailsService customerDetailsService;

	@Autowired
	PLCustomerDetailService plCustomerDetailService;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private APIStatusRepository apiStatusRespo;
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private PLPerfiosService PlperfiosService;

	@Autowired
	private BankRepository bankRepository;

	@Value("${abfl.reportgen.url}")
	private String reportGenUrl;

	@Value("${abfl.fiplist.url}")
	private String fipListUrl;

	@Value("${abfl.transaction.url}")
	private String transactionUrl;
	
	@Value("${abfl.consent.url}")
	private String consentUrl;
	
	@Value("${abfl.prod.reportgen.url}")
	private String prodReportGenUrl;

	@Value("${abfl.prod.fiplist.url}")
	private String prodFipListUrl;

	@Value("${abfl.prod.transaction.url}")
	private String prodTransactionUrl;

	@Value("${abfl.prod.consent.url}")
	private String prodConsentUrl;
	
	@Value("${abfl.bre2.url}")
	private String bre2Url;

	@Value("${abfl.creditdetails.url}")
	private String getCreditDetailsUrl;

	@Value("${pl.retry.bredetails}")
	private String breRetryConfig;

	@Value("${pl.banklist.refresh.days}")
	private String refreshDays;

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getFipList() {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL2103";
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		/**
		 * External API Call
		 */
		ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_FIP_LIST).accountId(EMPTY)
				.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(PROD.equals(perfEnv) ? prodFipListUrl : fipListUrl)
				.requestHeaders(getRequestHeaders(getTokenByEnv())).method(HttpMethod.POST)
				.request(new ReportGenerationRequest(EMPTY, EMPTY)).isAudit(Boolean.FALSE).build();

		map = callExternalApi(commonRequest, FipResponse.class);

		if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
			apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			if (validateResponse(apiResponse)) {
				obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
			} else {
				obj = CommonUtil.getErrorResponse(apiResponse.getBody());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> bankList() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		String code = "PL2107";
		Object obj = null;
		try {
			List<PLBank> list = bankRepository.findAll();
			// Check for Refresh
			refreshBankList(list);

			if (null == list || list.isEmpty()) {
				code = "PL2108";
			} else {
				list.sort(Comparator.comparing(PLBank::getFullName, Comparator.nullsLast(Comparator.naturalOrder())));
			}
			obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), list);

		} catch (Exception e) {
//			e.printStackTrace();
			log.error(e.getMessage());

		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	private void refreshBankList(List<PLBank> tmpList) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		boolean autoSync = Boolean.FALSE;
		int daysDiff = 0;
		try {
			if (!tmpList.isEmpty() && null != tmpList.get(0)) {
				if (null == tmpList.get(0).getModifiedDate()) {
					// Initial Refresh data, if Modified Date null
					autoSync = Boolean.TRUE;
				} else {
					// Refresh data if Modified Date >={xx} days
					daysDiff = CommonUtil.getDifferenceDays(tmpList.get(0).getModifiedDate(), new Date());
					log.info(className + "[refreshBankList]" + " DAYS_DIFF: " + daysDiff);
					int refreshDay = Integer.parseInt(refreshDays);
					autoSync = (daysDiff >= refreshDay) ? Boolean.TRUE : autoSync;
				}
			}
			if (autoSync) {
				// PLBankMap
				Map<String, PLBank> plBankMap = new LinkedHashMap<>();
				for (PLBank plBank : tmpList) {
					String fullName = plBank.getFullName().replace("\"", EMPTY).replace(INDIA, EMPTY).trim();
					plBankMap.put(fullName, plBank);
				}
				// Asynchronous call
				new Thread(() -> {
					List<PLBank> list = new ArrayList<>();

					Map<String, String> fipMap = new HashMap<>();
					Map<String, String> instMap = new HashMap<>();
					try {
						// FipMap - call Account Aggregator FiPList Api
						ResponseEntity<Object> fipResponseEntity = getFipList();
						SuccessResponse fipResponse = (SuccessResponse) fipResponseEntity.getBody();
						if (null != fipResponse && null != fipResponse.getData()) {
							FipResponse response = (FipResponse) fipResponse.getData();
							List<FipData> fipList = response.getData();
							for (FipData fipData : fipList) {
								fipMap.put(fipData.getName().replace(INDIA, EMPTY), fipData.getId());
							}
						}
						// instMap - call Perfios ListInstitutions Api
						ResponseEntity<Object> instResponseEntity = PlperfiosService.getInstitution(NETBANKING_FETCH,
								NETBANKING_FETCH);
						SuccessResponse instResponse = (SuccessResponse) instResponseEntity.getBody();
						if (null != instResponse && null != instResponse.getData()) {
							InstitutionsResponse response = (InstitutionsResponse) instResponse.getData();
							List<Institution> instList = response.getInstitutions().getInstitution();
							for (Institution institution : instList) {
								instMap.put(institution.getName().replace(INDIA, EMPTY),
										String.valueOf(institution.getId()));
							}
						}
						for (Map.Entry<String, PLBank> entry : plBankMap.entrySet()) {
							PLBank plBank = entry.getValue();
							if (!fipMap.isEmpty()) {
								String fipMapping = fipMap.get(entry.getKey());
								if (!isEmptyOrNull(fipMapping)) {
									plBank.setFipMapping(fipMapping);
									plBank.setAaAvailable(TRUE_STR);
								} else {
									plBank.setAaAvailable(FALSE_STR);
								}
							}
							if (!instMap.isEmpty()) {
								String netBankingAvailable = instMap.get(entry.getKey());
								if (!isEmptyOrNull(netBankingAvailable)) {
									plBank.setNetbankingMapping(netBankingAvailable);
									plBank.setNetbankingAvailable(TRUE_STR);
								} else {
									plBank.setNetbankingAvailable(FALSE_STR);
								}
							}
							if (plBank.getFullName().contains("\"")) {
								// one time activity
								plBank.setFullName(plBank.getFullName().replace("\"", EMPTY));
							}
							plBank.setModifiedBy(CREATED_BY);
							plBank.setModifiedDate(new Timestamp(new Date().getTime()));
							list.add(plBank);
						}
						log.info(className + methodName + "save");
						// Update t_pl_bank_list
						bankRepository.saveAll(list);
						log.info(className + methodName + "save");
					} catch (Exception ex) {
						//ex.printStackTrace();
						log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
					}
				}).start();
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}

	@Override
	public ResponseEntity<Object> addBank(PLBankRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		String code = "PL2110";
		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		Object obj = null;
		boolean flag = Boolean.FALSE;
		/**
		 * Input request validation
		 */
		request = bizService.validatePLBankRequest(request);
		try {
			if (request != null) {

				PLBank plBank = new PLBank();
				Optional<PLBank> plBank1 = bankRepository.findByName(request.getName());
				if (plBank1.isPresent()) {
					plBank.setBankId(plBank1.get().getBankId());
				}
				plBank.setName(request.getName());
				plBank.setFullName(request.getFullName());
				plBank.setAaAvailable(request.getAaAvailable());
				plBank.setNetbankingAvailable(request.getNetbankingAvailable());
				plBank.setLogoUrl(request.getLogoUrl());
				plBank.setTopPriorityBank(request.getTopPriorityBank());
				plBank.setFipMapping(request.getFipMapping());
				plBank.setNetbankingMapping(request.getNetbankingMapping());
				plBank.setModifiedBy(CREATED_BY);
				plBank.setModifiedDate(new Timestamp(new Date().getTime()));
				PLBank bank = bankRepository.save(plBank);
				if (null != bank) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), bank);
					flag = Boolean.TRUE;
				}
				if (!flag) {
					code = "PL2111";
					obj = CommonUtil.getErrorResponse(env.getProperty(code));
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
			log.error(e.getMessage());
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> searchBankList(String input) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		String code = "PL2107";
		Object obj = null;
		List<PLBankDto> list = new ArrayList<>();
		try {
			list = bizService.searchBankList(bankCacheService.getBankListFromCache(), input);
			if (null == list || list.isEmpty()) {
				code = "PL2108";
			}
			obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), list);

		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> consentInit(ConsentInitRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL2105";
		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		ConsentInitResponse response = null;
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateConsentInitRequest(request);
		if (request != null) {
			accountId = request.getApplicationId();
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_CONSENT_INIT).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(PROD.equals(perfEnv) ? prodConsentUrl : consentUrl)
					.requestHeaders(getRequestHeaders(getTokenByEnv())).method(HttpMethod.POST)
					.request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, ConsentInitResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
						if (null != apiResponse && null != apiResponse.getBody()) {
							response = (ConsentInitResponse) apiResponse.getBody();	
							// PL_JOURNEY_AUDIT
							if (null != response && null != response.getData()) {
									PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
									plCustomerDetailDto.setAccountId(accountId);
									plCustomerDetailDto.setIncomeVerifyTxnid(response.getData().getRequestId());
									plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
							}	
							apiStatus.setRequestId(
									null != response && null != response.getData() ? response.getData().getRequestId()
											: EMPTY);
						}
						updateApiStatus(customerDetailsService.findByAccountId(accountId)
								, apiStatus
								, ""
								, 0L);
					}
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getTransactionStatus(TransactionStatusRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL2104";
		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		boolean isApiCallReq = Boolean.TRUE;
		TransactionStatusResponse statusResponse = null;
		String responseJson = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateTransactionStatusRequest(request);
		if (request != null) {
			accountId = request.getAccountId();
			// Not applicable for external API
			request.setAccountId(null);
			responseJson = apiStatusRespo.findByRequestIdAndApiNameAndAccountId(accountId,
					request.getRequestId(), PL_AA_TXN_STATUS, Boolean.FALSE);
			try {
				// Do not call API if status is COMPLETED or CONSENT_REJECTED
				if (!isEmptyOrNull(responseJson)) {
					statusResponse = objectMapper.readValue(responseJson, TransactionStatusResponse.class);
					if (null != statusResponse && null != statusResponse.getData()
							&& !isEmptyOrNull(statusResponse.getData().getStatus())
							&& (COMPLETED.equals(statusResponse.getData().getStatus())
									|| CONSENT_REJECTED.equals(statusResponse.getData().getStatus()))) {
						isApiCallReq = Boolean.FALSE;
					}
				}
				if (isApiCallReq) {
					/**
					 * External API Call
					 */
					ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_AA_TXN_STATUS)
							.accountId(accountId).profileId(EMPTY).requestId(request.getRequestId())
							.transactionId(EMPTY).url(PROD.equals(perfEnv) ? prodTransactionUrl : transactionUrl)
							.requestHeaders(getRequestHeaders(getTokenByEnv())).method(HttpMethod.POST)
							.request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE).apiStatus(null).build();

					map = callExternalApi(commonRequest, TransactionStatusResponse.class);

					if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
						if (validateResponse(apiResponse)) {
							obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
						} else {
							obj = CommonUtil.getErrorResponse(apiResponse.getBody());
						}
					}
				} else {
					log.info(className + methodName + " Fetching Data From DB");
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), statusResponse);
				}
			} catch (JsonProcessingException ex) {
				log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	public ResponseEntity<Object> consentcallback(AAConsentCallbackRequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		String responseJsonObject1 = null;
		Object obj = null;
		final String code = "PL2109";

		if (null == request) {
			throw new InternalException("1000", EMPTY_REQUEST);
		} else if (isEmptyOrNull(request.getTxnId())) {
			throw new InternalException("1000", FILED_TXN_ID + TILDA + EMPTY_FIELD);
		} else {
			apiStatus = apiStatusRespo.findByRequestIdAndApiName(request.getTxnId(), PL_AA_TXN_STATUS);
			if (apiStatus == null) {
				throw new InternalException("1002");
			} else {
				try {
					requestJsonObject = objectMapper.writeValueAsString(request);
					log.info(className + methodName + "[API_REQUEST= " + requestJsonObject + "]");
					TransactionStatusResponse statusResponse = objectMapper.readValue(apiStatus.getResponseJson(),
							TransactionStatusResponse.class);
					TransactionData transactionData = statusResponse.getData();
					transactionData.setStatus(request.getConsentStatus());
					statusResponse.setData(transactionData);
					responseJsonObject1 = objectMapper.writeValueAsString(statusResponse);
					apiStatus.setResponseJson(responseJsonObject1);
					apiStatusRespo.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), null);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					log.info(className + methodName + "[API_RESPONSE= " + responseJsonObject + "]");
					saveApiResponse(ApiStatus.builder().apiName(PL_CONSENT_CALL_BACK)
							.accountId(apiStatus.getAccountId()).profileId(EMPTY).requestId(EMPTY)
							.transactionId(request.getTxnId()).requestJson(requestJsonObject).responseJson(responseJsonObject)
							.status(SUCCESS).httpStatusCode(HttpStatus.OK.value()).active(Boolean.FALSE).build(), null);
				} catch (JsonProcessingException ex) {
					log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
				}
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);

	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> getReportGeneration(ReportGenerationRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL2102";
		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateReportRequest(request);
		if (request != null) {
			accountId = request.getAccountId();
			// Not applicable for external API
			request.setAccountId(null);

			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_REPORT_GENERATION)
					.accountId(accountId).profileId(EMPTY).requestId(request.getRequestId()).transactionId(EMPTY)
					.url(PROD.equals(perfEnv) ? prodReportGenUrl : reportGenUrl).requestHeaders(getRequestHeaders(getTokenByEnv()))
					.method(HttpMethod.POST).request(request).active(false).isAudit(Boolean.TRUE).apiStatus(null)
					.build();

			map = callExternalApi(commonRequest, ReportGenerationResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), apiResponse.getBody());
				} else {
					obj = CommonUtil.getErrorResponse(apiResponse.getBody());
				}
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> initiateBRE2(BreRequest breRequest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		BreResponse breResponse = null;
		String jsonResponse = null;
		Object obj = null;
		boolean flag = Boolean.FALSE;
		try {
			/**
			 * Input request validation
			 */
			breRequest = bizService.validateBreRequest(breRequest);
			String accountId = breRequest.getApplicationId();

			// Get BRE2 api updated success record from t_pl_apistatus table
			jsonResponse = apiStatusRespo.findByResponseJsonAndApiNameAndActive(accountId, PL_BRE2,
					Boolean.FALSE);
			if (!isEmptyOrNull(jsonResponse)) {
				log.info(className + methodName + " BRE2 record is exist: " + jsonResponse);
				// If present and ResponseStatus is success then allow to call BRE2_POLLING
				breResponse = objectMapper.readValue(jsonResponse, BreResponse.class);
				if (null != breResponse && !isEmptyOrNull(breResponse.getResponseStatus())
						&& SUCCESS.equalsIgnoreCase(breResponse.getResponseStatus())) {
					// If present and ResponseStatus is success then call BRE2_POLLING method
					flag = Boolean.TRUE;
				}
				obj = breResponse;
			} else {
				// If not present then call BRE2 api
				apiResponse = callBRE2Api(breRequest);

				if (validateResponse(apiResponse)) {
					if (null != apiResponse && null != apiResponse.getBody()) {
						breResponse = (BreResponse) apiResponse.getBody();
						if (null != breResponse && SUCCESS.equalsIgnoreCase(breResponse.getResponseStatus())) {
							flag = Boolean.TRUE;
						}
					}
					obj = breResponse;
				} else {
					obj = apiResponse.getBody();
				}
			}
			if (flag) {
				new Thread(() -> {
					// Call BRE2_POLLING (DB/API)
					ResponseEntity<Object> apiResponse1 = getBRE2PollingStatus(accountId);
					try {
						if (validateResponse(apiResponse1)) {
							Bre2PollingResponse response = (Bre2PollingResponse) apiResponse1.getBody();
							if (null != response && null != response.getResponseStatus() && null != response.getData()
									&& !isEmptyOrNull(response.getData().getCe2Status())
									&& IN_PROGRESS.equalsIgnoreCase(response.getData().getCe2Status())) {

								log.info(className + methodName
										+ " Initiating Asynchronous call - BRE2_POLLING api with Retry ");
								// Asynchronous call - with Retry
								callBRE2PollingStatus(accountId);
							}
						}
					} catch (CustomException | RetryException e) {
						e.printStackTrace();
					}
				}).start();
			}
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callBRE2Api(BreRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		AccountAggregatorBizService bizService = new AccountAggregatorBizService();
		BreResponse breResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		String accountId = null;
		ApiStatus apiStatus = null;
		String responseJson = null;
		try {
			/**
			 * Input request validation
			 */
			request = bizService.validateBreRequest(request);
			if (request != null) {
				accountId = request.getApplicationId();
				// Request construct form api status table
				if (null == request.getPerfiosInputJson()) {
					boolean isAAReportExist = false;
					responseJson = apiStatusRespo.findByResponseJsonAndApiNameAndActive(accountId, PL_REPORT_GENERATION, Boolean.FALSE);
					if (!isEmptyOrNull(responseJson)) {
						ReportGenerationResponse reportResponse = objectMapper.readValue(responseJson, ReportGenerationResponse.class);
						if (null != reportResponse && null != reportResponse.getData()
								&& !isEmptyOrNull(reportResponse.getResponseStatus())
								&& SUCCESS.equalsIgnoreCase(reportResponse.getResponseStatus())) {
							request.setPerfiosInputJson(reportResponse.getData());
							isAAReportExist = true;
						}
					}
					if (!isAAReportExist) {
						responseJson = apiStatusRespo.findByResponseJsonAndApiNameAndActive(accountId, PL_RETRIVE_REPORT, Boolean.FALSE);
						if (!isEmptyOrNull(responseJson)) {
							Object reportResponse = objectMapper.readValue(responseJson, Object.class);
							if (null != reportResponse) {
								request.setPerfiosInputJson(reportResponse);
								isAAReportExist = true;
							}
						}
					}
					if (!isAAReportExist) {
//						throw new CustomException(AA_IB_DATA_NOTFOUND);
						throw new InternalException("1003");

					}
				}
				apiStatus = apiStatusRespo.findByAccountIdAndApiNameAndActive(accountId, PL_BRE2, Boolean.FALSE);
				/**
				 * External API Call
				 */
				ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_BRE2).accountId(accountId)
						.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(bre2Url)
						.requestHeaders(getRequestHeaders(tokenService.getAccessToken()))
						.method(HttpMethod.POST).request(request).active(Boolean.FALSE).isAudit(Boolean.TRUE)
						.apiStatus(apiStatus).build();

				map = callExternalApi(commonRequest, BreResponse.class);

				if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
					apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					if (validateResponse(apiResponse)) {
						if (null != apiResponse && null != apiResponse.getBody()) {
							breResponse = (BreResponse) apiResponse.getBody();
							// PL_JOURNEY_AUDIT
							if (null != breResponse) {
									PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
									plCustomerDetailDto.setAccountId(accountId);
									plCustomerDetailDto.setCe2Start("Y");
									plCustomerDetailDto.setCe2StartDatetime(new Timestamp(new Date().getTime()));
									plCustomerDetailDto.setCurrentScreen("Loan Offer Page");
									plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
							}
						}
						obj = breResponse;
					} else {
						obj = apiResponse.getBody();
					}
				}
			}
		} catch (JsonProcessingException ex) {
			//ex.printStackTrace();
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> getBRE2PollingStatus(String accountId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		Bre2PollingResponse bre2PollingResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		boolean flag = Boolean.FALSE;
		String responseJson = null;

		// Check whether BRE2_POLLING exist in DB
		responseJson = apiStatusRespo.findByResponseJsonAndApiNameAndActive(accountId,
				PL_BRE2_POLLING, Boolean.FALSE);
		if (!isEmptyOrNull(responseJson)) {
			log.info(className + methodName + " BRE2_POLLING record is exist: " + responseJson);
			if (!isEmptyOrNull(responseJson)) {
				try {
					bre2PollingResponse = objectMapper.readValue(responseJson, Bre2PollingResponse.class);
					if (null != bre2PollingResponse && null != bre2PollingResponse.getData()
							&& !isEmptyOrNull(bre2PollingResponse.getData().getCe2Status())
							&& IN_PROGRESS.equalsIgnoreCase(bre2PollingResponse.getData().getCe2Status())) {
						flag = Boolean.TRUE;
					}
				} catch (JsonProcessingException ex) {
					log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
				}
			}
			obj = bre2PollingResponse;
		} else {
			flag = Boolean.TRUE;
		}
		if (flag) {
			// Call BRE2_POLLING Api
			apiResponse = callBRE2PollingApi(accountId);
			if (validateResponse(apiResponse)) {
				bre2PollingResponse = (Bre2PollingResponse) apiResponse.getBody();
				obj = bre2PollingResponse;
			} else {
				obj = apiResponse.getBody();
			}
		}

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callBRE2PollingApi(String accountId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Bre2PollingResponse bre2PollingResponse = null;
		Object obj = null;
		Map<String, Object> map = null;
		BrePollingRequest brePollingRequest = BrePollingRequest.builder().accountId(accountId).build();
		/**
		 * External API Call
		 */
		ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_BRE2_POLLING).accountId(accountId)
				.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(getCreditDetailsUrl)
				.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
				.request(brePollingRequest).isAudit(Boolean.TRUE).build();

		map = callExternalApi(commonRequest, Bre2PollingResponse.class);

		if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
			apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			if (validateResponse(apiResponse)) {
				if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
					ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
					if (null != apiResponse && null != apiResponse.getBody()) {
						bre2PollingResponse = (Bre2PollingResponse) apiResponse.getBody();
						// PL_JOURNEY_AUDIT
						if (null != bre2PollingResponse && null != bre2PollingResponse.getData()) {
							try {
								PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
								plCustomerDetailDto.setAccountId(accountId);
								plCustomerDetailDto.setBre2roi(bre2PollingResponse.getData().getRoi());
								plCustomerDetailDto.setBre2loanAmount(bre2PollingResponse.getData().getApprovedLoanAmount());
								plCustomerDetailDto.setBre2Offertime(new Timestamp(new Date().getTime()));
								plCustomerDetailDto.setCurrentScreen("Loan Offer Page");
								if(!isEmptyOrNull(bre2PollingResponse.getData().getCe2CallbackMessage())) {
									plCustomerDetailDto.setBre2RejectReason(bre2PollingResponse.getData().getCe2CallbackMessage());	
								}
								plCustomerDetailDto.setCe2Status(bre2PollingResponse.getData().getCe2Status());
								plCustomerDetailDto.setA8ApplicationStatus(bre2PollingResponse.getData().getA8ApplicationStatus());
								plCustomerDetailDto.setA8CallbackResp(bre2PollingResponse.getData().getA8CallbackResp());
								plCustomerDetailDto.setA8VideoPdStatus(bre2PollingResponse.getData().getA8VideoPdStatus());
								plCustomerDetailDto.setA8FlgUpdFrom(bre2PollingResponse.getData().getA8FlgUpdFrom());
								plCustomerDetailDto.setA8ProcessInstanceId(bre2PollingResponse.getData().getA8ProcessInstanceId());
								plCustomerDetailDto.setPrevA8CeStatus(bre2PollingResponse.getData().getPrevA8CeStatus());
								plCustomerDetailDto.setA8FiStatus(bre2PollingResponse.getData().getA8FiStatus());
								if (null != bre2PollingResponse.getData().getA8SanctionDetails()) {
									String sanctionJson = objectMapper.writeValueAsString(bre2PollingResponse.getData().getA8SanctionDetails());
									plCustomerDetailDto.setA8SanctionDetails(sanctionJson);
								}
								plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);

								apiStatus.setRequestId(bre2PollingResponse.getData().getApplicationId());
								apiStatus.setTransactionId(bre2PollingResponse.getData().getCccId());
								updateApiStatus(customerDetailsService.findByAccountId(accountId), apiStatus, "", 0L);
								
							} catch (JsonProcessingException e) {
								e.printStackTrace();
							}
						}
					}
				}
				obj = bre2PollingResponse;
			} else {
				obj = apiResponse.getBody();
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public Bre2PollingResponse callBRE2PollingStatus(String accountId) throws RetryException, CustomException {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		Bre2PollingResponse response = null;
		CommonBizService bizService = new CommonBizService();
		List<RetryConfg> configList = bizService.getRetryConfig(breRetryConfig);
		log.info(className + methodName + " Retry Configuration: " + breRetryConfig);
		for (RetryConfg confg : configList) {
			try {
				// External Api with Retry
				response = getBRE2PollingStatusRetry(accountId, confg.getMaxAttempts(), confg.getDelay());
				// Stop processing
				if (null != response && null != response.getData()
						&& !Constants.IN_PROGRESS.equalsIgnoreCase(response.getData().getCe2Status())) {
					break;
				}
			} catch (CustomException | RetryException | InternalException ex) {
				log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			}
		}
		return response;
	}

	public Bre2PollingResponse getBRE2PollingStatusRetry(String accountId, int maxAttempts, long backOffPeriod)
			throws RetryException, CustomException {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		CommonBizService bizService = new CommonBizService();
		RetryTemplate retryTemplate = bizService.createRetryTemplate(maxAttempts, backOffPeriod);

		RetryCallback<Bre2PollingResponse, RetryException> retryCallback = context -> {
			// Call External Api
			ResponseEntity<Object> apiResponse = callBRE2PollingApi(accountId);

			Bre2PollingResponse response = (Bre2PollingResponse) apiResponse.getBody();
			log.info(className + methodName + " Count:: " + context.getRetryCount());

			if (response != null && (Constants.IN_PROGRESS.equalsIgnoreCase(response.getResponseStatus())
					|| (response.getData() != null
							&& Constants.IN_PROGRESS.equalsIgnoreCase(response.getData().getCe2Status())))) {
				log.info(className + methodName + " Ce_status: " + response.getData().getCe2Status() + "]");
				throw new RetryException(response.getResponseStatus(), response.getData());

			} else {
				String status = null != response && null != response.getData() ? response.getData().getCe2Status()
						: Constants.EMPTY;
				log.info(className + methodName + " Ce_status Changed from " + Constants.IN_PROGRESS + " To " + status);
			}

			return response;
		};

		RecoveryCallback<Bre2PollingResponse> recoveryCallback = context -> {
			log.info(className + methodName + " Recovery action taken");
			return new Bre2PollingResponse(Constants.IN_PROGRESS);
		};

		return retryTemplate.execute(retryCallback, recoveryCallback);

	}

	@Override
	public ResponseEntity<Object> callBRE2Callback(BreCallbackRequest breCallbackRequest) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		String responseJsonObject1 = null;
		Object obj = null;
		final String code = "PL2112";
		try {
			if (null == breCallbackRequest) {
				throw new InternalException("1008");
			} else if (null == breCallbackRequest.getData()
					|| isEmptyOrNull(breCallbackRequest.getData().getAccountId())) {
				throw new InternalException("1000"," "+FILED_ACCOUNT_ID + TILDA + EMPTY_FIELD);
			} else {
				String applicationId = breCallbackRequest.getData().getApplicationId();
				apiStatus = apiStatusRespo.findByRequestIdAndApiName(applicationId, PL_BRE2_POLLING);
				requestJsonObject = objectMapper.writeValueAsString(breCallbackRequest);
				if (apiStatus == null) {
					throw new InternalException("1002");
				} else {
					Bre2PollingResponse bre2PollingResponse = objectMapper.readValue(apiStatus.getResponseJson(),
							Bre2PollingResponse.class);
					BrePollingData brePollingData = bre2PollingResponse.getData();
					brePollingData.setCe2CallbackMessage(breCallbackRequest.getMessage());
					bre2PollingResponse.setData(brePollingData);
					responseJsonObject1 = objectMapper.writeValueAsString(bre2PollingResponse);
					apiStatus.setResponseJson(responseJsonObject1);
					apiStatusRespo.save(apiStatus);

					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), EMPTY);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_BRE2_CALLBACK)
							.accountId(breCallbackRequest.getData().getAccountId()).profileId(EMPTY).requestId(EMPTY)
							.transactionId(applicationId).requestJson(requestJsonObject)
							.responseJson(responseJsonObject).status(SUCCESS).httpStatusCode(HttpStatus.OK.value())
							.active(Boolean.FALSE).build(), null);

					// PL_JOURNEY_AUDIT
					if (null != bre2PollingResponse && null != bre2PollingResponse.getData()) {
						PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
						plCustomerDetailDto.setAccountId(breCallbackRequest.getData().getAccountId());
						plCustomerDetailDto.setBre2RejectReason(breCallbackRequest.getMessage());
						plCustomerDetailDto.setCe2Status(bre2PollingResponse.getData().getCe2Status());
						plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
					}
				}
			}
			log.info(className + methodName + END);

		} catch (JsonProcessingException ex) {
			//ex.printStackTrace();
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> reportGenerationCallback(ReportGenerationCallbackRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		String responseJsonObject1 = null;
		Object obj = null;
		final String code = "PL2113";

		if (null == request) {
			throw new InternalException("1008");
		} else if (isEmptyOrNull(request.getTxnId())) {
			throw new InternalException("1000", " " + FILED_TXN_ID + TILDA + EMPTY_FIELD);
		} else {
			apiStatus = apiStatusRespo.findByRequestIdAndApiName(request.getTxnId(), PL_AA_TXN_STATUS);
			if (apiStatus == null) {
				throw new InternalException("1002");
			} else {
				try {
					requestJsonObject = objectMapper.writeValueAsString(request);
					TransactionStatusResponse statusResponse = objectMapper.readValue(apiStatus.getResponseJson(),
							TransactionStatusResponse.class);
					TransactionData transactionData = statusResponse.getData();
					transactionData.setStatus(request.getStatus());
					statusResponse.setData(transactionData);
					responseJsonObject1 = objectMapper.writeValueAsString(statusResponse);
					apiStatus.setResponseJson(responseJsonObject1);
					apiStatusRespo.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), null);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_REPORT_GENERATION_CALL_BACK)
							.accountId(apiStatus.getAccountId()).profileId(EMPTY).requestId(EMPTY)
							.transactionId(request.getTxnId()).requestJson(requestJsonObject).responseJson(responseJsonObject)
							.status(SUCCESS).httpStatusCode(HttpStatus.OK.value()).active(Boolean.FALSE).build(), null);
				} catch (JsonProcessingException ex) {
					log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
				}
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	public String getTokenByEnv() {

		String token = null;
		if (null != perfEnv && PROD.equals(perfEnv)) {
			token = tokenService.getProdAccessToken();
		} else {
			token = tokenService.getAccessToken();
		}
		return token;
	}
}
