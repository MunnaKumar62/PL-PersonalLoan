package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class MonthlyData1 {
    @JsonProperty("monthName")
    private String monthName;

    @JsonProperty("creditsAsPerStmt")
    private double creditsAsPerStmt;

    @JsonProperty("totalCreditAsPerStmt")
    private double totalCreditAsPerStmt;

    @JsonProperty("debitsAsPerStmt")
    private double debitsAsPerStmt;

    @JsonProperty("totalDebitAsPerStmt")
    private double totalDebitAsPerStmt;

    @JsonProperty("avgEODBalOn5th15th25th")
    private double avgEODBalOn5th15th25th;

    @JsonProperty("avgEODBalOn5th10th15th20th25th30th")
    private double avgEODBalOn5th10th15th20th25th30th;

    @JsonProperty("utilizationOn5th")
    private double utilizationOn5th;

    @JsonProperty("utilizationOn10th")
    private double utilizationOn10th;

    @JsonProperty("utilizationOn15th")
    private double utilizationOn15th;

    @JsonProperty("utilizationOn20th")
    private double utilizationOn20th;

    @JsonProperty("utilizationOn25th")
    private double utilizationOn25th;

    @JsonProperty("utilizationOn30th")
    private double utilizationOn30th;

    @JsonProperty("avgUtilizationOn5th15th25th")
    private double avgUtilizationOn5th15th25th;

    @JsonProperty("avgUtilizationOn5th10th15th20th25th30th")
    private double avgUtilizationOn5th10th15th20th25th30th;

    @JsonProperty("limitUtilization")
    private double limitUtilization;

    @JsonProperty("creditSummation")
    private double creditSummation;

    @JsonProperty("creditSummationAfterDeduction")
    private double creditSummationAfterDeduction;

    @JsonProperty("debitSummationAfterDeduction")
    private double debitSummationAfterDeduction;

    @JsonProperty("avgOverdrawnAsPercentOfLimit")
    private double avgOverdrawnAsPercentOfLimit;

    @JsonProperty("peakUtilization")
    private double peakUtilization;

    @JsonProperty("creditsAfterDeduction")
    private double creditsAfterDeduction;

    @JsonProperty("totalCreditAfterDeduction")
    private double totalCreditAfterDeduction;

    @JsonProperty("debitsAfterDeduction")
    private double debitsAfterDeduction;

    @JsonProperty("totalDebitAfterDeduction")
    private double totalDebitAfterDeduction;

    @JsonProperty("avgOverdrawnAmount")
    private double avgOverdrawnAmount;

    @JsonProperty("inwPaymentReturn")
    private double inwPaymentReturn;

    @JsonProperty("outwChqReturn")
    private double outwChqReturn;

    @JsonProperty("businessCreditsValue")
    private double businessCreditsValue;

    @JsonProperty("nonBusinessCreditsValue")
    private double nonBusinessCreditsValue;

    @JsonProperty("techInwardBounces")
    private int techInwardBounces;

    @JsonProperty("nonTechInwardBounces")
    private int nonTechInwardBounces;

    @JsonProperty("inwardBouncePercent")
    private double inwardBouncePercent;

    @JsonProperty("sumOfLoanEMIPaid")
    private double sumOfLoanEMIPaid;

    @JsonProperty("countOfEMIPaid")
    private int countOfEMIPaid;

    @JsonProperty("outwardBouncePercent")
    private double outwardBouncePercent;

    @JsonProperty("cashWithdrawalCount")
    private int cashWithdrawalCount;

    @JsonProperty("cashWithdrawalAmount")
    private double cashWithdrawalAmount;

    @JsonProperty("cashWithdrawalPercent")
    private double cashWithdrawalPercent;

    @JsonProperty("emiBounceCount")
    private int emiBounceCount;

}