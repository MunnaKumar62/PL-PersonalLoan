package com.abc.account.service;

import org.springframework.http.ResponseEntity;

public interface AdditionalDetailsTokenService {

	ResponseEntity<Object> generateToken() throws Exception;
}
