package com.abc.account.dto.bre;

import java.util.List;

import lombok.Data;

@Data
public class AccountAnalysis{
    private List<Top10PaymentsmadeMonthwise> top10PaymentsmadeMonthwise;
    private List<MonthlyDetail> monthlyDetails;
    private List<Top10PaymentsReceivedMonthwise> top10PaymentsReceivedMonthwise;
    private SummaryInfo summaryInfo;
    private String accountType;
    private EmiEcsLoanDatesDetail emiEcsLoanDetails;
    private List<EMILOANXn> eMILOANXns;
    private PersonalInfo personalInfo;
    private List<EODBalance> eODBalances;
    private Income income;
    private List<SalaryXn> salaryXns;
    private String accountNo;
}