package com.abc.account.service;

import com.abc.account.dto.BankAccountDetailsRequestBuilder;
import org.springframework.http.ResponseEntity;

import com.abc.account.dto.BankAccountDetailsRequest;
import com.abc.account.dto.NameMatchRequest;
import com.abc.account.dto.NameMatchResponse;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.RetryException;

public interface AccountVerificationService {

	public ResponseEntity<Object> initiatePennyDrop(BankAccountDetailsRequest bankAccountDetails);

	public ResponseEntity<Object> callPennyDropApi(BankAccountDetailsRequest request, BankAccountDetailsRequestBuilder bankAccountDetailsRequestBuilder);

	public ResponseEntity<Object> getNameCheckWithBank(NameMatchRequest request);

	public NameMatchResponse callNameCheckWithBank(NameMatchRequest namecheckRequest)
			throws RetryException, CustomException;

	public ResponseEntity<Object> callNameCheckWithBankApi(NameMatchRequest request);

	public ResponseEntity<Object> validateIfsc(String ifscCode);

}
