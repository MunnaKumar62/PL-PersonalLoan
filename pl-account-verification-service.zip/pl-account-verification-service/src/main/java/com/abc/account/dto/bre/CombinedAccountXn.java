package com.abc.account.dto.bre;

import lombok.Data;
@Data
public class CombinedAccountXn {
	private String bank;
	private String accNo;
	private double balance;
	private int slNo;
	private double amount;
	private String narration;
	private String date;
	private String chqNo;
	private String category;

}
