package com.abc.account.dto.aggregator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountXns {

	@JsonProperty("accountNo")
	private String accountNo;

	@JsonProperty("accountType")
	private String accountType;

	@JsonProperty("ifscCode")
	private String ifscCode;

	@JsonProperty("micrCode")
	private String micrCode;

	@JsonProperty("location")
	private String location;

	@JsonProperty("xns")
	private List<Xns> xns;

}
