package com.abc.account.response;

import lombok.Data;

@Data
public class TransactionResponse {

	private String responseStatus;

	private TransactionData data;

}
