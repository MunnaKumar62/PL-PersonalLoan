package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class IncomeSummary{
    private int totalMonthsWithIncome;
    private int maxDateVariation;
    private String latestMonth;
    private int monthsWithNoSalary;
    private int amountVariationMonths;
    private int totalMonths;
    private String amountVariationPresent;
    private int dateVariationMonths;
    private String dateVariationPresent;
    private int impsCreditsCount;
    private double maxAmountVariation;
    private int monthsWithSalary;
}