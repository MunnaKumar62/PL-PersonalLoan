package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CombinedMonthlyDetail {
    @JsonProperty("monthName")
    private String monthName;

    @JsonProperty("startDate")
    private String startDate;

}