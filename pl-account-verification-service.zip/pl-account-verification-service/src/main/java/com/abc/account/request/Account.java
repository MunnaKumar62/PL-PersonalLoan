package com.abc.account.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString

public class Account {
	    private String fiType;
	    private String fipId;
	    private String accType;
	    private String linkRefNumber;
	    private String maskedAccNumber;
	    private String status;
}
