package com.abc.account.dto.plprefio;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AccountAnalysis {
    @JsonProperty("accountNo")
    private String accountNo;

    @JsonProperty("accountType")
    private String accountType;

    @JsonProperty("personalInfo")
    private PersonalInfo personalInfo;

    @JsonProperty("summaryInfo")
    private SummaryInfo summaryInfo;

    @JsonProperty("monthlyDetails")
    private List<MonthlyDetail> monthlyDetails;

    @JsonProperty("eODBalances")
    private List<EODBalance> eODBalances;

    @JsonProperty("salaryXns")
    private List<SalaryXn> salaryXns;

}