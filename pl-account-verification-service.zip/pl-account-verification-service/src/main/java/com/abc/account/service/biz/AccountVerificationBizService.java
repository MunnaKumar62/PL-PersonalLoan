package com.abc.account.service.biz;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.dto.BankAccountDetailsRequest;
import com.abc.account.dto.NameMatchRequest;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.InternalException;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class AccountVerificationBizService implements Constants, MessageConstants {

	public BankAccountDetailsRequest validatePennyDropRequest(BankAccountDetailsRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getAccountNumber())) {
				msg = FILED_ACC_NUM + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getIFSCCode())) {
				msg = FILED_IFSC_CODE + TILDA + EMPTY_FIELD;
			}else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
			}
		return request;
	}
	
	public NameMatchRequest validateNameCheckRequest(NameMatchRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getApplicationId())) {
				msg = FILED_APPLICATION_ID + TILDA + EMPTY_FIELD;
			}else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);		}
		return request;
	}

	public String validateIfscRequest(String ifscCode) {

		String msg = EMPTY;
		boolean flag = Boolean.TRUE;
		if (isEmptyOrNull(ifscCode)) {
			msg = FILED_IFSC_CODE + TILDA + EMPTY_PARAM;
		} else {
			flag = Boolean.FALSE;
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);		}
		return ifscCode;
	}
	
	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}

}