package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Email {

	@JsonProperty("additionalInfo")
	public AdditionalInfo additionalInfo;

	@JsonProperty("data")
	public EmailData data;

	@JsonProperty("result")
	public Boolean result;
}
