package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VPARequest {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("accountid")
	private String accountId;
	
	@JsonProperty("vpa")
	private String vpa;

	@JsonProperty("loanId")
	private String loanId;

	@JsonProperty("customerId")
	private Long customerId;
}
