package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransactionStatusRequest {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("accountId")
	private String accountId;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("requestId")
	private String requestId;

}
