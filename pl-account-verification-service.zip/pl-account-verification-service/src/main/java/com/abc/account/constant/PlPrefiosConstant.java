package com.abc.account.constant;

public interface PlPrefiosConstant {

	public static final String vendor = "adityaBirlaDigital"; 

	public static final String Server = "https://demo.perfios.com";

	public static final String Host = "demo.perfios.com";

	public static final String ENCRYPTION_ALGO = "SHA256withRSA/PSS";

	public static final String privateKey = "-----BEGIN RSA PRIVATE KEY-----\r\n"
			+ "MIIJKAIBAAKCAgEAu67PbZAlubM0iEv3YCd39Y/Tiz8KfRmBRRrO8bDvlMKtEF20\r\n"
			+ "DLUxbD+PLRt7elsvpPGfOXN+izTAxcY3CV5Mipxn/JLCM7jbnzcDvC87f6ncu3t5\r\n"
			+ "TUlcvfigI4JKPhDx9H06jUKZYm6JDRsT2qt+1Yp8og2qP5GGR+3Ay5ARVojJaY/l\r\n"
			+ "vbHoH+B/XYqqU9lthR9iIHh41wdnI00qHQuhCOjG9SISSyS9FebOxvLYDLxaoBb/\r\n"
			+ "hxsYxz9YJgMNtPaXuEnSpUOaQLmgDyXECZrVCUmfOSUy7Y55X3CYDJM/WVdMT9ma\r\n"
			+ "EbFWxj0S8T93gkgkC+qi7IY5M9PZGz7JaJBHiNIlWejjn3TpWoqIAFwxj+IZGmgI\r\n"
			+ "f1CC9sZfeUdpf3EQT+mEzmuSwZ6TtPg831l3Xf8yOc/0pWrBc9n9JLLmmDRxghFI\r\n"
			+ "9ZnbCyupqSS/FMrB06gd/8yyLCUfgeuuDFSLXiLqY7HOyXOeMARugWrtn+l3RPZ9\r\n"
			+ "1VUMl8osa1hD3vIgJD4zI7bzzyxFLVHH1sEzraLX/ZSeMZZIQBceDk3WTrypIJCj\r\n"
			+ "0JfGbg9i9sXJ8EppHfCwLj1TEsDmglqHDraXx3cLflYwPh762IstGp7wSJhfvhdg\r\n"
			+ "kPti6txH1X2x5O1aqYFL+oDBbDJOc518YNgMBxJjyw8vXml9pWRh4JsFg7ECAwEA\r\n"
			+ "AQKCAgAjeNougICI1QR4QDdcfokvKcRXPI58b24dw//Z8VGOwa6Y+cTWZAaXyXmD\r\n"
			+ "kn6ndQWPvLUV1CzWHZ3To29yf1ajGgWTWJ+IzAcCVBEKJ7ksm0ujSaZ3A4caRpvp\r\n"
			+ "qi3jBivcxDBlU3GPB4oypmv9t80MihSdQkzrn9ML1DVMpAmK2+aJY4+N50qSf8lC\r\n"
			+ "wjsIBv+qmfBfZ7WbGoSVSPfNLo38k5ZK7WoctrBgK9PoCSzpV04flMkt3WK1AdVk\r\n"
			+ "tc4I5lRtmdJMtva4Bf1o73/aOt/J1hbYY535BSUOc0bhlZDzD0tWii+S6XwXkqJ6\r\n"
			+ "Yz7wqjbZ47pwTrwP/hm6CwdhEmfactOQr0HLbSQRXB2fp5MUHtbImohjgaj/xavh\r\n"
			+ "MTt/UyTi7c6GmXCWsk6vAOQYmboOKC2bT1mX/kUMKE2Zdae6+xh4KoZBzLMdkGxQ\r\n"
			+ "iAGhpnMM6RlBMv+XbnvksQlQKQ7OM2LREpJOh82Pq5jingyHfphLgQt2DorydiIJ\r\n"
			+ "xvZn+zTURC/T7sjtZKcYV+t6nKsFbWAcFy548Mg8MzYeLmDRObvNFKkZzbNGhLSn\r\n"
			+ "BoRtA+D29fiNAk3xaQ2XYLgbAQqbUSJigQNxmyU/eePrFhWqJw7Fw6hKpjgj94Kq\r\n"
			+ "hD2iieZKdECnKbNcm3FFwEpNJH58Nj1wS1F/miZotAysBJ7xmQKCAQEA3n8dIZAS\r\n"
			+ "OTrNGA6qPlQLt7gLIaTisgTg3EAvPTihJGQfoXWCBPtK+sSZ0jHO3jV8xd2QLWzR\r\n"
			+ "hb2XkB+qAgBTOS0f99Hk4UpVBnpNZbhxiabmvtjVKduhv041lwCdS6J5/TG9YXCA\r\n"
			+ "jdf6VodUXM/VxBMb+b2R/XujEo4yUgqWxCu5E+scbiIter5N3AOe34L+wVipME0B\r\n"
			+ "6Cy7qDhhMNdFch54KjxnuIXM9Saju1TEn2fOLu6YCNPwon/NhpnjqjjlRq65LciL\r\n"
			+ "VoQLTke1Xm7fvY4QZxCr/rCHq640hoxpG/sMRIRLzmlb6PCGEOBBpk9tMIMi4UPg\r\n"
			+ "5D98Ei4B+vDi7QKCAQEA1/GvOr7QJWGt3FA7sF+gIW6ZIc64nMmOEqNWdXEaLl6U\r\n"
			+ "fBIkZjHw6XOAI7yZivDdbTYgXHV3vYSxojGE1WUIIRG99P+kD8Y0TMQdZUNN7RuP\r\n"
			+ "BnhdUXvvXjcqWsY7GYGuj/556Woykv+Va0JOPQoNFgd5U2lH9hEDPrZVXBLMx+l/\r\n"
			+ "DrVwymCDiaYaEBh4J62vMWh7dUNooopRKGdOV37/e7rpCfbNed2YfqqnZxn7800P\r\n"
			+ "1UbM8kShB1NiLoioHZrtEMHiQo+i21YvhSRe0F4v3pJgiaw4jnsD031S59Qb+zAM\r\n"
			+ "9KCCM8OvIcfN6oXKtYghyclKnI7j944wi5lrNgZ3VQKCAQBBUOGVY7zlzgw9Prjd\r\n"
			+ "eUDDWyTxaH0gM2xrW/BCMaikjTv34w4bNkYJncNmQDbxZpRNZcCYhTRw5Xpj1dfL\r\n"
			+ "pJrJ0yRqVNSzCmYxc5/a961k8nkUl4TkN9Sg223B+W0zsevL11k4DJXAjiGwWyP5\r\n"
			+ "5w1i9RUmWG9OEYiKvvGowfEGf6tiXIfJEQF24fzrVKjEBqmQyt1ID6M6rD8eoAZw\r\n"
			+ "FxIM8ULnazoroiPL597y9GyQOyH9Bw/cr5MZsRj9pZl+9BriiBJWjWPSLws+nLBy\r\n"
			+ "m2vVMqpAB1Xme54oWQiUYw3MKAOu7YNvgeB4XnuM4riDARgVwLlxlcKkXrqmf5kX\r\n"
			+ "OLX1AoIBACchoMNgeI+Nl9fooihf68CjLhS2RTYEQD6YYr59dGUatoWVNAtg2Ws0\r\n"
			+ "hu/y6VAIPdfgixS2JLCvLxFZL90LpeF4OZgAC1bgb/HJSBpli+V/rPdbMG3nq4TD\r\n"
			+ "MmWormT83wkw8B6gI/IHZqg9J7hf7eckC5RV67hndNMUb3tz3LANW/zqXDoQK0Xy\r\n"
			+ "V567EGsASlMFv/mL8ZYiwnoz3jp0xQ9C25/2nV2MDmpFungweTupp0jav6DXVubg\r\n"
			+ "8VXFZdGXlYYH3Fx7cuOURqA16wiPSNVoaR4Jm2YWXKciereP9FIcbvyVaYK/3yib\r\n"
			+ "8HCjNgyXUqgiVebw7daaaamib48mtNECggEBAK7H1xoJhLw63xdji3uPhC+/ueqE\r\n"
			+ "L/6hiXLQd4e2z6uYjAyydiU7Xd226Dct/CkxPvosCAnVLF/sWdSWKrstpbvQM6+G\r\n"
			+ "vSY3R4ehBNJGXeV3Mh9ZH9SIXmvyuwVhURnQZA3/Giji7cVrhJfpsaziG/vG06r4\r\n"
			+ "9tiMMJ0uNjvmUzTuPRJESAregFnhl69mQ5MkV01BhTGRkpBNzkAc9F5SfzlvUqft\r\n"
			+ "9p1tS+EoSmGKiRth7g9y2KFZdjbw4OgO1pP9qlJmcxQjyxAcY7uS5VQNsgoaYdpu\r\n"
			+ "Fkh1NmP4iU4A+hpSBxOwBcZzWrgZEtkl7EyfjgY4xOM4q+K8ISJGNYO64U8=\r\n" + "-----END RSA PRIVATE KEY-----";


	public final String institutions_URL = Server + "/KuberaVault/api/v3/organisations/" + vendor + "/institutions"

			+ "?dataSource=STATEMENT" + "&processingType=STATEMENT"// STATEMENT"
	;

	public static final String PARAM1 = "dataSource";
	public static final String PARAM2 = "processingType";
	public static final String REPORT_FORMAT = "json";
	public static final String QUERY_PARAM = "types";

	public static final String X_PERFIOS_DATE = "X-Perfios-Date";
	public static final String X_PERFIOS_ALGORITHM = "X-Perfios-Algorithm";
	public static final String X_PERFIOS_CONTENT = "X-Perfios-Content-Sha256";
	public static final String X_PERFIOS_SIGNATURE = "X-Perfios-Signature";
	
	public static final String X_PERFIOS_SIGNED_HEADERS = "X-Perfios-Signed-Headers";
	public static final String X_PERFIOS_CONTENT_DATE = "host;x-perfios-content-sha256;x-perfios-date";
	public static final String  X_PERFIOS_RSA_SHA256 = "PERFIOS-RSA-SHA256";
	public static final String NO_CACHE = "no-cache";
	
	public static final String X_PERFIOS_SIGN_HOST_PARAM = "host:";
	public static final String X_PERFIOS_SIGN_CONTENT_SHA256_PARAM = "x-perfios-content-sha256:";
	public static final String X_PERFIOS_SIGN_DATE_PARAM = "x-perfios-date:";
	


}
