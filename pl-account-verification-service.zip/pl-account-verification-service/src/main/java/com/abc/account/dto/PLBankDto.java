package com.abc.account.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PLBankDto {

	@JsonProperty("plbank_id")
	private Long bankId;

	@JsonProperty("name")
	private String name;

	@JsonProperty("fullname")
	private String fullName;

	@JsonProperty("aa_available")
	private String aaAvailable;

	@JsonProperty("netbanking_available")
	private String netbankingAvailable;

	@JsonProperty("fip_mapping")
	private String fipMapping;

	@JsonProperty("netbanking_mapping")
	private String netbankingMapping;

	@JsonProperty("logo_url")
	private String logoUrl;
	
	@JsonProperty("top_priority_bank")
	private String topPriorityBank;
	
	@JsonProperty("modified_by")
    private String modifiedBy;

	@JsonProperty("modified_date")
    private Date modifiedDate;

}
