package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerInfo {

	@JsonProperty("name")
	private String name;

	@JsonProperty("address")
	private String address;

	@JsonProperty("landline")
	private String landline;

	@JsonProperty("mobile")
	private String mobile;

	@JsonProperty("email")
	private String email;

	@JsonProperty("pan")
	private String pan;

	@JsonProperty("perfiosTransactionId")
	private String perfiosTransactionId;

	@JsonProperty("customerTransactionId")
	private String customerTransactionId;

	@JsonProperty("bank")
	private String bank;

	@JsonProperty("instId")
	private int instId;
}
