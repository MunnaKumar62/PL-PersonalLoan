package com.abc.account.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.abc.account.entity.BankAccountDetails;

@Repository
public interface BankAccountDetailsRepository extends JpaRepository<BankAccountDetails, Long> {

	List<BankAccountDetails> findByCustomerIdAndAccountNumber(Long customerId, String accountNumber);

	@Query("SELECT a FROM BankAccountDetails a WHERE a.bankAccountId=(SELECT max(a.bankAccountId) FROM BankAccountDetails a WHERE a.customerId =:customerId and a.loanId =:loanId and a.accountId =:accountId and a.active =:active)")
	Optional<BankAccountDetails> findByCustomerIdAndAccountIdAndLoanIdAndActive(Long customerId, String accountId, String loanId, Boolean active);
}
