package com.abc.account.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class EMandatePollData {
	
	private String code;
	private String description;
	private String razorpayCustid;
	private String tokenId;
	private String tokenStatus;
	private Object failureReason;
	private Object mrnNo;

}
