package com.abc.account.dto.aggregator;

import lombok.Data;

@Data
public class ConsentResData {

	private String redirectURL;
	private String requestId;
	private String consentHandle;
	private String qrcode;

}
