package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TokenResponse {

  @JsonProperty("scope")
  //@JsonIgnoreProperties(ignoreUnknown = true)
  private String scope;

  @JsonProperty("access_token")
  private String accessToken;
  
  @JsonProperty("token_type")
  private String tokenType;
  
  @JsonProperty("expires_in")
  private String expiresIn;
  
}