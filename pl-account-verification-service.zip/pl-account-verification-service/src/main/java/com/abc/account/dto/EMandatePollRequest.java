package com.abc.account.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class EMandatePollRequest {

	@NotEmpty(message = "Account ID cannot be empty")
	@Schema(name="accountId",example = "UPSELL000000470")
	private String accountId;
}
