package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SummaryInfo {

	@JsonProperty("instName")
	private String instName;

	@JsonProperty("accNo")
	private String accNo;

	@JsonProperty("accType")
	private String accType;

	@JsonProperty("fullMonthCount")
	private int fullMonthCount;

	@JsonProperty("total")
	private Total total;

	@JsonProperty("average")
	private Average average;
}
