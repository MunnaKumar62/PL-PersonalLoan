package com.abc.account.dto;

import java.util.ArrayList;

import lombok.Data;
@Data
public class SplitAddress {
	ArrayList<Object> district = new ArrayList<Object>();
	ArrayList<Object> state = new ArrayList<Object>();
	ArrayList<Object> city = new ArrayList<Object>();
	private String pincode;
	ArrayList<Object> country = new ArrayList<Object>();
	private String addressLine;

}
