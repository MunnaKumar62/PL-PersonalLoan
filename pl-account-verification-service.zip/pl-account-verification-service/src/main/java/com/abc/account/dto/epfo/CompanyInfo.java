package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyInfo {

	@JsonProperty("orgDomainMatch")
	public List<OrgDomainMatch> orgDomainMatch;

	@JsonProperty("orgEmailMatch")
	public List<OrgEmailMatch> orgEmailMatch;

	@JsonProperty("usrDirectorMatch")
	public List<Object> usrDirectorMatch;
}
