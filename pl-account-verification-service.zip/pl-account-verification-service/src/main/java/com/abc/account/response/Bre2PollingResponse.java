package com.abc.account.response;

import com.abc.account.dto.bre.BrePollingData;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Bre2PollingResponse {
	
	public Bre2PollingResponse(String responseStatus) {
		super();
		this.responseStatus = responseStatus;
	}
	
	@JsonProperty("responseStatus")
	public String responseStatus;
	
	@JsonProperty("data")
	public BrePollingData data;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
