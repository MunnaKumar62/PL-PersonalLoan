package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdditionalInfo {

	@JsonProperty("companyInfo")
	public CompanyInfo companyInfo;

	@JsonProperty("individualMatch")
	public List<IndividualMatch> individualMatch;

	@JsonProperty("spamRecord")
	public SpamRecord spamRecord;

	@JsonProperty("whoisInfo")
	public WhoisInfo whoisInfo;
}
