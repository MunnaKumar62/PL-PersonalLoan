package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ConsentReqData {

	@JsonProperty("productType")
	public String productType;

	@JsonProperty("processingType")
	public String processingType;

	@JsonProperty("loanType")
	public String loanType;

	@JsonProperty("employmentType")
	public String employmentType;

	@JsonProperty("employerName")
	public String employerName;

	@JsonProperty("loanAmount")
	public int loanAmount;
}
