package com.abc.account.dto.aggregator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AdditionalRelatedPartyDetails {

	@JsonProperty("RelatedPartyData1")
	private List<RelatedPartyData1> relatedPartyData1;

}
