package com.abc.account.dto.bre;

import java.util.List;

import lombok.Data;

@Data
public class Income{
    public List<IncomeXn> incomeXns;
    public IncomeSummary incomeSummary;
}
