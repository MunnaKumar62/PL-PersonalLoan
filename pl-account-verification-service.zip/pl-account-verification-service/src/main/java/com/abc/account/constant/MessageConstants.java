package com.abc.account.constant;

public interface MessageConstants {

	public static final String STATUS_CODE_200 = "200";
	public static final String STATUS_CODE_500 = "500";
	public static final String BAD_REQUEST_400 = "400";
	public static final String STATUS_CODE_404 = "404";
	public static final String API_STATUS_200 = " Your Request is Succeeded";
	public static final String API_STATUS_500 = "Service temporarily unavailable";
	public static final String API_STATUS_404 = "Unable to process your request";
	public static final String EMPTY_REQUEST = "Request Body can not be empty";
	public static final String EMPTY_FIELD = "Field can not be empty";
	public static final String NULL_FIELD = "Field can not be null";
	public static final String EMPTY_PARAM = "Parameter can not be empty";
	public static final String DETAILS_NOT_FOUND = "Details Not Found";
	public static final String DETAILS_UPDATED = "Details Updated Successfully";
	public static final String MUST_SALARIED = "Customer must be salaried";
	public static final String AA_IB_DATA_NOTFOUND = "Analysed Report/Retrive Report response not found";
	public static final String INTERACTIVE_LINK_DATA_NOTFOUND = "Create Interactive Link response not found";
	public static final String INVALID_HEADER = "Invalid Header";
	public static final String MAX_RETRY_MESSAGE = "Max Retry limit exhausted for PennyDrop. Please retry after 24 hours";
	
}
