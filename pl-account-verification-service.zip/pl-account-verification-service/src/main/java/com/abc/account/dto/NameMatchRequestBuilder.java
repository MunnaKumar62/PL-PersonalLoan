package com.abc.account.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.Data;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class NameMatchRequestBuilder {

    @Schema(name="name1",example = "")
    public String name1;

    @Schema(name="name2",example = "")
    public String name2;

    @Schema(name="transactionId",example = "123")
    public String transactionId;

    @Builder.Default
    @Schema(name="product",example = "123")
    public String product="123";

    @Schema(name="applicationId",example = "123")
    public String applicationId;

}