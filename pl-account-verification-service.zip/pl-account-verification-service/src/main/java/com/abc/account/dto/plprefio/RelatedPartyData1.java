package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RelatedPartyData1 {
    @JsonProperty("monthName")
    private String monthName;

    @JsonProperty("noOfDebits")
    private int noOfDebits;

    @JsonProperty("debits")
    private double debits;

    @JsonProperty("totalDebits")
    private double totalDebits;

    @JsonProperty("totalDebitsPercent")
    private double totalDebitsPercent;

    @JsonProperty("noOfCredits")
    private int noOfCredits;

    @JsonProperty("credits")
    private double credits;

    @JsonProperty("totalCredits")
    private double totalCredits;

    @JsonProperty("totalCreditsPercent")
    private double totalCreditsPercent;

    @JsonProperty("netDebitOrCredit")
    private double netDebitOrCredit;

}