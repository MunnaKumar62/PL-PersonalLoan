package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Uan {

	@JsonProperty("uan")
	public String uan;

	@JsonProperty("uanSource")
	public String uanSource;

	@JsonProperty("employer")
	public List<Employer> employer;
}
