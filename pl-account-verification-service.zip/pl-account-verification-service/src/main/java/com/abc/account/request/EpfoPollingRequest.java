package com.abc.account.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class EpfoPollingRequest {

    @NotBlank(message = "Account ID is required")
    private String accountId;

    private String loanId;

    private Long customerId;

}