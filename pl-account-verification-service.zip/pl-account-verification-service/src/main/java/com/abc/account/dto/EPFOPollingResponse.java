package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@lombok.Data
@Builder
public class EPFOPollingResponse {

    @JsonProperty("responseStatus")
    public String responseStatus;

    @JsonProperty("data")
    public EPFOData data;
}