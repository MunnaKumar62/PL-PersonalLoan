package com.abc.account.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.service.TokenService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping(Constants.API + Constants.VERSION+Constants.ADMIN)
@RequiredArgsConstructor
public class TokenController {

	private final TokenService tokenService;

	/**
	 * Retrieves the access token from the API response obtained by calling the token API.
	 * This method calls the token API to fetch an access token. It extracts the token from
	 * the API response and returns it as a String. If the API response or token is null,
	 * it returns an empty string.
	 * @return The access token obtained from the token API response, or an empty string if not available.
	 */
	@GetMapping("/token")
	public String getToken() {
		try {
			return tokenService.getAccessToken();
		} catch (Exception e) {
			return "Error generating token: " + e.getMessage();
		}
	}

}
