package com.abc.account.dto.aggregator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Insights {

	@JsonProperty("reportFiles")
	public List<String> reportFiles;
	@JsonProperty("status")
	public String status;
}
