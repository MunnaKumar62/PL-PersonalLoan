package com.abc.account.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;

import com.abc.account.request.AdditionalDetailBuilder;
import com.abc.account.request.AdditionalDetailsRequestBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.account.constant.Constants;
import com.abc.account.dto.PLCustomerDetailDto;
import com.abc.account.entity.ApiStatus;
import com.abc.account.entity.LoanOfferDetails;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.repo.LoanRepository;
import com.abc.account.request.AdditionalDetail;
import com.abc.account.request.AdditionalDetailsRequest;
import com.abc.account.response.AdditionalDetailsSuccessResponse;
import com.abc.account.util.AdditionalDetailsErrorResponseUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
@RequiredArgsConstructor
public class PLAdditionalDetailsServiceImpl implements PLAdditionalDetailsService {
	private final AdditionalDetailsTokenService additionalDetailsTokenService;
	private final RestTemplate restTemplate;
	private final ObjectMapper objectMapper;
	private final AdditionalDetailsErrorResponseUtil additionalDetailsErrorResponseUtil;
	private final APIStatusRepository apiStatusRepo;

	@Value("${abfl.additional-details.url}")
	private String additionalDetailsURL;
	
	@Autowired
	private LoanRepository loanRepository;
	
	@Autowired
	private PLCustomerDetailService plCustomerDetailService;

	public ResponseEntity<Object> sendAdditionalDetails(AdditionalDetailsRequest request) throws Exception {
		log.info("Start of sendAdditionalDetails Method in Service...");
		log.debug("ADDITIONAL_DETAILS_REQUEST :: " + request);
		String accountId = request.getAccountId();

		ResponseEntity<Object> tokenObject = additionalDetailsTokenService.generateToken();
		JsonNode responseJson = objectMapper.valueToTree(tokenObject.getBody());
		String token = responseJson.get("access_token").asText();
		log.debug("Access_Token :: " + token);
		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		ResponseEntity<String> response = null;
		AdditionalDetailsSuccessResponse additionalDetailsSuccessResponse = null;
		AdditionalDetailsRequestBuilder additionalDetailsRequestBuilder = new AdditionalDetailsRequestBuilder();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("auth-token", token);

			additionalDetailsRequestBuilder.setOfficeAddress(request.getOfficeAddress());
			additionalDetailsRequestBuilder.setAnnualIncome(request.getAnnualIncome());
			additionalDetailsRequestBuilder.setPurposeOfLoan(request.getPurposeOfLoan());
			additionalDetailsRequestBuilder.setOfficialEmailId(request.getOfficialEmailId());
			additionalDetailsRequestBuilder.setAccountId(request.getLoanId());
			HttpEntity<Object> entityHeader = new HttpEntity<>(additionalDetailsRequestBuilder, headers);

			response = restTemplate.exchange(additionalDetailsURL, HttpMethod.POST, entityHeader, String.class);
			JsonNode jsonNode = objectMapper.readTree(response.getBody());
			String responseStatus = jsonNode.get("responseStatus").asText();
			additionalDetailsSuccessResponse = AdditionalDetailsSuccessResponse.builder().timestamp(LocalDateTime.now())
					.status(responseStatus).build();
			//Save the data into loanofferdetails table
		    LoanOfferDetails loanOfferDetails = loanRepository.getLoanOfferDetailsByAccountIdAndLoanIdAndCustomerId(accountId, request.getLoanId(), request.getCustomerId());
		    loanOfferDetails.setLoanType(request.getPurposeOfLoan());
		    loanRepository.save(loanOfferDetails);
			//save customer office adderss and mail id
			log.debug("Response :: " + additionalDetailsSuccessResponse.toString());
			saveAdditionalDetailsAPIStatus("ADDITIONAL_WORK_DETAILS", accountId, additionalDetailsRequestBuilder, response,"SUCCESS", request.getLoanId(), request.getCustomerId());
			//PL_JOURNEY_AUDIT
			plCustomerDetailDto.setAccountId(accountId);
			plCustomerDetailDto.setLoanId(request.getLoanId());
			plCustomerDetailDto.setCustomerId(request.getCustomerId());
			plCustomerDetailDto.setLoanPurpose(request.getPurposeOfLoan());
			plCustomerDetailDto.setWorkEmail(request.getOfficialEmailId());
			plCustomerDetailDto.setWorkemailAddedDate(new Timestamp(new Date().getTime()));
			plCustomerDetailDto.setCurrentScreen("Success/Congratulations Page");
			plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);

			return new ResponseEntity<>(additionalDetailsSuccessResponse, HttpStatus.OK);
		} catch (HttpClientErrorException ex) {
			saveAdditionalDetailsAPIStatus("ADDITIONAL_WORK_DETAILS", accountId, additionalDetailsRequestBuilder, ex.getResponseBodyAsString(),"ERROR", request.getLoanId(), request.getCustomerId());
			if (ex.getStatusCode().is4xxClientError()) {
				log.error("ERROR :: " + ex.getResponseBodyAsString());
				return new ResponseEntity<>(additionalDetailsErrorResponseUtil.badRequestErrorResponse(ex),
						HttpStatus.BAD_REQUEST);
			}
			log.error("ERROR :: " + ex.getResponseBodyAsString());
			return new ResponseEntity<>(additionalDetailsErrorResponseUtil.badRequestErrorResponse(ex),
					HttpStatus.BAD_REQUEST);
		}
	}
	public ResponseEntity<Object> sendAdditionalDetail(AdditionalDetail additionalDetail) throws Exception {
		log.info("Start of sendAdditionalDetail Method in Service...");
		log.debug("ADDITIONAL_DETAILS_REQUEST :: " + additionalDetail);
		String accountId = additionalDetail.getAccountId();

		PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
		ResponseEntity<Object> tokenObject = additionalDetailsTokenService.generateToken();
		JsonNode responseJson = objectMapper.valueToTree(tokenObject.getBody());
		String token = responseJson.get("access_token").asText();
		log.debug("Access_Token :: " + token);

		ResponseEntity<String> response = null;
		AdditionalDetailsSuccessResponse adtlsResponse = null;
		AdditionalDetailBuilder additionalDetailBuilder = new AdditionalDetailBuilder();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.add("auth-token", token);

			additionalDetailBuilder.setCustomerId(additionalDetail.getCustomerId());
			additionalDetailBuilder.setOrderId(additionalDetail.getOrderId());
			additionalDetailBuilder.setTokenStatus(additionalDetail.getTokenStatus());
			additionalDetailBuilder.setAccountId(additionalDetail.getLoanId());
			additionalDetailBuilder.setTokenId(additionalDetail.getTokenId());
			HttpEntity<Object> entityHeader = new HttpEntity<>(additionalDetailBuilder, headers);

			response = restTemplate.exchange(additionalDetailsURL, HttpMethod.POST, entityHeader, String.class);
			JsonNode jsonNode = objectMapper.readTree(response.getBody());
			String responseStatus = jsonNode.get("responseStatus").asText();
			adtlsResponse = AdditionalDetailsSuccessResponse.builder().timestamp(LocalDateTime.now())
					.status(responseStatus).build();
			String emandate = null != adtlsResponse && Constants.SUCCESS.equalsIgnoreCase(adtlsResponse.getStatus()) ? "Y" : "N";
			//PL_JOURNEY_AUDIT
			plCustomerDetailDto.setAccountId(accountId);
			plCustomerDetailDto.setCustomerId(additionalDetail.getAbfCustomerId());
			plCustomerDetailDto.setLoanId(additionalDetail.getLoanId());
			plCustomerDetailDto.setEmandateStatus(emandate);
			plCustomerDetailDto.setEmanDatetime(new Timestamp(new Date().getTime()));
			plCustomerDetailDto.setCurrentScreen("Enach Page");
			plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
			
			log.debug("Response :: " + adtlsResponse.toString());
			saveAdditionalDetailsAPIStatus("ADDITIONAL_DETAIL", accountId, additionalDetailBuilder, response,"SUCCESS", additionalDetail.getLoanId(), additionalDetail.getAbfCustomerId());

			return new ResponseEntity<>(adtlsResponse, HttpStatus.OK);
		} catch (HttpClientErrorException ex) {
			saveAdditionalDetailsAPIStatus("ADDITIONAL_DETAIL", accountId, additionalDetailBuilder, ex.getResponseBodyAsString(),"ERROR", additionalDetail.getLoanId(), additionalDetail.getAbfCustomerId());
			if (ex.getStatusCode().is4xxClientError()) {
				log.error("ERROR :: " + ex.getResponseBodyAsString());
				return new ResponseEntity<>(additionalDetailsErrorResponseUtil.badRequestErrorResponse(ex),
						HttpStatus.BAD_REQUEST);
			}
			log.error("ERROR :: " + ex.getResponseBodyAsString());
			return new ResponseEntity<>(additionalDetailsErrorResponseUtil.badRequestErrorResponse(ex),
					HttpStatus.BAD_REQUEST);
		}
	}
	
	
	
	private void saveAdditionalDetailsAPIStatus(String apiName, String accountID,
												Object requestObject,
												Object responseObject,
												String status,
												String loanId,
												Long customerId) throws Exception {
		log.info("Start of API Status Persisting.");
		String requestJsonObject = objectMapper.writeValueAsString(requestObject);
		String responseJsonObject = objectMapper.writeValueAsString(responseObject);
		ApiStatus apiStatusRequest = ApiStatus.builder().journey("PL").apiName(apiName).accountId(accountID)
				.loanId(loanId).customerId(customerId)
				.requestJson(requestJsonObject).responseJson(responseJsonObject).status(status).build();
		apiStatusRepo.save(apiStatusRequest);
		log.info("API Status Persisted Successfully.");
	}

}
