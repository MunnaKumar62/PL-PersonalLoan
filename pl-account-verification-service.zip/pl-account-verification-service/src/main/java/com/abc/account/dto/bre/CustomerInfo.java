package com.abc.account.dto.bre;

import lombok.Data;
@Data
public class CustomerInfo{
    private String email;
    private String name;
    private String bank;
    private String customerTransactionId;
    private String mobile;
    private int instId;
    private String landline;
    private String perfiosTransactionId;
    private String address;
    private String pan;
}
