package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PLBankRequest {

	@JsonProperty("name")
	private String name;

	@JsonProperty("fullname")
	private String fullName;

	@JsonProperty("aa_available")
	private String aaAvailable;

	@JsonProperty("netbanking_available")
	private String netbankingAvailable;

	@JsonProperty("fip_mapping")
	private String fipMapping;

	@JsonProperty("netbanking_mapping")
	private String netbankingMapping;

	@JsonProperty("logo_url")
	private String logoUrl;

	@JsonProperty("top_priority_bank")
	private String topPriorityBank;

}
