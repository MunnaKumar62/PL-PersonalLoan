package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class EODBalance {
    @JsonProperty("date")
    private String date;

    @JsonProperty("balance")
    private double balance;
}