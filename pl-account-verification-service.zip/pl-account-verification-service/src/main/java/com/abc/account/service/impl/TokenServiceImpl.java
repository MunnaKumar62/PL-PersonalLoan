package com.abc.account.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.account.constant.Constants;
import com.abc.account.exception.CustomException;
import com.abc.account.exception.InternalException;
import com.abc.account.request.ApiCommonRequest;
import com.abc.account.response.TokenResponse;
import com.abc.account.service.TokenService;
import com.abc.account.service.biz.CommonBizService;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class TokenServiceImpl extends CommonBizService implements TokenService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${abfl.token.client_id}")
	private String clientId;

	@Value("${abfl.token.scope}")
	private String inputScope;

	@Value("${abfl.toke.grant_type}")
	private String grantType;

	@Value("${abfl.token.auth}")
	private String authToken;
	
	@Value("${abfl.prod.token.url}")
	private String prodTokenUrl;

	@Value("${abfl.prod.token.client_id}")
	private String prodClientId;

	@Value("${abfl.prod.token.scope}")
	private String prodInputScope;

	@Value("${abfl.prod.toke.grant_type}")
	private String prodGrantType;

	@Value("${abfl.prod.token.auth}")
	private String prodAuthToken;

	@Override
	public String getAccessToken() {

		ResponseEntity<Object> apiResponse = callTokenApi();
		String token = EMPTY;
		if (null != apiResponse && null != apiResponse.getBody()) {
			TokenResponse response = (TokenResponse) apiResponse.getBody();
			token = null != response && null != response.getAccessToken() ? response.getAccessToken() : token;
		}
		return token;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callTokenApi() {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;

		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam(CLIENT_ID, clientId)
					.queryParam(SCOPE, inputScope).queryParam(GRANT_TYPE, grantType).build();
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_AUTH_TOKEN)
					.requestHeaders(getTokenRequestHeaders(authToken)).url(builder.toUriString())
					.method(HttpMethod.POST).request(null).accountId(EMPTY).profileId(EMPTY).requestId(EMPTY)
					.transactionId(EMPTY).active(true).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, TokenResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1005");

		}
		log.info(className + methodName + END);

		return apiResponse;
	}
	
	@Override
	public String getProdAccessToken() {

		ResponseEntity<Object> apiResponse = callProdTokenApi();
		String token = EMPTY;
		if (null != apiResponse && null != apiResponse.getBody()) {
			TokenResponse response = (TokenResponse) apiResponse.getBody();
			token = null != response && null != response.getAccessToken() ? response.getAccessToken() : token;
		}
		return token;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callProdTokenApi() {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = null;
		Map<String, Object> map = null;

		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(prodTokenUrl).queryParam(CLIENT_ID, prodClientId)
					.queryParam(SCOPE, prodInputScope).queryParam(GRANT_TYPE, prodGrantType).build();
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_AUTH_TOKEN)
					.requestHeaders(getTokenRequestHeaders(prodAuthToken)).url(builder.toUriString())
					.method(HttpMethod.POST).request(null).accountId(EMPTY).profileId(EMPTY).requestId(EMPTY)
					.transactionId(EMPTY).active(true).isAudit(Boolean.FALSE).build();

			map = callExternalApi(commonRequest, TokenResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new InternalException("1005");

		}
		log.info(className + methodName + END);

		return apiResponse;
	}

}
