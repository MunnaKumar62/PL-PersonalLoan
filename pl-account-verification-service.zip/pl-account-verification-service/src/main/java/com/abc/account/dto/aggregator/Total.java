package com.abc.account.dto.aggregator;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Total {

	@JsonProperty("bal1")
	private double bal1;

	@JsonProperty("bal10")
	private double bal10;

	@JsonProperty("bal15")
	private double bal15;

	@JsonProperty("bal20")
	private double bal20;

	@JsonProperty("bal25")
	private double bal25;

	@JsonProperty("bal30")
	private double bal30;

	@JsonProperty("bal5")
	private double bal5;

	@JsonProperty("balAvg")
	private double balAvg;

	@JsonProperty("balMax")
	private double balMax;

	@JsonProperty("balMin")
	private double balMin;

	@JsonProperty("cashDeposits")
	private int cashDeposits;

	@JsonProperty("cashWithdrawals")
	private int cashWithdrawals;

	@JsonProperty("chqDeposits")
	private int chqDeposits;

	@JsonProperty("chqIssues")
	private int chqIssues;

	@JsonProperty("credits")
	private int credits;

	@JsonProperty("creditsSC")
	private int creditsSC;

	@JsonProperty("creditsSelf")
	private int creditsSelf;

	@JsonProperty("debits")
	private int debits;

	@JsonProperty("debitsSC")
	private int debitsSC;

	@JsonProperty("debitsSelf")
	private int debitsSelf;

	@JsonProperty("dpLimit")
	private int dpLimit;

	@JsonProperty("emiEcsLoanIssues")
	private int emiEcsLoanIssues;

	@JsonProperty("emiOrLoans")
	private int emiOrLoans;

	@JsonProperty("intraDayClearedBouncesNonTechnical")
	private int intraDayClearedBouncesNonTechnical;

	@JsonProperty("intraDayClearedBouncesTechnical")
	private int intraDayClearedBouncesTechnical;

	@JsonProperty("inwBounceNonTechnical")
	private int inwBounceNonTechnical;

	@JsonProperty("inwBounces")
	private int inwBounces;

	@JsonProperty("inwBounceTechnical")
	private int inwBounceTechnical;

	@JsonProperty("inwChqBounces")
	private int inwChqBounces;

	@JsonProperty("inwEMIBounces")
	private int inwEMIBounces;

	@JsonProperty("outwBounces")
	private int outwBounces;

	@JsonProperty("outwChqBounces")
	private int outwChqBounces;

	@JsonProperty("overdrawnAmount")
	private int overdrawnAmount;

	@JsonProperty("overdrawnDays")
	private int overdrawnDays;

	@JsonProperty("samePartyCredits")
	private int samePartyCredits;

	@JsonProperty("samePartyCreditsSC")
	private int samePartyCreditsSC;

	@JsonProperty("samePartyCreditsSelf")
	private int samePartyCreditsSelf;

	@JsonProperty("samePartyDebits")
	private int samePartyDebits;

	@JsonProperty("samePartyDebitsSC")
	private int samePartyDebitsSC;

	@JsonProperty("samePartyDebitsSelf")
	private int samePartyDebitsSelf;

	@JsonProperty("selfSisterUpiDebits")
	private int selfSisterUpiDebits;

	@JsonProperty("snLimit")
	private int snLimit;

	@JsonProperty("totalCashDeposit")
	private int totalCashDeposit;

	@JsonProperty("totalCashWithdrawal")
	private int totalCashWithdrawal;

	@JsonProperty("totalChqDeposit")
	private int totalChqDeposit;

	@JsonProperty("totalChqIssue")
	private int totalChqIssue;

	@JsonProperty("totalCredit")
	private int totalCredit;

	@JsonProperty("totalCreditSC")
	private int totalCreditSC;

	@JsonProperty("totalCreditSelf")
	private int totalCreditSelf;

	@JsonProperty("totalDebit")
	private double totalDebit;

	@JsonProperty("totalDebitSC")
	private int totalDebitSC;

	@JsonProperty("totalDebitSelf")
	private int totalDebitSelf;

	@JsonProperty("totalEmiEcsLoanIssue")
	private int totalEmiEcsLoanIssue;

	@JsonProperty("totalEmiOrLoan")
	private int totalEmiOrLoan;

	@JsonProperty("totalInterestCharged")
	private int totalInterestCharged;

	@JsonProperty("totalInvIncome")
	private int totalInvIncome;

	@JsonProperty("totalInwBounce")
	private int totalInwBounce;

	@JsonProperty("totalInwBounceNonTechnical")
	private int totalInwBounceNonTechnical;

	@JsonProperty("totalInwChqBounce")
	private int totalInwChqBounce;

	@JsonProperty("totalLoanDisbursal")
	private int totalLoanDisbursal;

	@JsonProperty("totalOutwBounce")
	private int totalOutwBounce;

	@JsonProperty("totalOutwChqBounce")
	private int totalOutwChqBounce;

	@JsonProperty("totalPenalCharge")
	private int totalPenalCharge;

	@JsonProperty("totalSalary")
	private int totalSalary;

	@JsonProperty("totalSamePartyCredit")
	private int totalSamePartyCredit;

	@JsonProperty("totalSamePartyCreditSC")
	private int totalSamePartyCreditSC;

	@JsonProperty("totalSamePartyCreditSelf")
	private int totalSamePartyCreditSelf;

	@JsonProperty("totalSamePartyDebit")
	private int totalSamePartyDebit;

	@JsonProperty("totalSamePartyDebitSC")
	private int totalSamePartyDebitSC;

	@JsonProperty("totalSamePartyDebitSelf")
	private int totalSamePartyDebitSelf;

}
