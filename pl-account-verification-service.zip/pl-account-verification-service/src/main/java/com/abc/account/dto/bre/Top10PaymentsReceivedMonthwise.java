package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class Top10PaymentsReceivedMonthwise{
    private double amount;
    private String party;
    private String month;


}
