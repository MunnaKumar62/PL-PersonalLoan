package com.abc.account.service.biz;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.exception.InternalException;
import com.abc.account.request.CreateCustomer;
import com.abc.account.request.CreateOrder;
import com.abc.account.request.VPARequest;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class CustomerBizService implements Constants, MessageConstants {

	public CreateCustomer validateCreateCustomerRequest(CreateCustomer request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getName())) {
				msg = FILED_NAME + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getEmail())) {
				msg = FILED_EMAIL + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getContact())) {
				msg = FILED_CONTACT + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public CreateOrder validateCreateOrderRequest(CreateOrder request) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getCustomerId())) {
				msg = FILED_CUSTOMER_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getMethod())) {
				msg = FILED_METHOD + TILDA + EMPTY_FIELD;
			} else if (request.getMethod().equalsIgnoreCase(EMANDATE) && null == request.getToken()) {
				msg = FILED_TOKEN + TILDA + NULL_FIELD;
			} else if (request.getMethod().equalsIgnoreCase(EMANDATE) && null == request.getToken().getBankAccount()) {
				msg = FILED_BANK_ACCOUNT + TILDA + NULL_FIELD;
			} else if (request.getMethod().equalsIgnoreCase(EMANDATE)
					&& StringUtils.isBlank(request.getToken().getBankAccount().getBeneficiaryName())) {
				msg = FILED_BENE_NAME + TILDA + EMPTY_FIELD;
			} else if (request.getMethod().equalsIgnoreCase(EMANDATE)
					&& StringUtils.isBlank(request.getToken().getBankAccount().getAccountNumber())) {
				msg = FILED_ACCOUNT_NUMBER + TILDA + EMPTY_FIELD;
			} else if (request.getMethod().equalsIgnoreCase(EMANDATE)
					&& StringUtils.isBlank(request.getToken().getBankAccount().getIfscCode())) {
				msg = FILED_IFSC + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public boolean validateTokenIdRequest(String paymentId, String customerId) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.FALSE;
		if (StringUtils.isBlank(paymentId)) {
			msg = FILED_PAYMENT_ID + TILDA + EMPTY_PARAM;
		} else if (StringUtils.isBlank(customerId)) {
			msg = FILED_CUSTOMERID + TILDA + EMPTY_PARAM;
		} else {
			flag = Boolean.TRUE;
		}
		if (!flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return flag;
	}
	
	public boolean validateUPITokenIdRequest(String paymentId) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.FALSE;
		if (StringUtils.isBlank(paymentId)) {
			msg = FILED_PAYMENT_ID + TILDA + EMPTY_PARAM;
		} else {
			flag = Boolean.TRUE;
		}
		if (!flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return flag;
	}
	
	public VPARequest validateVPARequest(VPARequest request ) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.FALSE;
		if (StringUtils.isBlank(request.getVpa())) {
			msg = FILED_VPA + TILDA + EMPTY_FIELD;
		} else {
			flag = Boolean.TRUE;
		}
		if (!flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

}
