package com.abc.account.dto;

import lombok.Data;

@Data
public class IFSCRequest {
	private String task;
	Essentials essentials;

}
