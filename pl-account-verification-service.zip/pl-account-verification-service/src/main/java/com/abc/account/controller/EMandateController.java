
package com.abc.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.dto.EMandatePollRequest;
import com.abc.account.dto.EMandatePollResponse;
import com.abc.account.dto.EMandateRequest;
import com.abc.account.dto.EMandateResponse;
import com.abc.account.service.EMandateService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@Tag(name = "EMandate API")
@RequestMapping(Constants.API + Constants.ONE_APP_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION
		+ Constants.PERSONAL_LOAN + Constants.ACCOUNT_VERIFICATION)
@RequiredArgsConstructor
public class EMandateController {

	@Autowired
	private EMandateService emandateService;
	
	
	/**
	 * Initiates an eMandate request using the provided {@link EMandateRequest}.
	 * This method validates the input, retrieves customer details if available,
	 * constructs an HTTP request entity, sends a POST request to the eMandate API,
	 * and handles the response, logging success or any errors encountered.
	 *
	 * @param eMandateRequest The {@link EMandateRequest} object containing the eMandate details.
	 * @return A {@link ResponseEntity} containing the {@link EMandateResponse} from the API call.
	 * @throws Exception If the input {@code eMandateRequest} is null or empty, or if account ID is not present.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
	@Operation(summary = "EMandate/NACH API", description = "")
	@ApiResponses(value = {
	        @ApiResponse(responseCode = "200", description = "Successfully retrieved the application"), 
	        @ApiResponse(responseCode = "404", description = "Unable to process")
	    })
	@PostMapping("/emandate")
	private ResponseEntity<EMandateResponse> emandate(@RequestBody EMandateRequest eMandateRequest) throws Exception {
		return emandateService.eMandate(eMandateRequest);
	}
	
	/**
	 * Handles callback responses for eMandate polling.
	 * Validates the incoming {@link EMandatePollResponse}, retrieves API status,
	 * logs request and response details, and saves the callback response status.
	 * 
	 * @param pollResponse The {@link EMandatePollResponse} containing callback data.
	 * @return A {@link ResponseEntity} indicating the success of the callback handling.
	 * @throws Exception If the {@code pollResponse} is null, lacks required fields,
	 *                         or if details associated with the token ID are not found.
	 */
	@PostMapping("/callback/emandate")
	private ResponseEntity<Object> callbackEMandate(@RequestBody EMandatePollResponse pollResponse) throws Exception {
		return emandateService.callbackEMandate(pollResponse);
	}
	
	/**
	 * Initiates eMandate polling by sending a request to the eMandate service endpoint.
	 * Validates the incoming {@link EMandatePollRequest}, sends the HTTP request,
	 * and processes the response to save the API success status and audit customer details.
	 * 
	 * @param eMandatePollRequest The {@link EMandatePollRequest} containing polling data.
	 * @return An {@link EMandatePollResponse} object representing the response from the eMandate service.
	 * @throws Exception If the {@code eMandatePollRequest} is null or empty.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
	@PostMapping("/emandate/poll")
	private EMandatePollResponse eMandatePolling(@RequestBody EMandatePollRequest eMandatePollRequest) throws Exception {
		return emandateService.eMandatePolling(eMandatePollRequest);
	}
	
	/**
	 * Retrieves eMandate data for a specific customer and account ID.
	 * Initiates eMandate polling if no existing data is found in the API status repository,
	 * otherwise retrieves and parses the stored response JSON.
	 *
	 * @param customerId The customer ID for whom eMandate data is requested.
	 * @param accountId The account ID associated with the customer.
	 * @return A {@link ResponseEntity} containing {@link EMandatePollResponse} object representing
	 *         the retrieved eMandate data or status.
	 * @throws Exception If there's an issue with the HTTP request or response parsing.
	 */
	@GetMapping("/emandatedata/{customerId}/{accountId}")
	private ResponseEntity<EMandatePollResponse> getEManadateData(@PathVariable String customerId, @PathVariable String accountId) throws Exception {		
		return emandateService.getEMandateData(customerId,accountId);
	}
}
