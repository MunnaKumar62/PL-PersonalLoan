package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VPAResponse {

	@JsonProperty("vpa")
	private String vpa;

	@JsonProperty("success")
	private boolean success;

	@JsonProperty("customer_name")
	private String customerName;
}
