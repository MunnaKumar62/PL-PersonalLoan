package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BankAccount {

	@JsonProperty("beneficiary_name")
	private String beneficiaryName;

	@JsonProperty("account_number")
	private String accountNumber;

	@JsonProperty("account_type")
	private String accountType;

	@JsonProperty("ifsc_code")
	private String ifscCode;
}
