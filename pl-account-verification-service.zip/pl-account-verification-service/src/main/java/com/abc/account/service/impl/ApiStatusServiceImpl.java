package com.abc.account.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.account.entity.ApiStatus;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.service.ApiStatusService;

@Service
public class ApiStatusServiceImpl implements ApiStatusService {

	@Autowired
	APIStatusRepository apiStatusRepo;

	@Override
	public 
		ApiStatus findByAccountIdAndApiName(String accountId, String apiName, Boolean active) {

		return apiStatusRepo.findByAccountIdAndApiNameAndActive(accountId, apiName, active);
	}

	@Override
	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus) {

		return apiStatusRepo.save(apiStatus);
	}
	@Override
	public ApiStatus findByTransactionIdAndApiName(String transactionId, String apiName, Boolean active) {
		
		return apiStatusRepo.findByTransactionIdAndApiNameAndActive(transactionId, apiName, active);
	}
}
