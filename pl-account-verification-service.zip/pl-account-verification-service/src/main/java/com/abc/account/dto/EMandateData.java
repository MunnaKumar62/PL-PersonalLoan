package com.abc.account.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EMandateData {
	
	private String code;
	private String description;
	private String errorType;
	private String requestId;
	private String short_url;

}
