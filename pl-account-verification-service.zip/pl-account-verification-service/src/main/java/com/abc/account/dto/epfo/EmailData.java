package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailData {

	@JsonProperty("disposable")
	public Boolean disposable;

	@JsonProperty("webmail")
	public Boolean webmail;

	@JsonProperty("result")
	public String result;

	@JsonProperty("acceptAll")
	public Boolean acceptAll;

	@JsonProperty("smtpCheck")
	public Boolean smtpCheck;

	@JsonProperty("regexp")
	public Boolean regexp;

	@JsonProperty("mxRecords")
	public Boolean mxRecords;

	@JsonProperty("email")
	public String email;

	@JsonProperty("genericEmail")
	public Boolean genericEmail;
}
