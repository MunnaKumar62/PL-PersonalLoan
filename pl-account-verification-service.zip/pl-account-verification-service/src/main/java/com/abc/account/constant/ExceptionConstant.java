package com.abc.account.constant;

import lombok.Getter;

@Getter
public enum ExceptionConstant {

	FAILED_TO_GET_API_RESPONSE("Failed to get API Response", 1012),
	FAILED_TO_FETCH_USER("Failed to find user, User not found", 1002),
	FAILED_TO_UPDATE_USER("Failed to update user", 1003),
	FAILED_TO_GET_USER_CONSENT("Failed to get User Consent", 1004),
	FAILED_TO_CREATE_USER_IN_FIREBASE("Failed to create user in firebase", 1012),
	FIREBASE_ADMIN_USER_NOT_FOUND("Admin user not found on firebase", 1013),
	FAILED_TO_GET_PROFILE("Failed to get Profile, Profile not found for the User", 1016),;
	private final String message;
	private final Integer code;

	ExceptionConstant(String message, Integer code) {
		this.code = code;
		this.message = message;
	}

}
