package com.abc.account.request;

import com.abc.account.dto.aggregator.ReportStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReportGenerationCallbackRequest {

	@JsonProperty("reportStatus")
	public ReportStatus reportStatus;
	
	@JsonProperty("txnId")
	public String txnId;
	
	@JsonProperty("status")
	public String status;
}
