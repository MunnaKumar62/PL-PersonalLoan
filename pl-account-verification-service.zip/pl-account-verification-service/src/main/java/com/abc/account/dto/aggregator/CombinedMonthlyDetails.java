package com.abc.account.dto.aggregator;

import java.util.Date;

import com.abc.account.constant.Constants;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CombinedMonthlyDetails {

	@JsonProperty("monthName")
	private String monthName;

	@JsonProperty("startDate")
	@JsonFormat(pattern = Constants.DATE_FORMAT, shape = JsonFormat.Shape.STRING)
	private Date startDate;
}
