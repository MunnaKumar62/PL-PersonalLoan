package com.abc.account.dto.plprefio;

import java.util.List;

import com.abc.account.dto.bre.AccountXn;
import com.abc.account.dto.bre.CombinedAccountXn;
import com.abc.account.dto.bre.CombinedBusinessCreditXn;
import com.abc.account.dto.bre.CombinedMonthlyDetail;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PerfiosReportResponse {
    @JsonProperty("customerInfo")
    private CustomerInfo customerInfo;

    @JsonProperty("accountAnalysis")
    private List<AccountAnalysis> accountAnalysis;

    @JsonProperty("combinedAccountXns")
    private List<CombinedAccountXn> combinedAccountXns;

    @JsonProperty("combinedMonthlyDetails")
    private List<CombinedMonthlyDetail> combinedMonthlyDetails;

    @JsonProperty("combinedTransferFromToIGXns")
    private List<CombinedTransferFromToIGXn> combinedTransferFromToIGXns;

    @JsonProperty("combinedSundayXns")
    private List<CombinedSundayXn> combinedSundayXns;

    @JsonProperty("combinedBusinessCreditXns")
    private List<CombinedBusinessCreditXn> combinedBusinessCreditXns;

    @JsonProperty("accountXns")
    private List<AccountXn> accountXns;

    @JsonProperty("additionalMonthlyDetails")
    private AdditionalMonthlyDetails additionalMonthlyDetails;

    @JsonProperty("additionalRelatedPartyDetails")
    private AdditionalRelatedPartyDetails additionalRelatedPartyDetails;

}
