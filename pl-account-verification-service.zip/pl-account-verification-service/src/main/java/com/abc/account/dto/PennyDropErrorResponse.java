package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@lombok.Data
@Builder
public class PennyDropErrorResponse {

    @JsonProperty("error")
    public String error;

    @JsonProperty("responseStatus")
    public String responseStatus;
}