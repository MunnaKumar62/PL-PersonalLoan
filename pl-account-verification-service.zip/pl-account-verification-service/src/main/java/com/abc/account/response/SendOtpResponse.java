package com.abc.account.response;

import lombok.Data;

@Data
public class SendOtpResponse {
	
	private String responseStatus;

}
