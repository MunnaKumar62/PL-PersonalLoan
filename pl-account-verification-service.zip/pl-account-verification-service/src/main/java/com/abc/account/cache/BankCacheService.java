package com.abc.account.cache;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.account.dto.PLBankDto;
import com.abc.account.entity.PLBank;
import com.abc.account.repo.BankRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BankCacheService {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	private static final String BANK_CACHE = "PLBank";
	private static final String CACHE_PARAM = "bankName";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	BankRepository bankRepository;

	public List<PLBankDto> getBankListFromCache() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		List<PLBankDto> list = null;
		try {
			String jsonInput = redisCacheProvider.getData(BANK_CACHE, CACHE_PARAM);
			if (StringUtils.isNotBlank(jsonInput)) {
				list = mapper.readValue(jsonInput, new TypeReference<List<PLBankDto>>() {
				});
			}
			if (null == list || list.isEmpty()) {
				log.info(className + methodName + "[Reading from Database]");
				list = readFromDatabase();
			}

		} catch (Exception ex) {
			log.error(className + methodName + "[EXCEPTION]" + "[" + ex.getMessage() + "]");
			list = readFromDatabase();
		}
		return list;
	}

	public void addBankListToCache(List<PLBankDto> list) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			redisCacheProvider.addData(BANK_CACHE, CACHE_PARAM, mapper.writeValueAsString(list));

		} catch (Exception ex) {
			log.error(className + methodName + "[EXCEPTION]" + "[" + ex.getMessage() + "]");
		}
	}
	
	public List<PLBankDto> readFromDatabase() {
		
		List<PLBank> list1 = bankRepository.findAll();

		List<PLBankDto> list = list1.stream()
				.map(p -> PLBankDto.builder().bankId(p.getBankId()).name(p.getName())
						.fullName(p.getFullName()).aaAvailable(p.getAaAvailable()).netbankingAvailable(p.getNetbankingAvailable())
						.fipMapping(p.getFipMapping()).netbankingMapping(p.getNetbankingMapping()).logoUrl(p.getLogoUrl())
						.topPriorityBank(p.getTopPriorityBank()).build())
				.collect(Collectors.toList());

		addBankListToCache(list);
		
		return list;
		
	}
}
