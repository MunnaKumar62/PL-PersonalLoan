package com.abc.account.dto.bre;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class PerfiosInputJson {
	private List<CombinedBusinessCreditXn> combinedBusinessCreditXns;
	private List<CombinedAccountXn> combinedAccountXns;
	@JsonProperty("AdditionalRelatedPartyDetails")
	private AdditionalRelatedPartyDetails additionalRelatedPartyDetails;
	private List<CombinedMonthlyDetail> combinedMonthlyDetails;
	private List<CombinedLoanDisbursalXn> combinedLoanDisbursalXns;
	private List<AccountXn> accountXns;
	private List<AccountAnalysis> accountAnalysis;
	private List<CombinedRegularCreditXn> combinedRegularCreditXns;
	private CustomerInfo customerInfo;
	private List<CombinedRegularDebitXn> combinedRegularDebitXns;
	@JsonProperty("AdditionalMonthlyDetails")
	private AdditionalMonthlyDetails additionalMonthlyDetails;
}