package com.abc.account.util;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.abc.account.response.AdditionalDetailsErrors;
import com.abc.account.response.AdditionalDetailsErrorsResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class AdditionalDetailsErrorResponseUtil {
	private final ObjectMapper objectMapper;

	public Object internalServerErrorPartnerResponse() {
		AdditionalDetailsErrors internalError = AdditionalDetailsErrors.builder().errorCode("INTERNAL_SERVER_ERROR").errorType("Partner Issue")
				.message("Something went Wrong, please try after sometime.").build();
		return AdditionalDetailsErrorsResponse.builder().timestamp(LocalDateTime.now()).status("ERROR").errors(internalError).build();
	}

	public Object badRequestErrorResponse(HttpClientErrorException ex) throws JsonProcessingException {
		JsonNode errorResponseNode = objectMapper.readTree(ex.getResponseBodyAsString());
		JsonNode errorNode = errorResponseNode.path("error");

		AdditionalDetailsErrorsResponse errorResponse = null;
		if (!errorNode.isMissingNode()) {
			String status = errorResponseNode.path("responseStatus").asText();
			String errorCode = errorNode.path("code").asText();
			String message = errorNode.path("description").asText();

			AdditionalDetailsErrors error = AdditionalDetailsErrors.builder().errorCode(errorCode).errorType("Partner Issue").message(message).build();
			errorResponse = AdditionalDetailsErrorsResponse.builder().timestamp(LocalDateTime.now()).status(status).errors(error)
					.build();
		}
		return errorResponse;
	}
}
