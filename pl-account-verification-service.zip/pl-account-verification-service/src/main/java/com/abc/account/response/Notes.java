package com.abc.account.response;

public class Notes {

}
