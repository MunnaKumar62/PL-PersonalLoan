package com.abc.account.service.biz;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.dto.PLBankDto;
import com.abc.account.exception.InternalException;
import com.abc.account.request.BreRequest;
import com.abc.account.request.ConsentInitRequest;
import com.abc.account.request.InteractiveLinkRequest;
import com.abc.account.request.PLBankRequest;
import com.abc.account.request.ReportGenerationRequest;
import com.abc.account.request.RetrieveTnxRequest;
import com.abc.account.request.TransactionStatusRequest;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class AccountAggregatorBizService implements Constants, MessageConstants {

	public ReportGenerationRequest validateReportRequest(ReportGenerationRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getRequestId())) {
				msg = FILED_REQ_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public TransactionStatusRequest validateTransactionStatusRequest(TransactionStatusRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getRequestId())) {
				msg = FILED_REQ_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public ConsentInitRequest validateConsentInitRequest(ConsentInitRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getApplicationId())) {
				msg = FILED_APPLICATION_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getMobileNumber())) {
				msg = FILED_MOB_NO + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getPanNumber())) {
				msg = FILED_PAN_NUM + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getProfileId())) {
				msg = FILED_PFOFILE_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public BreRequest validateBreRequest(BreRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getApplicationId())) {
				msg = FILED_APPLICATION_ID + TILDA + EMPTY_FIELD;
			} else if (null == request.getLoanAmount()) {
				msg = FILED_LOAN_AMOUNT + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getCompanyName())) {
				msg = FILED_COMPANY_NAME + TILDA + EMPTY_FIELD;
			} else if (!request.isSalaried()) {
				msg = FILED_SALARIED + TILDA + MUST_SALARIED;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public RetrieveTnxRequest RetrieveTnxValidation(RetrieveTnxRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getApplicationId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getApplicationId())) {
				msg = FILED_REQ_ID + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public PLBankRequest validatePLBankRequest(PLBankRequest request) {

		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getName())) {
				msg = FILED_NAME + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getFullName())) {
				msg = FILED_FULL_NAME + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getAaAvailable())) {
				msg = FILED_AA_AVAIL + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getNetbankingAvailable())) {
				msg = FILED_NB_AVAIL + TILDA + EMPTY_FIELD;
			} else if (StringUtils.isBlank(request.getLogoUrl())) {
				msg = FILED_LOGO_URL + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public InteractiveLinkRequest createIntractiveValidation(InteractiveLinkRequest request) {
		String msg = EMPTY_REQUEST;
		boolean flag = Boolean.TRUE;
		if (null != request) {
			if (StringUtils.isBlank(request.getAccountId())) {
				msg = FILED_ACC_ID + TILDA + EMPTY_FIELD;
			} else if (null != request.getPayload() && StringUtils.isBlank(request.getPayload().getProcessingType())) {
				msg = FILED_PROCESSING_TYPE + TILDA + EMPTY_FIELD;
			} else {
				flag = Boolean.FALSE;
			}
		}
		if (flag) {
			log.info(msg);
			throw new InternalException("1000", msg);
		}
		return request;
	}

	public List<PLBankDto> searchBankList(List<PLBankDto> list, String input) {

		List<PLBankDto> list1 = list.stream().filter(p -> p.getFullName().toUpperCase().startsWith(input.toUpperCase()))
				.collect(Collectors.toList());

		return (null != list1 && !list1.isEmpty()) ? list1 : List.of();
	}
}
