package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KarzaConditions {

	@JsonProperty("nameLookup")
	public Boolean nameLookup;

	@JsonProperty("isEmployed")
	public Object isEmployed;

	@JsonProperty("uanNameMatch")
	public Object uanNameMatch;

	@JsonProperty("epfoCheck")
	public Boolean epfoCheck;

	@JsonProperty("domainCheck")
	public Boolean domainCheck;
}
