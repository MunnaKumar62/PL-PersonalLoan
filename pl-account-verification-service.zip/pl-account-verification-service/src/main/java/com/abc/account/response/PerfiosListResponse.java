package com.abc.account.response;


import lombok.Data;

@Data
public class PerfiosListResponse {

	private Institutions institutions;
	
	
	
	
	
	
}
