package com.abc.account.request;

import lombok.Data;

@Data
public class pasdata {

	 private String productType;
     private String processingType;
     private String loanType;
     private String employmentType;
     private String employerName;
     private long loanAmount;
	
}
