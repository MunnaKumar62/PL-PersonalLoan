package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Summary {

	@JsonProperty("emailParameters")
	public EmailParameters emailParameters;

	@JsonProperty("emailValid")
	public Boolean emailValid;

	@JsonProperty("nameLookup")
	public SummaryNameLookup nameLookup;

	@JsonProperty("uanLookup")
	public UanLookup uanLookup;

	@JsonProperty("waiveFi")
	public Boolean waiveFi;
}
