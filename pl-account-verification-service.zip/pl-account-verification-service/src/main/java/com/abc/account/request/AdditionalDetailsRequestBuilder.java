package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AdditionalDetailsRequestBuilder {

    //	@NotEmpty(message = "accountId can not be empty")
    @JsonProperty("accountId")
    private String accountId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    //	@NotNull(message = "annualIncome can not be null")
    @JsonProperty("annualIncome")
    private float annualIncome;

    //	@NotEmpty(message = "officeAddress can not be empty")
    @JsonProperty("officeAddress")
    private String officeAddress;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("officialEmailId")
    private String officialEmailId;

    //	@NotEmpty(message = "purposeOfLoan can not be empty")
    @JsonProperty("purposeOfLoan")
    private String purposeOfLoan;
}