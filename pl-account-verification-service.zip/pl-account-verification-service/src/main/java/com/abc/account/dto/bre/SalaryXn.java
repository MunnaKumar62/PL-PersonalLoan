package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class SalaryXn{
    private double balance;
    private String mode;
    private double amount;
    private String chqNo;
    private String date;
    private String narration;
    private String category;
}