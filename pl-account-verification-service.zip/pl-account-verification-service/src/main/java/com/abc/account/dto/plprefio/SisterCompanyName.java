package com.abc.account.dto.plprefio;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SisterCompanyName {
	@JsonProperty("namePattern")
	public NamePattern namePattern;

}
