package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employer {

	@JsonProperty("name")
	public String name;

	@JsonProperty("memberId")
	public String memberId;

	@JsonProperty("settled")
	public Object settled;

	@JsonProperty("isNameUnique")
	public Object isNameUnique;

	@JsonProperty("matchName")
	public String matchName;

	@JsonProperty("lastMonth")
	public String lastMonth;

	@JsonProperty("isRecent")
	public Object isRecent;

	@JsonProperty("isNameExact")
	public Object isNameExact;

	@JsonProperty("isEmployed")
	public Boolean isEmployed;

	@JsonProperty("nameConfidence")
	public Object nameConfidence;

	@JsonProperty("emplrScore")
	public Double emplrScore;

	@JsonProperty("uanNameMatch")
	public Boolean uanNameMatch;

}
