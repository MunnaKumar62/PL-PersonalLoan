package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IndividualMatch {

	@JsonProperty("match")
	public Boolean match;

	@JsonProperty("name")
	public String name;

	@JsonProperty("score")
	public Double score;
}
