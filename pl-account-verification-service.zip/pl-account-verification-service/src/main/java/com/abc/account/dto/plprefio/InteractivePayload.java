package com.abc.account.dto.plprefio;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class InteractivePayload {
	@JsonProperty("loanAmount")
	public int loanAmount;
	@JsonProperty("loanDuration")
	public int loanDuration;
	@JsonProperty("loanType")
	public String loanType;
	@JsonProperty("processingType")
	public String processingType;
	@JsonProperty("transactionCompleteCallbackUrl")
	public String transactionCompleteCallbackUrl;
	@JsonProperty("txnId")
	public String txnId;
	@JsonProperty("employmentType")
	public String employmentType;
	@JsonProperty("sourceSystem")
	public String sourceSystem;
	@JsonProperty("productType")
	public String productType;
	@JsonProperty("facility")
	public String facility;
	@JsonProperty("acceptancePolicy")
	public String acceptancePolicy;
	@JsonProperty("yearMonthFrom")
	public String yearMonthFrom;
	@JsonProperty("yearMonthTo")
	public String yearMonthTo;
	@JsonProperty("institutionId")
	public String institutionId;
	@JsonProperty("accountNumber")
	public String accountNumber;
	@JsonProperty("currency")
	public String currency;
	@JsonProperty("uploadingScannedStatements")
	public String uploadingScannedStatements;
	@JsonProperty("companyNames")
	public List<CompanyName> companyNames;
	@JsonProperty("returnUrl")
	public String returnUrl;
	@JsonProperty("sisterCompanyNames")
	public List<SisterCompanyName> sisterCompanyNames;
	@JsonProperty("employerName")
	public String employerName;
}
