package com.abc.account.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerifyOtpResponse {
	private String responseStatus;
	private VerifyData data;

}