package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@lombok.Data
@Builder
public class PennyDropResponse {

	@JsonProperty("responseStatus")
	public String responseStatus;

	@JsonProperty("data")
	public Data data;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("Result")
	public String result;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("Cached")
	public boolean cached;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("Max Retry Exeeded")
	public boolean maxRetryExeeded;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("Request Id")
	public String requestId;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
