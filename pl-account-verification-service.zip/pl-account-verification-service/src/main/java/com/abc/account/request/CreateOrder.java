package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateOrder {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("accountid")
	private String accountId;
	
	@JsonProperty("amount")
	private long amount;
	
	@JsonProperty("currency")
	private String currency;
	
	@JsonProperty("payment_capture")
	private Boolean paymentCapture;
	
	@JsonProperty("method")
	private String method;
	
	@JsonProperty("customer_id")
	private String customerId;

	@JsonProperty("loanId")
	private String loanId;
	
	@JsonProperty("receipt")
	private String receipt;
	
	@JsonProperty("notes")
	private CustomerNote notes;
	
	@JsonProperty("token")
	private Tokenorder token;

	@JsonProperty("abfCustomerId")
	private Long abfCustomerId;
	
}
