package com.abc.account.dto.verifly;

import lombok.Data;

@Data
public class BankTransfer{
    public String response;
    public String bankRRN;
    public String beneName;
    public String beneMMID;
    public String beneMobile;
    public String beneIFSC;
}
