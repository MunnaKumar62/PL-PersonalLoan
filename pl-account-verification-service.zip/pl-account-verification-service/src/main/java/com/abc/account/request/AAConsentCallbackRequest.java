package com.abc.account.request;

import java.util.List;

import com.abc.account.dto.aggregator.Account;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AAConsentCallbackRequest {

	@JsonProperty("txnId")
	public String txnId;
	@JsonProperty("consentStatus")
	public String consentStatus;
	@JsonProperty("accounts")
	public List<Account> accounts;
	@JsonProperty("userId")
	public String userId;
	
}
