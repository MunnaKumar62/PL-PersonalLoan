package com.abc.account.dto;

import lombok.Data;

@Data
public class Essentials {
	private String ifscCode;

}
