package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrgDomainMatch {

	@JsonProperty("domain")
	public String domain;

	@JsonProperty("match")
	public Boolean match;

	@JsonProperty("orgName")
	public String orgName;

	@JsonProperty("source")
	public String source;
}
