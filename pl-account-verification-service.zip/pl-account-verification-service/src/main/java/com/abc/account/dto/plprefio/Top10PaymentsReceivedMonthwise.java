package com.abc.account.dto.plprefio;

import lombok.Data;

@Data
public class Top10PaymentsReceivedMonthwise{
    public double amount;
    public String party;
    public String month;
}