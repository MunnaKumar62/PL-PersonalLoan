package com.abc.account.dto.bre;

import lombok.Data;

@Data
public class EmiEcsLoanAmountDetail{
    private Object amount;
    private String month;
    private Object day;
}
