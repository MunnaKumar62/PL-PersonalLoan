package com.abc.account.repo;

import java.util.List;

import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.abc.account.dto.PLCustomerDto;



@Repository
public class RedisCustomerRepository {
	
	
	 private HashOperations hashOperations;

	    private RedisTemplate redisTemplate;

	    public RedisCustomerRepository(RedisTemplate redisTemplate){
	        this.redisTemplate = redisTemplate;
	        this.hashOperations = this.redisTemplate.opsForHash();
	    }
	    
	    public void save(PLCustomerDto customer){
	        hashOperations.put("PLCustomer", customer.getAccountId(), customer);	       	        
	    }
	    
	    public List findAll(){
	        return hashOperations.values("PLCustomer");
	    }

	    public PLCustomerDto findByAccountId(String accountId){
	        return (PLCustomerDto) hashOperations.get("PLCustomer", accountId);
	    }

	    public void update(PLCustomerDto customer){
	        save(customer);
	    }
	    

}
