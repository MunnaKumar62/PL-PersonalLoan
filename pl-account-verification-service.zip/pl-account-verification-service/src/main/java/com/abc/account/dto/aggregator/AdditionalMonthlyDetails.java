package com.abc.account.dto.aggregator;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdditionalMonthlyDetails {

	@JsonProperty("MonthlyData1")
	private List<MonthlyData1> monthlyData1;

}
