package com.abc.account.request;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString
public class TnxCallBackRequest {
	    private String status;
	    private Boolean success;
	    private List<Account> accounts;
	    private String errorCode;
	    private String txnId;
}