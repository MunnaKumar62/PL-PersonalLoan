package com.abc.account.response;

import com.abc.account.request.CustomerNote;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CreateOrderResponse {

	@JsonProperty("id")
	private String id;

	@JsonProperty("notes")
	private CustomerNote notes;

	@JsonProperty("token")
	private TokenOrderResponse token;

	@JsonProperty("amount")
	private int amount;

	@JsonProperty("entity")
	private String entity;

	@JsonProperty("status")
	private String status;

	@JsonProperty("receipt")
	private String receipt;

	@JsonProperty("attempts")
	private int attempts;

	@JsonProperty("currency")
	private String currency;

	@JsonProperty("payments")
	private OrderPayments payments;

	@JsonProperty("amount_due")
	private int amountDue;

	@JsonProperty("created_at")
	private String createdAt;

	@JsonProperty("amount_paid")
	private int amountPaid;

	@JsonProperty("first_payment_amount")
	private int firstPaymentAmount;

}
