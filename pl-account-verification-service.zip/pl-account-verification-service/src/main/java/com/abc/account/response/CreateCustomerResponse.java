package com.abc.account.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CreateCustomerResponse {

	@JsonProperty("id")
	private String id;

	@JsonProperty("entity")
	private String entity;

	@JsonProperty("name")
	private String name;

	@JsonProperty("email")
	private String email;

	@JsonProperty("contact")
	private String contact;

	@JsonProperty("gstin")
	private Object gstin;

	//@JsonProperty("notes")
	//private Notes notes;

	@JsonProperty("created_at")
	private int createdAt;

}
