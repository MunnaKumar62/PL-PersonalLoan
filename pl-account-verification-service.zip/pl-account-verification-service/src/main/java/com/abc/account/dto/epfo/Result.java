package com.abc.account.dto.epfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {

	@JsonProperty("email")
	public Email email;

	@JsonProperty("nameLookup")
	public NameLookup nameLookup;

	@JsonProperty("uan")
	public List<Uan> uan;

	@JsonProperty("summary")
	public Summary summary;
}
