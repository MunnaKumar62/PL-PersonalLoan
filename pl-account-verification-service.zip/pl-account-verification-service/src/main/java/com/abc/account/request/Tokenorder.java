package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Tokenorder {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("auth_type")
    private String authType;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("max_amount")
    private long  maxAmount;

	@JsonInclude(value = Include.NON_NULL)

	@JsonProperty("expire_at")
	private String expireAt; 
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("notes")
    private CustomerNote notes;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("bank_account")
    private BankAccount bankAccount;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("frequency")
    private String frequency;
	
}
