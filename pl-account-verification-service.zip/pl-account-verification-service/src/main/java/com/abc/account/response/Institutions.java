package com.abc.account.response;

import java.util.List;


import lombok.Data;

@Data
public class Institutions {

	private List<InstitutionData>institution;
	
	
}
