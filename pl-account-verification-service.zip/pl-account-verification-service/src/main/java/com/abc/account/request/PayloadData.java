package com.abc.account.request;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PayloadData {

	

}
