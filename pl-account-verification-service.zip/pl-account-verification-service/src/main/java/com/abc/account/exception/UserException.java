package com.abc.account.exception;

import org.springframework.http.HttpStatus;

import com.abc.account.model.Error;

import lombok.Getter;

@Getter
public class UserException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	private final HttpStatus httpStatus;
	private final Error error;
	public UserException(Error error, HttpStatus httpStatus) {
		super(String.format("%s", error.getMessage()));
		this.httpStatus = httpStatus;
		this.error = error;
	}
}
