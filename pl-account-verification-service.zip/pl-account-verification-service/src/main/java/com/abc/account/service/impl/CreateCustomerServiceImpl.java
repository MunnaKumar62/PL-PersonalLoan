package com.abc.account.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.abc.account.request.*;
import com.abc.account.service.ApiStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.abc.account.constant.Constants;
import com.abc.account.entity.ApiStatus;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.response.CreateCustomerResponse;
import com.abc.account.response.CreateOrderResponse;
import com.abc.account.response.CustomerTokenResponse;
import com.abc.account.response.Item;
import com.abc.account.response.PaymentTokenResponse;
import com.abc.account.response.TokensList;
import com.abc.account.response.VPAResponse;
import com.abc.account.service.CreateCustomerService;
import com.abc.account.service.CustomerDetailsService;
import com.abc.account.service.TokenService;
import com.abc.account.service.biz.CommonBizService;
import com.abc.account.service.biz.CustomerBizService;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CreateCustomerServiceImpl extends CommonBizService implements CreateCustomerService, Constants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Value("${abfl.perfios.env}")
	private String perfEnv;
	
	@Autowired
	CustomerDetailsService customerDetailsService;

	@Value("${abfl.createcustomer.url}")
	private String createCustomerUrl;

	@Value("${abfl.createorder.url}")
	private String createorderUrl;

	@Value("${abfl.fetchTokenByPaymentId.url}")
	private String fetchTokenByPaymentIdUrl;

	@Value("${abfl.fetchTokenByCustomerId.url}")
	private String fetchTokenByCustomerIdUrl;
	
	@Value("${abfl.razorpay.vpa.url}")
	private String validateVPAUrl;
	
	@Value("${pl.createcustomer.failexisting}")
	private String failExisting;
	
	@Value("${pl.createcustomer.notekey1}")
	private String ccNoteKey1;
	
	@Value("${pl.createcustomer.notekey2}")
	private String ccNoteKey2;
	
	@Value("${pl.createorder.currency}")
	private String coCurrency;
	
	@Value("${pl.createorder.receipt}")
	private String coReceipt;
	
	@Value("${pl.createorder.emandate.maxamount}")
	private String coEmdMaxAmount;
	
	@Value("${pl.createorder.expireat}")
	private String coExpireAt;

	@Value("${pl.createorder.upi.amount}")
	private String coAmount;
	
	@Value("${pl.createorder.upi.maxamount}")
	private String coUpiMaxAmount;
	
	@Value("${pl.createorder.upi.frequency}")
	private String coFrequency;
	
	@Value("${pl.createorder.upi.recurringvalue}")
	private String coRecurringValue;
	
	@Value("${pl.createorder.upi.recurringtype}")
	private String coRecurringType;
	
	@Value("${pl.createorder.notekey1}")
	private String coNoteKey1;
	
	@Value("${pl.createorder.notekey2}")
	private String coNoteKey2;
	
	@Value("${pl.createorder.token.notekey1}")
	private String coTokenNoteKey1;
	
	@Value("${pl.createorder.token.notekey2}")
	private String coTokenNoteKey2;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private TokenService tokenService;

	@Autowired
	APIStatusRepository apiStatusRepository;

	@Autowired
	ApiStatusService apiService;

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> createCustomer(CreateCustomer request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateCreateCustomerRequest(request);
		if (request != null) {
			if (isEmptyOrNull(request.getFailExisting())) {
				request.setFailExisting(failExisting);
			}
			if (null == request.getNotes()) {
				CustomerNote notes = CustomerNote.builder().notesKey1(ccNoteKey1).notesKey2(ccNoteKey2).build();
				request.setNotes(notes);
			}
			String accountId = request.getAccountId();

			/**
			 * External API Call
			 */
			CreateCustomerRequest createCustomerRequest = new CreateCustomerRequest();
			createCustomerRequest.setName(request.getName());
			createCustomerRequest.setContact(request.getContact());
			createCustomerRequest.setEmail(request.getEmail());
			createCustomerRequest.setNotes(request.getNotes());
			createCustomerRequest.setFailExisting(request.getFailExisting());
			createCustomerRequest.setAccountId(null);

			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_CREATE_CUSTOMER).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(request.getContact()).url(createCustomerUrl)
					.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
					.request(createCustomerRequest).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, CreateCustomerResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByMobileNumber(request.getContact())
						, apiStatus, request.getLoanId(), request.getCustomerId());
			}

		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(apiResponse.getBody(), apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> createOrder(CreateOrder request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		request = bizService.validateCreateOrderRequest(request);
		if (request != null) {
			CreateOrder createOrder = null;
			// if method is upi,then create payload for UPI 
			if (request.getMethod().equalsIgnoreCase(UPI)) {

				createOrder = CreateOrder.builder().amount(Long.parseLong(coAmount)).currency(coCurrency)
						.customerId(request.getCustomerId()).method(request.getMethod()).paymentCapture(true)
						.receipt(coReceipt)
						.notes(null != request.getNotes() ? request.getNotes()
								: CustomerNote.builder().notesKey1(coNoteKey1).notesKey2(coNoteKey2).build())
						.token(Tokenorder.builder().maxAmount(Long.parseLong(coUpiMaxAmount))
								.frequency(coFrequency)
								.build())
						.build();
			} else {
				createOrder = CreateOrder.builder().amount(0).currency(coCurrency).customerId(request.getCustomerId())
						.method(request.getMethod()).paymentCapture(true).receipt(coReceipt)
						.notes(null != request.getNotes() ? request.getNotes()
								: CustomerNote.builder().notesKey1(coNoteKey1).notesKey2(coNoteKey2).build())
						.token(Tokenorder.builder().maxAmount(Long.parseLong(coEmdMaxAmount))
								.expireAt(coExpireAt)
								.notes(null != request.getToken().getNotes() ? request.getToken().getNotes()
										: CustomerNote.builder().notesKey1(coTokenNoteKey1).notesKey2(coTokenNoteKey2)
												.build())
								.bankAccount(BankAccount.builder()
										.beneficiaryName(request.getToken().getBankAccount().getBeneficiaryName())
										.accountNumber(request.getToken().getBankAccount().getAccountNumber())
										.ifscCode(request.getToken().getBankAccount().getIfscCode())
										.accountType("savings").build())
								.build())
						.build();
			}
			String accountId = request.getAccountId();

			CreateOrderRequest createOrderRequest = new CreateOrderRequest();
			createOrderRequest.setCustomerId(createOrder.getCustomerId());
			createOrderRequest.setNotes(createOrder.getNotes());
			createOrderRequest.setAmount(createOrder.getAmount());
			createOrderRequest.setCurrency(createOrder.getCurrency());
			createOrderRequest.setReceipt(createOrder.getReceipt());
			createOrderRequest.setToken(createOrder.getToken());
			createOrderRequest.setMethod(createOrder.getMethod());
			createOrderRequest.setAccountId(null);
			createOrderRequest.setPaymentCapture(createOrder.getPaymentCapture());


			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_CREATE_ORDER).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(createorderUrl)
					.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.POST)
					.request(createOrderRequest).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, CreateOrderResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatus(customerDetailsService.findByAccountId(accountId)
						, apiStatus, request.getLoanId(), request.getAbfCustomerId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(apiResponse.getBody(), apiResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> fetchTokenStatus(String paymentId, String customerId,String accountId, String loanId, Long abfCustomerId) {

		TokensList tokensLists = new TokensList();
		List<Item> items = null;
		ResponseEntity<Object> payResponse = fetchTokenByPaymentId(paymentId, customerId, accountId, loanId, abfCustomerId);
		PaymentTokenResponse paymentTokenResponse = (PaymentTokenResponse) payResponse.getBody();
		if (null != paymentTokenResponse) {
			ResponseEntity<Object> custResponse = fetchTokenByCustId(paymentId, customerId, accountId, loanId, abfCustomerId);
			CustomerTokenResponse customerTokenResponse = (CustomerTokenResponse) custResponse.getBody();
			if (null != customerTokenResponse) {
				items = customerTokenResponse.getItems().stream()
						.filter(i -> i.getId().equalsIgnoreCase(paymentTokenResponse.getTokenId())).toList();
				if (null != items && !items.isEmpty()) {
					tokensLists.setCustomerTokenStatus(items.get(0).getRecurringDetails().getStatus());
					tokensLists.setTokenid(items.get(0).getId());
				}
			}
		}
		return new ResponseEntity<>(tokensLists, HttpStatus.OK);

	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> fetchTokenByPaymentId(String paymentId, String customerId, String accountId, String loanId, Long abfCustomerId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		PaymentTokenResponse paymentTokenResponse = null;
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Map<String, Object> map = null;
		String jsonResponse = null;
		Object obj = null;
		try {
			/**
			 * Input request validation
			 */
			if (bizService.validateTokenIdRequest(paymentId, customerId)) {
				jsonResponse = apiStatusRepository.findTokenDetails(PL_TOKEN_BY_PAYMENT_ID,
						customerId, paymentId, Boolean.FALSE);
				if (!isEmptyOrNull(jsonResponse)) {
					log.info(className + methodName + PL_TOKEN_BY_PAYMENT_ID + " record is exist: " + jsonResponse);
					paymentTokenResponse = objectMapper.readValue(jsonResponse, PaymentTokenResponse.class);
					obj = paymentTokenResponse;
				} else {
					String url = fetchTokenByPaymentIdUrl + "/" + paymentId;
					/**
					 * External API Call
					 */
					ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_TOKEN_BY_PAYMENT_ID)
							.accountId(accountId).profileId(EMPTY).requestId(customerId).transactionId(paymentId).url(url)
							.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.GET)
							.request(null).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

					map = callExternalApi(commonRequest, PaymentTokenResponse.class);

					if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					}
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
						updateApiStatusByLoanId(abfCustomerId, apiStatus, loanId);
					}
					obj = apiResponse.getBody();
				}
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	public void updateApiStatusByLoanId(Long customerId, ApiStatus apiStatus, String loanId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			if (null != apiStatus) {
				apiStatus.setLoanId(loanId);
				apiStatus.setCustomerId(customerId);
				apiStatus.setModifiedBy(CREATED_BY);
				apiStatus.setModifiedDt(new Timestamp(new Date().getTime()));
			}
			apiService.savOrUpdateApiStatus(apiStatus);

		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> fetchTokenByCustId(String paymentId, String customerId, String accountId, String loanId, Long abfCustomerId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CustomerTokenResponse customerTokenResponse = null;
		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Map<String, Object> map = null;
		String jsonResponse = null;
		Object obj = null;
		try {
			/**
			 * Input request validation
			 */
			if (bizService.validateTokenIdRequest(paymentId, customerId)) {
				jsonResponse = apiStatusRepository.findTokenDetails(PL_TOKEN_BY_CUST_ID,
						customerId, paymentId,Boolean.FALSE);
				if (!isEmptyOrNull(jsonResponse)) {
					log.info(className + methodName + PL_TOKEN_BY_CUST_ID + " record is exist: " + jsonResponse);
					customerTokenResponse = objectMapper.readValue(jsonResponse, CustomerTokenResponse.class);
					obj = customerTokenResponse;
				} else {
					String url = fetchTokenByCustomerIdUrl + "/" + customerId + "/tokens";
					/**
					 * External API Call
					 */
					ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_TOKEN_BY_CUST_ID)
							.accountId(accountId).profileId(EMPTY).requestId(customerId).transactionId(paymentId).url(url)
							.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.GET)
							.request(null).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

					map = callExternalApi(commonRequest, CustomerTokenResponse.class);

					if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					}
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
						updateApiStatusByLoanId(abfCustomerId, apiStatus, loanId);
					}
					obj = apiResponse.getBody();
				}
			}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> validateVPA(VPARequest request) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Map<String, Object> map = null;
		/**
		 * Input request validation
		 */
		VPARequestBuilder vpaRequestBuilder = new VPARequestBuilder();
		request = bizService.validateVPARequest(request);
		if (request != null) {
			String accountId = request.getAccountId();
			vpaRequestBuilder.setAccountId(null);
			vpaRequestBuilder.setVpa(request.getVpa());
			/**
			 * External API Call
			 */
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_VALIDATE_VPA).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(validateVPAUrl)
					.requestHeaders(getRequestHeaders(getTokenByEnv())).method(HttpMethod.POST)
					.request(vpaRequestBuilder).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

			map = callExternalApi(commonRequest, VPAResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			}
			if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
				ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
				updateApiStatusByLoanId(request.getCustomerId(), apiStatus, request.getLoanId());
			}
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(apiResponse.getBody(), apiResponse.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> fetchUPITokenStatus(String paymentId
			, String accountId, String loanId, Long customerId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		CustomerBizService bizService = new CustomerBizService();
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Map<String, Object> map = null;
		Object obj = null;
		try {
			/**
			 * Input request validation
			 */
			if (bizService.validateUPITokenIdRequest(paymentId)) {
					String url = fetchTokenByPaymentIdUrl + "/" + paymentId+"/?expand[]=upi";
					/**
					 * External API Call
					 */
					ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_TOKEN_BY_UPI_PAYMENT_ID)
							.accountId(accountId).profileId(EMPTY).requestId(paymentId).transactionId(paymentId).url(url)
							.requestHeaders(getRequestHeaders(tokenService.getAccessToken())).method(HttpMethod.GET)
							.request(null).active(Boolean.FALSE).isAudit(Boolean.TRUE).build();

					map = callExternalApi(commonRequest, PaymentTokenResponse.class);

					if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
						apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
					}
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
						updateApiStatusByLoanId(customerId, apiStatus, loanId);
					}
					obj = apiResponse.getBody();
				}
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}
	public String getTokenByEnv() {

		String token = null;
		if (null != perfEnv && PROD.equals(perfEnv)) {
			token = tokenService.getProdAccessToken();
		} else {
			token = tokenService.getAccessToken();
		}
		return token;
	}
}
