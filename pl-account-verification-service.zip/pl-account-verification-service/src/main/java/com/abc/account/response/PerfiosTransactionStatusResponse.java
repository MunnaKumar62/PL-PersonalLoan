package com.abc.account.response;

import com.abc.account.dto.plprefio.Transactions;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class PerfiosTransactionStatusResponse {

	@JsonProperty("responseStatus")
	public String responseStatus;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("transactions")
	public Transactions transactions;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
