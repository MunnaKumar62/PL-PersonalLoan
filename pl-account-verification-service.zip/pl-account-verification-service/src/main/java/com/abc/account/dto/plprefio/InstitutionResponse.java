package com.abc.account.dto.plprefio;

import java.util.List;

import lombok.Data;

@Data
public class InstitutionResponse {
	  private List<Institution> institution;
	}
