package com.abc.account.request;

import lombok.Data;

@Data
public class Payload {

	
	private Long loanAmount;
	private long loanDuration;
	private String loanType;
	private String processingType;
	private String transactionCompleteCallbackUrl;
	private String txnId;
	private String employmentType;
	private String sourceSystem;
	private String productType;
	private String facility;
	private String employerName;
	private String acceptancePolicy;
	private String yearMonthFrom;
	private String yearMonthTo;

	
}
