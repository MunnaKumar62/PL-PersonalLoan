package com.abc.account.service;

import org.springframework.http.ResponseEntity;

import com.abc.account.request.InteractiveLinkRequest;
import com.abc.account.request.TxnCompleteCallbackRequest;

public interface PLPerfiosService {

	public ResponseEntity<Object> getInstitution(String dataSource, String processingType);
	
	public ResponseEntity<Object> createInteractiveLink(InteractiveLinkRequest request);

	public ResponseEntity<Object> getTransactionStatus(String txnid);

	public ResponseEntity<Object> getRetrieveReport(String txnid);

	public ResponseEntity<Object> getTxnCompleteCallback(String callbackType, TxnCompleteCallbackRequest request);
	
}
