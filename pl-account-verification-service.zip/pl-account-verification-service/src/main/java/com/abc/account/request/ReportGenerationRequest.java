package com.abc.account.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ReportGenerationRequest {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("accountId")
	private String accountId;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("requestId")
	private String requestId;

}
