package com.abc.account.response;

import com.abc.account.dto.aggregator.TransactionData;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class TransactionStatusResponse {
	
	@JsonProperty("responseStatus")
	private String responseStatus;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private TransactionData data;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private Error error;
}
