package com.abc.account.dto.bre;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class A8SanctionDetails {

	@JsonProperty("maxTenureConsidered")
	public double maxTenureConsidered;
	@JsonProperty("maxEmi")
	public String maxEmi;
	@JsonProperty("maxTenure")
	public String maxTenure;
	@JsonProperty("approvedBy")
	public String approvedBy;
	@JsonProperty("minLoanAmount")
	public String minLoanAmount;
	@JsonProperty("minTopup")
	public String minTopup;
	@JsonProperty("maxTopup")
	public String maxTopup;
	@JsonProperty("minTenure")
	public String minTenure;
	@JsonProperty("approvedAt")
	public String approvedAt;
	@JsonProperty("roi")
	public String roi;
	@JsonProperty("loanAmount")
	public String loanAmount;
}
