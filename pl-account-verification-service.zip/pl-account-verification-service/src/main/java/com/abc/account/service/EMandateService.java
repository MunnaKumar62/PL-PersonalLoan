package com.abc.account.service;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.abc.account.cache.CustomerCacheService;
import com.abc.account.cache.TokenCacheService;
import com.abc.account.constant.Constants;
import com.abc.account.constant.MessageConstants;
import com.abc.account.dto.EMandatePollRequest;
import com.abc.account.dto.EMandatePollResponse;
import com.abc.account.dto.EMandateRequest;
import com.abc.account.dto.EMandateResponse;
import com.abc.account.dto.PLCustomerDetailDto;
import com.abc.account.dto.PLCustomerDto;
import com.abc.account.dto.Token;
import com.abc.account.entity.ApiStatus;
import com.abc.account.exception.CustomException;
import com.abc.account.repo.APIStatusRepository;
import com.abc.account.service.biz.CommonBizService;
import com.abc.account.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

//import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Log4j2
@Service
public class EMandateService extends CommonBizService implements Constants, MessageConstants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private TokenService tokenService;

	@Value("${abfl.emandate.url}")
	private String eMandateUrl;

	@Value("${abfl.emandatepoll.url}")
	private String eMandatePollUrl;

	@Autowired
	private APIStatusRepository apiStatusRepository;

	@Autowired
	private TokenCacheService tokenCacheService;

	@Autowired
	private CustomerCacheService customerService;

	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private PLCustomerDetailService plCustomerDetailService;

	/**
	 * 
	 * @param eMandateRequest
	 * @return
	 * @throws Exception
	 */
	// @CircuitBreaker(name = "eMandate", fallbackMethod = "fallbackEMandate")
	public ResponseEntity<EMandateResponse> eMandate(EMandateRequest eMandateRequest) throws Exception {
		log.debug("Entering into eMandate");
		if (eMandateRequest == null) {
			log.error("INPUT IS NULL/EMPTY");
			throw new CustomException("INPUT IS NULL/EMPTY");
		}

		PLCustomerDto dto = PLCustomerDto.builder().build();
		EMandateResponse response = null;
		if (eMandateRequest.getAccountId() != null) {
			dto = customerService.getCustomerFromCache(eMandateRequest.getAccountId());
			log.info("PLCustomerDto=" + dto);
			/*
			 * if (dto != null) {
			 * //eMandateRequest.getCustomer().setContact(dto.getMobileNumber());
			 * //eMandateRequest.getCustomer().setEmail(dto.getEmail());
			 * eMandateRequest.getCustomer().setName(dto.getFirstname() + " " +
			 * dto.getLastname());
			 * 
			 * eMandateRequest.getSubscription_registration().getBank_account()
			 * .setBeneficiary_name(dto.getFirstname() + " " + dto.getLastname()); } else {
			 * throw new CustomException(HttpStatus.BAD_REQUEST.value(),
			 * "Failed to fetch Customer Object"); }
			 */

		} else {
			log.error("Account Id is not present!");
			throw new CustomException("Account Id not present!");
		}

		EMandateService service = new EMandateService();
		HttpEntity<Object> request = new HttpEntity<>(eMandateRequest, service.getRequestHeaders(tokenService));
		try {
			ResponseEntity<EMandateResponse> responseEntity = restTemplate.exchange(eMandateUrl, HttpMethod.POST,
					request, EMandateResponse.class);
			response = responseEntity.getBody();
			if ("SUCCESS".equalsIgnoreCase(response.getResponseStatus())) {
				log.debug("EMandate API Success");
			}
			log.debug("Returning from eMandate");
			saveApiSuccessResponse("E_MANDATE", eMandateRequest.getAccountId(), "", "",
					response.getData().getRequestId(), eMandateRequest, response);
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			saveApiErrorResponse("E_MANDATE_POLLING", eMandateRequest.getAccountId(), eMandateRequest,
					ex.getResponseBodyAsString());
			log.error("E_MANDATE_POLLING=" + ex.getResponseBodyAsString());
		}
		return new ResponseEntity<EMandateResponse>(response, HttpStatus.OK);
	}

	public EMandateResponse fallbackEMandate(ResourceAccessException throwable) {
		log.debug("ABFL is down");
		EMandateResponse p = new EMandateResponse();
		p.setResponseStatus(
				"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
		return p;
	}

	public EMandatePollResponse fallbackEMandateData(ResourceAccessException throwable) {
		System.out.println("ABFL is down");
		EMandatePollResponse p = new EMandatePollResponse();
		p.setResponseStatus(
				"This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
		return p;
	}

	/**
	 * 
	 * @param eMandatePollRequest
	 * @return
	 * @throws Exception
	 */
	public EMandatePollResponse eMandatePolling(EMandatePollRequest eMandatePollRequest) throws Exception {
		log.debug("Entering from eMandatePolling");
		if (eMandatePollRequest == null) {
			log.error("INPUT IS NULL/EMPTY");
			throw new CustomException("INPUT IS NULL/EMPTY");
		}

		EMandateService service = new EMandateService();

		HttpEntity<Object> request = new HttpEntity<>(eMandatePollRequest, service.getRequestHeaders(tokenService));
		EMandatePollResponse response = null;
		try {
			ResponseEntity<EMandatePollResponse> responseEntity = restTemplate.exchange(eMandatePollUrl,
					HttpMethod.POST, request, EMandatePollResponse.class);
			response = responseEntity.getBody();
			saveApiSuccessResponse("E_MANDATE_POLLING", eMandatePollRequest.getAccountId(),response.getData().getTokenId(),response.getData().getTokenId(),response.getData().getRazorpayCustid(), eMandatePollRequest,
					response);
			//PL_JOURNEY_AUDIT
			if(null!=response && null!=response.getData() && null!=response.getData().getTokenStatus()) {
				PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
				plCustomerDetailDto.setAccountId(eMandatePollRequest.getAccountId());
				plCustomerDetailDto.setEmandateStatus(response.getData().getTokenStatus());
				plCustomerDetailDto.setEmanDatetime(new Timestamp(new Date().getTime()));
				plCustomerDetailDto.setCurrentScreen("Enach Page");
				plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto, null);
			}
			
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			saveApiErrorResponse("E_MANDATE_POLLING", eMandatePollRequest.getAccountId(), eMandatePollRequest,
					ex.getResponseBodyAsString());
			log.error("E_MANDATE_POLLING="+ex.getResponseBodyAsString());

		}
		return response;
	}

	/**
	 * 
	 * @param pollResponse
	 * @return
	 */

	public ResponseEntity<Object> callbackEMandate(EMandatePollResponse pollResponse) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		Object obj = null;
		final String code = "PL2204";
		try {
			if (null == pollResponse) {
				throw new CustomException(EMPTY_REQUEST);
			} else if (null == pollResponse.getData() || isEmptyOrNull(pollResponse.getData().getTokenId())) {
				throw new CustomException(FILED_TOKEN_ID + TILDA + EMPTY_FIELD);
			} else if (isEmptyOrNull(pollResponse.getData().getTokenId())) {
				throw new CustomException(FILED_RAZP_CUST_ID + TILDA + EMPTY_FIELD);
			} else {
				apiStatus = apiStatusRepository.findByRequestIdAndApiName(pollResponse.getData().getTokenId(),
						PL_E_MANDATE_POLLING);
				requestJsonObject = objectMapper.writeValueAsString(pollResponse);
				if (apiStatus == null) {
					throw new CustomException(DETAILS_NOT_FOUND);
				} else {
					apiStatus.setResponseJson(requestJsonObject);
					apiStatusRepository.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), EMPTY);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_E_MANDATE_CALLBACK).accountId(EMPTY).profileId(EMPTY)
							.requestId(pollResponse.getData().getTokenId())
							.transactionId(pollResponse.getData().getRazorpayCustid()).requestJson(requestJsonObject)
							.responseJson(responseJsonObject).status(SUCCESS).httpStatusCode(HttpStatus.OK.value())
							.active(Boolean.FALSE).build(), null);
				}
			}
			log.info(className + methodName + END);

		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	/*
	 * public void savePollResponse(APIStatusRepository apiStatusRepository,
	 * EMandatePollResponse pollResponse, int custId, String acctId) { String
	 * responseStatus = pollResponse.getResponseStatus();
	 * 
	 * // EMandatePollResponse response = new EMandatePollResponse();
	 * 
	 * if ("SUCCESS".equalsIgnoreCase(responseStatus)) { APIStatus successStatusObj
	 * = APIStatus.builder().journey("PL").customerId(custId).accountId(acctId)
	 * .apiName("E_MANDATE_CALLBACK").httpStatusCode(200).status(responseStatus)
	 * .responseJson(json.toString()).build();
	 * apiStatusRepository.save(successStatusObj); } else { APIStatus
	 * failureStatusObj =
	 * APIStatus.builder().journey("PL").customerId(custId).accountId(acctId)
	 * .apiName("E_MANDATE_CALLBACK").status(pollResponse.getResponseStatus()).
	 * httpStatusCode(400) .responseJson(json.toString()).build();
	 * apiStatusRepository.save(failureStatusObj); } }
	 */
	/*
	 * public void saveEmandateResponse(APIStatusRepository apiStatusRepository,
	 * EMandatePollResponse pollResponse, int custId, String acctId) { String
	 * responseStatus = pollResponse.getResponseStatus();
	 * 
	 * EMandatePollResponse response = new EMandatePollResponse(); JSONObject json =
	 * pollResponse.toJSON(); if ("SUCCESS".equalsIgnoreCase(responseStatus)) {
	 * APIStatus successStatusObj =
	 * APIStatus.builder().journey("PL").customerId(custId).accountId(acctId)
	 * .apiName("E_MANDATE_CALLBACK").httpStatusCode(200).status(responseStatus)
	 * .responseJson(json.toString()).build();
	 * apiStatusRepository.save(successStatusObj); } else { APIStatus
	 * failureStatusObj =
	 * APIStatus.builder().journey("PL").customerId(custId).accountId(acctId)
	 * .apiName("E_MANDATE_CALLBACK").status(pollResponse.getResponseStatus()).
	 * httpStatusCode(400) .responseJson(json.toString()).build();
	 * apiStatusRepository.save(failureStatusObj); } }
	 */

	/**
	 * 
	 * @param customerId
	 * @param accountId
	 * @return
	 * @throws Exception
	 */
	// @CircuitBreaker(name = "eMandateData", fallbackMethod =
	// "fallbackEMandateData")
	public ResponseEntity<EMandatePollResponse> getEMandateData(String customerId, String accountId) throws Exception {
		log.debug("Entering into getEMandateData");
		int custId = Integer.parseInt(customerId);
		EMandatePollResponse response = new EMandatePollResponse();
		ApiStatus status = apiStatusRepository.findByApiNameAndCustomerIdAndAccountId("EMandate", custId, accountId);
		if (status == null) {
			Token token = tokenCacheService.getTokenFromCache("1");
			EMandateService service = new EMandateService();
			try {
				EMandatePollRequest eMandatePollRequest = EMandatePollRequest.builder().accountId(accountId).build();
				HttpEntity<Object> request = new HttpEntity<>(eMandatePollRequest,
						service.getRequestHeaders(tokenService));
				ResponseEntity<EMandatePollResponse> responseEntity = restTemplate.exchange(eMandatePollUrl,
						HttpMethod.POST, request, EMandatePollResponse.class);
				log.debug("EMandate Polling API Success");
				response = responseEntity.getBody();
				if ("SUCCESS".equalsIgnoreCase(response.getResponseStatus())) {
					log.debug("EMandate Polling API Success");
				}
				// EMandateService service = new EMandateService();
				// saveApiSuccessResponse("E_MANDATE_DATA",accountId,response, "");
				else {
					String json = status.getResponseJson();
					ObjectMapper objectMapper = new ObjectMapper();
					response = objectMapper.readValue(json, EMandatePollResponse.class);
					log.debug("Exiting from getEMandateData");
				}
			} catch (HttpClientErrorException | HttpServerErrorException ex) {
				ex.getResponseBodyAsString();
				//saveApiErrorResponse("E_MANDATEDATA",accountId,accountId,ex.getResponseBodyAsString());
				log.error("E_MANDATEDATA=" + ex.getResponseBodyAsString());
			}
		}
		return new ResponseEntity<EMandatePollResponse>(response, HttpStatus.OK);
	}

	public void saveApiSuccessResponse(String apiName, String acctId, String profileId, String requestId,
			String transactionId, Object reqestObject, Object responseObject) throws Exception {
		String resquestJsonObject = objectMapper.writeValueAsString(reqestObject);
		String responseJsonObject = objectMapper.writeValueAsString(responseObject);
		ApiStatus successStatusObj = ApiStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.profileId(profileId).requestId(requestId).transactionId(transactionId).requestJson(resquestJsonObject)
				.responseJson(responseJsonObject).status("SUCCESS").build();
		apiStatusRepository.save(successStatusObj);
	}
	
	public void saveApiErrorResponse(String apiName, String acctId, Object javaObject, String errorResponse)
			throws Exception {
		String responseJsonObject = objectMapper.writeValueAsString(javaObject);
		ApiStatus failureStatusObj = ApiStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.status("ERROR").requestJson(responseJsonObject).responseJson(errorResponse).build();
		apiStatusRepository.save(failureStatusObj);
	}

	public HttpHeaders getRequestHeaders(TokenService tokenService) throws Exception {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("auth-token", tokenService.getAccessToken());
		return headers;

	}

}
