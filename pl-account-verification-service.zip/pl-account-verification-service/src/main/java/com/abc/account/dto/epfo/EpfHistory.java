package com.abc.account.dto.epfo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EpfHistory {

	@JsonProperty("totalAmount")
	public Integer totalAmount;

	@JsonProperty("totalMembers")
	public Integer totalMembers;

	@JsonProperty("formatted_wage_month")
	public String formattedWageMonth;

	@JsonProperty("wageMonth")
	public String wageMonth;
}
