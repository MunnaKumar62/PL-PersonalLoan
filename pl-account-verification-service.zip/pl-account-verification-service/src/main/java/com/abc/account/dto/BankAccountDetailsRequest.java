package com.abc.account.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class BankAccountDetailsRequest {

	@NotEmpty(message = "Account ID cannot be Empty")
	@Schema(name = "accountId", example = "UPSELLXXXXXXXXX")
	private String accountId;

	@Schema(name = "accountNumber", example = "12345678910126")
	private String accountNumber;

	@NotEmpty(message = "IFSC Code cannot be Empty")
	@JsonProperty("IFSCCode")
	@Schema(name = "iFSCCode", example = "HDFC0000133")
	private String iFSCCode;

	@Builder.Default
	@Schema(name = "bankName", example = "HDFC Bank, India")
	private String bankName = "ABC Bank";

	@Builder.Default
	@Schema(name = "bankBranch", example = "BANGALORE J P NAGAR")
	private String bankBranch = "ABC Branch";

	@Schema(name = "email", example = "abc@gmail.com")
	private String email;

	@Builder.Default
	@Schema(name = "accountHolderName", example = "Chaitali Sonavane")
	private String accountHolderName = "";

	@Builder.Default
	@Schema(name = "nameMatchType", example = "Individual")
	private String nameMatchType = "Individual";

	@Builder.Default
	@Schema(name = "useCombinedSolution", example = "N")
	private String useCombinedSolution = "N";

	@Builder.Default
	@Schema(name = "allowPartialMatch", example = "false")
	private boolean allowPartialMatch = false;

	private ClientData clientData = new ClientData();
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("bank_consent")
	private String bankConsent;

	@JsonProperty("loanId")
	private String loanId;

	@JsonProperty("customerId")
	private Long customerId;

}
