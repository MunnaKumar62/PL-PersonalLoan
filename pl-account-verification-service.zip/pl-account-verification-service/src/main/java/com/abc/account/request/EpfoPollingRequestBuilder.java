package com.abc.account.request;

import lombok.Data;

@Data
public class EpfoPollingRequestBuilder {

    private String accountId;
}