
package com.abc.account.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.account.constant.Constants;
import com.abc.account.request.AAConsentCallbackRequest;
import com.abc.account.request.BreCallbackRequest;
import com.abc.account.request.BreRequest;
import com.abc.account.request.ConsentInitRequest;
import com.abc.account.request.PLBankRequest;
import com.abc.account.request.ReportGenerationCallbackRequest;
import com.abc.account.request.ReportGenerationRequest;
import com.abc.account.request.TransactionStatusRequest;
import com.abc.account.service.AccountAggregatorService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@Tag(name = "Account aggregator API")
@RequestMapping(Constants.API + Constants.VERSION + Constants.PERSONAL_LOAN + Constants.ACCOUNT_AGGREGATOR)
public class AccountAggregatorController extends BaseController {

	@Autowired
	private AccountAggregatorService service;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	/**
	 * This API is used to get the FIP list for particular requestId , and it is for
	 * NSTP flow.
	 * 
	 * @return Response object contains list of FIP with id, code, name, baseURL.
	 */
	@PostMapping(FIP_LIST)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getFipList() {
		auditUrl();
		return service.getFipList();
	}

	/**
	 * This API is used to get the All the Bank List , and it is for NSTP flow.
	 * 
	 * @return Response object contains bankId, name, fullName, aaAvailable,
	 *         netbankingAvailable, fipMapping netbankingMapping, logoUrl,
	 *         topPriorityBank.
	 */
	@GetMapping(BANK_LIST)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> bankList() {
		auditUrl();
		return service.bankList();
	}

	/**
	 * This API is used to save the details of bank details into t_pl_bank_list table , and it is for NSTP flow.
	 * @param request contains name, fullName, aaAvailable, netbankingAvailable, fipMapping,
	 *              netbankingMapping, logoUrl, topPriorityBank.
	 * @return Response object contains code, message, data. If code is PL2110 means SUCCESS or PL2111 means ERROR.
	 */
	@PostMapping(ADD_BANK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> addBank(@RequestBody PLBankRequest request) {
		auditUrl();
		return service.addBank(request);
	}

	/**
	 * This API is used to search bank list by bank id , and it is for NSTP flow.
	 * @param input Bank ID.
	 * @return Response object contains bankId, name, fullName, aaAvailable, netbankingAvailable, fipMapping, netbankingMapping
	 * logoUrl, topPriorityBank.
	 */
	@GetMapping(SEARCH_BANK_LIST)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> searchBankList(@PathVariable String input) {
		auditUrl();
		return service.searchBankList(input);
	}

	/**
	 * This API is used to call consent api, and it is for NSTP flow.
	 * @param request object contains applicationId, returnURL, mobileNumber, panNumber, fiTypes, fipIds, profileId.
	 * @return Response object contains the Data, Status, TimeStamp.
	 */
	@PostMapping(CONSENT_INIT)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> consentInit(@RequestBody ConsentInitRequest request) {
		auditUrl();
		return service.consentInit(request);
	}

	/**
	 * This API is used to get the transaction status of accountid, and it is for NSTP flow.
	 * @param request object contains the accountId, requestId.
	 * @return Response object contains the code, message, data.
	 */
	@PostMapping(AA_TRAN_STATUS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getTransactionStatus(@RequestBody TransactionStatusRequest request) {
		auditUrl();
		return service.getTransactionStatus(request);
	}

	/**
	 * This API method will call by external api to confirm Consent API is happened for that particular transaction id
	 * and insertion will happen in apistatus table for this callback api , and it is for NSTP flow.
	 * @param request this request pojo object contains txnId, consentStatus, accounts, userId.
	 * @return Response object contains the code, message, data.
	 */
	@PostMapping(CONSENT_CALLBACK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> consentcallback(@RequestBody AAConsentCallbackRequest request) {
		auditUrl();
		return service.consentcallback(request);
	}

	/**
	 * This API is used to generate report for particular account id, and it is for NSTP flow.
	 * @param request object contains accountId, requestId.
	 * @return Response object contains the code, message, data.
	 */
	@PostMapping(REPORT_GENERATION)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getReportGeneration(@RequestBody ReportGenerationRequest request) {
		auditUrl();
		return service.getReportGeneration(request);
	}

	/**
	 * This API is used to call BRE2 api to fetch the loan offer details of particular accountid.
	 * @param breRequest object contains the applicationId, loanAmount, companyName, salaried, income, perfiosInputJson.
	 * @return Response object contains the code, message, data.
	 */
	@PostMapping(BRE2)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> initiateBRE2(@RequestBody BreRequest breRequest) {
		auditUrl();
		return service.initiateBRE2(breRequest);
	}

	/**
	 * This API is used to get the BRE2 Polling api to fetch the loan offer status of particular accountid.
	 * @param accountId
	 * @return Response object contains the status of Polling API.
	 */
	@GetMapping(BRE2_DETAILS)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> getBRE2PollingStatus(@PathVariable String accountId) {
		auditUrl();
		return service.getBRE2PollingStatus(accountId);
	}
	/**
	 * This API method will call by external api to confirm BRE2 API is happened for that particular transaction id
	 * and insertion will happen in apistatus table for this callback api , and it is for NSTP flow.
	 * @param breCallbackRequest this request pojo object contains isRetryable, message, status, breCallBackData.
	 * @return Response object contains the code, message, data.
	 */
	@PostMapping(BRE2_CALLBACK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> callBRE2Callback(@RequestBody BreCallbackRequest breCallbackRequest) {
		auditUrl();
		return service.callBRE2Callback(breCallbackRequest);
	}

	/**
	 * This API method will generate the report for CallBack API.
	 * @param request object contains the reportStatus, txnId, status.
	 * @return Response object contains the code, message, data.
	 */
	@PostMapping(REPORT_GENERATION_CALLBACK)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> reportGenerationCallback(@RequestBody ReportGenerationCallbackRequest request) {
		auditUrl();
		return service.reportGenerationCallback(request);
	}
}
