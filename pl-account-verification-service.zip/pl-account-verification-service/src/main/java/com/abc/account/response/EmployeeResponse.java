package com.abc.account.response;

import com.abc.account.dto.EPFOError;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeResponse{
    public String responseStatus;
    public Data data;
}
