package com.abc.customer.prefilldata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlCustomerPrefilldataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
