package com.abc.customer.prefilldata;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.abc.customer.prefilldata.controller.CustomerController;
import com.abc.customer.prefilldata.model.BreCallbackRequest;
import com.abc.customer.prefilldata.serviceImp.CustomerServiceImp;

@SpringBootTest
class CustomerControllerTest {

	@InjectMocks
	private CustomerController customerController;

	@Autowired
	private CustomerServiceImp customerService;

	@BeforeEach
	public void setup() {
		customerService = mock(CustomerServiceImp.class);
		customerController = new CustomerController(customerService);
	}

	

	@Test
	public void testGetCreditCallbackSuccess() throws Exception {
		BreCallbackRequest brePollingResponse = new BreCallbackRequest();
		brePollingResponse.setData(any());

		ResponseEntity<Object> expectedResponseEntity = new ResponseEntity<>(HttpStatus.OK);

		when(customerService.saveCreditCallbackDetails(any(BreCallbackRequest.class)))
				.thenReturn(expectedResponseEntity);

		ResponseEntity<Object> responseEntity = customerController.getCreditCallback(brePollingResponse);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	}
}
