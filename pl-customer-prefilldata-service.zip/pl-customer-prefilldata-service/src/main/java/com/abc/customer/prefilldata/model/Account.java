package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Account {
	
	@Builder.Default
	@JsonProperty("AccountNumber")
	private String accountNumber = "";

}
