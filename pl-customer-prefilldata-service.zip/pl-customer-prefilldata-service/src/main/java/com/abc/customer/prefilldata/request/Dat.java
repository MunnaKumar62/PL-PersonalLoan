package com.abc.customer.prefilldata.request;

import lombok.Data;

@Data
public class Dat {
    private String type;
}