package com.abc.customer.prefilldata.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
public class BrePollingRequest {
    private String accountId;
}
