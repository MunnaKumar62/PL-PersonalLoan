package com.abc.customer.prefilldata.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Telephone {
	
	//@Builder.Default
	@JsonProperty("TelephoneNumber")
	private String telephoneNumber; //="9955735453";
	
	@Builder.Default
	@JsonProperty("TelephoneType")
	private String telephoneType="01";
	
	@Builder.Default
	@JsonProperty("TelephoneCountryCode")
	private String telephoneCountryCode="91";

}
