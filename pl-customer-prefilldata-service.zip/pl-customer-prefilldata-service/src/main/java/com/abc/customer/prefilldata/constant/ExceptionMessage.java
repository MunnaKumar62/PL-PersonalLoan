package com.abc.customer.prefilldata.constant;

public interface ExceptionMessage {

    public static final String OFFER_FREEZE_ERROR = "Unable to Update Offer Freeze Details";
    public static final String OFFER_DTLS_NOT_AVAILABLE = "Offer Details are not available for this customer";
}
