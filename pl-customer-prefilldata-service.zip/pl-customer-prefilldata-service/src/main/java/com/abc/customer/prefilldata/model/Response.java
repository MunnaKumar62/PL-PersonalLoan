package com.abc.customer.prefilldata.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@AllArgsConstructor
@Data
public class Response<T> {
    private int statusCode;
    private String message;
}
