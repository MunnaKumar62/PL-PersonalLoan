package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BreCallbackRequest {

	@JsonProperty("is_retryable")
	public boolean isRetryable;
	
	@JsonProperty("message")
	public String message;
	
	@JsonProperty("status")
	public String status;
	
	@JsonProperty("application_id")
	public String applicationId;
	
	@JsonProperty("data")
	public BreCallbackData data;
}
