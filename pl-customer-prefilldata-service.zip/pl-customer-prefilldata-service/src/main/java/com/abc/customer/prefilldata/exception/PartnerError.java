package com.abc.customer.prefilldata.exception;

import lombok.Data;

@Data
public class PartnerError {

	private ErrorDetail error;
	private String message;
	private Integer code;
	private String reason;

}

