package com.abc.customer.prefilldata.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_address")
public class AddressDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2546793369822175436L;

	@Id
	@Column(name = "id")
	private Long addressId;
	
	@Column(name = "active")
	private String active;
	
	@Column(name = "addresslineone")
	private String addressLine1;
	
	@Column(name = "addresslinetwo")
	private String addressLine2;
	
	//@Column(name ="city")
	private String city;
	
	@Column(name ="landmark")
	private String landMark;
	
	@Column(name ="pincode")
	private String pinCode;
	
	//@Column(name ="state")
	private String state;
	
	@Column(name ="typeofaddress")
	private String typeOfAddress;	
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date")
	private LocalDateTime createdDate;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;
	
	@ManyToOne	
	@JsonBackReference
	@JoinColumn(name = "customer_id")
	private CustomerDetails customerDetails;
	
	//@Column(name = "customerid")
	//private Long customerId;


}
