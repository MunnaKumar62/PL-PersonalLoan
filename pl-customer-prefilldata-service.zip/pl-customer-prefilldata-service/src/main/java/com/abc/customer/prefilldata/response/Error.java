package com.abc.customer.prefilldata.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class Error {

	private String code;
	private String errorType;
	private String description;

}
