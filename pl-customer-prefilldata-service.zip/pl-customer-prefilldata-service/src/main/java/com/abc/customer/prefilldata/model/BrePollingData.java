package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BrePollingData {

	
	public BrePollingData(String ce_status) {
		super();
		this.ce_status = ce_status;
	}

	@JsonProperty("application_id")
	private String account_id;

	private String async_id;

	@JsonProperty("cccId")
	private String ccc_id;

	@JsonProperty("emi")
	private Double min_loan_amount;

	@JsonProperty("max_requested_loan_amount")
	private Double max_loan_amount;

	@JsonProperty("min_tenure")
	private String min_tenure;

	@JsonProperty("max_tenure")
	private String max_tenure;

	@JsonProperty("roi")
	private Double roi = 0.00;
	
	@JsonProperty("approved_loan_amount")
	private Double approved_loan_amount=0.00;
	
	@JsonProperty("ce_status")
	private String ce_status;
	
	@JsonProperty("ce_callback_message")
	private String ceCallbackMessage;
	
}
