package com.abc.customer.prefilldata.repo;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.abc.customer.prefilldata.entity.ApiStatus;

import jakarta.transaction.Transactional;

public interface ApiStatusRepository extends JpaRepository<ApiStatus, Integer> {

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByAccountIdAndApiName(@Param("accountId") String accountId,@Param("apiName") String apiName);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.loanId= :loanId and a.customerId= :customerId and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByAccountIdAndApiNameAndLoanIdAndCustomerId(@Param("accountId") String accountId,@Param("apiName") String apiName, @Param("loanId") String loanId, @Param("customerId") Long customerId);

	@Query("SELECT a FROM ApiStatus a WHERE a.transactionId =:transactionId and a.apiName= :apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findByTransactionIdAndApiName(@Param("transactionId") String transactionId,@Param("apiName") String apiName);
 
	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.apiName= :apiName and a.active= :active and a.status ='SUCCESS' order by a.id desc limit 1")
	Optional<ApiStatus> findByAccountIdAndApiNameAndActive(String apiName, String accountId, Boolean active);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.loanId = :loanId and a.customerId = :customerId and a.apiName= :apiName and a.active= :active and a.status ='SUCCESS' order by a.id desc limit 1")
	Optional<ApiStatus> findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(String accountId, String loanId, Long customerId, String apiName, Boolean active);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("UPDATE ApiStatus a set a.status =:status, a.modifiedDate =:modifiedDate WHERE a.active = false AND a.accountId =:accountId AND a.apiName IN (:list) AND a.status ='SUCCESS'")
	public void updateStatusError(@Param("list") List<String> list, @Param("accountId") String accountId, @Param("status") String status, @Param("modifiedDate") Date modifiedDate);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId = :accountId AND a.loanId = :loanId AND a.customerId = :customerId AND a.apiName = :apiName AND a.status IN ('SUCCESS', 'SOFT-REJECT','DISBURSED') AND a.createdDate >= :startDate ORDER BY a.id DESC LIMIT 1")
	ApiStatus findLatestByAccountIdAndLoanIdAndCustomerIdAndApiName(@Param("accountId") String accountId, @Param("loanId") String loanId, @Param("customerId") Long customerId, @Param("apiName") String apiName,
			@Param("startDate") Date startDate);

	@Query("SELECT a FROM ApiStatus a WHERE a.accountId =:accountId and a.loanId = :loanId and a.customerId = :customerId and a.apiName= :apiName and a.status ='SUCCESS' order by a.id desc limit 1")
	ApiStatus findLatestByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(String accountId, String loanId,
			Long customerId, String apiName);

}
