package com.abc.customer.prefilldata.exception;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ExceptionResponse {
	// private final int code;
	// private final String reason;
	private Integer code;
	private String reason;
	private String errorCode;
	private String errorMessage;
	private String message;
	private String errorType;
}
