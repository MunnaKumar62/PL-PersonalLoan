package com.abc.customer.prefilldata.request;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import com.abc.customer.prefilldata.entity.ApiStatus;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.ToString;
import lombok.Builder.Default;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
@ToString
public class ApiCommonRequest {

	private Integer id;
	private String apiName;
	private String accountId;
	private String profileId;
	private String requestId;
	private String transactionId;
	private Boolean active;
	private Long customerId;

	private String url;
	private HttpHeaders requestHeaders;
	private HttpMethod method;
	private Object request;

	@Default
	private boolean isAudit = false;

	private ApiStatus apiStatus;

}
