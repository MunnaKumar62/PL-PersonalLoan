package com.abc.customer.prefilldata.exception;

import java.util.List;

import lombok.Data;

@Data
public class ErrorDetail {
	private Integer status;
	private String code;
	private String message;
	private List<ErrorItem> errors;
	private String  description;

}
