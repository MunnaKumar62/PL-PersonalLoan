package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Address {
	
	@Builder.Default
	@JsonProperty("AddressType")
	private String addressType="01";
	
	@Builder.Default
	@JsonProperty("AddressLine1")
	private String addressLine1="MALINI GODDABAJRANGBALI MANDIR LUDHIANA";
	 
	@Builder.Default
	@JsonProperty("AddressLine2")
	private String addressLine2="";
	    
	@Builder.Default
	@JsonProperty("AddressLine3")
	private String addressLine3="";
	    
	@Builder.Default
	@JsonProperty("AddressLine4")
	private String addressLine4="";
	    
	@Builder.Default
	@JsonProperty("AddressLine5")
	private String addressLine5="";
	    
	@Builder.Default
	@JsonProperty("City")
	private String city="LUDHIANA";
	    
	@Builder.Default
	@JsonProperty("PinCode")
	private String pinCode="577538";
	    
	@Builder.Default
	@JsonProperty("ResidenceType")
	private String residenceType="02";
	    
	@Builder.Default
	@JsonProperty("StateCode")
	private String stateCode="29";

}
