package com.abc.customer.prefilldata.service;

import org.springframework.http.ResponseEntity;

import com.abc.customer.prefilldata.model.PreApprovedOfferRequest;
import com.abc.customer.prefilldata.model.PreApprovedOfferResponse;
import com.abc.customer.prefilldata.request.OfferRequest;
import com.abc.customer.prefilldata.response.PreapprovedEmpOfferData;

public interface PreApprovedOfferService {
	
	public PreApprovedOfferResponse getPreApprovedOffers(PreApprovedOfferRequest preApprovedOfferRequest);
	public ResponseEntity<PreapprovedEmpOfferData> getPreapprovedEmpOffer(OfferRequest request);
	public ResponseEntity<Object> callPreapprovedEmpOffer(OfferRequest request);
	public void bqFreezeCustomer(OfferRequest request);
	public void bqNonFreezeCustomer(OfferRequest request);

}
