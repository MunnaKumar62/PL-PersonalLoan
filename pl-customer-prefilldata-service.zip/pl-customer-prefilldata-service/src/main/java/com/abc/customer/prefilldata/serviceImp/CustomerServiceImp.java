package com.abc.customer.prefilldata.serviceImp;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import com.abc.customer.prefilldata.dto.BREPollingDto;
import com.abc.customer.prefilldata.entity.*;
import com.abc.customer.prefilldata.repo.CustomerLoginRepository;
import com.abc.customer.prefilldata.request.Dat;
import com.abc.customer.prefilldata.request.LoginFcmRequest;
import com.abc.customer.prefilldata.util.Message;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.constant.MessageConstants;
import com.abc.customer.prefilldata.dto.PLCustomerDetailDto;
import com.abc.customer.prefilldata.dto.RetryConfg;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.exception.InternalException;
import com.abc.customer.prefilldata.exception.RetryException;
import com.abc.customer.prefilldata.model.Applicant;
import com.abc.customer.prefilldata.model.Applicants;
import com.abc.customer.prefilldata.model.ApplicationData;
import com.abc.customer.prefilldata.model.BreCallbackRequest;
import com.abc.customer.prefilldata.model.BrePollingData;
import com.abc.customer.prefilldata.model.BrePollingRequest;
import com.abc.customer.prefilldata.model.BrePollingResponse;
import com.abc.customer.prefilldata.model.CibilBureauRequestBuilderVO;
import com.abc.customer.prefilldata.model.CibilBureauRequestVO;
import com.abc.customer.prefilldata.model.D2CPullRequestVO;
import com.abc.customer.prefilldata.model.DecisionEngineRequest;
import com.abc.customer.prefilldata.model.Fields;
import com.abc.customer.prefilldata.model.Identifier;
import com.abc.customer.prefilldata.model.Identifiers;
import com.abc.customer.prefilldata.model.Operation;
import com.abc.customer.prefilldata.model.Operations;
import com.abc.customer.prefilldata.model.Param;
import com.abc.customer.prefilldata.model.Params;
import com.abc.customer.prefilldata.model.ServiceCibil;
import com.abc.customer.prefilldata.model.Services;
import com.abc.customer.prefilldata.model.Telephone;
import com.abc.customer.prefilldata.model.Telephones;
import com.abc.customer.prefilldata.repo.ApiStatusRepository;
import com.abc.customer.prefilldata.repo.CustomerRepository;
import com.abc.customer.prefilldata.repo.PLCustomerDetailRepository;
import com.abc.customer.prefilldata.repo.PreapprovedEmpOfferRepository;
import com.abc.customer.prefilldata.request.ApiCommonRequest;
import com.abc.customer.prefilldata.response.BreErrorResponse;
import com.abc.customer.prefilldata.response.BreErrors;
import com.abc.customer.prefilldata.service.ApiStatusService;
import com.abc.customer.prefilldata.service.CustomerService;
import com.abc.customer.prefilldata.service.PLCustomerDetailService;
import com.abc.customer.prefilldata.service.biz.CommonBizService;
import com.abc.vascredit.model.equifax.request.BrefailureRequest;
import com.abc.vascredit.model.equifax.request.EquiFaxRequest;
import com.abc.vascredit.model.equifax.request.LeadDropRequest;
import com.abc.vascredit.model.equifax.response.EquifaxResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class CustomerServiceImp extends CommonBizService implements CustomerService, Constants, MessageConstants {

	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;
	
	@Autowired
	private ObjectMapper objectMapper;

	@Value("${PL-Distance.zumbio.url}")
	private String DISTANCE_ZUMBIO_URL;

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${abfl.d2cpull.url}")
	private String d2cPullUrl;

	@Value("${abfl.cibilbureau.url}")
	private String cibilBureauUrl;

	@Value("${abfl.brewrapper.url}")
	private String brewrapperUrl;

	@Value("${abfl.creditdetails.url}")
	private String getCreditDetailsUrl;

	@Value("${pl.token.client_id}")
	private String clientId;

	@Value("${pl.token.scope}")
	private String scope;

	@Value("${pl.token.grant_type}")
	private String grantType;

	@Value("${pl.token.auth}")
	private String authToken;

	@Value("${equifax.customer_id}")
	private String eqfxCustId;

	@Value("${equifax.user_id}")
	private String eqfxUserId;

	@Value("${equifax.password}")
	private String eqfxPassword;

	@Value("${equifax.member_number}")
	private String eqfxMemNumber;

	@Value("${equifax.security_code}")
	private String eqfxSecCode;

	@Value("${equifax.product_name}")
	private String[] eqfxProductName;

	@Value("${equifax.url}")
	private String equifaxUrl;

	@Value("${equifax.prod}")
	private boolean equifaxProd;
	@Value("${equifax.token.url}")
	private String equifaxTokenUrl;
	@Value("${equifax.clientid}")
	private String equifaxClientId;
	@Value("${equifax.scope}")
	private String equifaxScope;
	@Value("${equifax.grantype}")
	private String equifaxGrantType;
	@Value("${equifax.authorization}")
	private String equifaxAuth;

	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	PreapprovedEmpOfferRepository preapprovedEmpOfferRepository;
	
	@Autowired
	PLCustomerDetailRepository pLCustomerDetailRepository;

	@Autowired
	ApiStatusService apiStatusService;
	
	@Autowired
	private ApiStatusRepository apiStatusRepository;

	@Autowired
	CustomerRepository customerRepo;

	@Autowired
	CustomerLoginRepository customerLoginRepository;

	@Autowired
	private PLCustomerDetailService plCustomerDetailService;

	@Value("${preapproved.offer.url}")
	private String preApprovedOfferUrl;
	
	@Value("${pl.retry.bredetails}")
	private String breRetryConfig;
	
	@Value("${pl.prefill.whitelist.services}")
	private String whiteListedServices;
	
	@Value("${pl.prefill.cestatus}")
	private String ceStatus;
	
	public Optional<CustomerDetails> findByMobileNumber(String mobileNumber) {
		Optional<CustomerDetails> customerDetails = customerRepo.findByMobileNumber(mobileNumber);
		return customerDetails;
	}

	public Optional<CustomerDetails> findByPanNumber(String panNumber) {
		Optional<CustomerDetails> customerDetails = customerRepo.findByMobileNumber(panNumber);
		return customerDetails;
	}
	
	public CustomerDetails findByAccountId(String accountId) {

		CustomerDetails customerDetails = new CustomerDetails();
		Optional<CustomerDetails> details = customerRepo.findByAccountId(accountId);
		if (details.isPresent()) {
			customerDetails = details.get();
		}
		return customerDetails;
	}

	// @CircuitBreaker(name = "customerService", fallbackMethod =
	// "getDistencefallback")
	public ResponseEntity<String> getDistancezumbio(Distance distance) {
		try {
			HttpHeaders headers = getRequestHeaders();
			HttpEntity<Object> entityHeader = new HttpEntity<>(distance, headers);
			ResponseEntity<String> response = restTemplate.exchange(DISTANCE_ZUMBIO_URL, HttpMethod.POST, entityHeader,
					String.class);
			log.info("response  " + response.getBody());

			/*
			 * String jsonObject = objectMapper.writeValueAsString(response);
			 * 
			 * if (jsonObject != null) { saveDistancezumbio(distance, jsonObject); } else {
			 * 
			 * jsonObject = "Something went wrong"; saveDistancezumbio(distance,
			 * jsonObject); }
			 */
			return response;
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				// saveRequest(body ,ex.getResponseBodyAsString(), requestName, accountId);
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-customerservice-HttpClientErrorException=" + ex.getResponseBodyAsString());
			throw new CustomException(code, description, errorType);
		} catch (Exception e) {
			log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new CustomException(e.getMessage());
		}

	}

	public ResponseEntity<String> getDistencefallback(Throwable throwable) {

		String res = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";

		return new ResponseEntity<>(res, HttpStatus.OK);
	}

	@Override
	public BrePollingResponse getBreDetailsStatus(String accountId, String loanId, Long customerId) throws RetryException, CustomException {

		BrePollingResponse response = null;
		CommonBizService bizService = new CommonBizService();
		List<RetryConfg> configList = bizService.getRetryConfig(breRetryConfig);
		log.info("[getBreDetailsStatus] Retry Configuration: " + breRetryConfig);
		for (RetryConfg confg : configList) {
			try {
				// External Api with Retry
				response = getBreDetailsStatusRetry(accountId, confg.getMaxAttempts(), confg.getDelay(), loanId, customerId);

				// Stop processing
				if (null != response && null != response.getData()
						&& !Constants.IN_PROGRESS.equalsIgnoreCase(response.getData().getCe_status())) {
					break;
				}
			} catch (CustomException | RetryException ex) {
				log.error("[getBreDetailsStatus] Exception: " + ex.getMessage());
			}
		}
		return response;
	}

	public BrePollingResponse getBreDetailsStatusRetry(String accountId
			, int maxAttempts
			, long backOffPeriod
			, String loanId
			, Long customerId)
			throws RetryException, CustomException {

		CommonBizService bizService = new CommonBizService();
		RetryTemplate retryTemplate = bizService.createRetryTemplate(maxAttempts, backOffPeriod);

		RetryCallback<BrePollingResponse, RetryException> retryCallback = context -> {
			// Call External Api
			ResponseEntity<Object> apiResponse = getCreditOfferDetail(accountId, loanId, customerId);

			BrePollingResponse response = (BrePollingResponse) apiResponse.getBody();
			log.info("[getBreDetailsStatusRetry] Count:: " + context.getRetryCount());

			if (response != null && (Constants.IN_PROGRESS.equalsIgnoreCase(response.getResponseStatus())
					|| (response.getData() != null
							&& Constants.IN_PROGRESS.equalsIgnoreCase(response.getData().getCe_status())))) {
				log.info("[getBreDetailsStatusRetry] Ce_status: " + response.getData().getCe_status() + "]");
				throw new RetryException(response.getResponseStatus(), response.getData());

			} else {
				String status = null != response && null != response.getData() ? response.getData().getCe_status()
						: Constants.EMPTY;
				log.info("[getBreDetailsStatus- Ce_status Changed from " + Constants.IN_PROGRESS + " To " + status);
			}

			return response;
		};

		RecoveryCallback<BrePollingResponse> recoveryCallback = context -> {
			log.info("[getBreDetailsStatusRetry] Recovery action taken");
			return new BrePollingResponse(Constants.IN_PROGRESS, new BrePollingData(Constants.IN_PROGRESS), null);
		};

		return retryTemplate.execute(retryCallback, recoveryCallback);

	}
	
	public ResponseEntity<String> getbre(Throwable throwable) {

		log.info(getClass().getCanonicalName() + " This service appears to be unavailable ");
		String res = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";

		return new ResponseEntity<>(res, HttpStatus.OK);
	}

	public ResponseEntity<String> verifyEmployment(String requestbody) throws Exception {

		// Token token = tokenCacheService.getTokenFromCache("1");
		HttpHeaders headers = getRequestHeaders();
		HttpEntity<String> verifyEmploymentHeader = new HttpEntity<>(requestbody, headers);
		String verifyEmploymentUrl = "https://wso2-apigw-uat.abfldirect.com/ABCD/VerifyEmployment/1.0/sync";
		ResponseEntity<String> response;
		log.info(" url  " + verifyEmploymentUrl);
		log.info(" verifyEmploymentHeader  " + verifyEmploymentHeader);

		try {

			response = restTemplate.exchange(verifyEmploymentUrl, HttpMethod.POST, verifyEmploymentHeader,
					String.class);

		} catch (Exception e) {

			return new ResponseEntity<String>(e.getMessage(), HttpStatus.OK);

		}

		return response;
	}

	public ResponseEntity<String> getD2cService(String requestbody) throws Exception {

		// String token = generateToken();
		HttpHeaders headers = new HttpHeaders();
		// headers.add("Content-Type", "application/json");
		// headers.add("ABFL-AG-OAuth", "Bearer " + token);

		HttpEntity<String> verifyEmploymentHeader = new HttpEntity<>(requestbody, headers);

		String verifyEmploymentUrl = "https://eportuat.equifax.co.in/cir360Report/cir360Report";

		log.info(" url  " + verifyEmploymentUrl);
		log.info(" verifyEmploymentHeader  " + verifyEmploymentHeader);

		ResponseEntity<String> response = restTemplate.exchange(verifyEmploymentUrl, HttpMethod.POST,
				verifyEmploymentHeader, String.class);

		return response;
	}

	public ResponseEntity<String> generateCIBILBureau(String requestbody) {

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "application/json");
		headers.add("x-api-key", "86WDKIoatAAMT1qedYb1Pu7rkJpor5txMO");

		HttpEntity<String> verifyEmploymentHeader = new HttpEntity<>(requestbody, headers);
		String verifyEmploymentUrl = "https://wso2-apigw-uat.abfldirect.com/transuniondecisioncentre_v2";
		ResponseEntity<String> response = restTemplate.exchange(verifyEmploymentUrl, HttpMethod.POST,
				verifyEmploymentHeader, String.class);

		return response;
	}

	@SuppressWarnings("unchecked")
	public ResponseEntity<Object> getCreditOfferDetail(String accountId, String loanId, Long customerId) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		BrePollingResponse brePollingResponse = null;
		try {
			BrePollingRequest brePollingRequest = BrePollingRequest.builder().accountId(loanId).build();
			// Get BRE_DETAILS api updated success record from api_status table
			ApiStatus apiStatus1 = apiStatusRepository.findByAccountIdAndApiNameAndLoanIdAndCustomerId(accountId, PL_BRE_DETAILS, loanId, customerId);
			// External API Call
			ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(PL_BRE_DETAILS).accountId(accountId)
					.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).url(getCreditDetailsUrl)
					.requestHeaders(getRequestHeaders(generateToken())).method(HttpMethod.POST)
					.request(brePollingRequest).isAudit(Boolean.TRUE).apiStatus(apiStatus1).build();

			map = callExternalApi(commonRequest, BrePollingResponse.class);

			if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
				apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
				if (validateResponse(apiResponse)) {
					brePollingResponse = (BrePollingResponse) apiResponse.getBody();
					// PL_JOURNEY_AUDIT
					if (null != brePollingResponse && null != brePollingResponse.getData()) {
						PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
						plCustomerDetailDto.setAccountId(accountId);
						plCustomerDetailDto.setLoanId(loanId);
						plCustomerDetailDto.setCustomerId(customerId);
						plCustomerDetailDto.setBreroi(brePollingResponse.getData().getRoi());
						plCustomerDetailDto.setBreloanAmount(brePollingResponse.getData().getApproved_loan_amount());
						plCustomerDetailDto.setBreOffertime(new Timestamp(new Date().getTime()));
						plCustomerDetailDto.setCurrentScreen("Loan Offer Page");
						plCustomerDetailDto.setBreRejectReason(brePollingResponse.getData().getCeCallbackMessage());
						plCustomerDetailDto = setBreDetailsRejectReson(plCustomerDetailDto,	brePollingResponse.getData().getCeCallbackMessage());
						plCustomerDetailDto.setCeStatus(brePollingResponse.getData().getCe_status());
						plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto);

						// PL_LEAD_UPDATE
						String ceStatus = brePollingResponse.getData().getCe_status();

						Long custId = findByAccountId(accountId).getCustomerId();



						new Thread(() -> {
							if (!isEmptyOrNull(ceStatus) && (DECLINED.equalsIgnoreCase(ceStatus)
									|| IN_PROGRESS.equalsIgnoreCase(ceStatus))) {
								LeadDropRequest leadDropRequest = LeadDropRequest.builder()
										.customer_id(String.valueOf(custId))
										.abcd_app_status_code__c(ceStatus.toUpperCase())
										.lead_Milestone__c("Loan Offer Page").build();
								plCustomerDetailService.updateLeadMileStone(leadDropRequest, accountId,	generateToken(), loanId, customerId);
							}
						}).start();
					}
					//Handled from Front end in new build
					/*if (!apiResponse.getStatusCode().equals(HttpStatus.NOT_ACCEPTABLE)
							&& apiResponse.getStatusCode().is4xxClientError()) {
						apiStatusRepository.updateStatusError(apiNameList(whiteListedServices), accountId,
								BRE_DETAILS_ERROR, new Timestamp(new Date().getTime()));
					}*/
					obj = brePollingResponse;
					if (null != map && !map.isEmpty() && null != map.get(API_STATUS)) {
						ApiStatus apiStatus = (ApiStatus) map.get(API_STATUS);
						if (null != apiResponse && null != apiResponse.getBody()) {
							brePollingResponse = (BrePollingResponse) apiResponse.getBody();
							// PL_JOURNEY_AUDIT
							if (null != brePollingResponse && null != brePollingResponse.getData()) {
								apiStatus.setRequestId(brePollingResponse.getData().getCcc_id());
								apiStatus.setTransactionId(brePollingResponse.getData().getAccount_id());
								apiStatus.setLoanId(loanId);
								apiStatus.setCustomerId(customerId);
							}
						}
						updateApiStatus(apiStatus);
					}
				} else {
					obj = apiResponse.getBody();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	@Override
	public String generateToken() {
		TokenResponse tokenResp = null;
		try {
			log.info("Generate Token Start");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam("client_id", clientId)
					.queryParam("scope", scope).queryParam("grant_type", grantType).build();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			headers.add("Authorization", "Basic " + authToken);

			HttpEntity<Object> request = new HttpEntity<>(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					request, String.class);

			tokenResp = objectMapper.readValue(responseEntity.getBody(), TokenResponse.class);

			if (Objects.isNull(tokenResp) || Objects.isNull(tokenResp.getAccessToken())) {

				throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
						// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
						HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

			}

			log.info("Token " + tokenResp.getAccessToken());
			log.info("Generate Token End");
		} catch (Exception e) {
			throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}

		return tokenResp.getAccessToken();
	}

	public ResponseEntity<String> decisionEngineConfigFallback(Throwable throwable) {

		log.info(getClass().getCanonicalName() + " This service appears to be unavailable ");
		String res = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";

		return new ResponseEntity<>(res, HttpStatus.OK);
	}

	// @CircuitBreaker(name = "customerService", fallbackMethod =
	// "decisionEngineConfigFallback")
	public ResponseEntity<String> decisionEngineConfig(String requestbody,
													   String loanId,
													   Long customerId) {
		DecisionEngineRequest tokenReq = null;
		String accountId = null, city = null, state = null, addressLine1 = null;
		String updateCity = null, updateState = null, updateAddressLine1 = null;
		String accountIdForApi = null;
		JSONObject customerReport;
		try {
			log.info("Inside decisionEngineConfig method with request body : " + requestbody);
			JSONObject jsonObject = new JSONObject(requestbody);
			accountIdForApi = jsonObject.getString("accountId");
			customerReport = jsonObject.getJSONObject("customerReport");
			city = customerReport.getJSONObject("kycInfo").getString("city");
			state = customerReport.getJSONObject("kycInfo").getString("state");
			addressLine1 = customerReport.getJSONObject("kycInfo").getString("addressLine1");
			if(StringUtils.isNotEmpty(accountIdForApi)) {
				requestbody = requestbody.replaceAll(accountIdForApi, loanId);
			}

			if(StringUtils.isNotEmpty(city)) {
				updateCity = Message.removeSpecialCharactersByRegexPattern(city, "[a-zA-Z .-_]*");
				requestbody = requestbody.replace(city, updateCity);
			}

			if(StringUtils.isNotEmpty(state)) {
				updateState = Message.removeSpecialCharactersByRegexPattern(state, "[a-zA-Z .]*");
				requestbody = requestbody.replace(state, updateState);
			}

			if(StringUtils.isNotEmpty(addressLine1)) {
				updateAddressLine1 = Message.removeSpecialCharactersForAddressLine1(addressLine1);
				requestbody = requestbody.replace(addressLine1, updateAddressLine1);
			}

			tokenReq = objectMapper.readValue(requestbody.getBytes(), DecisionEngineRequest.class);
			String token = generateToken();
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", "application/json");
			ResponseEntity<String> response = null;

			headers.add("auth-token", token);

			HttpEntity<Object> verifyEmploymentHeader = new HttpEntity<>(requestbody, headers);
			log.info("header " + verifyEmploymentHeader);
			log.info(" brewrapperUrl " + brewrapperUrl);


			response = restTemplate.exchange(brewrapperUrl, HttpMethod.POST, verifyEmploymentHeader, String.class);

			// PL_JOURNEY_AUDIT
			if (null != response && null != response.getBody()) {
				String requestJson = objectMapper.writeValueAsString(tokenReq);
				String responseJson = objectMapper.writeValueAsString(response.getBody());
				log.info(" responseJson " + responseJson);
				saveApiResponse(ApiStatus.builder().apiName(PL_DECISION_ENGINE_CONFIG).accountId(accountIdForApi)
						.loanId(loanId).customerId(customerId)
						.profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY).requestJson(requestJson)
						.responseJson(responseJson).status(SUCCESS).httpStatusCode(HttpStatus.OK.value())
						.active(Boolean.FALSE).build(), null);
				PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
				plCustomerDetailDto.setAccountId(accountIdForApi);
				plCustomerDetailDto.setLoanId(loanId);
				plCustomerDetailDto.setCustomerId(Long.valueOf(customerId));
				plCustomerDetailDto.setCeStart("Y");
				plCustomerDetailDto.setCeStartDatetime(new Timestamp(new Date().getTime()));
				plCustomerDetailDto.setCurrentScreen("Loan Offer Page");
				plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto);
			}
			
			return response;
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			try {
				saveApiErrorResponse("DECISION_ENGINE_CONFIG", accountIdForApi
						, "", "", "", Long.valueOf(customerId), loanId, requestbody,
						ex.getResponseBodyAsString());
			} catch (Exception e) {
				e.printStackTrace();
			}

			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					//Update DecisionEngineRejectReason
					auditDecisionEngineRejectReason(ex, accountIdForApi, loanId, customerId);
					
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-customerservice-HttpClientErrorException=" + ex.getResponseBodyAsString());
			throw new CustomException(code, description, errorType);
		} catch (Exception e) {
			try {
				saveApiErrorResponse("DECISION_ENGINE_CONFIG", accountIdForApi
						, "", "", ""
						, Long.valueOf(customerId), loanId, requestbody,
						e.getMessage());
			} catch (Exception e1) {

				e1.printStackTrace();
			}

			log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	private void auditDecisionEngineRejectReason(HttpStatusCodeException ex
			, String accountId
			, String loanId
			, Long customerId ) {

		StringBuilder sb = new StringBuilder();
		String rejectReason = null;
		try {
			BreErrorResponse response = objectMapper.readValue(ex.getResponseBodyAsString(), BreErrorResponse.class);
			if (null != response && null != response.getError() && null == response.getError().getErrors()) {
				sb.append(response.getError().getDescription());
			} else if (null != response && null != response.getError() && null != response.getError().getErrors()
					&& !response.getError().getErrors().isEmpty()) {
				List<BreErrors> list = response.getError().getErrors();
				for (BreErrors errors : list) {
					sb.append(errors.getDescription()).append(Constants.PIPE_SYMBOL);
				}
				sb.append(response.getError().getDescription());
			}
			rejectReason = sb.toString();
			log.info("[auditDecisionEngineRejectReason]" + rejectReason);
			if (!isEmptyOrNull(rejectReason)) {
				PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
				plCustomerDetailDto.setAccountId(accountId);
				plCustomerDetailDto.setLoanId(loanId);
				plCustomerDetailDto.setCustomerId(customerId);
				plCustomerDetailDto.setDecisionEngineRejectReason(rejectReason);
				plCustomerDetailDto.setCurrentScreen("Loan Offer Page");
				plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto);
			}
		} catch (JsonProcessingException e) {
			log.error("[auditDecisionEngineRejectReason][EXCEPTION]" + e.getMessage());
		}
	}

	private PLCustomerDetailDto setBreDetailsRejectReson(PLCustomerDetailDto dto, String reason) {
		if (!isEmptyOrNull(reason) && reason.contains(REASON)) {
			String[] arr = reason.split(REASON);
			dto.setBreRejectReason(arr[0]);
			dto.setBreSubRejectReason(reason.substring(reason.indexOf(REASON)));
		}
		return dto;
	}

	public ResponseEntity<String> generateCIBILBureauFallbacl(Throwable throwable) {

		log.info(getClass().getCanonicalName() + " This service appears to be unavailable ");
		String res = "This service appears to be unavailable. You will soon get a response from where you can resume your journey.";
		return new ResponseEntity<>(res, HttpStatus.OK);
	}

	// @CircuitBreaker(name = "customerService", fallbackMethod =
	// "generateCIBILBureauFallbacl")
	public ResponseEntity<String> generateCIBILBureauRequest(CibilBureauRequestVO cibilBureauRequestVO)
			throws Exception {

		log.info(getClass().getCanonicalName() + " ::Inside generateCIBILBureauRequest method with request body : "
				+ cibilBureauRequestVO);

		String token = generateToken();
		ResponseEntity<String> response = null;
		CibilBureauRequestBuilderVO cibilBureauRequestBuilderVO = CibilBureauRequestBuilderVO.builder().build();
		try {

			cibilBureauRequestBuilderVO.setAccountId(cibilBureauRequestVO.getAccountId());
			Fields fields = Fields.builder().build();

			Applicants applicants = Applicants.builder().build();
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("ddMMyyyy");
			Optional<CustomerDetails> customerDetails = findByMobileNumber(cibilBureauRequestVO.getMobileNumber());
			LocalDate dateOfBirth = LocalDate.now();
			String emailAddress = null, gender = null;
			if (customerDetails.isPresent()) {
				dateOfBirth = customerDetails.get().getDateOfBirth();
				emailAddress = customerDetails.get().getEmailAddress() != null ? customerDetails.get().getEmailAddress()
						: "";
				gender = customerDetails.get().getGender() != null ? customerDetails.get().getGender() : "M";
			}
			Applicant applicant = Applicant.builder().build();
			String[] splited = cibilBureauRequestVO.getName().split("\\s+");
			applicant.setApplicantFirstName(splited[0]);
			applicant.setApplicantLastName(splited[1]);
			String formattedDate = dateOfBirth.format(dateTimeFormatter);
			applicant.setDateOfBirth(formattedDate);
			applicant.setGender(gender);
			applicant.setEmailAddress(emailAddress);

			Telephones telephones = Telephones.builder().build();
			Telephone telephone = Telephone.builder().build();
			telephone.setTelephoneNumber(cibilBureauRequestVO.getMobileNumber());
			telephones.setTelephone(telephone);
			applicant.setTelephones(telephones);

			/*
			 * List<AddressDetails> addressDetails =
			 * customerDetails.get().getAddressDetails(); for(AddressDetails addressData :
			 * addressDetails) { Addresses addresses = Addresses.builder().build(); Address
			 * address = Address.builder().build();
			 * address.setAddressType(addressData.getTypeOfAddress());
			 * address.setAddressLine1(addressData.getAddressLine1());
			 * address.setAddressLine2(addressData.getAddressLine2());
			 * address.setCity(addressData.getCity());
			 * address.setPinCode(addressData.getPinCode()); addresses.setAddress(address);
			 * applicant.setAddresses(addresses); }
			 */

			Identifiers identifiers = Identifiers.builder().build();
			Identifier identifier = Identifier.builder().build();
			identifier.setIdNumber(cibilBureauRequestVO.getPanNo());
			applicant.setIdentifiers(identifiers);

			Services services = Services.builder().build();
			ServiceCibil service = ServiceCibil.builder().build();
			Operations operations = Operations.builder().build();

			Params params1 = Params.builder().build();

			List<Operation> operationList = new ArrayList<>();

			List<Param> paramsList1 = new ArrayList<>();
			Operation operation1 = Operation.builder().build();
			operation1.setName("ConsumerCIR");
			Param param1 = Param.builder().build();
			param1.setName("CibilBureauFlag");
			param1.setValue("false");
			paramsList1.add(param1);
			Param param2 = Param.builder().build();
			param2.setName("Amount");
			param2.setValue("100000");
			paramsList1.add(param2);
			Param param3 = Param.builder().build();
			param3.setName("Purpose");
			param3.setValue("05");
			paramsList1.add(param3);
			Param param4 = Param.builder().build();
			param4.setName("ScoreType");
			param4.setValue("08");
			paramsList1.add(param4);
			Param param5 = Param.builder().build();
			param5.setName("MemberCode");
			param5.setValue("NB66049998_UATC2CNPE1");
			paramsList1.add(param5);
			Param param6 = Param.builder().build();
			param6.setName("Password");
			param6.setValue("stskw@3sRldvdgytnmrogptr");
			paramsList1.add(param6);
			Param param7 = Param.builder().build();
			param7.setName("FormattedReport");
			param7.setValue("true");
			paramsList1.add(param7);
			Param param8 = Param.builder().build();
			param8.setName("GSTStateCode");
			param8.setValue("33");
			paramsList1.add(param8);
			params1.setParam(paramsList1);
			operation1.setParams(params1);
			operationList.add(operation1);
			operations.setOperation(operationList);
			Params params2 = Params.builder().build();
			List<Param> paramsList2 = new ArrayList<>();
			Operation operation2 = Operation.builder().build();
			operation2.setName("IDV");
			Param param9 = Param.builder().build();
			param9.setName("IDVerificationFlag");
			param9.setValue("false");
			paramsList2.add(param9);
			Param param10 = Param.builder().build();
			param10.setName("ConsumerConsentForUIDAIAuthentication");
			param10.setValue("N");
			paramsList2.add(param10);
			Param param11 = Param.builder().build();
			param11.setName("GSTStateCode");
			param11.setValue("33");
			paramsList2.add(param11);
			params2.setParam(paramsList2);
			operation2.setParams(params2);
			operationList.add(operation2);
			operations.setOperation(operationList);

			Params params3 = Params.builder().build();
			List<Param> paramsList3 = new ArrayList<>();
			Operation operation3 = Operation.builder().build();
			operation3.setName("FIWaiver");
			Param param12 = Param.builder().build();
			param12.setName("FIWaiver");
			param12.setValue("false");
			paramsList3.add(param11);
			params3.setParam(paramsList3);
			operation3.setParams(params3);
			operationList.add(operation3);

			operations.setOperation(operationList);
			service.setOperations(operations);
			services.setService(service);
			applicant.setServices(services);

			applicants.setApplicant(applicant);
			fields.setApplicants(applicants);
			cibilBureauRequestBuilderVO.setFields(fields);

			ApplicationData applicationData = ApplicationData.builder().build();
			Services serviceData = Services.builder().build();
			ServiceCibil serviceCibil = ServiceCibil.builder().build();
			Operations operationData = null;
			serviceCibil.setOperations(operationData);
			serviceData.setService(serviceCibil);
			applicationData.setServices(serviceData);
			fields.setApplicationData(applicationData);
			cibilBureauRequestBuilderVO.setFields(fields);

			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", "application/json");
			// headers.add("x-api-key", "86WDKIoatAAMT1qedYb1Pu7rkJpor5txMO");
			headers.add("auth-token", token);

			HttpEntity<Object> verifyEmploymentHeader = new HttpEntity<>(cibilBureauRequestBuilderVO, headers);

			response = restTemplate.exchange(cibilBureauUrl, HttpMethod.POST, verifyEmploymentHeader, String.class);
			saveApiSuccessResponse("CIBIL_BUREAU", cibilBureauRequestBuilderVO.getAccountId(), "", "", "",
					0L, "",
					cibilBureauRequestBuilderVO, response.getBody());

			log.info(getClass().getCanonicalName() + " :: End of generateCIBILBureauRequest method with response : "
					+ response.getBody());

		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			String description = ex.getMessage() + ex.getResponseBodyAsString();
			String code = "";
			String errorType = "";
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("CIBIL_BUREAU", cibilBureauRequestBuilderVO.getAccountId(), "", "", "",
					0L, "",
					cibilBureauRequestBuilderVO, response.getBody());

			if (null != ex.getResponseBodyAsString() && !ex.getResponseBodyAsString().isBlank()) {
				JSONObject errorResponse = new JSONObject(ex.getResponseBodyAsString());
				if (errorResponse.has("error")) {
					JSONObject errorObj = errorResponse.getJSONObject("error");
					errorType = errorObj.has("errorType") ? errorObj.getString("errorType") : "Partner Issue";
					description = errorObj.has("description") ? errorObj.getString("description") : "Partner Issue";
					code = errorObj.has("code") ? errorObj.getString("code") : "Partner Issue";
				} else {
					description = errorResponse.has("description") ? errorResponse.getString("description")
							: "Partner Issue";
				}
			}
			log.info("PL-customerservice-HttpClientErrorException=" + ex.getResponseBodyAsString());
			throw new CustomException(code, description, errorType);
		} catch (Exception e) {
			saveApiErrorResponse("CIBIL_BUREAU", cibilBureauRequestBuilderVO.getAccountId()
					, "", "", ""
					, 0L, ""
					, cibilBureauRequestBuilderVO, e.getMessage());
			log.info("pl-Rest-connector-Exception=" + e.getMessage());
			throw new CustomException(e.getMessage());
		}
		return response;
	}

	public ResponseEntity<Object> saveCreditCallbackDetails(BreCallbackRequest breCallbackRequest) {
		
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);
		ApiStatus apiStatus = null;
		String requestJsonObject = null;
		String responseJsonObject = null;
		String responseJsonObject1 = null;
		Object obj = null;
		final String code = "PL2205";
		try {
			if (null == breCallbackRequest) {
				throw new CustomException(EMPTY_REQUEST);
			} else if (null == breCallbackRequest.getData() || isEmptyOrNull(breCallbackRequest.getData().getAccountId())) {
				throw new CustomException(FILED_ACCOUNT_ID + TILDA + EMPTY_FIELD);
			} else {
				String accountId = breCallbackRequest.getData().getAccountId();
				String applicationId = breCallbackRequest.getApplicationId();
				apiStatus = apiStatusRepository.findByTransactionIdAndApiName(applicationId, PL_BRE_DETAILS);
				requestJsonObject = objectMapper.writeValueAsString(breCallbackRequest);
				if (apiStatus == null) {
					throw new CustomException(DETAILS_NOT_FOUND);
				} else {
					BrePollingResponse brePollingResponse = objectMapper.readValue(apiStatus.getResponseJson(), BrePollingResponse.class);
					BrePollingData brePollingData = brePollingResponse.getData();
					brePollingData.setCeCallbackMessage(breCallbackRequest.getMessage());					
					brePollingResponse.setData(brePollingData);
					responseJsonObject1 = objectMapper.writeValueAsString(brePollingResponse);
					apiStatus.setResponseJson(responseJsonObject1);
					apiStatusRepository.save(apiStatus);
					obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), EMPTY);
					responseJsonObject = objectMapper.writeValueAsString(obj);
					saveApiResponse(ApiStatus.builder().apiName(PL_BRE_DETAILS_CALLBACK)
							.accountId(apiStatus.getAccountId()).profileId(EMPTY)
							.loanId(apiStatus.getLoanId())
							.customerId(apiStatus.getCustomerId())
							.requestId(EMPTY)
							.transactionId(applicationId).requestJson(requestJsonObject)
							.responseJson(responseJsonObject).status(SUCCESS).httpStatusCode(HttpStatus.OK.value())
							.active(Boolean.FALSE).build(), null);
					
					//PL_JOURNEY_AUDIT
					if(null!= brePollingResponse && null!= brePollingResponse.getData()) {
						String accountIdFromApiStatus = apiStatus.getAccountId();
						PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
						plCustomerDetailDto.setLoanId(accountId);
						plCustomerDetailDto.setAccountId(apiStatus.getAccountId());
						plCustomerDetailDto.setBreRejectReason(breCallbackRequest.getMessage());
						plCustomerDetailDto.setCeStatus(brePollingResponse.getData().getCe_status());
						plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto);
						// PL_LEAD_UPDATE
						String ceStatus = brePollingResponse.getData().getCe_status();
						Long custId = findByAccountId(accountIdFromApiStatus).getCustomerId();
						new Thread(() -> {
						if (!isEmptyOrNull(ceStatus)
								&& (DECLINED.equalsIgnoreCase(ceStatus) || IN_PROGRESS.equalsIgnoreCase(ceStatus))) {
							LeadDropRequest leadDropRequest = LeadDropRequest.builder().customer_id(String.valueOf(custId)).abcd_app_status_code__c(ceStatus.toUpperCase())
									.lead_Milestone__c("Loan Offer Page").build();
							plCustomerDetailService.updateLeadMileStone(leadDropRequest, accountIdFromApiStatus, generateToken(), accountId, custId);
						}
						}).start();
					}
				}
			}
			log.info(className + methodName + END);

		} catch (JsonProcessingException ex) {
			ex.printStackTrace();
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> getBreDetails(String accountId, String loanId, Long customerId){
		log.debug("Start of getBreDetails");

		String jsonResponse = null;
		ApiStatus apiStatus = null;
		BrePollingResponse brePollingResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		boolean flag = Boolean.FALSE;
		Object obj = null;
		// Get BRE_DETAILS api updated success record from api_status table
		Optional<ApiStatus> apiStatusOpt = apiStatusService.findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(accountId, loanId, customerId, Constants.PL_BRE_DETAILS, Boolean.FALSE);

		if (apiStatusOpt.isPresent()) {
			apiStatus = apiStatusOpt.get();
			jsonResponse = null != apiStatus ? apiStatus.getResponseJson() : "";
			log.info("BRE_DETAILS api record is exist: " + jsonResponse);
			if (!StringUtils.isBlank(jsonResponse)) {
				try {
					brePollingResponse = objectMapper.readValue(jsonResponse, BrePollingResponse.class);
					if (null != brePollingResponse && null != brePollingResponse.getData()
							&& Constants.IN_PROGRESS.equalsIgnoreCase(brePollingResponse.getData().getCe_status())) {
						flag = Boolean.TRUE;
					}
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
			}
			obj = brePollingResponse;
		} else {
			flag = Boolean.TRUE;
		}
		if (flag) {
			// Call BRE2_POLLING Api
			apiResponse = getCreditOfferDetail(accountId, loanId, customerId);
			if (validateResponse(apiResponse)) {
				brePollingResponse = (BrePollingResponse) apiResponse.getBody();
				obj = brePollingResponse;
			} else {
				obj = apiResponse.getBody();
			}
		}
		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}

	public ApiStatus saveDistancezumbio(Distance distance, String res) {

		String jsonObject;
		try {
			jsonObject = objectMapper.writeValueAsString(distance);
			ApiStatus apiStatusRequest = ApiStatus.builder().apiName("DISTANCE_ZUMBIO")
					.accountId(distance.getAccountId())
					// .profileId(distance.getUniqueId())
					.journey("PL").responseJson(res).requestJson(jsonObject).build();
			ApiStatus apiStatus = apiStatusRepository.save(apiStatusRequest);
			log.info(getClass().getCanonicalName() + " :: saveDistancezumbio  request  response saved  : ");
			return apiStatus;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings("unused")
	private HttpHeaders getRequestHeaders() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("auth-token", generateToken());
		return headers;
	}

	public void saveApiSuccessResponse(String apiName, String acctId, String profileId, String transactionId,
									   String requestId,Long customerId, String loanId, Object reqestObject, Object responseObject) throws Exception {
		String resquestJsonObject = objectMapper.writeValueAsString(reqestObject);
		String responseJsonObject = objectMapper.writeValueAsString(responseObject);
		ApiStatus successStatusObj = ApiStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.loanId(loanId).customerId(customerId)
				.profileId(profileId).transactionId(transactionId).requestId(requestId)
				.requestJson(resquestJsonObject).responseJson(responseJsonObject).status("SUCCESS")
				.active(Boolean.FALSE).build();
		apiStatusRepository.save(successStatusObj);

	}

	public void saveApiErrorResponse(String apiName, String acctId, String profileId, String transactionId,
			String requestId, Long customerId, String loanId, Object javaObject, String errorResponse) throws Exception {
		String responseJsonObject = objectMapper.writeValueAsString(javaObject);
		ApiStatus failureStatusObj = ApiStatus.builder().journey("PL").apiName(apiName).accountId(acctId)
				.customerId(customerId).loanId(loanId)
				.status("ERROR").requestJson(responseJsonObject).responseJson(errorResponse).build();
		apiStatusRepository.save(failureStatusObj);
	}

public ResponseEntity<String> executeEquifaxAPI(D2CPullRequestVO d2cPullRequestVO) throws Exception {
		
		
		Optional<CustomerDetails> customerDetails = findByMobileNumber(d2cPullRequestVO.getMobileNumber());


		EquiFaxRequest equiFaxRequest = objectMapper.readValue(Constants.EQUIFAXREQUEST, EquiFaxRequest.class);
		equiFaxRequest.getRequestHeader().setCustomerId(eqfxCustId);
		equiFaxRequest.getRequestHeader().setUserId(eqfxUserId);
		equiFaxRequest.getRequestHeader().setPassword(eqfxPassword);
		equiFaxRequest.getRequestHeader().setMemberNumber(eqfxMemNumber);
		equiFaxRequest.getRequestHeader().setSecurityCode(eqfxSecCode);
		equiFaxRequest.getRequestHeader().setProductCode(eqfxProductName);
		equiFaxRequest.getRequestHeader()
				.setCustRefField(d2cPullRequestVO.getLoanId() + "-" + d2cPullRequestVO.getPanNo());
		equiFaxRequest.getRequestBody().setFirstName(d2cPullRequestVO.getName());
		equiFaxRequest.getRequestBody().getInquiryPhones()[0].setNumber(d2cPullRequestVO.getMobileNumber());
		equiFaxRequest.getRequestBody().getIdDetails()[0].setIdValue(d2cPullRequestVO.getPanNo());
		String json = objectMapper.writeValueAsString(equiFaxRequest);
		ResponseEntity<String> equifaxResponseEntity = null;
		try {
			ApiStatus apiStatus = apiStatusRepository.findLatestByAccountIdAndLoanIdAndCustomerIdAndApiName(customerDetails.get().getAccountId(), d2cPullRequestVO.getLoanId(), d2cPullRequestVO.getCustomerId(), "EQUIFAX",findLatestApiStatus());
					
			
			if(apiStatus==null) {
			log.info(getClass().getCanonicalName() + " :: executeEquifaxAPI request : " + json);
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(equifaxUrl).build();

			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", "application/json");
			headers.add("Accept", "*/* ");

			if (equifaxProd) {
				headers.add("auth-token", generateEquifaxToken());
			}
			HttpEntity<String> entityHeader = new HttpEntity<>(json, headers);

			equifaxResponseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, entityHeader,
					String.class);

			saveApiSuccessResponse("EQUIFAX", d2cPullRequestVO.getAccountId()
					, "", "", ""
					, d2cPullRequestVO.getCustomerId()
					, d2cPullRequestVO.getLoanId()
					, equiFaxRequest,
					equifaxResponseEntity.getBody());
			//PL_JOURNEY_AUDIT
			String value = null;
			EquifaxResponse equiFaxresponse = objectMapper.readValue(equifaxResponseEntity.getBody(),
					EquifaxResponse.class);
			if (equiFaxresponse != null && equiFaxresponse.getCcrResponse() != null
					&& equiFaxresponse.getCcrResponse().getCirReportDataList() != null
					&& equiFaxresponse.getCcrResponse().getCirReportDataList().length > 0
					&& equiFaxresponse.getCcrResponse().getCirReportDataList()[0] != null
					&& equiFaxresponse.getCcrResponse().getCirReportDataList()[0].getCirReportDataInfo() != null
					&& equiFaxresponse.getCcrResponse().getCirReportDataList()[0].getCirReportDataInfo()
							.getScoreDetails() != null
					&& equiFaxresponse.getCcrResponse().getCirReportDataList()[0].getCirReportDataInfo()
							.getScoreDetails().length > 0
					&& equiFaxresponse.getCcrResponse().getCirReportDataList()[0].getCirReportDataInfo()
							.getScoreDetails()[0] != null) {
				value = equiFaxresponse.getCcrResponse().getCirReportDataList()[0].getCirReportDataInfo()
						.getScoreDetails()[0].getValue();
			}
			if (null != value) {
				PLCustomerDetailDto plCustomerDetailDto = new PLCustomerDetailDto();
				plCustomerDetailDto.setAccountId(d2cPullRequestVO.getAccountId());
				plCustomerDetailDto.setLoanId(d2cPullRequestVO.getLoanId());
				plCustomerDetailDto.setCustomerId(d2cPullRequestVO.getCustomerId());
				plCustomerDetailDto.setCreditScore(value);
				plCustomerDetailDto.setCurrentScreen("PAN Card Page");
				plCustomerDetailService.auditCustomerDetails(plCustomerDetailDto);
			}

			log.info(getClass().getCanonicalName() + " :: inside executeEquifaxAPI method response : "
					+ equifaxResponseEntity.toString());
		}else { 
			log.info("Already the user made for the account id : {}"+customerDetails.get().getAccountId());
		    String jsonResponse = apiStatus.getResponseJson();
		    String cleanedOutput = jsonResponse.substring(1, jsonResponse.length() - 1);
		    String cleanedJsonResponse = cleanedOutput.replace("\\\"", "\"");
		    return ResponseEntity.ok()
		                         .contentType(MediaType.APPLICATION_JSON)
		                         .body(cleanedJsonResponse);
		}
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.info("pl-Rest-connector-HttpStatusCodeException=" + ex.getResponseBodyAsString());
			saveApiErrorResponse("EQUIFAX", d2cPullRequestVO.getAccountId()
					, "", "", ""
					, d2cPullRequestVO.getCustomerId()
					, d2cPullRequestVO.getLoanId()
					, equiFaxRequest,
					ex.getResponseBodyAsString());
			throw new CustomException(ex.getResponseBodyAsString());
		} catch (IOException ex) {
			throw new CustomException("Unable to connect with partner. Please try after sometime");
		}

		return equifaxResponseEntity;
	}
		
	public String generateEquifaxToken() throws JsonProcessingException {
		restTemplate.getMessageConverters().add(new org.springframework.http.converter.FormHttpMessageConverter());

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(equifaxTokenUrl)
				.queryParam("client_id", equifaxClientId).queryParam("scope", equifaxScope)
				.queryParam("grant_type", equifaxGrantType);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set("Authorization", "Basic " + equifaxAuth);

		HttpEntity<Object> request = new HttpEntity<>(headers);
		ResponseEntity<String> responseEntity = restTemplate.exchange(uriBuilder.toUriString(), HttpMethod.POST,
				request, String.class);

		TokenResponse resp = null;

		if (responseEntity.hasBody())
			resp = objectMapper.readValue(responseEntity.getBody(), TokenResponse.class);
		else
			throw new CustomException("Unable to connect with partner. Please try after sometime");
		return resp.getAccessToken();
	}
	
	@Override
	public ResponseEntity<String> initiateBRE(String requestbody, String loanId, Long customerId,String deviceId) {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		String jsonResponse = EMPTY;
		ApiStatus apiStatus = null;
		String accountId = null;
		ResponseEntity<String> decisionResponse = new ResponseEntity<>(HttpStatus.OK);
		BrePollingResponse formattedResponse = null;
		boolean flag = Boolean.FALSE;
		try {
			DecisionEngineRequest decisionEngineRequest = objectMapper.readValue(requestbody.getBytes(),
					DecisionEngineRequest.class);
			accountId = decisionEngineRequest.getAccountId();
			// Get DECISION_ENGINE_CONFIG api updated success record from api_status table
			Optional<ApiStatus> apiStatusOpt = apiStatusService.findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(accountId, loanId, customerId,
					Constants.PL_DECISION_ENGINE_CONFIG, Boolean.FALSE);

			if (apiStatusOpt.isPresent()) {
				apiStatus = apiStatusOpt.get();
				jsonResponse = apiStatus.getResponseJson();
				log.info("DECISION_ENGINE_CONFIG api record is exist: " + jsonResponse);
				if (!StringUtils.isBlank(jsonResponse) && jsonResponse.contains("SUCCESS")) {
					// If present and ResponseStatus is success then call breDetails method
					flag = Boolean.TRUE;
				}
			} else {
				
				JSONObject jsonObject = new JSONObject(requestbody);
				String accountIdForApi = jsonObject.getString("accountId");
				log.info("deviceId: "+deviceId);
				log.info("accountId: "+accountIdForApi);
				log.info("customerId: "+customerId);
				log.info("LoanId: "+loanId);;
				
				if (deviceId != null && !deviceId.trim().isEmpty()) {
					 List<String> customerIds = preapprovedEmpOfferRepository.findCustomerActivation(deviceId);
					
					 if (customerIds.size() > 1) {
						 for (String customer : customerIds) {
							 long customerIdString = Long.parseLong(customer);
							 if(customerIdString!=customerId)
							 {
							 List<Object[]> plDetails = pLCustomerDetailRepository.findPlDetails(customer);
							boolean hasGrantedStatus=false;
							 if(!plDetails.isEmpty())
					            {
					            	 hasGrantedStatus = plDetails.stream()
					            	            .anyMatch(plDetail -> "GRANTED".equalsIgnoreCase((String) plDetail[0]));
					             
					             if (hasGrantedStatus) {
					            	 ResponseEntity<String> errorResponse=buildErrorResponse("BUSINESS_RULE_ERROR", "Soft reject as disbursal from same device identified.");
					            	 saveApiResponse(ApiStatus.builder().apiName(PL_DECISION_ENGINE_CONFIG).accountId(accountIdForApi)
					 						.loanId(loanId).customerId(customerId).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY)
					 						.requestJson(requestbody).responseJson(errorResponse.getBody()).status(ERROR)
					 						.httpStatusCode(HttpStatus.PARTIAL_CONTENT.value()).active(Boolean.FALSE).build(), null);
					            	 log.info("Device id check errorResponse: "+errorResponse);
						                return buildErrorResponse("BUSINESS_RULE_ERROR", "Soft reject as disbursal from same device identified.");
						            }
					            }
							 }
							 
						 }
					 }
				}
				
				//EPFO true / false check
				
				/*int count = pLCustomerDetailRepository.countByCustomerIdAndJourneyType(customerId,accountIdForApi,loanId);
				if (count>0) {
					 ResponseEntity<String> errorResponse=buildErrorResponse("BUSINESS_RULE_ERROR", "lead drop before offer");
					saveApiResponse(ApiStatus.builder().apiName(PL_DECISION_ENGINE_CONFIG).accountId(accountIdForApi)
	 						.loanId(loanId).customerId(customerId).profileId(EMPTY).requestId(EMPTY).transactionId(EMPTY)
	 						.requestJson(requestbody).responseJson(errorResponse.getBody()).status(ERROR)
	 						.httpStatusCode(HttpStatus.PARTIAL_CONTENT.value()).active(Boolean.FALSE).build(), null);
					log.info("EPFO true / false check errorResponse: "+errorResponse);
					return buildErrorResponse("BUSINESS_RULE_ERROR", "lead drop before offer");
				}*/
				
				// If not present then call decisionEngineConfig api
				decisionResponse = decisionEngineConfig(requestbody, loanId, customerId);
				if (null != decisionResponse) {
					formattedResponse = objectMapper.readValue(decisionResponse.getBody(), BrePollingResponse.class);
					if (null != formattedResponse
							&& Constants.SUCCESS.equalsIgnoreCase(formattedResponse.getResponseStatus())) {
						log.info("decisionEngineConfig api response: " + formattedResponse.getResponseStatus());
						flag = Boolean.TRUE;
					}
				}
			}
			if (flag) {
				new Thread(() -> {
					String accId= decisionEngineRequest.getAccountId();
					// Call BRE_DETAILS (DB/API)
					try {
						Thread.sleep(3000);
						ResponseEntity<Object> apiResponse1 = getBreDetails(accId, loanId, customerId);
						if (validateResponse(apiResponse1)) {
							BrePollingResponse response = (BrePollingResponse) apiResponse1.getBody();
							if (null != response && null != response.getData()
									&& !StringUtils.isBlank(response.getData().getCe_status())
									&& Constants.IN_PROGRESS.equalsIgnoreCase(response.getData().getCe_status())) {
								log.info("Initiating Asynchronous call - breDetails api with Retry ");
								// Asynchronous call - breDetails api with Retry
								getBreDetailsStatus(accId, loanId, customerId);
							}
						}
					} catch (InterruptedException | CustomException | RetryException e) {
						e.printStackTrace();
					}
				}).start();
			}
			jsonResponse = null != formattedResponse ? objectMapper.writeValueAsString(formattedResponse)
					: jsonResponse;
		} catch (IOException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return new ResponseEntity<>(jsonResponse, decisionResponse.getStatusCode());
	}

	@Override
	public ResponseEntity<Object> brePollingJob() {
		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		BrePollingResponse brePollingResponse = null;
		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		String code = "PL2206";
		int count = 0;
		List<BREPollingDto> list = plCustomerDetailService.findByCeStatus(ceStatus);

		if (null != list && !list.isEmpty()) {
			log.info(className + methodName + "Total " + ceStatus + " Count " + list.size());
			log.info(className + methodName + "Total " + ceStatus + " Account List " + list);
			for (BREPollingDto brePollingDto : list) {
				try {
					// Call external API
					apiResponse = getCreditOfferDetail(brePollingDto.getAccountId(), brePollingDto.getLoanId(), 0L);
					if (validateResponse(apiResponse)) {
						brePollingResponse = (BrePollingResponse) apiResponse.getBody();
						if (null != brePollingResponse && null != brePollingResponse.getData()
								&& !isEmptyOrNull(brePollingResponse.getData().getCe_status())) {
							log.info(className + methodName + "After Processing " + brePollingDto.getAccountId() + "ce_status: "
									+ brePollingResponse.getData().getCe_status());
							count++;
						}
					}
				} catch (Exception ex) {
					log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
				}
			}
		}
		obj = CommonUtil.getSuccessResponse(code, env.getProperty(code), "Total Processed Count " + count);
		log.info(className + methodName + "Total Processed Count " + count);
		log.info(className + methodName + END);
		
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> getBrefailureRequest(BrefailureRequest brefailureRequest) {
		try {
			if (brefailureRequest.getAccountId() == null) {
				return ResponseEntity.badRequest().body("AccountId cannot be null");
			}

			ApiStatus apiStatusBre = apiStatusRepository.findLatestByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(
					brefailureRequest.getAccountId(), brefailureRequest.getLoanId(), brefailureRequest.getCustomerId(),
					PL_BRE_DETAILS);

			if (apiStatusBre != null) {
				apiStatusBre.setStatus("ERROR");
				apiStatusRepository.save(apiStatusBre);
			} else {
				return ResponseEntity.notFound().build();
			}

			ApiStatus apiStatusDecision = apiStatusRepository.findLatestByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(
					brefailureRequest.getAccountId(), brefailureRequest.getLoanId(), brefailureRequest.getCustomerId(),
					PL_DECISION_ENGINE_CONFIG);

			if (apiStatusDecision != null) {
				apiStatusDecision.setStatus("ERROR");
				apiStatusRepository.save(apiStatusDecision);
			} else {
				return ResponseEntity.notFound().build();
			}

			log.info("Status updated successfully for AccountId: {}, LoanId: {}, CustomerId: {}",
					brefailureRequest.getAccountId(), brefailureRequest.getLoanId(), brefailureRequest.getCustomerId());

			return ResponseEntity.ok("Status updated successfully");
		} catch (Exception e) {
			log.error("Error updating status for AccountId: {}, LoanId: {}, CustomerId: {}. Error: {}",
					brefailureRequest.getAccountId(), brefailureRequest.getLoanId(), brefailureRequest.getCustomerId(),
					e.getMessage());
			throw new InternalException(e.getMessage());
		}
	}

	private ResponseEntity<String> buildErrorResponse(String errorCode, String description) {
	    String value="{\r\n"
	    		+ "  \"error\": {\r\n"
	    		+ "    \"code\": \"BUSINESS_RULE_ERROR\",\r\n"
	    		+ "    \"description\": \""+description+"\"\r\n"
	    		+ "  },\r\n"
	    		+ "  \"responseStatus\": \"ERROR\"\r\n"
	    		+ "}";
	    return new ResponseEntity<>(value.toString(), HttpStatus.PARTIAL_CONTENT);
	}

}
