package com.abc.customer.prefilldata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TokenResponse {

  

  @JsonProperty("scope")
  //@JsonIgnoreProperties(ignoreUnknown = true)
  private String scope;

  @JsonProperty("access_token")
  private String accessToken;
  
  @JsonProperty("token_type")
  private String tokenType;
  
  @JsonProperty("expires_in")
  private String expiresIn;
}