package com.abc.customer.prefilldata.response;

import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class BqOfferResponse {
	

	@JsonProperty("Email")
	public String email;
	@JsonProperty("Name")
	public String name;
	@JsonProperty("Phone")
	public String phone;
	@JsonProperty("abc_email")
	public String abc_email;
	@JsonProperty("abc_mobile")
	public String abc_mobile;
	@JsonProperty("abcName")
	public String abc_name;
	@JsonProperty("age")
	public String age;
	@JsonProperty("blpa_fresh_repeat")
	public String blpa_fresh_repeat;
	@JsonProperty("blpa_offer_amount")
	public String blpa_offer_amount;
	@JsonProperty("blpa_ohp_waive")
	public String blpa_ohp_waive;
	@JsonProperty("blpa_pf_percentage")
	public String blpa_pf_percentage;
	@JsonProperty("blpa_roi")
	public Double blpa_roi;
	@JsonProperty("blpa_vintage_waive")
	public String blpa_vintage_waive;
	public String bureau_email;
	@JsonProperty("bureau_mobile")
	public String bureau_mobile;
	@JsonProperty("bureau_name")
	public String bureau_name;

	@JsonProperty("cc_tag")
	public String cc_tag;
	@JsonProperty("cc_validity")
	public String cc_validity;

	@JsonProperty("dob")
	public String dob;

	@JsonProperty("hl_flag")
	public String hl_flag;

	public String hl_pa_offer_amount;

	@JsonProperty("hl_roi")
	public String hl_roi;

	@JsonProperty("nonterm_li_financial_eligibility")
	public String nonterm_li_financial_eligibility;
	@JsonProperty("nonterm_li_income")
	public String nonterm_li_income;
	@JsonProperty("nonterm_li_non_finance_limit")
	public String nonterm_li_non_finance_limit;
	@JsonProperty("nonterm_li_non_medical")
	public String nonterm_li_non_medical;
	@JsonProperty("nonterm_li_pasa_values")
	public String nonterm_li_pasa_values;
	@JsonProperty("nonterm_li_status")
	public String nonterm_li_status;

	@JsonProperty("offer_1")
	public String offer_1;
	@JsonProperty("offer_2")
	public String offer_2;
	@JsonProperty("offer_3")
	public String offer_3;
	@JsonProperty("pan")
	public String pan;
	@JsonProperty("gender")

	public String gender;
	@JsonProperty("plpa_emi")
	public Double plpa_emi;
	@JsonProperty("plpa_emi_amount")
	public BigInteger plpa_emi_amount;
	@JsonProperty("plpa_fresh_repeat")
	public String plpa_fresh_repeat;
	@JsonProperty("plpa_max_eligible_tenure")
	public Integer plpa_max_eligible_tenure;
	@JsonProperty("plpa_offer_amount")
	public BigInteger plpa_offer_amount;
	@JsonProperty("plpa_pf_percentage")
	public Double plpa_pf_percentage;
	@JsonProperty("plpa_roi")
	public String plpa_roi;
	@JsonProperty("plpa_min_loan_offered")
    public BigInteger plpa_min_loan_offered;
	@JsonProperty("plpa_min_tenure")
    public Integer plpa_min_tenure;
	@JsonProperty("plpq_fresh_repeat")
	public String plpq_fresh_repeat;
	@JsonProperty("product_category_1")
	public String product_category_1;
	@JsonProperty("product_category_2")
	public String product_category_2;
	@JsonProperty("product_category_3")
	public String product_category_3;
	@JsonProperty("segment_1")
	public String segment_1;
	@JsonProperty("segment_2")
	public String segment_2;
	@JsonProperty("segment_3")
	public String segment_3;
	@JsonProperty("term_li_financial_eligibility")
	public String term_li_financial_eligibility;
	@JsonProperty("term_li_income")
	public String term_li_income;
	@JsonProperty("term_li_pasa_values")
	public String term_li_pasa_values;
	@JsonProperty("term_li_status")
	public String term_li_status;
	@JsonProperty("term_li_vfmr_eligibility")
	public String term_li_vfmr_eligibility;
	@JsonProperty("validity_1")
	public String validity_1;
	@JsonProperty("validity_2")
	public String validity_2;
	@JsonProperty("validity_3")
	public String validity_3;
}
