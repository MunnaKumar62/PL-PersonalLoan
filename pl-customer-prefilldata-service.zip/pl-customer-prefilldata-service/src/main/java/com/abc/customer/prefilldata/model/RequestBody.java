package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class RequestBody {
	
	

	@Builder.Default
	@JsonProperty("InquiryPurpose")
	private String inquiryPurpose = "00";
	
	@JsonProperty("FirstName")
	private String firstName;
	
	@Builder.Default
	@JsonProperty("MiddleName")
	private String middleName="";
	
	@Builder.Default
	@JsonProperty("LastName")
	private String lastName="";
    
	@Singular("phones")
	@JsonProperty("InquiryPhones")
	private List<InquiryPhones> inquiryPhones;
	
	@Singular("ids")
	@JsonProperty("IDDetails")
	private List<IDDetails> idDetails;
	

	public RequestBody() {
		// TODO Auto-generated constructor stub
	}

}
