package com.abc.customer.prefilldata.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BreErrors {

	@JsonProperty("code")
	public String code;

	@JsonProperty("errorType")
	public String errorType;

	@JsonProperty("description")
	public String description;
	
}
