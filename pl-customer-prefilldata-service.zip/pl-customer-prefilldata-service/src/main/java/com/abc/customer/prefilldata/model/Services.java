package com.abc.customer.prefilldata.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Services {
	
	@Builder.Default
	@JsonProperty("Service")
	private ServiceCibil service = ServiceCibil.builder().build();

}
