package com.abc.customer.prefilldata.entity;

public class Source {
	
	private Coordinates coordinates ;

	public Coordinates getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
	}
	
	
	

}
