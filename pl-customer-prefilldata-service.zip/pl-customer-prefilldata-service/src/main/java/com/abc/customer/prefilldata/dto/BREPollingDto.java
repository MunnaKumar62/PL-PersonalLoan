package com.abc.customer.prefilldata.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class BREPollingDto {

    private String accountId;

    private String loanId;
}