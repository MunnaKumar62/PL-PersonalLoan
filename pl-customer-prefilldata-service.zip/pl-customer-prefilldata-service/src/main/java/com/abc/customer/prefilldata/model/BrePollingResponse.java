package com.abc.customer.prefilldata.model;


import com.abc.customer.prefilldata.response.BreError;
import com.abc.customer.prefilldata.response.BreErrors;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BrePollingResponse {
	
	public BrePollingResponse(String responseStatus) {
		super();
		this.responseStatus = responseStatus;
	}

	@JsonProperty("responseStatus")
	private String responseStatus;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("data")
	private BrePollingData data;
	
	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("error")
	private BreError error;
    
}
