package com.abc.customer.prefilldata.service;

import java.util.List;

import com.abc.customer.prefilldata.dto.BREPollingDto;
import com.abc.customer.prefilldata.dto.PLCustomerDetailDto;
import com.abc.customer.prefilldata.entity.PLCustomerDetail;
import com.abc.vascredit.model.equifax.request.LeadDropRequest;

public interface PLCustomerDetailService {

	public PLCustomerDetail auditCustomerDetails(PLCustomerDetailDto plCustomerDetailDto);
	
	public PLCustomerDetail savOrUpdateCustomerDetails(PLCustomerDetail plCustomerDetail);
	
	public PLCustomerDetail findByAccountIdAndActive(String accountId, Boolean active);

	public PLCustomerDetail findByAccountIdAndActiveAndLoanIdAndCustomerId(String accountId, Boolean active, String loanId, Long customerId);

	public PLCustomerDetail findByAccountIdAndLoanIdAndCustomerIdActive(String accountId, String loanId, Long customerId, Boolean active);
	
	public void updateLeadMileStone(LeadDropRequest request, String accountId, String token, String loanId, Long customerId);

	public List<BREPollingDto> findByCeStatus(String ceStatus);
}
