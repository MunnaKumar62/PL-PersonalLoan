package com.abc.customer.prefilldata.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@JsonRootName("Service")
public class ServiceCibil {
	
	@Builder.Default
	@JsonProperty("Id")
	private String id="CORE";	
	
	//@Singular("operation")
	//@JsonProperty("Operations")
	//private Map<String, List<Operation>> operations;
	
	@Builder.Default
	@JsonProperty("Operations")
	private Operations operations = Operations.builder().build();
	
	//@Builder.Default
	//@JsonProperty("Operations")
	//private Map<String, Operation> operationsData = null;
	 
	@Builder.Default
	@JsonProperty("Skip")
	private String skip="N";
	    
	@Builder.Default
	@JsonProperty("Consent")
	private String consent="true";
	    
	@Builder.Default
	@JsonProperty("Name")
	private String name=null;
}
