package com.abc.customer.prefilldata.model;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
//@NoArgsConstructor
@ToString
@Builder
public class D2CPullRequestVO {
	
	private String name;
	private String mobileNumber;
	private String panNo;
	private String loanId;
	private Long customerId;

	@NotBlank
	private String accountId;
	 public D2CPullRequestVO() {
		 
	 }

}
