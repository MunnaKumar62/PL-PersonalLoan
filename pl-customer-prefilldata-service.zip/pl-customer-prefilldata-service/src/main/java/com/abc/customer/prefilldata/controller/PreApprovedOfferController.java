package com.abc.customer.prefilldata.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.model.PreApprovedOfferRequest;
import com.abc.customer.prefilldata.model.PreApprovedOfferResponse;
import com.abc.customer.prefilldata.request.OfferRequest;
import com.abc.customer.prefilldata.response.PreapprovedEmpOfferData;
import com.abc.customer.prefilldata.service.PreApprovedOfferService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.ONE_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION)
public class PreApprovedOfferController extends BaseController {

	@Autowired
	private PreApprovedOfferService preApprovedOfferService;

	@Override
	public void auditUrl() {
		logUrl(this.getClass().getSimpleName());
	}

	/**
	 * This API is used to get Pre Approved Offer for customer.
	 * @param preApprovedOfferRequest contains the mobilenumber, pannubmer, name, dateofbirth.
	 * @return PreApprovedOfferResponse contains the customer kyc details and cibilScore, monthlyIncome, approved loan amount
	 * Rate Of Intrest.
	 * @throws CustomException -  if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping("/offer/preapproved")
	public ResponseEntity<PreApprovedOfferResponse> getPreApprovedOffers(@Valid @RequestBody PreApprovedOfferRequest preApprovedOfferRequest) {
		PreApprovedOfferResponse response = preApprovedOfferService.getPreApprovedOffers(preApprovedOfferRequest);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * This API is used to get the Pre Approved Offer details of Customer.
	 * @param request contains mobileNumber.
	 * @return Response Contains the Customer Kyc Details, Customer's Organization details and preApprovedLoanAmount and
	 * processingFeePercentage
	 */
	@PostMapping(BQ_OFFER)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<PreapprovedEmpOfferData> getPreapprovedEmpOffer(@RequestBody OfferRequest request) {
		auditUrl();
		ResponseEntity<PreapprovedEmpOfferData> preapprovedEmpOfferData = preApprovedOfferService.getPreapprovedEmpOffer(request);
		return preapprovedEmpOfferData;
	}

	/**
	 * This API is used to freeze the Pre Approved Offer of Customer by making the status and isvalid column as 0 or false.
	 * By doing this customer not able to use Pre Approved Offers.
	 * @param request mobileNumber.
	 * @return It returns a response as object. It contains responseStatus.
	 * @throws CustomException -  if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping(BQ_OFFER_FREEZE)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> bqFreezeCustomer(@RequestBody OfferRequest request) {
		logUrl("bqFreezeCustomer method of PreApprovedOfferController class");
		Map<String,String> map = new HashMap<>();
		map.put("responseStatus", Constants.SUCCESS);
		preApprovedOfferService.bqFreezeCustomer(request);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * This API is for internal purpose. It is used to un freeze the Pre Approved Offer of Customer by making the status and
	 * isvalid column as 1 or false. By doing this customer able to use Pre Approved Offers.
	 * @param request mobileNumber.
	 * @return It returns a response as object. It contains responseStatus.
	 * @throws CustomException -  if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping(BQ_OFFER_NON_FREEZE)
	@ApiResponses(value = { @ApiResponse(responseCode = STATUS_CODE_200, description = API_STATUS_200),
			@ApiResponse(responseCode = STATUS_CODE_404, description = API_STATUS_404),
			@ApiResponse(responseCode = STATUS_CODE_500, description = API_STATUS_500) })
	public ResponseEntity<Object> bqNonFreezeCustomer(@RequestBody OfferRequest request) {
		logUrl("bqNonFreezeCustomer method of PreApprovedOfferController class");
		Map<String,String> map = new HashMap<>();
		map.put("responseStatus", Constants.SUCCESS);
		preApprovedOfferService.bqNonFreezeCustomer(request);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
