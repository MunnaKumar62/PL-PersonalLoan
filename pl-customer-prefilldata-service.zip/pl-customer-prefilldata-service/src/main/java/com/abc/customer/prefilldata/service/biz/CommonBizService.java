package com.abc.customer.prefilldata.service.biz;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.dto.RetryConfg;
import com.abc.customer.prefilldata.entity.ApiStatus;
import com.abc.customer.prefilldata.entity.PreapprovedEmpOffer;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.request.ApiCommonRequest;
import com.abc.customer.prefilldata.response.Error;
import com.abc.customer.prefilldata.response.ErrorResponse;
import com.abc.customer.prefilldata.response.PreapprovedEmpOfferResponse;
import com.abc.customer.prefilldata.service.ApiStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;


@Log4j2
@Component
public class CommonBizService implements Constants {
	
private final String className = "[" + this.getClass().getSimpleName() + "]";
	
	@Autowired
	private Environment env;
	
	@Autowired
	private ApiStatusService apiService;
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper mapper;

	public ApiStatus saveApiResponse(ApiStatus apiStatus, ApiStatus existApiStatus) {

		if (null != existApiStatus && null != existApiStatus.getId()) {
			existApiStatus.setProfileId(apiStatus.getProfileId());
			existApiStatus.setRequestId(apiStatus.getRequestId());
			existApiStatus.setTransactionId(apiStatus.getTransactionId());
			existApiStatus.setAccountId(apiStatus.getAccountId());
			existApiStatus.setLoanId(apiStatus.getLoanId());
			existApiStatus.setCustomerId(apiStatus.getCustomerId());
			existApiStatus.setRequestJson(apiStatus.getRequestJson());
			existApiStatus.setResponseJson(apiStatus.getResponseJson());
			existApiStatus.setStatus(apiStatus.getStatus().toUpperCase());
			existApiStatus.setModifiedBy(CREATED_BY);
			existApiStatus.setModifiedDate(new Timestamp(new Date().getTime()));
		} else {
			existApiStatus = apiStatus;
			existApiStatus.setStatus(existApiStatus.getStatus().toUpperCase());
			existApiStatus.setJourney(PL_JOURNEY);
			existApiStatus.setCreatedBy(CREATED_BY);
			existApiStatus.setCreatedDate(new Timestamp(new Date().getTime()));
		}

		return apiService.savOrUpdateApiStatus(existApiStatus);
	}

	public void updateApiStatus(ApiStatus apiStatus) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		try {
			apiStatus.setModifiedBy(CREATED_BY);
			apiStatus.setModifiedDate(new Timestamp(new Date().getTime()));
			apiService.savOrUpdateApiStatus(apiStatus);
		} catch (Exception ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
	}
	
	public RetryTemplate createRetryTemplate(int maxAttempts, long backOffPeriod) {

		RetryTemplate retryTemplate = new RetryTemplate();
		// Fixed delay of XX seconds between retries
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		fixedBackOffPolicy.setBackOffPeriod(backOffPeriod);
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy);

		// Retry only XX times
		SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
		retryPolicy.setMaxAttempts(maxAttempts);
		retryTemplate.setRetryPolicy(retryPolicy);

		return retryTemplate;
	}

	public List<RetryConfg> getRetryConfig(String value) {

		int maxAttempts = 1;
		List<RetryConfg> list = new ArrayList<>();
		if (!StringUtils.isBlank(value) && value.contains(Constants.TILDA)) {
			String[] arr1 = value.trim().split(Constants.TILDA);
			for (String str : arr1) {
				if (!StringUtils.isBlank(str) && str.contains(Constants.UNDER_SQUARE)) {
					String[] arr2 = str.split(Constants.UNDER_SQUARE);
					maxAttempts = null != arr2[0] ? Integer.parseInt(arr2[0]) : maxAttempts;
					list.add(new RetryConfg(maxAttempts, caculateWaitDuration(arr2[1])));
				}
			}
		} else if (!StringUtils.isBlank(value) && value.contains(Constants.UNDER_SQUARE)) {
			String[] arr2 = value.trim().split(Constants.UNDER_SQUARE);
			maxAttempts = null != arr2[0] ? Integer.parseInt(arr2[0]) : maxAttempts;
			list.add(new RetryConfg(maxAttempts, caculateWaitDuration(arr2[1])));
		} else {
			list.add(new RetryConfg(maxAttempts, 1000L));
		}

		return list;
	}

	public static long caculateWaitDuration(String str) {

		long waitDuration = 1000L;

		try {
			boolean flag = isNumeric(str);
			if (flag) {
				// default seconds
				waitDuration = Integer.parseInt(str) * waitDuration;
			} else if (str.length() > 1) {
				String loadFactor = str.substring(0, str.length() - 1);
				char format = str.charAt(str.length() - 1);
				if (format == 's') {
					// seconds
					waitDuration = Integer.parseInt(loadFactor) * waitDuration;

				} else if (format == 'm') {
					// minutes
					waitDuration = Integer.parseInt(loadFactor) * (60 * waitDuration);
				}
			}
		} catch (NumberFormatException e) {
			return waitDuration;
		}
		return waitDuration;
	}

	private static boolean isNumeric(String s) {
		// match a number with optional '-' and decimal.
		return s.matches("-?\\d+(\\.\\d+)?");
	}

	public static boolean isEmptyOrNull(String str) {
		return (null == str || str.isBlank());
	}
	
	public HttpHeaders getRequestHeaders(String token) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add(AUTH_TOKEN, token);

		return headers;
	}
	
	public <T> Map<String, Object> callExternalApi(ApiCommonRequest commonRequest, Class<T> responseType) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		Map<String, Object> map = new HashMap<>();
		String requestJsonObject = null;
		String responseJsonObject = null;
		String status = ERROR;
		int statusCode = STATUS_CODE_400;
		boolean isValid = Boolean.TRUE;
		ResponseEntity<T> apiResponse = null;
		try {
			requestJsonObject = null != commonRequest.getRequest()
					? mapper.writeValueAsString(commonRequest.getRequest())
					: null;
			log.info(className + methodName + "[API_URL= " + commonRequest.getUrl() + "]");
			HttpEntity<Object> apiRequest = new HttpEntity<>(commonRequest.getRequest(),
					commonRequest.getRequestHeaders());
			log.info(className + methodName + "[API_REQUEST= " + requestJsonObject + "]");

			apiResponse = restTemplate.exchange(commonRequest.getUrl(), commonRequest.getMethod(), apiRequest,
					responseType);
			if (null != apiResponse && null != apiResponse.getBody()) {
				status = SUCCESS;
				responseJsonObject = mapper.writeValueAsString(apiResponse.getBody());
				log.info(className + methodName + "[API_RESPONSE= " + responseJsonObject + "]");
			}
			map.put(API_RESPONSE, apiResponse);
			statusCode = apiResponse.getStatusCode().value();

		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error(className + methodName + EXCEPTION + "[HttpClientErrorException | HttpServerErrorException= "
					+ ex.getMessage());
			String partnerErrorMessage = getPartnerErrorMessage(ex.getResponseBodyAsString());
			responseJsonObject = ex.getResponseBodyAsString();

			Object error = null;
			try {
				if (!isEmptyOrNull(partnerErrorMessage) && partnerErrorMessage.startsWith(ERROR_)) {
					error = mapper.readValue(partnerErrorMessage.replace(ERROR_, EMPTY), Object.class);
				} else {
					error = new Error(String.valueOf(ex.getStatusCode().value()), ex.getStatusText(),
							partnerErrorMessage);
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			map.put(API_RESPONSE, new ResponseEntity<>(new ErrorResponse(status, error), ex.getStatusCode()));
			statusCode = ex.getStatusCode().value();

		} catch (Exception ex) {
			isValid = Boolean.FALSE;
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
			throw new CustomException(ex.getMessage());

		} finally {
			if (commonRequest.isAudit() && isValid) {
				ApiStatus apiStatus = saveApiResponse(ApiStatus.builder().apiName(commonRequest.getApiName())
						.accountId(commonRequest.getAccountId()).profileId(commonRequest.getProfileId())
						.requestId(commonRequest.getRequestId()).transactionId(commonRequest.getTransactionId())
						.requestJson(requestJsonObject).responseJson(responseJsonObject).status(status)
						.httpStatusCode(statusCode).active(commonRequest.getActive()).build(),
						commonRequest.getApiStatus());
				map.put(API_STATUS, apiStatus);
			}
		}

		return map;
	}

	public String getPartnerErrorMessage(String partnerError) {

		String code = "PE0100";
		String partnerErrorMessage = code + env.getProperty(code);
		final String desc = "description";
		final String desc1 = "message";
		final String error = "error";

		if (!StringUtils.isBlank(partnerError)) {
			JSONObject errorResponse = new JSONObject(partnerError);
			if (errorResponse.has(error)) {
				boolean flag = false;
				JSONObject errorObj = errorResponse.getJSONObject(error);
				if (errorObj.has(desc)) {
					if (!isValidJson(errorObj.get(desc).toString())) {
						partnerErrorMessage = errorObj.getString(desc);
					} else {
						flag = true;
					}
				} else if (errorObj.has(desc1)) {
					if (!isValidJson(errorObj.get(desc1).toString())) {
						partnerErrorMessage = errorObj.getString(desc1);
					} else {
						flag = true;
					}
				} else {
					flag = true;
				}
				if (flag) {
					partnerErrorMessage = ERROR_ + errorObj.toString();
				}
			} else {
				partnerErrorMessage = errorResponse.has(desc) ? errorResponse.getString(desc) : partnerErrorMessage;
			}
		}
		return partnerErrorMessage;
	}

	public boolean isValidJson(String json) {
		try {
			new JSONObject(json);
		} catch (JSONException e) {
			return false;
		}
		return true;
	}

	public <T> boolean validateResponse(ResponseEntity<T> apiResponse) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";

		boolean isSuccess = Boolean.TRUE;
		String error = "error";
		String errors = "errors";
		try {
			if (null != apiResponse && null != apiResponse.getBody()) {
				String json = mapper.writeValueAsString(apiResponse.getBody());

				if (!StringUtils.isBlank(json)) {
					JSONObject errorResponse = new JSONObject(json);
					JSONObject errorObj = null;
					if (errorResponse.has(error)) {
						errorObj = errorResponse.getJSONObject(error);
					} else if (errorResponse.has(errors)) {
						errorObj = errorResponse.getJSONObject(errors);
					}
					if (null != errorObj) {
						isSuccess = Boolean.FALSE;
					}
				}
			}
		} catch (JsonProcessingException ex) {
			log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return isSuccess;
	}
	
	public String getStringDate(String inputDate) {
		try {
			SimpleDateFormat df = new SimpleDateFormat(ZONE_DATE_FORMAT);
			SimpleDateFormat df1 = new SimpleDateFormat(DATE_FORMAT);
			Date date = df.parse(inputDate);
			inputDate = df1.format(date);
		} catch (ParseException ex) {
			log.error(className + "[getStringDate]" + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return inputDate;
	}
	
	public boolean date1BeforeDate2(String d1, String d2) {
		boolean flag = false;
		try {
			if (!isEmptyOrNull(d1)) {
				SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
				Date date1 = sdf.parse(d1);
				Date date2 = sdf.parse(d2);
				flag = date1.before(date2);
			}
		} catch (ParseException ex) {
			log.error(className + "[date1BeforeDate2]" + EXCEPTION + "[" + ex.getMessage() + "]");
		}
		return flag;
	}

	public PreapprovedEmpOfferResponse constructResponseObj(PreapprovedEmpOffer offer) {
		
		// Construct data from DB
		PreapprovedEmpOfferResponse offerResponse = new PreapprovedEmpOfferResponse();
		
		offerResponse.setEmpIntId(offer.getEmpIntId());
		offerResponse.setId(offer.getId());
		offerResponse.setCustomerName(offer.getCustomerName());
		offerResponse.setGender(offer.getGender());
		offerResponse.setMobileNo(offer.getMobileNo());
		offerResponse.setDateOfBirth(doFormatDate(offer.getDateOfBirth()));
		offerResponse.setPanNumber(offer.getPanNumber());
		offerResponse.setMaritalStatus(offer.getMaritalStatus());
		offerResponse.setScoreCust(offer.getScoreCust());
		offerResponse.setMinLoanOffered(offer.getMinLoanOffered());
		offerResponse.setMaxLoanAmount(offer.getMaxLoanAmount());
		offerResponse.setMinTenure(offer.getMinTenure());
		offerResponse.setMaxTenure(offer.getMaxTenure());
		offerResponse.setProcessingFeePercentage(offer.getProcessingFeePercentage());
		offerResponse.setPreApprovedLoanAmount(offer.getPreApprovedLoanAmount());
		offerResponse.setInterestRate(offer.getInterestRate());
		offerResponse.setMaxEmi(offer.getMaxEmi());
		offerResponse.setPersonalEmailId(offer.getPersonalEmailId());
		offerResponse.setProfessionalEmailId(offer.getProfessionalEmailId());
		offerResponse.setResiAddress(offer.getResiAddress());
		offerResponse.setResiPincode(offer.getResiPincode());
		offerResponse.setResiState(offer.getResiState());
		offerResponse.setResiCity(offer.getResiCity());
		offerResponse.setEmployerCategory(offer.getEmployerCategory());
		offerResponse.setOrganizationName(offer.getOrganizationName());
		offerResponse.setOrgAddress(offer.getOrgAddress());
		offerResponse.setOrgPincode(offer.getOrgPincode());
		offerResponse.setOrgCity(offer.getOrgCity());
		offerResponse.setOrgState(offer.getOrgState());
		offerResponse.setEmploymentType(offer.getEmploymentType());
		offerResponse.setBankName(offer.getBankName());
		offerResponse.setBankAccountNumber(offer.getBankAccountNumber());
		offerResponse.setIfscCode(offer.getIfscCode());
		offerResponse.setBranchName(offer.getBranchName());
		offerResponse.setOfferType(offer.getOfferType());
		offerResponse.setChecksToSkip(offer.getChecksToSkip());
		offerResponse.setValidity(doFormatDate(offer.getValidity()));
		offerResponse.setValid(offer.isValid());
		offerResponse.setBureauScrubDate(doFormatDate(offer.getBureauScrubDate()));
		offerResponse.setOfferCreatedAt(doFormatDate(offer.getOfferCreatedAt()));
		offerResponse.setInterestRateNew(offer.getInterestRate());
		offerResponse.setStatus(offer.getStatus());
		
		return offerResponse;
		
	}
	
	public List<PreapprovedEmpOfferResponse> constructResponseList(List<PreapprovedEmpOfferResponse> list,
			PreapprovedEmpOffer offer) {

		List<PreapprovedEmpOfferResponse> list1 = new ArrayList<>();
		if (!list.isEmpty()) {
			PreapprovedEmpOfferResponse offerResponse = list.get(0);
			SimpleDateFormat sd = new SimpleDateFormat(DATE_FORMAT);
			if (null != offer && null != offer.getEmpIntId()) {
				offerResponse.setEmpIntId(offer.getEmpIntId());
			}
			offerResponse.setDateOfBirth(
					!isEmptyOrNull(offerResponse.getDateOfBirth()) ? getStringDate(offerResponse.getDateOfBirth())
							: offerResponse.getDateOfBirth());
			offerResponse.setValidity(
					!isEmptyOrNull(offerResponse.getValidity()) ? getStringDate(offerResponse.getValidity())
							: offerResponse.getValidity());
			offerResponse.setBureauScrubDate(!isEmptyOrNull(offerResponse.getBureauScrubDate())
					? getStringDate(offerResponse.getBureauScrubDate())
					: offerResponse.getBureauScrubDate());
			offerResponse.setOfferCreatedAt(
					!isEmptyOrNull(offerResponse.getOfferCreatedAt()) ? getStringDate(offerResponse.getOfferCreatedAt())
							: offerResponse.getDateOfBirth());

			String currDate = sd.format(new Date());
			DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
			Boolean flag = false;

			if (offer != null && offer.getStatus() != null && Boolean.FALSE.equals(offer.getStatus())) {
				if (offer.getValidity() != null && StringUtils.isNotEmpty(offerResponse.getValidity())) {
					String offerValid = dateFormat.format(offer.getValidity());
					if (!offerResponse.getValidity().equals(offerValid)
							&& (offerResponse.getMinLoanOffered() != null)) {
						offerResponse.setStatus(Boolean.TRUE);
						offerResponse.setValid(Boolean.TRUE);
					} else {
						offerResponse.setStatus(offer.getStatus());
						offerResponse.setValid(offer.isValid());
					}
				}
			} else {
				if (offerResponse.getMinLoanOffered() != null
						&& Boolean.TRUE.equals(!date1BeforeDate2(offerResponse.getValidity(), currDate))) {

					flag = true;
				}
				offerResponse.setValid(flag);
				offerResponse.setStatus(Boolean.TRUE);
			}
			offerResponse.setInterestRate(offerResponse.getInterestRateNew());

			list1.add(offerResponse);
		}
		return list1;
	}

	public PreapprovedEmpOffer constructDBObj(PreapprovedEmpOfferResponse offerResponse) {
	
		PreapprovedEmpOffer offer = new PreapprovedEmpOffer();
		// Construct data from DB
		if(null == offerResponse.getEmpIntId()) {
			offer.setCreatedDate(new Timestamp(new Date().getTime()));
		}
		offer.setEmpIntId(offerResponse.getEmpIntId());
		offer.setId(offerResponse.getId());
		offer.setCustomerName(offerResponse.getCustomerName());
		offer.setGender(offerResponse.getGender());
		offer.setMobileNo(offerResponse.getMobileNo());
		offer.setDateOfBirth(doParseDate(offerResponse.getDateOfBirth()));
		offer.setPanNumber(offerResponse.getPanNumber());
		offer.setMaritalStatus(offerResponse.getMaritalStatus());
		offer.setScoreCust(offerResponse.getScoreCust());
		offer.setMinLoanOffered(offerResponse.getMinLoanOffered());
		offer.setMaxLoanAmount(offerResponse.getMaxLoanAmount());
		offer.setMinTenure(offerResponse.getMinTenure());
		offer.setMaxTenure(offerResponse.getMaxTenure());
		offer.setProcessingFeePercentage(offerResponse.getProcessingFeePercentage());
		offer.setPreApprovedLoanAmount(offerResponse.getPreApprovedLoanAmount());
		offer.setInterestRate(offerResponse.getInterestRate());
		offer.setMaxEmi(offerResponse.getMaxEmi());
		offer.setPersonalEmailId(offerResponse.getPersonalEmailId());
		offer.setProfessionalEmailId(offerResponse.getProfessionalEmailId());
		offer.setResiAddress(offerResponse.getResiAddress());
		offer.setResiPincode(offerResponse.getResiPincode());
		offer.setResiState(offerResponse.getResiState());
		offer.setResiCity(offerResponse.getResiCity());
		offer.setEmployerCategory(offerResponse.getEmployerCategory());
		offer.setOrganizationName(offerResponse.getOrganizationName());
		offer.setOrgAddress(offerResponse.getOrgAddress());
		offer.setOrgPincode(offerResponse.getOrgPincode());
		offer.setOrgCity(offerResponse.getOrgCity());
		offer.setOrgState(offerResponse.getOrgState());
		offer.setEmploymentType(offerResponse.getEmploymentType());
		offer.setBankName(offerResponse.getBankName());
		offer.setBankAccountNumber(offerResponse.getBankAccountNumber());
		offer.setIfscCode(offerResponse.getIfscCode());
		offer.setBranchName(offerResponse.getBranchName());
		offer.setOfferType(offerResponse.getOfferType());
		offer.setChecksToSkip(offerResponse.getChecksToSkip());
		offer.setValidity(doParseDate(offerResponse.getValidity()));
		offer.setValid(offerResponse.isValid());
		offer.setStatus(offerResponse.getStatus());
		offer.setBureauScrubDate(doParseDate(offerResponse.getBureauScrubDate()));
		offer.setOfferCreatedAt(doParseDate(offerResponse.getOfferCreatedAt()));
		offer.setCreatedBy(CREATED_BY);
		offer.setModifiedBy(CREATED_BY);
		offer.setModifiedDate(new Timestamp(new Date().getTime()));

		return offer;

	}
	
	public List<String> apiNameList(String whiteListedServices) {
		List<String> list = new ArrayList<>();
		if (!StringUtils.isBlank(whiteListedServices)) {
			String[] arr = whiteListedServices.split(",");
			if (arr.length > 1) {
				for (String str : arr) {
					str = str.trim();
					list.add(str);
				}
			}
		}
		return list;
	}
	
	public Date doParseDate(String strDate) {

		Date date = null;
		try {
			SimpleDateFormat sd = new SimpleDateFormat(DATE_FORMAT);
			date = !isEmptyOrNull(strDate) ? sd.parse(strDate) : date;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public String doFormatDate(Date date) {

		String strDate = EMPTY;
		SimpleDateFormat sd = new SimpleDateFormat(DATE_FORMAT);
		strDate = date != null ? sd.format(date) : strDate;
		return strDate;
	}

	public Date findLatestApiStatus() throws ParseException {
	    LocalDate localStartDate = LocalDate.now().minusDays(30);
	    
	    Date startDate = Date.from(localStartDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
	    String formattedStartDateString = dateFormat.format(startDate);

	    Date formattedStartDate = dateFormat.parse(formattedStartDateString);

	    log.info("Formatted Start Date: " + formattedStartDateString);
	    return formattedStartDate;
	}
}
