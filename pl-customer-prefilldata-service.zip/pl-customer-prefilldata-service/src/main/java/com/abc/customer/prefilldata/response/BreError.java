package com.abc.customer.prefilldata.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BreError {

	@JsonProperty("code")
	public String code;
	
	@JsonProperty("errorType")
	public String errorType;

	@JsonProperty("description")
	public String description;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("errors")
	public List<BreErrors> errors;

	
	
}
