package com.abc.customer.prefilldata.repo;


import com.abc.customer.prefilldata.entity.CustomerLoginDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CustomerLoginRepository extends JpaRepository<CustomerLoginDetails, Integer> {

    @Query("SELECT a FROM CustomerLoginDetails a WHERE a.customerId = :customerId ORDER BY a.customerDeviceId DESC LIMIT 1")
    CustomerLoginDetails findByCustomerId(@Param("customerId") Long customerId);
}
