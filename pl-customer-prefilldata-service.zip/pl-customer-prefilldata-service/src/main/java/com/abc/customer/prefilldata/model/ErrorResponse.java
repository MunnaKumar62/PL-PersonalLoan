
package com.abc.customer.prefilldata.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {

	private String timestamp;
	private String status;
	private String path;
	private List<Errors> errors;

}
