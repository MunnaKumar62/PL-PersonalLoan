package com.abc.customer.prefilldata.entity;

import java.math.BigInteger;
import java.util.Date;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "t_pl_preapproved_emp_offer")
public class PreapprovedEmpOffer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emp_int_id")
	private BigInteger empIntId;
	
	@Column(name = "id")
	private String id;
	
	@Column(name = "mobile_no")
	private String mobileNo;
	
	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "date_of_birth")
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;

	@Column(name = "gender")
	private String gender;

	@Column(name = "max_Loan_Amount")
	private BigInteger maxLoanAmount;

	@Column(name = "validity")
	@Temporal(TemporalType.DATE)
	private Date validity;
	
	@Column(name = "is_valid")
	private boolean valid;

	@Column(name = "status")
	private Boolean status;

	@Column(name = "interest_rate")
	private double interestRate;
	
	@Column(name = "min_tenure")
	private int minTenure;
	
	@Column(name = "max_tenure")
	private int maxTenure;

	@Column(name = "min_loan_offered")
	private BigInteger minLoanOffered;

	@Column(name = "max_emi")
	private double maxEmi;	

	@Column(name = "score_cust")
	private int scoreCust;

	@Column(name = "bank_account_number")
	private String bankAccountNumber;

	@Column(name = "bank_name")
	private String bankName;

	@Column(name = "branch_name")
	private String branchName;

	@Column(name = "checks_to_skip")
	private String checksToSkip;

	@Column(name = "employer_category")
	private String employerCategory;

	@Column(name = "employment_type")
	private String employmentType;

	@Column(name = "ifsc_code")
	private String ifscCode;

	@Column(name = "marital_status")
	private String maritalStatus;

	@Column(name = "offer_type")
	private String offerType;

	@Column(name = "org_address")
	private String orgAddress;

	@Column(name = "org_city")
	private String orgCity;

	@Column(name = "org_pincode")
	private String orgPincode;

	@Column(name = "org_state")
	private String orgState;

	@Column(name = "organization_name")
	private String organizationName;

	@Column(name = "pan_number")
	private String panNumber;

	@Column(name = "personal_email_id")
	private String personalEmailId;

	@Column(name = "pre_approved_loan_amount")
	private double preApprovedLoanAmount;

	@Column(name = "processing_fee_percentage")
	private double processingFeePercentage;

	@Column(name = "professional_email_id")
	private String professionalEmailId;

	@Column(name = "resi_address")
	private String resiAddress;

	@Column(name = "resi_city")
	private String resiCity;

	@Column(name = "resi_pincode")
	private String resiPincode;

	@Column(name = "resi_state")
	private String resiState;
	
	@Column(name = "bureau_scrub_date")
	@Temporal(TemporalType.DATE)
	private Date bureauScrubDate;
	
	@Column(name = "offer_created_at")
	@Temporal(TemporalType.DATE)
	private Date offerCreatedAt;
	
	@Column(name="created_by")
    private String createdBy;

    @CreatedDate
    @Column(name="created_date", updatable = false)   
    private Date createdDate;

    @Column(name="modified_by")
    private String modifiedBy;

    @LastModifiedDate
    @Column(name="modified_date")    
    private Date modifiedDate;
}