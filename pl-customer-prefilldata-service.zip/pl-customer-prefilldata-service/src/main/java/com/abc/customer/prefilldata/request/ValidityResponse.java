package com.abc.customer.prefilldata.request;

import lombok.Data;

@Data
public class ValidityResponse {
	
	private String loanType;
	private String ValidityDate;
	private Boolean isValidity;
	
	

}