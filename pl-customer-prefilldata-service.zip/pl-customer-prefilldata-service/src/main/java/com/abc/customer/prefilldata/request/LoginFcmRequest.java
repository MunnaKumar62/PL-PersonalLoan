package com.abc.customer.prefilldata.request;

import lombok.Data;

@Data
public class LoginFcmRequest {
    private String to;
    private Dat data;
}