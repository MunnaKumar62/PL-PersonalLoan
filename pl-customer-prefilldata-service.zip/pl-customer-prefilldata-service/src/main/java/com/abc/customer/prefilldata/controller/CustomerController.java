package com.abc.customer.prefilldata.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.entity.Distance;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.model.BreCallbackRequest;
import com.abc.customer.prefilldata.model.CibilBureauRequestVO;
import com.abc.customer.prefilldata.model.D2CPullRequestVO;
import com.abc.customer.prefilldata.service.CustomerService;
import com.abc.customer.prefilldata.serviceImp.CustomerServiceImp;
import com.abc.vascredit.model.equifax.request.BrefailureRequest;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.ONE_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION
		+ Constants.PERSONAL_LOAN)
public class CustomerController {

	@Autowired
	private CustomerService service;
	
	@Value("${pl.bre.scheduler.enabled}")
	private String isBreSchEnabled;
	
	public CustomerController(CustomerServiceImp customerService) {
	}

	/**
	 * API is used to call external api to get the response of distance details for account id.
	 * @param distance is the pojo object contains account id and other required params.
	 * @return ResponseEntity of String this method returns get the response of "zumigodistancesv2" external api.
	 * @throws this return CustomException if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping("/distance")
	public ResponseEntity<String> getDistancezumbio(@RequestBody Distance distance) throws Exception {
		return service.getDistancezumbio(distance);
	}

	/**
	 * API is used to call external api to validate the employment details of account id.
	 * @param requestbody contains the customer employment details.
	 * @return It returns the responseStatus based on verification of Employment details of account id.
	 * @throws Exception - If any external api client exception.
	 */
	@PostMapping("/verifyemployment")
	public ResponseEntity<String> verifyEmployment(@RequestBody String requestbody) throws Exception {
		return service.verifyEmployment(requestbody);
	}

	/**
	 * This API method will call by external api to confirm BRE polling is happened for that particular account id
	 * and insertion will happen in apistatus table for this callback api.
	 * @param breCallbackRequest this request pojo object contains transaction id or applicationid created at the time of BRE Polling,
	 *                           rate of intrest, ccid, max_emi, async_id, account_id, max_tenure, min_tenure, max_loan_amount, min_loan_amount
	 *                           status code and message, is_retryable, application_id for the particular account id.
	 * @return It will return response object, it is containing code and status and timestamp. Code is static value PL2205 and
	 * status is message like success.
	 */
	@PostMapping("/breCallback")
	public ResponseEntity<Object> getCreditCallback(@RequestBody BreCallbackRequest breCallbackRequest){
		return service.saveCreditCallbackDetails(breCallbackRequest);
	}

	/**
	 * This API is used to call BRE Polling API to get the offer status of particular account id. Status like IN_PROGRESS or
	 * SUCCESS or SOFT_REJECT.
	 * @param accountId
	 * @return It will return response object of BRE Polling API . It is containing status and min_tenure and max_tenure
	 * and approved loan amount and max_requested_loan_amount and emi and rate of intrest and ccid and applicationid.
	 */
	@GetMapping("/breDetails/{accountId}/{loanId}/{customerId}")
	public ResponseEntity<Object> getCreditDetails(@PathVariable String accountId, @PathVariable String loanId, @PathVariable Long customerId) {
		return service.getBreDetails(accountId, loanId, customerId);
	}

	/**
	 * This API is used to check the eligibility this account id is eligble for loan offer. For this, Calling external api to check the eligibility.
	 * @param requestbody contains the accountId, productCode, isAbc, isPreapproved and Kyc Details.
	 * @return This returns a response in string format. It contains the responseStatus value.
	 * @throws CustomException - if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping("/decisionEngineConfig/{loanId}/{customerId}/{deviceId}")
	public ResponseEntity<String> decisionEngineConfig(@RequestBody String requestbody, @PathVariable String loanId, @PathVariable Long customerId,@PathVariable String deviceId) throws Exception {
		return service.initiateBRE(requestbody, loanId, customerId,deviceId);
	}

	/**
	 * This API is used to get the equifax details for account id.
	 * @param d2cPullRequestVO Pojo Object contains name, mobileno, pannumber.
	 * @return This returns the response in string format.Response contains the clientid, CustRefField, ReportOrderNO
	 * ProductCode, SuccessCode, DateTime, CIRReportDataLst.
	 * @throws CustomException -  if any external api HttpClientErrorException or any other exception from external api.
	 */
	@PostMapping("/d2cpullrequest")
	public ResponseEntity<String> d2cPullRequest(@RequestBody D2CPullRequestVO d2cPullRequestVO) throws Exception {
		return service.executeEquifaxAPI(d2cPullRequestVO);
	}

	/**
	 * This API is used to generate cibil report for customer.
	 * @param cibilBureauRequestVO name, mobileNumber, panNo
	 * @return Response object contains cibil report data and response status of account id.
	 * @throws CustomException - If any external api HttpClientErrorException or HttpServerErrorException.
	 */
	@PostMapping("/generatecibilrequest")
	public ResponseEntity<String> generateCibilBureau(@RequestBody CibilBureauRequestVO cibilBureauRequestVO) throws Exception {
		return service.generateCIBILBureauRequest(cibilBureauRequestVO);
	}

	/**
	 * This API is a scheduler job. This will pick In Progress BRE Polling Status Transaction and it will again call the
	 * BRE Polling API to make it SUCCESS.
	 * @return This will return a response as a object and it is containing the code and status, message, data.
	 */
	@PostMapping("/brepolling-job")
	public ResponseEntity<Object> brePollingJob(){
		Object obj = null;
		if (null != isBreSchEnabled && isBreSchEnabled.equals("Y")) {
			return service.brePollingJob();
		}else {
			obj = "BRE Scheduler is disabled";
		}
		return new ResponseEntity<>(obj, HttpStatus.OK);
	}
	
	@PostMapping("/brefailure")
	public ResponseEntity<String> getBrefailureRequest(@RequestBody BrefailureRequest brefailureRequest) throws Exception {
		return service.getBrefailureRequest(brefailureRequest);
	}
	

}
