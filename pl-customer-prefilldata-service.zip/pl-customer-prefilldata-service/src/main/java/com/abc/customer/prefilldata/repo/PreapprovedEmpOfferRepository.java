package com.abc.customer.prefilldata.repo;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.customer.prefilldata.entity.PreapprovedEmpOffer;

@Repository
public interface PreapprovedEmpOfferRepository extends JpaRepository<PreapprovedEmpOffer, BigInteger> {

	PreapprovedEmpOffer findByMobileNo(String mobileNo);
	
	@Query(value = "SELECT customer_id FROM t_customer_activation WHERE device_id = :deviceId", nativeQuery = true)
    List<String> findCustomerActivation(@Param("deviceId") String deviceId);

	
}
