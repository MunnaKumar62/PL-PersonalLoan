package com.abc.customer.prefilldata.cache;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.abc.customer.prefilldata.dto.Token;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class TokenCacheService {

	private static final String TOKEN_CACHE = "Token";

	@Autowired
	private RedisCacheProvider redisCacheProvider;

	@Autowired
	private ObjectMapper objectMapper;

	public Token getTokenFromCache(String tokenId) {
		Token token = null;
		log.info("Fetching Token from  Cache {} ", tokenId);
		try {
			String data = redisCacheProvider.getData(TOKEN_CACHE, tokenId);
			if (StringUtils.isNotBlank(data)) {
				token = objectMapper.readValue(data, Token.class);
			}
		} catch (Exception e) {
			log.error("Failed to fetch User from User Cache", e);
		}
		return token;
	}
	
	public void addTokenToCache(Token token) {
		log.info("Fetching Token from  Cache {} ", token);
		try {
			 redisCacheProvider.addData(TOKEN_CACHE,token.getTokenId(),objectMapper.writeValueAsString(token));
			
		} catch (Exception e) {
			log.error("Failed to fetch Token from Token Cache", e);
		}
		
	}

}
