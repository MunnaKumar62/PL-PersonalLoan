package com.abc.customer.prefilldata.model;

import lombok.Data;

@Data
public class CustomerReport {
	
	public KycInfo kycInfo;

}
