package com.abc.customer.prefilldata.constant;

public enum ResponseEnum {
	SUCCESS(1700, "Success"),
	FAILURE(1701, "Failure"),
	INVALID_REQUEST_BODY(1702, "MobileNo/PAN is Mandotory");

	private final Integer statusCode;
	private final String message;

	private ResponseEnum(Integer statusCode, String message) {
		this.statusCode = statusCode;
		this.message = message;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public String getMessage() {
		return message;
	}
}
