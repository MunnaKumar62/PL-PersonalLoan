package com.abc.customer.prefilldata.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.constant.MessageConstants;
import com.abc.customer.prefilldata.service.biz.CommonBizService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.log4j.Log4j2;

@Log4j2
public abstract class BaseController extends CommonBizService implements Constants, MessageConstants {

	@Autowired
	HttpServletRequest request;

	public abstract void auditUrl();

	public void logUrl(String className) {
		String fullURL = request.getRequestURL().toString();
		log.info("[" + className + "][" + fullURL + "]");
	}
}