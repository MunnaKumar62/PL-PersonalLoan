package com.abc.customer.prefilldata.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Operation {
	
	@Builder.Default
	@JsonProperty("Name")
	private String name; //= "ConsumerCIR";
	
	//@Singular("params")
	//@JsonProperty("Params")
	//private Map<String, List<Param>> params;
	
	@Builder.Default
	@JsonProperty("Params")
	private Params params = Params.builder().build();

}
