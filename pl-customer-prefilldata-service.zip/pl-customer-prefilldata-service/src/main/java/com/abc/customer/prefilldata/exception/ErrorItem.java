package com.abc.customer.prefilldata.exception;

import lombok.Data;

@Data
public class ErrorItem {
	private String field;
    private String message;

}
