package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Identifiers {
	
	@Singular("identifier")
	@JsonProperty("Identifier")
	private List<Identifier> identifier;

}
