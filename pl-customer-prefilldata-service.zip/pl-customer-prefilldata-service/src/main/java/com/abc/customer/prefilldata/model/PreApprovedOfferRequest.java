package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreApprovedOfferRequest {

	@JsonProperty("mobno")
	private String mobileNumber;

	@JsonProperty("pan")
	private String panNumber;

	@JsonProperty("name")
	private String name;

	@JsonProperty("dob")
	private String dateOfBirth;
}
