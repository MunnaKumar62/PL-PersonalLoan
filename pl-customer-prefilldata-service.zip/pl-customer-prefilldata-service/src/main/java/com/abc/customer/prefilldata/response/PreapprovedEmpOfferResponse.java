package com.abc.customer.prefilldata.response;

import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.boot.context.properties.bind.DefaultValue;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PreapprovedEmpOfferResponse {

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("emp_int_id")
	private BigInteger empIntId;

	@JsonProperty("id")
	private String id;

	@JsonProperty("mobile_no")
	private String mobileNo;

	@JsonProperty("Customer_name")
	private String customerName;

	@JsonProperty("Date_of_birth")
	private String dateOfBirth;

	@JsonProperty("Gender")
	private String gender;

	@JsonProperty("Max_Loan_Amount")
	private BigInteger maxLoanAmount;

	@JsonProperty("Validity")
	private String validity;

	@JsonInclude(value = Include.NON_NULL)
	@JsonProperty("is_valid")
	private boolean valid;

	@JsonProperty("status")
	private Boolean status;

	@JsonProperty("_interest_rate_")
	private double interestRate;

	@JsonProperty("interest_rate")
	private double interestRateNew;

	@JsonProperty("min_tenure")
	private int minTenure;

	@JsonProperty("max_tenure")
	private int maxTenure;

	@JsonProperty("min_loan_offered")
	private BigInteger minLoanOffered;

	@JsonProperty("max_emi")
	private double maxEmi;

	@JsonProperty("score_cust")
	private int scoreCust;

	@JsonProperty("bank_account_number")
	private String bankAccountNumber;

	@JsonProperty("bank_name")
	private String bankName;

	@JsonProperty("branch_name")
	private String branchName;

	@JsonProperty("checks_to_skip")
	private String checksToSkip;

	@JsonProperty("employer_category")
	private String employerCategory;

	@JsonProperty("employment_type")
	private String employmentType;

	@JsonProperty("ifsc_code")
	private String ifscCode;

	@JsonProperty("marital_status")
	private String maritalStatus;

	@JsonProperty("offer_type")
	private String offerType;

	@JsonProperty("org_address")
	private String orgAddress;

	@JsonProperty("org_city")
	private String orgCity;

	@JsonProperty("org_pincode")
	private String orgPincode;

	@JsonProperty("org_state")
	private String orgState;

	@JsonProperty("organization_name")
	private String organizationName;

	@JsonProperty("pan_number")
	private String panNumber;

	@JsonProperty("personal_email_id")
	private String personalEmailId;

	@JsonProperty("pre_approved_loan_amount")
	private double preApprovedLoanAmount;

	@JsonProperty("processing_fee_percentage")
	private double processingFeePercentage;

	@JsonProperty("professional_email_id")
	private String professionalEmailId;

	@JsonProperty("resi_address")
	private String resiAddress;

	@JsonProperty("resi_city")
	private String resiCity;

	@JsonProperty("resi_pincode")
	private String resiPincode;

	@JsonProperty("resi_state")
	private String resiState;

	@JsonProperty("bureau_scrub_date")
	private String bureauScrubDate;

	@JsonProperty("offer_created_at")
	private String offerCreatedAt;

}