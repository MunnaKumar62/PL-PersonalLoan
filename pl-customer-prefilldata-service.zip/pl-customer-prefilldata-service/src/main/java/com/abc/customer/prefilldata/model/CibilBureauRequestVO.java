package com.abc.customer.prefilldata.model;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
//import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
//@NoArgsConstructor
@ToString
@Builder
public class CibilBureauRequestVO {
	
	private String name;
	private String mobileNumber;
	private String panNo;

	@NotBlank
	private String accountId;
	
	public CibilBureauRequestVO() {
		// TODO Auto-generated constructor stub
	}

}
