package com.abc.customer.prefilldata.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Telephones {
	
	//@Singular("applicant")
	//@JsonProperty("Applicants")
	//private Map<String,Applicant> applicants;
	
	@Builder.Default
	@JsonProperty("Telephone")
	private Telephone telephone = Telephone.builder().build();

}
