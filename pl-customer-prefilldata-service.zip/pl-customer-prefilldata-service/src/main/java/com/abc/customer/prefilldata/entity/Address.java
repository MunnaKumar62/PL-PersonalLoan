package com.abc.customer.prefilldata.entity;

import java.util.List;

public class Address {
	
	private  List<PhysicalAddress> physicalAddressList;

	public List<PhysicalAddress> getPhysicalAddressList() {
		return physicalAddressList;
	}

	public void setPhysicalAddressList(List<PhysicalAddress> physicalAddressList) {
		this.physicalAddressList = physicalAddressList;
	}

	
	
}
