package com.abc.customer.prefilldata.serviceImp;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.customer.prefilldata.entity.ApiStatus;
import com.abc.customer.prefilldata.repo.ApiStatusRepository;
import com.abc.customer.prefilldata.service.ApiStatusService;

@Service
public class ApiStatusServiceImpl implements ApiStatusService {

	@Autowired
	ApiStatusRepository apiStatusRepo;

	@Override
	public ApiStatus findByAccountIdAndApiName(String apiName, String accountId) {
		return apiStatusRepo.findByAccountIdAndApiName(apiName, accountId);
	}

	@Override
	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus) {
		return apiStatusRepo.save(apiStatus);
	}

	@Override
	public Optional<ApiStatus> findByAccountIdAndApiNameAndActive(String accountId, String apiName, Boolean active) {
		return apiStatusRepo.findByAccountIdAndApiNameAndActive(apiName, accountId, active);
	}

	@Override
	public Optional<ApiStatus> findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(String accountId, String loanId, Long customerId, String apiName, Boolean active) {
		return apiStatusRepo.findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(accountId, loanId, customerId, apiName, active);
	}
}
