package com.abc.customer.prefilldata.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class IDDetails {
	
	
	@Builder.Default
	@JsonProperty("seq")
	private String Seq = "1";
	
	@JsonProperty("IDValue")
	private String idValue;
	
	@Builder.Default
	@JsonProperty("IDType")
	private String idType = "V";
	
	@Builder.Default
	@JsonProperty("Source")
	private String source = "Inquiry";
	
	public IDDetails() {
		// TODO Auto-generated constructor stub
	}


}
