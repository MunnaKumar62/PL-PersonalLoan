package com.abc.customer.prefilldata.service;

import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.abc.customer.prefilldata.entity.CustomerDetails;
import com.abc.customer.prefilldata.entity.Distance;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.exception.RetryException;
import com.abc.customer.prefilldata.model.BreCallbackRequest;
import com.abc.customer.prefilldata.model.BrePollingResponse;
import com.abc.customer.prefilldata.model.CibilBureauRequestVO;
import com.abc.customer.prefilldata.model.D2CPullRequestVO;
import com.abc.vascredit.model.equifax.request.BrefailureRequest;


public interface CustomerService {
	
	public Optional<CustomerDetails> findByMobileNumber(String mobileNumber);
	public Optional<CustomerDetails> findByPanNumber(String panNumber);
	public ResponseEntity<Object> getBreDetails(String accountId, String loanId, Long customerId);
	public BrePollingResponse getBreDetailsStatus(String accountId, String loanId, Long customerId) throws RetryException, CustomException;
	public String generateToken();
	public ResponseEntity<String> initiateBRE(String breRequest, String loanId, Long customerId,String deviceId);
	public ResponseEntity<Object> brePollingJob();
	public ResponseEntity<String> getDistancezumbio(Distance distance);
	public ResponseEntity<String> verifyEmployment(String requestbody) throws Exception;
	public ResponseEntity<Object> saveCreditCallbackDetails(BreCallbackRequest breCallbackRequest);
	public ResponseEntity<String> executeEquifaxAPI(D2CPullRequestVO d2cPullRequestVO)throws Exception;
	public ResponseEntity<String> generateCIBILBureauRequest(CibilBureauRequestVO cibilBureauRequestVO) throws Exception;
	public ResponseEntity<String> getBrefailureRequest(BrefailureRequest brefailureRequest);
}
