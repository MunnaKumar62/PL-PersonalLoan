package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreApprovedOfferResponse {

	@JsonProperty("abcName")
	private String abcName;

	@JsonProperty("mobile")
	private String mobile;

	@JsonProperty("abcEmail")
	private String abcEmail;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("martialStatusCode")
	private String martialStatusCode;

	@JsonProperty("dob")
	private String dob;

	@JsonProperty("pan")
	private String pan;

	@JsonProperty("aadhaarNum")
	private String aadhaarNum;

	@JsonProperty("ckycNumber")
	private String ckycNumber;

	@JsonProperty("activeStatus")
	private String activeStatus;

	@JsonProperty("sourceOfIncome")
	private String sourceOfIncome;

	@JsonProperty("cibilScrubScore")
	private String cibilScrubScore;

	@JsonProperty("monthlyIncome")
	private String monthlyIncome;

	@JsonProperty("addressLine1")
	private String addressLine1;

	@JsonProperty("addressLine2")
	private String addressLine2;

	@JsonProperty("pincode")
	private String pincode;

	@JsonProperty("city")
	private String city;

	@JsonProperty("state")
	private String state;

	@JsonProperty("customerType")
	private String customerType;

	@JsonProperty("schemeCode")
	private String schemeCode;

	@JsonProperty("lob")
	private String lob;

	@JsonProperty("bankAccountNum")
	private String bankAccountNum;

	@JsonProperty("bankName")
	private String bankName;

	@JsonProperty("branchName")
	private String branchName;

	@JsonProperty("ifscCode")
	private String ifscCode;

	@JsonProperty("accountType")
	private String accountType;

	@JsonProperty("bureauExpiryDate")
	private String bureauExpiryDate;

	@JsonProperty("approvedLoanAmount")
	private String approvedLoanAmount;

	@JsonProperty("tenor")
	private String tenor;

	@JsonProperty("roi")
	private String roi;

	@JsonProperty("cibilScrubdate")
	private String cibilScrubdate;

	@JsonProperty("occupationType")
	private String occupationType;

	@JsonProperty("existingABFLFlag")
	private String existingABFLFlag;

	@JsonProperty("kycValidationFlag")
	private String kycValidationFlag;

	@JsonProperty("bureauFlag")
	private String bureauFlag;

	@JsonProperty("preApprovedFlag")
	private String preApprovedFlag;

	@JsonProperty("hunterStatus")
	private String hunterStatus;

	@JsonProperty("pepStatus")
	private String pepStatus;

	@JsonProperty("elmsBlacklist")
	private String elmsBlacklist;

	@JsonProperty("unscr")
	private String unscr;

	@JsonProperty("updateFlag")
	private String updateFlag;

	@JsonProperty("statusCode")
	private String statusCode;

	@JsonProperty("statusMessage")
	private String statusMessage;

}
