package com.abc.customer.prefilldata.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class ApplicationData {
	
	@Builder.Default
	@JsonProperty("GSTStateCode")
    private String gstStateCode = "27";
	
	//@Builder.Default
	//@JsonProperty("Services")
	//private Map<String,Service> services;
	
	@Builder.Default
	@JsonProperty("Services")
	private Services services = Services.builder().build();
	
}
