package com.abc.customer.prefilldata.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data

public class OfferRequest {
	@JsonProperty("mobile_number")
	private String mobileNumber;
}
