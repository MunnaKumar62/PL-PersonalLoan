package com.abc.customer.prefilldata.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class CibilBureauRequestBuilderVO {
	
	@Builder.Default
	@JsonProperty("RequestInfo")
	private RequestInfo requestInfo = RequestInfo.builder().build();
	
	@JsonProperty("AccountId")
	private String AccountId;
	
	@Builder.Default
	@JsonProperty("Fields")
	private Fields fields = Fields.builder().build();

}
