package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Identifier {
	
	@JsonProperty("IdNumber")
	private String idNumber; //"CCCPB1055J",
	
	@JsonProperty("IdType")
	@Builder.Default
	private String idType = "01";

}
