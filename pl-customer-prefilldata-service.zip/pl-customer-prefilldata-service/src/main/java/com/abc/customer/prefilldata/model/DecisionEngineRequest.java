package com.abc.customer.prefilldata.model;
 
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
@Data
public class DecisionEngineRequest {
	 private String source;
	 private String accountId;
	 private String productCode;
	 @JsonProperty(value="isAbc")
	 private boolean isAbc;
	 @JsonProperty(value="isPreapproved")
	 private boolean isPreapproved;
	 private long preapprovedAmount;
	 private CustomerReport customerReport;
}
