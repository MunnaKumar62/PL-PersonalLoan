package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
@SuperBuilder
public class Score {
	
	@Builder.Default
	@JsonProperty("Type")
	private String type = "ERS";
	
	@Builder.Default
	@JsonProperty("Version")
	private String version = "3.1";
	

	//public ScoreData() {
		// TODO Auto-generated constructor stub
	//}

}
