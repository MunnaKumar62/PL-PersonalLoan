package com.abc.customer.prefilldata.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.customer.prefilldata.entity.LMSLeadDrop;

@Repository
public interface LMSLeadDropRepository extends JpaRepository<LMSLeadDrop, Long> {

	Optional<LMSLeadDrop> findByLeadId(String leadId);
}
