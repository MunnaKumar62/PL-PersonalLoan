package com.abc.customer.prefilldata.util;

import java.util.Objects;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.abc.customer.prefilldata.constant.Constants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class Message {

	private String defaultLocale = Constants.LOCALE_MESSAGE_ENGLISH;
	private String defaultCountryCode = Constants.LOCALE_MESSAGE_COUNTRYCODE;

	public String getMessage(String messageKey) {
		String messageValue = null;
		try {
			ResourceBundle bundle = ResourceBundle
					.getBundle("messages" + "_" + defaultLocale + "_" + defaultCountryCode);
			messageValue = bundle.getString(messageKey);
		} catch (Exception e) {
			log.error("getMessage: {}", e.getMessage());
		}
		return null != messageValue ? messageValue : messageKey;
	}

	public String getMessage(String messageKey, String locale, String countryCode) {
		String messageValue = null;
		locale = (Objects.nonNull(locale)) ? locale : defaultLocale;
		countryCode = (Objects.nonNull(countryCode)) ? countryCode : defaultCountryCode;
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("messages" + "_" + locale + "_" + countryCode);
			messageValue = bundle.getString(messageKey);
		} catch (Exception e) {
			log.error("getMessage: {}", e.getMessage());
		}
		return null != messageValue ? messageValue : messageKey;
	}

	public static String removeSpecialCharactersByRegexPattern(String inputStr, String pattern){
		if(StringUtils.isNotEmpty(inputStr)) {
			String nonMatching = inputStr.replaceAll(pattern, "");
			for (int i = 0; i < nonMatching.length(); i++) {
				inputStr = inputStr.replace(String.valueOf(nonMatching.charAt(i)), "");
			}
		}
		return inputStr;
	}

	public static String removeSpecialCharactersForAddressLine1(String inputStr){

		String regex = "[^\\w\\s\\d(-_.)]+";
		String modifiedStr = "";
		if(StringUtils.isNotEmpty(inputStr)) {
			modifiedStr = Pattern.compile(regex).matcher(inputStr).replaceAll("");
		}

		return modifiedStr;
	}
}
