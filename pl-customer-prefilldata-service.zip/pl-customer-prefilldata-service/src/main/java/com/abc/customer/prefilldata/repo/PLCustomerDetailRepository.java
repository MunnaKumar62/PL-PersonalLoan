package com.abc.customer.prefilldata.repo;

import java.util.List;
import java.util.Optional;

import com.abc.customer.prefilldata.dto.BREPollingDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.customer.prefilldata.entity.PLCustomerDetail;

@Repository
public interface PLCustomerDetailRepository extends JpaRepository<PLCustomerDetail, Long> {

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndActive(String accountId, Boolean active);

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId and a.active =:active)")
	Optional<PLCustomerDetail> findByAccountIdAndActiveAndLoanIdAndCustomerId(String accountId, Boolean active, String loanId, Long customerId);

	@Query("SELECT a FROM PLCustomerDetail a WHERE a.customerDetailId=(SELECT max(a.customerDetailId) FROM PLCustomerDetail a WHERE a.accountId =:accountId and a.loanId =:loanId and a.customerId =:customerId and a.active= :active)")
	Optional<PLCustomerDetail> findByAccountIdAndLoanIdAndCustomerIdActive(String accountId, String loanId, Long customerId, Boolean active);

	@Query("SELECT a.accountId, a.loanId FROM PLCustomerDetail a WHERE a.ceStatus = :ceStatus and a.active=false order by a.customerDetailId")
	List<BREPollingDto> findByCeStatus(String ceStatus);
	
	@Query("SELECT ceStatus,customerId FROM PLCustomerDetail "
			+ "WHERE journeyType IN ('ntb_flow', 'pre_approved_flow') " + "AND ceStatus IS NOT NULL "
			+ "AND customerId = :customerId")
	List<Object[]> findPlDetails(@Param("customerId") String customerId);

	@Query(value = "SELECT COUNT(*) FROM t_pl_customer_detail " +
            "WHERE customer_id = :customerId " +
            "AND journey_type = 'ntb_flow' " +
            "AND epfocheck = 0 " +
            "AND epfo_otp_req = 0"
            + " AND accountid=:accountid AND loan_id=:loan_id", 
    nativeQuery = true)
int countByCustomerIdAndJourneyType(@Param("customerId") Long customerId,@Param("accountid") String accountid,@Param("loan_id") String loan_id);
}
