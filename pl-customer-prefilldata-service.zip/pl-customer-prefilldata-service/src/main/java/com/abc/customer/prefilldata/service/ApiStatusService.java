package com.abc.customer.prefilldata.service;

import java.util.Optional;

import com.abc.customer.prefilldata.entity.ApiStatus;

public interface ApiStatusService {

	public ApiStatus savOrUpdateApiStatus(ApiStatus apiStatus);

	public ApiStatus findByAccountIdAndApiName(String accountId, String apiName);

	public Optional<ApiStatus> findByAccountIdAndApiNameAndActive(String accountId, String apiName, Boolean active);

	public Optional<ApiStatus> findByAccountIdAndLoanIdAndCustomerIdAndApiNameAndActive(String accountId, String loanId, Long customerId, String apiName, Boolean active);
}
