package com.abc.customer.prefilldata.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PreapprovedEmpOfferData {

	private List<PreapprovedEmpOfferResponse> data;
}
