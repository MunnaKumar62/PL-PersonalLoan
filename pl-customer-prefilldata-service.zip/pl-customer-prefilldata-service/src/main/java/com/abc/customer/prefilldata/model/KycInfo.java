package com.abc.customer.prefilldata.model;

import lombok.Data;

@Data
public class KycInfo {
	
	
	
	private String cccId;
	private String firstName;
	private String lastName;
	private String middleName;
	private String mobile;
	private String email;
	private String panNumber;
	private String gender;
	private String dob;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String city;
	private String state;
	private long pincode;
	

}
