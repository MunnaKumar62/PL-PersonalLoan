package com.abc.customer.prefilldata.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Applicant {
	
	//@Builder.Default
	@JsonProperty("ApplicantFirstName")
	private String applicantFirstName ; //= "BAGRECHA"
	
	@Builder.Default
	@JsonProperty("ApplicantMiddleName")
	private String applicantMiddleName = "";
	
	//@Builder.Default
	@JsonProperty("ApplicantLastName")
	private String applicantLastName; //="NAMRATA"
	
	@Builder.Default
	@JsonProperty("DateOfBirth")
	private String dateOfBirth="01011988";
	
	@Builder.Default
	@JsonProperty("Gender")
	private String gender="Male";
	
	@Builder.Default
	@JsonProperty("EmailAddress")
	private String emailAddress="BAGRECHA_NAMRATA@gmail.com";
	
	@Builder.Default
	@JsonProperty("Identifiers")
	private Identifiers identifiers = Identifiers.builder().build();
	
	//@Singular("telephone")
	//@JsonProperty("Telephones")
	//private Map<String, Telephone> telephones;
	@Builder.Default
	@JsonProperty("Telephones")
	private Telephones telephones = Telephones.builder().build();
	
	//@Singular("addresse")
	//@JsonProperty("Addresses")
	//private Map<String, Address> addresses;	
	@Builder.Default
	@JsonProperty("Addresses")
	private Addresses addresses = Addresses.builder().build();
	
	@Builder.Default
	@JsonProperty("KeyPersonRelation")
	private String keyPersonRelation="";
	
	@Builder.Default
	@JsonProperty("KeyPersonName")
	private String keyPersonName="";
	
	@Builder.Default
	@JsonProperty("MemberRelationName1")
	private String memberRelationName1="";
	
	@Builder.Default
	@JsonProperty("MemberRelationType1")
	private String memberRelationType1="";
	
	@Builder.Default
	@JsonProperty("MemberRelationName2")
	private String memberRelationName2="";
	
	@Builder.Default
	@JsonProperty("MemberRelationType2")
	private String memberRelationType2="";
	
	@Builder.Default
	@JsonProperty("MemberRelationName3")
	private String memberRelationName3="";
	
	@Builder.Default
	@JsonProperty("MemberRelationType3")
	private String memberRelationType3="";
	
	@Builder.Default
	@JsonProperty("MemberRelationName4")
	private String memberRelationName4="";
	
	@Builder.Default
	@JsonProperty("MemberRelationType4")
	private String memberRelationType4="";
	
	@Builder.Default
	@JsonProperty("NomineeName")
	private String nomineeName="";
	
	@Builder.Default
	@JsonProperty("NomineeRelation")
	private String nomineeRelation="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId1")
	private String memberOtherId1="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId1Type")
	private String memberOtherId1Type="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId2")
	private String memberOtherId2="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId2Type")
	private String memberOtherId2Type="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId3")
	private String memberOtherId3="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId3Type")
	private String memberOtherId3Type="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId4")
	private String memberOtherId4="";
	
	@Builder.Default
	@JsonProperty("MemberOtherId4Type")
	private String memberOtherId4Type="";
	
	//@Singular("account")
	//@JsonProperty("Accounts")
	//private Map<String, Account> accounts;
	@Builder.Default
	@JsonProperty("Accounts")
	private Accounts accounts = Accounts.builder().build();
	
	//@Singular("service")
	//@JsonProperty("Services")
	//private Map<String, Service> services;
	@Builder.Default
	@JsonProperty("Services")
	private Services services = Services.builder().build();

}
