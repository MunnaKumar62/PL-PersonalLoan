package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class InquiryPhones {
	
	

	@Builder.Default
	@JsonProperty("seq")
	private String Seq = "1";
	
	@JsonProperty("Number")
	private String number;
	
	@Singular("phoneType")
	@JsonProperty("PhoneType")
	private List<String> phoneType;
	

	public InquiryPhones() {
		// TODO Auto-generated constructor stub
	}

}
