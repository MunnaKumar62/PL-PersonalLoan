package com.abc.customer.prefilldata.serviceImp;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.constant.ExceptionMessage;
import com.abc.customer.prefilldata.constant.MessageConstants;
import com.abc.customer.prefilldata.entity.CustomerDetails;
import com.abc.customer.prefilldata.entity.PreapprovedEmpOffer;
import com.abc.customer.prefilldata.entity.TokenResponse;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.exception.InternalException;
import com.abc.customer.prefilldata.model.PreApprovedOfferRequest;
import com.abc.customer.prefilldata.model.PreApprovedOfferResponse;
import com.abc.customer.prefilldata.repo.CustomerRepository;
import com.abc.customer.prefilldata.repo.PreapprovedEmpOfferRepository;
import com.abc.customer.prefilldata.request.ApiCommonRequest;
import com.abc.customer.prefilldata.request.OfferRequest;
import com.abc.customer.prefilldata.request.ValidityResponse;
import com.abc.customer.prefilldata.response.BqOfferResponse;
import com.abc.customer.prefilldata.response.PreapprovedEmpOfferData;
import com.abc.customer.prefilldata.response.PreapprovedEmpOfferResponse;
import com.abc.customer.prefilldata.service.PreApprovedOfferService;
import com.abc.customer.prefilldata.service.biz.CommonBizService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class PreApprovedOfferServiceImpl  extends CommonBizService implements PreApprovedOfferService,  Constants, MessageConstants {
	
	private final String className = "[" + this.getClass().getSimpleName() + "]";

	@Autowired
	private Environment env;
	
	@Autowired
	ObjectMapper objectMapper;

	@Value("${preapproved.offer.url}")
	private String preApprovedOfferUrl;

	@Value("${abfl.token.url}")
	private String tokenUrl;

	@Value("${pl.token.client_id}")
	private String clientId;

	@Value("${pl.token.scope}")
	private String scope;

	@Value("${pl.token.grant_type}")
	private String grantType;

	@Value("${pl.token.auth}")
	private String authToken;
	
	@Value("${bq.preapproved.offer.url}")
	private String preApprovedEmpOfferUrl;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private PreapprovedEmpOfferRepository offerRepository;
	
	@Autowired
	private CustomerRepository customerRepo;

	@Override
	public PreApprovedOfferResponse getPreApprovedOffers(PreApprovedOfferRequest preApprovedOfferRequest) {
		if (preApprovedOfferRequest != null && (Strings.isNotBlank(preApprovedOfferRequest.getMobileNumber())
				|| Strings.isNotBlank(preApprovedOfferRequest.getPanNumber()))) {
			try {
				ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
				String jsonBody = ow.writeValueAsString(preApprovedOfferRequest);

				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.add("auth-token", generateToken());
				HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);

				PreApprovedOfferResponse postForObject = restTemplate.postForObject(preApprovedOfferUrl, entity,
						PreApprovedOfferResponse.class);
				if (postForObject.getStatusCode() != null && !postForObject.getStatusCode().equals("10")) {
					if ("11".equals(postForObject.getStatusCode())||"12".equals(postForObject.getStatusCode())
							|| "13".equals(postForObject.getStatusCode())) {
						throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
								"Unable to Fetch Offer Details", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
					} 				}
				return postForObject;
			} catch (Exception e) {
				e.printStackTrace();
				throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
						"Unable to Fetch Offer Details", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} else {
			throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					"Unable to Fetch Offer Details", HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

	public String generateToken() {
		TokenResponse tokenResp = null;
		try {
			log.info("Generate Token Start");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam("client_id", clientId)
					.queryParam("scope", scope).queryParam("grant_type", grantType).build();

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			headers.add("Authorization", "Basic " + authToken);

			HttpEntity<Object> request = new HttpEntity<>(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					request, String.class);

			tokenResp = objectMapper.readValue(responseEntity.getBody(), TokenResponse.class);

			if (Objects.isNull(tokenResp) || Objects.isNull(tokenResp.getAccessToken())) {

				throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
						// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
						HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}

			log.info("Token " + tokenResp.getAccessToken());
			log.info("Generate Token End");
		} catch (Exception e) {
			throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					// ResponseStatusCode.FAILED_TO_GET_TOKEN.getValue(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}

		return tokenResp.getAccessToken();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> callPreapprovedEmpOffer(OfferRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		ResponseEntity<Object> apiResponse = new ResponseEntity<>(HttpStatus.OK);
		Object obj = null;
		Map<String, Object> map = null;
		// External API Call
		ApiCommonRequest commonRequest = ApiCommonRequest.builder().apiName(GET_BQ_OFFER).accountId(EMPTY)
				.profileId(EMPTY).requestId(request.getMobileNumber()).transactionId(EMPTY).url(preApprovedEmpOfferUrl)
				.requestHeaders(getRequestHeaders(generateToken())).method(HttpMethod.POST).request(request)
				.isAudit(Boolean.FALSE).build();

		map = callExternalApi(commonRequest, String.class);

		if (null != map && !map.isEmpty() && null != map.get(API_RESPONSE)) {
			apiResponse = (ResponseEntity<Object>) map.get(API_RESPONSE);
			obj = apiResponse.getBody();
		}
		log.info(className + methodName + END);

		return new ResponseEntity<>(obj, apiResponse.getStatusCode());
	}
	
	/**
	 * Call API once in a day per customer
	 * 
	 * Call API if Modified Date < Current Date
	 * 
	 * Get details from DB for subsequent call on same day
	 */
	@Override
	public ResponseEntity<PreapprovedEmpOfferData> getPreapprovedEmpOffer(OfferRequest request) {

		String methodName = "[" + Thread.currentThread().getStackTrace()[1].getMethodName() + "]";
		log.info(className + methodName + BEGIN);

		final String code = "PL2201";
		ResponseEntity<Object> apiResponse;
		boolean flag = Boolean.FALSE;
		CommonBizService service = new CommonBizService();
		List<PreapprovedEmpOfferResponse> list = new ArrayList<>();
		PreapprovedEmpOfferData preapprovedEmpOfferData = new PreapprovedEmpOfferData();

		if (request.getMobileNumber().isEmpty()) {
			throw new CustomException(code, FILED_MOBILE_NUMBER, EMPTY_FIELD);
		} else {
			// Validate whether Customer is Registered or not
			Optional<CustomerDetails> customerDetails = customerRepo.findByMobileNumber(request.getMobileNumber());
			if (!customerDetails.isPresent()) {
				throw new CustomException(code, env.getProperty(code), CUST_VALIDATION);
			} else {
				// Fetch details from t_pl_preapproved_emp_offer table
				PreapprovedEmpOffer offer = offerRepository.findByMobileNo(request.getMobileNumber());
				if (null != offer && null != offer.getValidity()) {
					// Compare Modified Date & Current Date
					SimpleDateFormat sd = new SimpleDateFormat(DATE_FORMAT);
					String modifiedDate = sd.format(offer.getModifiedDate());
					String currDate = sd.format(new Date());
					log.info(className + methodName + "ModifiedDate: " + modifiedDate + " and CurrentDate: " + currDate);
					/*if (service.date1BeforeDate2(modifiedDate, currDate)) {
						flag = Boolean.TRUE;
					} else {
						// Construct list from DB
						list.add(service.constructResponseObj(offer));
					}*/
				} /*else {
					flag = Boolean.TRUE;
				}*/
				if (flag) {
					// Call API
					apiResponse = callPreapprovedEmpOffer(request);

					try {
						List<BqOfferResponse> bqOfferResponse = objectMapper.readValue((String) apiResponse.getBody(),
								new TypeReference<List<BqOfferResponse>>() {
								});

						if (!bqOfferResponse.isEmpty()) {
							PreapprovedEmpOfferResponse apiResponse1 = merege(bqOfferResponse);
							List<PreapprovedEmpOfferResponse> apiResponseList = Collections.singletonList(apiResponse1);

							String jsonString = objectMapper.writeValueAsString(apiResponseList);
							log.info("jsonString: " + jsonString);

							list = objectMapper.readValue(jsonString,
									new TypeReference<List<PreapprovedEmpOfferResponse>>() {
									});
						} else {
							list = objectMapper.readValue((String) apiResponse.getBody(),
									new TypeReference<List<PreapprovedEmpOfferResponse>>() {
									});
						}

						// Construct list from API Response
						list = service.constructResponseList(list, offer);
						if (!list.isEmpty()) {
							// Save Or Update
							offerRepository.save(service.constructDBObj(list.get(0)));
						}
					} catch (JsonProcessingException ex) {
						log.error(className + methodName + EXCEPTION + "[" + ex.getMessage() + "]");
					}
				}
			}
			// Set list into final response
			preapprovedEmpOfferData.setData(list);
		}
		return ResponseEntity.ok(preapprovedEmpOfferData);
	}

	public void bqFreezeCustomer(OfferRequest request) {
		log.info("******* bqFreezeCustomer Service Class Method Begins *********");
		try {
			PreapprovedEmpOffer offer = offerRepository.findByMobileNo(request.getMobileNumber());
			if (Objects.nonNull(offer)) {
				offer.setStatus(Boolean.FALSE);
				offer.setValid(Boolean.FALSE);
				offer.setModifiedDate(new Timestamp(new Date().getTime()));
				offerRepository.save(offer);
			}else{
				log.info("**** bqFreezeCustomer OFFER DETAILS NOT AVAILABLE BLOCK **********");
				throw new InternalException("1012");
			}
		}catch (Exception e){
			log.info("Exception Message **********"+e.getMessage());
			throw new InternalException("1012");
		}
		log.info("******* bqFreezeCustomer Service Class Method Ends *********");
	}

	public void bqNonFreezeCustomer(OfferRequest request) {
		log.info("******* bqNonFreezeCustomer Service Class Method Begins *********");
		try {
			PreapprovedEmpOffer offer = offerRepository.findByMobileNo(request.getMobileNumber());
			if (Objects.nonNull(offer)) {
				offer.setStatus(Boolean.TRUE);
				offer.setValid(Boolean.TRUE);
				offer.setModifiedDate(new Timestamp(new Date().getTime()));
				offerRepository.save(offer);
			}else{
				log.error("**** bqNonFreezeCustomer OFFER DETAILS NOT AVAILABLE BLOCK **********");
				throw new CustomException(String.valueOf(HttpStatus.NOT_FOUND.value()),
						ExceptionMessage.OFFER_DTLS_NOT_AVAILABLE, HttpStatus.NOT_FOUND.getReasonPhrase());
			}
		}catch (Exception e){
			e.printStackTrace();
			throw new CustomException(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()),
					ExceptionMessage.OFFER_FREEZE_ERROR, HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		}
		log.info("******* bqNonFreezeCustomer Service Class Method Ends *********");
	}
	
	private PreapprovedEmpOfferResponse merege(List<BqOfferResponse> bqOfferResponse) {
		BqOfferResponse bqOffer = bqOfferResponse.get(0);
		PreapprovedEmpOfferResponse preapproved = new PreapprovedEmpOfferResponse();

		preapproved.setCustomerName(bqOffer.getName() != null ? bqOffer.getName() : null);
		preapproved.setGender(bqOffer.getGender() != null ? bqOffer.getGender() : null);
		preapproved.setMobileNo(bqOffer.getAbc_mobile() != null ? bqOffer.getAbc_mobile() : null);
		preapproved.setDateOfBirth(bqOffer.getDob() != null ? bqOffer.getDob() : null);
		preapproved.setPanNumber(bqOffer.getPan() != null ? bqOffer.getPan() : null);
		preapproved.setMinLoanOffered(bqOffer.getPlpa_min_loan_offered() != null ? bqOffer.getPlpa_min_loan_offered() : null);
		preapproved.setMaxLoanAmount(bqOffer.getPlpa_offer_amount() != null ? bqOffer.getPlpa_offer_amount() : null);
		preapproved.setMinTenure(bqOffer.getPlpa_min_tenure() != null ? bqOffer.getPlpa_min_tenure() : 0);
		preapproved.setMaxTenure(bqOffer.getPlpa_max_eligible_tenure() != null ? bqOffer.getPlpa_max_eligible_tenure() : 0);
		preapproved.setProcessingFeePercentage(bqOffer.getPlpa_pf_percentage() != null ? bqOffer.getPlpa_pf_percentage() : 0);

		BigInteger bigInteger = bqOffer.getPlpa_offer_amount() != null ? new BigInteger(bqOffer.getPlpa_offer_amount().toString()) : null;
		Double doubleValue = bigInteger != null ? bigInteger.doubleValue() : 0;
		preapproved.setPreApprovedLoanAmount(doubleValue);
		log.info(bqOffer.getPlpa_roi());
		preapproved.setInterestRateNew(bqOffer.getPlpa_roi() != null ? Double.parseDouble(bqOffer.getPlpa_roi()) : 0);

		preapproved.setInterestRate(bqOffer.getPlpa_roi() != null ? Double.parseDouble(bqOffer.getPlpa_roi()) : 0);
		preapproved.setMaxEmi(bqOffer.getPlpa_emi() != null ? bqOffer.getPlpa_emi() : 0);
		preapproved.setPersonalEmailId(bqOffer.getAbc_email() != null ? bqOffer.getAbc_email() : null);
		preapproved.setProfessionalEmailId(bqOffer.getAbc_email() != null ? bqOffer.getAbc_email() : null);
		ValidityResponse validity = CheckValidity(bqOffer);
		
		preapproved.setValidity(validity != null ? validity.getValidityDate() : null);
		preapproved.setOfferCreatedAt(validity != null ? validity.getValidityDate() : null);
		preapproved.setOfferType(validity != null ? validity.getLoanType() : null);
		log.info("preapproved"+preapproved);
		return preapproved;

	}
	public Double bigtoDouble(BigInteger value) {
	    return value.doubleValue();
	}
	
	
	public ValidityResponse CheckValidity(BqOfferResponse bqOfferResponse) {
		
		BqOfferResponse	bqOffer=bqOfferResponse;
	String[] productCategories = { bqOffer.getProduct_category_1(), bqOffer.getProduct_category_2(),
			bqOffer.getProduct_category_3() };
	String[] validities = { bqOffer.getValidity_1(), bqOffer.getValidity_2(),
			bqOffer.getValidity_3() };

	boolean isValid = false;
	ValidityResponse response1= new ValidityResponse();
	for (int i = 0; i < productCategories.length; i++) {
		if (productCategories[i] != null && validities[i]!= null ) {
			if (productCategories[i].equalsIgnoreCase("Personal Loan") && validities[i] != null
					&& calculate(validities[i]) == true) {
				response1.setLoanType("Personal Loan");
				response1.setValidityDate(validities[i]);
				response1.setIsValidity(true);
				break;
			}
		}
			else {
				response1.setLoanType("Personal Loan");
				response1.setValidityDate(validities[i]);
				response1.setIsValidity(false);
			}
	}
	
	log.info(response1);
	return response1;
	}
	public boolean calculate(String value) {
		String inputDateString = value;
		SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));

		try {
			Date inputDate = sdf.parse(inputDateString);

			// Get the current date at midnight
			Calendar today = Calendar.getInstance();
			today.set(Calendar.HOUR_OF_DAY, 0);
			today.set(Calendar.MINUTE, 0);
			today.set(Calendar.SECOND, 0);
			today.set(Calendar.MILLISECOND, 0);

			// Compare inputDate with today's date in milliseconds
			boolean isTodayOrFuture = inputDate.getTime() >= today.getTimeInMillis();

			if (isTodayOrFuture) {
				log.info("The input date is today or in the future.");
			} else {
				log.info("The input date is in the past.");
			}

			return isTodayOrFuture; // Return the result of the comparison
		} catch (ParseException e) {
			e.printStackTrace();
			return false; 
		}
	}
}
