package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@SuperBuilder
public class RequestInfo {
	
	@Builder.Default
	@JsonProperty("SolutionSetName")
	private String solutionSetName = "GO_Aditya_Birla_Finance_AGSS";
	
	@Builder.Default
	@JsonProperty("ExecuteLatestVersion")
	private String executeLatestVersion = "true";

}
