package com.abc.customer.prefilldata.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BreCallbackData {

	@JsonProperty("min_loan_amount")
	public String minLoanAmount;
	
	@JsonProperty("account_id")
	public String accountId;

	@JsonProperty("customer_id")
	public Long customerId;

	@JsonProperty("loan_id")
	public String loanId;
	
	@JsonProperty("max_tenure")
	public String maxTenure;
	
	@JsonProperty("max_emi")
	public String maxEmi;
	
	@JsonProperty("min_tenure")
	public String minTenure;
	
	@JsonProperty("max_loan_amount")
	public String maxLoanAmount;
	
	@JsonProperty("ccc_id")
	public String cccId;
	
	@JsonProperty("async_id")
	public String asyncId;
	
	@JsonProperty("roi")
	public String roi;
}
