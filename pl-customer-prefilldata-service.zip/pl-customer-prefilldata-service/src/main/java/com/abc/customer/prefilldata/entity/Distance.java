package com.abc.customer.prefilldata.entity;

import java.util.List;

public class Distance {
	
	private String accountId;
	private Source source;
	private   List  optionList;	
	private Address locationAddresses;
	
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public Source getSource() {
		return source;
	}
	public void setSource(Source source) {
		this.source = source;
	}
	public List getOptionList() {
		return optionList;
	}
	public void setOptionList(List optionList) {
		this.optionList = optionList;
	}
	public Address getLocationAddresses() {
		return locationAddresses;
	}
	public void setLocationAddresses(Address locationAddresses) {
		this.locationAddresses = locationAddresses;
	}

}
