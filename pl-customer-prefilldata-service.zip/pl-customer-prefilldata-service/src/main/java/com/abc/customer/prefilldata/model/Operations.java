package com.abc.customer.prefilldata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.Singular;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Operations {
	
	@Singular("operation")
	@JsonProperty("Operation")
	private List<Operation> operation;

}
