package com.abc.customer.prefilldata.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
public class Fields {
	
	//@JsonProperty("Applicants")
	//private Map<String,Applicant> applicants;
	
	@Builder.Default
	@JsonProperty("Applicants")
	private Applicants applicants = Applicants.builder().build();
	
	@Builder.Default
	@JsonProperty("ApplicationData")
	private ApplicationData applicationData = ApplicationData.builder().build();

}
