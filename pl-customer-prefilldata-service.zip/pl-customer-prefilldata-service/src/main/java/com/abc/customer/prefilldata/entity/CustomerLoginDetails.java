package com.abc.customer.prefilldata.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "t_customer_login_details")
public class CustomerLoginDetails {
    @Id
    @Column(name = "customer_device_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long customerDeviceId;

    @Column(name = "mdn")
    private String mdn;

    @Column(name = "device_id")
    private String deviceId;

    @Column(name = "imei")
    private String imei;

    @Column(name = "os_name")
    private String osName;

    @Column(name = "os_version")
    private String osVersion;

    @Column(name = "mobile_operator")
    private String mobileOperator;

    @Column(name = "battery_status")
    private String batteryStatus;

    @Column(name = "login_location_lat")
    private Float loginLocationLat;

    @Column(name = "login_location_long")
    private Float loginLocationLong;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "login_time")
    private LocalDateTime loginTime;

    @Column(name = "logout_time")
    private LocalDateTime logoutTime;

    @Column(name = "network_source")
    private String networkSource;

    @Column(name = "activation_count")
    private Integer activationCount;

    @Column(name = "is_loggedin")
    private String isLoggedin;

    @Column(name = "channel")
    private String channel;

    @Column(name = "logout_type")
    private String logoutType;

    @Column(name = "sessionid")
    private String sessionid;

    @Column(name = "jwttoken")
    private String jwttoken;

    @Column(name = "fcmtoken")
    private String fcmtoken;

    @Column(name = "os_patch_version")
    private String osPatchVersion;

    @Column(name = "device_bind")
    private String deviceBind;

    @Column(name = "ssid")
    private String ssid;
    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "authtype")
    private String authtype;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "active")
    private Boolean active = true;

    @Column(name = "model")
    private String model;

    @Column(name = "app_version")
    private String appVersion;
}