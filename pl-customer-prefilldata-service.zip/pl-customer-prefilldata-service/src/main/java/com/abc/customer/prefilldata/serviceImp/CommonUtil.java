package com.abc.customer.prefilldata.serviceImp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.WebRequest;

import com.abc.customer.prefilldata.constant.Constants;
import com.abc.customer.prefilldata.exception.CustomException;
import com.abc.customer.prefilldata.exception.ExternalException;
import com.abc.customer.prefilldata.exception.PartnerError;
import com.abc.customer.prefilldata.model.ErrorResponse;
import com.abc.customer.prefilldata.model.Errors;
import com.abc.customer.prefilldata.model.SuccessResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j;
import lombok.extern.log4j.Log4j2;




@Component
@Log4j2
public class CommonUtil {

	@Value("${spring.application.name}")
	private static String applicationName;
	
	@Autowired
	ObjectMapper objectMapper;

	public static SuccessResponse getSuccessResponse(String code, String message, Object data) {

		SuccessResponse successResponse = new SuccessResponse();
		//successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.SUCCESS);
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}
	
	public static SuccessResponse getErrorResponse(Object data) {
		SuccessResponse successResponse = new SuccessResponse();
		//successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.ERROR);
		successResponse.setData(data);
		return successResponse;
	}

	public static ErrorResponse getCustomErrorResponse(CustomException ex, HttpHeaders headers, HttpStatusCode status,
			WebRequest request) {
		
		List<Errors> errorList = new ArrayList<>();
		Errors errors = new Errors();
		/*
		 * if(ex.getDiscription().equalsIgnoreCase("401 Unauthorized: [no body]")) {
		 * errors.setMessage("User not authenticated"); }else
		 * if(ex.getDiscription().equalsIgnoreCase("'ccc_request_id'")){
		 * errors.setMessage("Something went wrong, Please try after sometime"); }else {
		 * 
		 * }
		 */
		errors.setMessage(ex.getDiscription());
		errors.setErrorCode(ex.getErrorCode());
		
		errors.setErrorType(ex.getErrorType());
		String path = request != null ? request.getContextPath() : "";
		ErrorResponse errorMessage = new ErrorResponse();
		errorMessage.setTimestamp(LocalDateTime.now()+"");
		
            
		if(ex.getErrorType() != null) {
			if(ex.getErrorType().equalsIgnoreCase("INTERNAL_API_FAILED_TO_RESPOND")) {
				errorMessage.setStatus("This service appears to be unavailable. You will soon get a response from where you can resume your journey.");
			}else {
				errorMessage.setStatus("ERROR");
			}
		}else {
			errorMessage.setStatus("ERROR");
		}
		
		errorList.add(errors);
		errorMessage.setPath(path);
		
		errorMessage.setErrors(errorList);
		return errorMessage;
	} 
	
	public static ErrorResponse getErrorResponse(Exception ex, HttpHeaders headers, HttpStatusCode status,
			WebRequest request) {
		List<Errors> errorsList = new ArrayList<>();
		String errorCode = "PL" + "4" + status.value();
		String message = ex.getMessage() != null ? ex.getMessage() : "";
		String path = request != null ? request.getContextPath() : "";
		getErrorList(errorCode, "", message, errorsList);
		return getErrorMessage(  path, errorsList);
	}

	public static ErrorResponse getErrorResponse(List<FieldError> fieldErrors, HttpHeaders headers,
			HttpStatusCode status, WebRequest request) {
		List<Errors> errorList = new ArrayList<>();
		String errorCode = "PL" + "4" + status.value();
		String path = request != null ? request.getContextPath() : "";
		for (FieldError fieldError : fieldErrors) {
			getErrorList(errorCode, fieldError.getField(), fieldError.getDefaultMessage(), errorList);
		}
		return getErrorMessage(path, errorList);
	}

	public static ErrorResponse getErrorMessage( String path, List<Errors> errorList) {
		ErrorResponse errorMessage = new ErrorResponse();
		errorMessage.setTimestamp(LocalDateTime.now()+"");
		errorMessage.setPath(path);
		errorMessage.setErrors(errorList);
		return errorMessage;
	}

	public static void getErrorList(String errorCode, String fieldName, String message, List<Errors> errorList) {
		Errors errors = new Errors(errorCode, fieldName, message,"");
		errorList.add(errors);
	}
	

    public void handleHttpClientError(HttpStatusCodeException ex, String apiName) {
        log.info("handleHttpClientError()-apiName=" + apiName + "; statusCode=" + ex.getStatusCode().value()
                + "; response =" + ex.getResponseBodyAsString());
        PartnerError partnerError = null;
        String errorMessage = null;
        String reason = null;
        String errorDescription;
        int httpStatusCode = ex.getStatusCode().value();
        if (!ex.getResponseBodyAsString().isEmpty()) {
            try {
                partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
                if (partnerError.getError() != null) {
                    errorDescription = partnerError.getError().getDescription() != null ? partnerError.getError().getDescription() : "Client Error";
                    errorMessage = partnerError.getError().getMessage() != null ? partnerError.getError().getMessage() : errorDescription;
                }

            } catch (JsonProcessingException e) {
                errorMessage = "Error processing JSON response from the client";
                reason = ex.getStatusText();
                log.error("Error processing JSON response from client: " + ex.getResponseBodyAsString(), e);
            }
        } else {
            errorMessage = "Empty or null response from the client";
            log.error("Empty or null response received from client API: " + apiName);
        }
        if (partnerError != null && partnerError.getError() != null) {
            throw new ExternalException("C" + httpStatusCode, errorMessage,
                    httpStatusCode, errorMessage);
        } else {
            throw new ExternalException("C" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
                    500, reason);
        }
    }

    public void handleHttpServerError(HttpStatusCodeException ex, String apiName) throws Exception {
        log.info("handleHttpServerError() - apiName=" + apiName + "; statusCode=" + ex.getStatusCode().value()
                + "; response =" + ex.getResponseBodyAsString());
        PartnerError partnerError = null;
        String errorMessage = null;
        String reason = null;
        int httpStatusCode = ex.getStatusCode().value();
        if (ex.getResponseBodyAsString() != null && !ex.getResponseBodyAsString().isEmpty()) {
            try {
                partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
                errorMessage = partnerError.getError() != null ? partnerError.getError().getMessage() : null;
            } catch (JsonProcessingException e) {
                errorMessage = "Error processing JSON response from the server";
                reason = ex.getStatusText();
                log.error("Error processing JSON response from server: " + ex.getResponseBodyAsString(), e);
            }
        } else {
            errorMessage = "Empty or null response from the server";
            log.error("Empty or null response received from server for API: " + apiName);
        }
        if (partnerError != null && partnerError.getError() != null && partnerError.getError().getStatus() != null
                && partnerError.getError().getMessage() != null) {
            throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
                    partnerError.getError().getStatus(), partnerError.getError().getMessage());
        } else {
            throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
                    500, reason);
        }
    }

}
