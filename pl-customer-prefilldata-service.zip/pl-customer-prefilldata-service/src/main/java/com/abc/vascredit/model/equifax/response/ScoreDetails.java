package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ScoreDetails {
    @JsonProperty("Type")
    private String type;

    @JsonProperty("Version")
    private String version;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Value")
    private String value;

    @JsonProperty("ScoringElements")
    private ScoringElement[] scoringElements;
}