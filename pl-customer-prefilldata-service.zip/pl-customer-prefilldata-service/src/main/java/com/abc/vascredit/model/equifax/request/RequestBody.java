package com.abc.vascredit.model.equifax.request;

import com.abc.vascredit.model.equifax.response.CustomFields;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestBody {
    @JsonProperty("InquiryPurpose")
    private String inquiryPurpose;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("MiddleName")
    private String middleName;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("InquiryAddresses")
    private InquiryAddresses[] inquiryAddresses;
    @JsonProperty("InquiryPhones")
    private InquiryPhone[] inquiryPhones;
    @JsonProperty("IDDetails")
    private IDDetails[] idDetails;
    @JsonProperty("CustomFields")
    private CustomFields[] customFields;
    @JsonProperty("DOB")
    private String dob;
    @JsonProperty("Gender")
    private String gender;
}