package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Decision {
	@JsonProperty("Decision")
	private String decision;
	@JsonProperty("Error")
	private Error error;
	
	@JsonProperty("Active")
	private Boolean active;
	
}
