package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RetailAccountsSummary {
    @JsonProperty("NoOfAccounts")
    private String noOfAccounts;

    @JsonProperty("NoOfActiveAccounts")
    private String noOfActiveAccounts;

    @JsonProperty("NoOfWriteOffs")
    private String noOfWriteOffs;

    @JsonProperty("TotalPastDue")
    private String totalPastDue;

    @JsonProperty("SingleHighestCredit")
    private String singleHighestCredit;

    @JsonProperty("SingleHighestSanctionAmount")
    private String singleHighestSanctionAmount;

    @JsonProperty("TotalHighCredit")
    private String totalHighCredit;

    @JsonProperty("AverageOpenBalance")
    private String averageOpenBalance;

    @JsonProperty("SingleHighestBalance")
    private String singleHighestBalance;

    @JsonProperty("NoOfPastDueAccounts")
    private String noOfPastDueAccounts;

    @JsonProperty("NoOfZeroBalanceAccounts")
    private String noOfZeroBalanceAccounts;

    @JsonProperty("RecentAccount")
    private String recentAccount;

    @JsonProperty("OldestAccount")
    private String oldestAccount;

    @JsonProperty("TotalBalanceAmount")
    private String totalBalanceAmount;

    @JsonProperty("TotalSanctionAmount")
    private String totalSanctionAmount;

    @JsonProperty("TotalCreditLimit")
    private String totalCreditLimit;

    @JsonProperty("TotalMonthlyPaymentAmount")
    private String totalMonthlyPaymentAmount;
}