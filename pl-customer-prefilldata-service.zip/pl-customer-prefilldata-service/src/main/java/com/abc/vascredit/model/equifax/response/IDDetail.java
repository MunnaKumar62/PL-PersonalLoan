package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class IDDetail {
    @JsonProperty("seq")
    private String seq;

    @JsonProperty("IDType")
    private String idType;

    @JsonProperty("IDValue")
    private String idValue;

    @JsonProperty("Source")
    private String source;
}