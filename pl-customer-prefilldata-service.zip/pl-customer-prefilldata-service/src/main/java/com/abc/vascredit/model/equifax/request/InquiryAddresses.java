package com.abc.vascredit.model.equifax.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class InquiryAddresses {

	@JsonProperty("seq")
	private String seq;
	@JsonProperty("AddressType")
	private String[] addressType;
	@JsonProperty("AddressLine1")
	private String addressLine1;
	@JsonProperty("AddressLine2")
	private String addressLine2;
	@JsonProperty("Locality")
	private String locality;
	@JsonProperty("City")
	private String city;
	@JsonProperty("State")
	private String state;
	@JsonProperty("Postal")
	private String postal;
	
}
