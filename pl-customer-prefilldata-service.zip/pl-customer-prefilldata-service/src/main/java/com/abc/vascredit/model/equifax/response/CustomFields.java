package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomFields {

    @JsonProperty("key")
    private String key;

    @JsonProperty("value")
    private String value;
}
