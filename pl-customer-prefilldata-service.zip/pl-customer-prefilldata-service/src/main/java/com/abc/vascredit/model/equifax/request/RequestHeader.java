package com.abc.vascredit.model.equifax.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestHeader {
    
	@JsonProperty("CustomerId")
    private String CustomerId;
    
	@JsonProperty("UserId")
    private String userId;
    
	@JsonProperty("Password")
    private String password;
    
	@JsonProperty("MemberNumber")
    private String memberNumber;
    
	@JsonProperty("SecurityCode")
    private String securityCode;
    
	@JsonProperty("ProductCode")
    private String[] productCode;
    
	@JsonProperty("CustRefField")
    private String custRefField;

}