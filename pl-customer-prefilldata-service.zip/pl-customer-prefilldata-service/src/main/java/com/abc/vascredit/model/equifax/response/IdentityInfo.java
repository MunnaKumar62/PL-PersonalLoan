package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class IdentityInfo {
    @JsonProperty("PANId")
    private PANId[] panId;
}