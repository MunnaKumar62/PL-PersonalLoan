package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RecentActivities {
    @JsonProperty("AccountsDeliquent")
    private String accountsDelinquent;

    @JsonProperty("AccountsOpened")
    private String accountsOpened;

    @JsonProperty("TotalInquiries")
    private String totalInquiries;

    @JsonProperty("AccountsUpdated")
    private String accountsUpdated;
}