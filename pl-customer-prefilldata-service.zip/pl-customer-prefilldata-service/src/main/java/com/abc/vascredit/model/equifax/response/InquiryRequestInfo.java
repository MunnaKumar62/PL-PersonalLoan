package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InquiryRequestInfo {
    @JsonProperty("InquiryPurpose")
    private String inquiryPurpose;

    @JsonProperty("FirstName")
    private String firstName;

    @JsonProperty("MiddleName")
    private String middleName;

    @JsonProperty("LastName")
    private String lastName;

    @JsonProperty("InquiryPhones")
    private InquiryPhone[] inquiryPhones;

    @JsonProperty("IDDetails")
    private IDDetail[] idDetails;

    @JsonProperty("CustomFields")
    private CustomFields[] customFields;
}