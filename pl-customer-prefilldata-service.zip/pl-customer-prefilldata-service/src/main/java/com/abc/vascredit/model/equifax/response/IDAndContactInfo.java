package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class IDAndContactInfo {
    @JsonProperty("PersonalInfo")
    private PersonalInfo personalInfo;

    @JsonProperty("IdentityInfo")
    private IdentityInfo identityInfo;

    @JsonProperty("AddressInfo")
    private AddressInfo[] addressInfo;

    @JsonProperty("PhoneInfo")
    private PhoneInfo[] phoneInfo;

    @JsonProperty("EmailAddressInfo")
    private EmailAddressInfo[] emailAddressInfo;
}