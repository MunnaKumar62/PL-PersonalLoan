package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AddressInfo {
    @JsonProperty("Seq")
    private String seq;

    @JsonProperty("ReportedDate")
    private String reportedDate;

    @JsonProperty("Address")
    private String address;

    @JsonProperty("State")
    private String state;

    @JsonProperty("Postal")
    private String postal;
}