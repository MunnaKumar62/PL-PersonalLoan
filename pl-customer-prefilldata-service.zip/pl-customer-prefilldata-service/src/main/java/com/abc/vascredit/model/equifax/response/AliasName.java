package com.abc.vascredit.model.equifax.response;

import lombok.Data;

@Data
public class AliasName {
    // Add fields if applicable
}