package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CCRResponse {
    @JsonProperty("Status")
    private String status;

    @JsonProperty("CIRReportDataLst")
    private CIRReportData[] cirReportDataList;
}