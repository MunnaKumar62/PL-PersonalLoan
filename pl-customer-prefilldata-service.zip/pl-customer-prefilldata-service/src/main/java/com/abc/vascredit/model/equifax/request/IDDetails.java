package com.abc.vascredit.model.equifax.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IDDetails {
    @JsonProperty("seq")
    private String seq;
    @JsonProperty("IDValue")
    private String idValue;

    @JsonProperty("IDType")
    private String idType;
    @JsonProperty("Source")
    private String source;

}