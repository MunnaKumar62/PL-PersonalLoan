package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ScoringElement {
    @JsonProperty("type")
    private String type;

    @JsonProperty("seq")
    private String seq;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("code")
    private String code;
}