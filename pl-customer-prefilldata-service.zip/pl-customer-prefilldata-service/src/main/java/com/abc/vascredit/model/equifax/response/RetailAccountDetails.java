package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RetailAccountDetails {
    @JsonProperty("seq")
    private String seq;

    @JsonProperty("AccountNumber")
    private String accountNumber;

    @JsonProperty("Institution")
    private String institution;

    @JsonProperty("AccountType")
    private String accountType;

    @JsonProperty("OwnershipType")
    private String ownershipType;

    @JsonProperty("Balance")
    private String balance;

    @JsonProperty("PastDueAmount")
    private String pastDueAmount;

    @JsonProperty("Open")
    private String open;

    @JsonProperty("SanctionAmount")
    private String sanctionAmount;

    @JsonProperty("LastPaymentDate")
    private String lastPaymentDate;

    @JsonProperty("DateReported")
    private String dateReported;

    @JsonProperty("DateOpened")
    private String dateOpened;

    @JsonProperty("AccountStatus")
    private String accountStatus;

    @JsonProperty("source")
    private String source;

    @JsonProperty("History48Months")
    private History48Months[] history48Months;

    @JsonProperty("LastPayment")
    private String lastPayment;

    @JsonProperty("WriteOffAmount")
    private String writeOffAmount;

    @JsonProperty("RepaymentTenure")
    private String repaymentTenure;

    @JsonProperty("InstallmentAmount")
    private String installmentAmount;

    @JsonProperty("TermFrequency")
    private String termFrequecy;

    @JsonProperty("DateClosed")
    private String dateClosed;

    @JsonProperty("Reason")
    private String reason;
    
    @JsonProperty("CreditLimit")
    private String creditLimit;
    
    @JsonProperty("HighCredit")
    private String highCredit;
}
