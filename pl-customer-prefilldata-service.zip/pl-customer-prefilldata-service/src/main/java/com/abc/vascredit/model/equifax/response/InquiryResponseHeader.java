package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InquiryResponseHeader {
    @JsonProperty("CustomerCode")
    private String customerCode;
    @JsonProperty("HitCode")
    private String hitCode;
    @JsonProperty("CustomerName")
    private String customerName;
    @JsonProperty("ClientID")
    private String clientId;

    @JsonProperty("CustRefField")
    private String custRefField;

    @JsonProperty("ReportOrderNO")
    private String reportOrderNo;

    @JsonProperty("ProductCode")
    private String[] productCode;

    @JsonProperty("SuccessCode")
    private String successCode;

    @JsonProperty("Date")
    private String date;

    @JsonProperty("Time")
    private String time;


}