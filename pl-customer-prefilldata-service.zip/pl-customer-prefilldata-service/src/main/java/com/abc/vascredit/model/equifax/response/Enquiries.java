package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Enquiries {
    @JsonProperty("seq")
    private String seq;

    @JsonProperty("Institution")
    private String institution;

    @JsonProperty("Date")
    private String date;

    @JsonProperty("Time")
    private String time;

    @JsonProperty("RequestPurpose")
    private String requestPurpose;

    @JsonProperty("Amount")
    private String amount;
}