package com.abc.vascredit.model.equifax.request;

import lombok.Data;

@Data
public class BrefailureRequest {
	private String accountId;
	private String loanId;
	private Long customerId;

}
