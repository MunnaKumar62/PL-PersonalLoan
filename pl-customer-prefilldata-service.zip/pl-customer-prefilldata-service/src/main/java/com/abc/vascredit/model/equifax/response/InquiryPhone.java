package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InquiryPhone {
    @JsonProperty("seq")
    private String seq;

    @JsonProperty("PhoneType")
    private String[] phoneType;

    @JsonProperty("Number")
    private String number;
}