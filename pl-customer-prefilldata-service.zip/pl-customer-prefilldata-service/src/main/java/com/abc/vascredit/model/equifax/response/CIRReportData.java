package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CIRReportData {
    @JsonProperty("InquiryResponseHeader")
    private InquiryResponseHeader inquiryResponseHeader;

    @JsonProperty("InquiryRequestInfo")
    private InquiryRequestInfo inquiryRequestInfo;

    @JsonProperty("Score")
    private Score[] score;

    @JsonProperty("CIRReportData")
    private CIRReportDataInfo cirReportDataInfo;
    @JsonProperty("Error")
    private Error error;
}