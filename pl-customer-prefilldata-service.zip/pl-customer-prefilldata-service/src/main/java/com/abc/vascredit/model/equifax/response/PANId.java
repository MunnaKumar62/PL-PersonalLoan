package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PANId {
    @JsonProperty("seq")
    private String seq;

    @JsonProperty("ReportedDate")
    private String reportedDate;

    @JsonProperty("IdNumber")
    private String idNumber;
}