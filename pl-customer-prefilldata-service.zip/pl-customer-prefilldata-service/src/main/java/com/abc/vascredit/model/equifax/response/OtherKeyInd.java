package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OtherKeyInd {
    @JsonProperty("AgeOfOldestTrade")
    private String ageOfOldestTrade;

    @JsonProperty("NumberOfOpenTrades")
    private String numberOfOpenTrades;

    @JsonProperty("AllLinesEVERWritten")
    private String allLinesEVERWritten;

    @JsonProperty("AllLinesEVERWrittenIn9Months")
    private String allLinesEVERWrittenIn9Months;

    @JsonProperty("AllLinesEVERWrittenIn6Months")
    private String allLinesEVERWrittenIn6Months;
}