package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EnquirySummary {
    @JsonProperty("Purpose")
    private String purpose;

    @JsonProperty("Total")
    private String total;

    @JsonProperty("Past30Days")
    private String past30Days;

    @JsonProperty("Past12Months")
    private String past12Months;

    @JsonProperty("Past24Months")
    private String past24Months;

    @JsonProperty("Recent")
    private String recent;
}