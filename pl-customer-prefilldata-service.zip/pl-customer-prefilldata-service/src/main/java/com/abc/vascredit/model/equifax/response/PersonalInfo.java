package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PersonalInfo {
    @JsonProperty("Name")
    private Name name;

    @JsonProperty("AliasName")
    private AliasName aliasName;

    @JsonProperty("DateOfBirth")
    private String dateOfBirth;

    @JsonProperty("Gender")
    private String gender;

    @JsonProperty("Age")
    private Age age;

    @JsonProperty("PlaceOfBirthInfo")
    private PlaceOfBirthInfo placeOfBirthInfo;
}