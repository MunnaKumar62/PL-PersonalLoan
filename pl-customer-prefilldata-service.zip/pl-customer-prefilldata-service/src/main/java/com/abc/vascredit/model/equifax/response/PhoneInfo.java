package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PhoneInfo {
    @JsonProperty("seq")
    private String seq;

    @JsonProperty("typeCode")
    private String typeCode;

    @JsonProperty("ReportedDate")
    private String reportedDate;

    @JsonProperty("Number")
    private String number;
}