package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Error {
    @JsonProperty("ErrorCode")
    String errorCode;
    @JsonProperty("ErrorDesc")
    String errorDesc;
}