package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Score {
    @JsonProperty("Type")
    private String type;

    @JsonProperty("Version")
    private String version;
}