package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class History48Months {
    @JsonProperty("key")
    private String key;

    @JsonProperty("PaymentStatus")
    private String paymentStatus;

    @JsonProperty("SuitFiledStatus")
    private String suitFiledStatus;

    @JsonProperty("AssetClassificationStatus")
    private String assetClassificationStatus;
}