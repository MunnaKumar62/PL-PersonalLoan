package com.abc.vascredit.model.equifax.response;

import lombok.Data;

@Data
public class PlaceOfBirthInfo {

}