package com.abc.vascredit.model.equifax.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CIRReportDataInfo {
    @JsonProperty("IDAndContactInfo")
    private IDAndContactInfo idAndContactInfo;

    @JsonProperty("RetailAccountDetails")
    private RetailAccountDetails[] retailAccountDetails;

    @JsonProperty("RetailAccountsSummary")
    private RetailAccountsSummary retailAccountsSummary;

    @JsonProperty("ScoreDetails")
    private ScoreDetails[] scoreDetails;

    @JsonProperty("Enquiries")
    private Enquiries[] enquiries;

    @JsonProperty("EnquirySummary")
    private EnquirySummary enquirySummary;

    @JsonProperty("OtherKeyInd")
    private OtherKeyInd otherKeyInd;

    @JsonProperty("RecentActivities")
    private RecentActivities recentActivities;
    @JsonProperty("Decision")
    private Decision[] decision;
    
}