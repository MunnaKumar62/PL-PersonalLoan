package com.abc.portfolio.sip.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalErrorMessage {


	private Integer code;
	private String reason;
	private String errorCode;
	private String errorMessage;
	private String message;

}
