package com.abc.portfolio.sip.serviceImpl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.poi.ss.formula.functions.Finance;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.portfolio.sip.entity.PfSipTransStatus;
import com.abc.portfolio.sip.exception.BusinessException;
import com.abc.portfolio.sip.exception.ExternalException;
import com.abc.portfolio.sip.exception.InternalException;
import com.abc.portfolio.sip.exception.Message;
import com.abc.portfolio.sip.repo.DigiGoldUserProfileRepository;
import com.abc.portfolio.sip.repo.MfPersonalDetailsRepository;
import com.abc.portfolio.sip.repo.PfSipMfListOfFundsRepository;
import com.abc.portfolio.sip.repo.PfSipTransStatusRepository;
import com.abc.portfolio.sip.request.FetchListofSIPsBasedonYearReq;
import com.abc.portfolio.sip.request.FetchPortfolioSIPdetailRequest;
import com.abc.portfolio.sip.request.FetchpanandemailRequest;
import com.abc.portfolio.sip.request.GoalCalculatorRequest;
import com.abc.portfolio.sip.request.GoldHistoricalPriceRequest;
import com.abc.portfolio.sip.request.IsinCategoryDetails;
import com.abc.portfolio.sip.request.IsinCategoryDetailsRequest;
import com.abc.portfolio.sip.request.SIPCalculatorRequest;
import com.abc.portfolio.sip.request.SchemeWiseReturnsRequest;
import com.abc.portfolio.sip.response.CreateMFPurchasePlansResponse;
import com.abc.portfolio.sip.response.FetchMFPurchasePlan;
import com.abc.portfolio.sip.response.FetchpanandemailResponse;
import com.abc.portfolio.sip.response.GoalCalculatorResponse;
import com.abc.portfolio.sip.response.GoldHistoricalPriceResponse;
import com.abc.portfolio.sip.response.IsinCategoryDetailsResponse;
import com.abc.portfolio.sip.response.Item;
import com.abc.portfolio.sip.response.Items;
import com.abc.portfolio.sip.response.ListOfSIPs;
import com.abc.portfolio.sip.response.ListofSIPsBasedonYear;
import com.abc.portfolio.sip.response.SIPCalculatorResponse;
import com.abc.portfolio.sip.response.SIPType;
import com.abc.portfolio.sip.response.SIPTypes;
import com.abc.portfolio.sip.response.SchemeWiseReturns;
import com.abc.portfolio.sip.response.SipResponse;
import com.abc.portfolio.sip.service.PortfolioSipService;
import com.abc.portfolio.sip.service.TokenService;
import com.abc.portfolio.sip.util.CommonUtil;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class PortfolioSipServiceImpl implements PortfolioSipService {

	private static final String SYSTEM = "SYSTEM";

	@Autowired
	private Message message;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PfSipMfListOfFundsRepository pfSipMfListOfFundsRepository;

	@Autowired
	private PfSipTransStatusRepository pfSipTransStatusRepository;

	private final Gson gson;

	@Value("${mf.external.api.schemewisereturns.url}")
	private String getSchemeWiseReturnsUrl;

	@Value("${mf.external.api.fetchMFPurchasePlan.url}")
	private String fetchMFPurchasePlanUrl;

	@Value("${mf.external.api.categoryDetails.url}")
	private String categoryDetailsUrl;

	@Value("${dg.abfss-api.historicalGoldPrice}")
	private String historicalGoldPriceURL;

	private final MfPersonalDetailsRepository mfPersonalDetailsRepository;
	private final DigiGoldUserProfileRepository digiGoldUserProfileRepository;

	@Autowired
	public PortfolioSipServiceImpl(MfPersonalDetailsRepository mfPersonalDetailsRepository,
			DigiGoldUserProfileRepository digiGoldUserProfileRepository, Gson gson) {
		this.mfPersonalDetailsRepository = mfPersonalDetailsRepository;
		this.digiGoldUserProfileRepository = digiGoldUserProfileRepository;
		this.gson = gson;
	}

	public FetchpanandemailResponse fetchpanandemail(FetchpanandemailRequest request) {

		FetchpanandemailResponse response = new FetchpanandemailResponse();
		List<Object[]> mfUserDetails = null;
		List<Object[]> digiGoldUserDetails = null;
		String requestStr = request.toString();
		String responseStr = "";
		try {
			mfUserDetails = mfPersonalDetailsRepository.findPanNumberAndEmailIdByCustomerIdAndMobileNumber(
					Long.parseLong(request.getCustomerID()), request.getMobileNo());

			digiGoldUserDetails = digiGoldUserProfileRepository.findPanNumberAndEmailIdByCustomerIdAndMobileNumber(
					Long.parseLong(request.getCustomerID()), request.getMobileNo());

			if (!mfUserDetails.isEmpty()) {
				Object[] data = mfUserDetails.get(0);
				response.setEmail((String) data[1]);
				response.setPan((String) data[0]);
				responseStr = Objects.nonNull(response) ? response.toString() : "";
				CommonUtil.savePfApiStatus(null, "fetchpanandemail", requestStr, responseStr, SYSTEM);
				return response;
			} else if (!digiGoldUserDetails.isEmpty()) {
				Object[] data = digiGoldUserDetails.get(0);
				response.setEmail((String) data[1]);
				response.setPan((String) data[0]);
				log.info("fetchpanandemail request: " + request);
				responseStr = Objects.nonNull(response) ? response.toString() : "";
				CommonUtil.savePfApiStatus(null, "fetchpanandemail", requestStr, responseStr, SYSTEM);
				return response;
			} else {
				log.info("fetchpanandemail is not found");
				throw new BusinessException("2000");
			}

		} catch (BusinessException e) {
			log.info("BusinessException fetchpanandemail: " + message.getMessage(e.getErrorCode()));
			CommonUtil.savePfApiStatus(null, "fetchpanandemail", requestStr, e.getMessage(), SYSTEM);
			throw new BusinessException(e.getErrorCode());
		} catch (Exception e) {
			log.info("fetchpanandemail request: " + request);
			log.info("Exception fetchpanandemail: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "fetchpanandemail", requestStr, e.getMessage(), SYSTEM);
			throw new InternalException("2001");
		}

	}

	public GoalCalculatorResponse goalCalculator(GoalCalculatorRequest request) {
		log.info("request=> " + request.toString());
		String requestStr = request.toString();
		GoalCalculatorResponse response = new GoalCalculatorResponse();
		try {
			if (request.getGoalAmount() <= 0) {
				throw new BusinessException("2011");
			}
			if (request.getTimeHorizon() <= 0) {
				throw new BusinessException("2012");
			}
			if (request.getExpectedRor() <= 0) {
				throw new BusinessException("2013");
			}
			double useDiscount = roundAvoid(Finance.pmt(request.getExpectedRor() / 1200, request.getTimeHorizon() * 12,
					0, -request.getGoalAmount(), 0), 2);
			SipResponse.minSip = roundFloor(useDiscount);
			double needToInvest = SipResponse.minSip * 12 * request.getTimeHorizon();
			response.setSipAmount(useDiscount);
			response.setNeedToInvest(needToInvest);
			return response;
		} catch (BusinessException e) {
			log.info("goalCalculator request: " + request);
			log.info("BusinessException in goalCalculator: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "goalCalculator", requestStr, e.getMessage(), SYSTEM);
			throw new BusinessException(e.getErrorCode());
		} catch (Exception e) {
			log.info("goalCalculator request: " + request);
			log.info("Exception in goalCalculator: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "goalCalculator", requestStr, e.getMessage(), SYSTEM);
			throw new InternalException("2002");
		}
	}

	public long roundFloor(double input) {
		long i = (long) Math.floor(input);
		return ((i) / 100) * 100;
	}

	public double roundAvoid(double value, int places) {
		double scale = Math.pow(10, places);
		return Math.round(value * scale) / scale;
	}

	public List<SIPCalculatorResponse> sipCalculator(SIPCalculatorRequest request) {
		List<SIPCalculatorResponse> list = new ArrayList<>();
		String requestStr = request.toString();
		try {
			if (request.getExpectedAnnualReturns() <= 0) {
				throw new BusinessException("2014");
			}
			if (request.getExpectedAnnualReturns() <= 0) {
				throw new BusinessException("2014");
			}
			if (request.getMonthlyInvestAmt() <= 0) {
				throw new BusinessException("2015");
			}
			int x_axis = 25;
			if (request.getInvestedPeriod() >= 26 && request.getInvestedPeriod() <= 50) {
				x_axis = 50;
			}
			for (int j = 1; j <= x_axis; j++) {
				SIPCalculatorResponse response = new SIPCalculatorResponse();
				request.setInvestedPeriod(j);
				double i = (request.getExpectedAnnualReturns() / 1200);
				int getInvestPeriodYearly = (request.getInvestedPeriod() * 12);
				// M = P × ({[1 + i]^n – 1} / i) × (1 + i)
				double inv = (Math.pow(1 + i, getInvestPeriodYearly) - 1);//
				long maturity = (long) (request.getMonthlyInvestAmt() * inv / i * (1 + i));
				long youInvest = (request.getMonthlyInvestAmt() * getInvestPeriodYearly); // total amount which we
																							// invested
				long totalWealthGained = maturity - youInvest;
				response.setTotalMoneyYouInvested(youInvest);
				response.setTotalWealthCreated(maturity);
				response.setExpectedWealthGain(totalWealthGained);
				response.setYear(j);
				list.add(response);
			}
			return list;
		} catch (BusinessException e) {
			log.info("sipCalculator request: " + request);
			log.info("BusinessException in sipCalculator: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "sipCalculator", requestStr, e.getMessage(), SYSTEM);
			throw new BusinessException(e.getErrorCode());
		} catch (Exception e) {
			log.info("sipCalculator request:" + request);
			log.info("Exception in sipCalculator:" + e.getMessage());
			CommonUtil.savePfApiStatus(null, "sipCalculator", requestStr, e.getMessage(), SYSTEM);
			throw new InternalException("2003");
		}

	}

	public PfSipTransStatus savepfItemCompletionStatus(PfSipTransStatus request) {
		PfSipTransStatus response = new PfSipTransStatus();
		String requestStr = request.toString();
		try {
			response.setCustomerId(request.getCustomerId());
			response.setDgSipId(request.getDgSipId());
			response.setDgSipStatus(request.getDgSipStatus());
			response.setMfSipId(request.getMfSipId());
			response.setMfStatus(request.getMfStatus());
			response.setMobno(request.getMobno());
			response.setPfSIPPlanname(request.getPfSIPPlanname());
			response.setPfSipId(request.getPfSipId());
			response.setSipType(request.getSipType());
			response.setStockSipId(request.getStockSipId());
			response.setStockSipStatus(request.getStockSipStatus());
			response.setCreatedBy(String.valueOf(request.getCustomerId()));
			response.setCreatedDate(LocalDateTime.now());
			response.setModifiedBy(String.valueOf(request.getCustomerId()));
			response.setModifiedDate(LocalDateTime.now());
			pfSipTransStatusRepository.save(response);
			return response;
		} catch (Exception e) {
			log.info("Exception savepfItemCompletionStatus: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "savepfItemCompletionStatus", requestStr, e.getMessage(), SYSTEM);
			throw new InternalException("2004");
		}

	}

	@JsonInclude(JsonInclude.Include.ALWAYS)
	public ListOfSIPs fetchPortfolioSIPdetails(FetchPortfolioSIPdetailRequest request) {

		List<Item> items = new ArrayList<>();
		ListOfSIPs returnlistOfSIPs = new ListOfSIPs();
		List<SIPType> sIPTypes = new ArrayList<>(3);

		// MF

		try {
			// Process mutual funds begin
			List<Object[]> mfSIPDetails = null;
			List<Object[]> cachedMfSIPDetails = getCachedMfSIPDetails(Long.parseLong(request.getCustomerID()),
					request.getMobileNumber(), request.getPortfolioSIPID());
			if (null != cachedMfSIPDetails && !cachedMfSIPDetails.isEmpty()) {
				mfSIPDetails = cachedMfSIPDetails;
			} else {
				mfSIPDetails = pfSipMfListOfFundsRepository.findAmountAndQuantityByMF(request.getCustomerID(),
						request.getMobileNumber(), request.getPortfolioSIPID(), "mutualFunds");

			}
			if (!mfSIPDetails.isEmpty()) {
				SIPType mfSIPType = processMfSIPDetails(mfSIPDetails);
				sIPTypes.add(mfSIPType);
			} else {
				sIPTypes.add(createEmptySIPType("mutualFunds"));
			}
			// Process mutual funds End

			// Process diggold funds begin
			List<Object[]> dgSIPDetails = null;
			List<Object[]> cachedDGSIPDetails = getCachedDgSIPDetails(Long.parseLong(request.getCustomerID()),
					request.getMobileNumber(), request.getPortfolioSIPID());
			if (null != cachedDGSIPDetails && !cachedDGSIPDetails.isEmpty()) {
				dgSIPDetails = cachedDGSIPDetails;
			} else {
				dgSIPDetails = pfSipMfListOfFundsRepository.findAmountAndQuantityByDG(request.getCustomerID(),
						request.getMobileNumber(),request.getPortfolioSIPID());

			}

			if (!dgSIPDetails.isEmpty()) {
				SIPType dgSIPType = processDGSIPDetails(dgSIPDetails);
				sIPTypes.add(dgSIPType);
			} else {
				sIPTypes.add(createEmptySIPType("digiGold"));
			}
			// Process diggold funds End

			// Process Stocks funds begin

			List<Object[]> stSIPDetails = null;
			List<Object[]> cachedSTSIPDetails = getCachedStSIPDetails(Long.parseLong(request.getCustomerID()),
					request.getMobileNumber(), request.getPortfolioSIPID());
			if (null != cachedSTSIPDetails && !cachedSTSIPDetails.isEmpty()) {
				stSIPDetails = cachedSTSIPDetails;
			} else {
				stSIPDetails = pfSipMfListOfFundsRepository.findAmountAndQuantityByST(request.getCustomerID(),
						request.getMobileNumber(),request.getPortfolioSIPID());

			}

			if (!stSIPDetails.isEmpty()) {
				SIPType stSIPType = processSTSIPDetails(stSIPDetails);
				sIPTypes.add(stSIPType);
			} else {
				sIPTypes.add(createEmptySIPType("stocks"));
			}

			// Process Stocks funds End

			returnlistOfSIPs.setListOfSIPs(sIPTypes);
			return returnlistOfSIPs;

		} catch (Exception e) {
			log.info("Exception in fetchPortfolioSIPdetails: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "fetchPortfolioSIPdetails", request.toString(), e.getMessage(), SYSTEM);
			throw new InternalException("2005");
		}

	}

	private SIPType processMfSIPDetails(List<Object[]> mfSIPDetails) throws IOException {
		SIPType sIPType = new SIPType();
		sIPType.setTypeOfSIP("mutualFunds");
		List<Item> items = new ArrayList<>(mfSIPDetails.size());

		for (Object[] row : mfSIPDetails) {
			String investmentId = String.valueOf(row[0]);
			String schemeIsin = String.valueOf(row[1]);

			String details = getSchemeWiseCurrentPrice(investmentId);
			JsonNode rootNode = objectMapper.readTree(details);
			JsonNode rowsArray = rootNode.path("data").path("rows");

			for (JsonNode node : rowsArray) {
				if (schemeIsin.equalsIgnoreCase(node.get(0).asText())) {
					Item item = new Item();
					item.setName(node.get(1).asText());
					item.setAmount(String.valueOf(node.get(6).asDouble()));
					item.setCurrentPrice(String.valueOf(node.get(7).asDouble()));
					item.setQuantity(String.valueOf(node.get(11).asDouble()));
					items.add(item);
				}
			}
		}
		sIPType.setListOfItems(items);
		return sIPType;
	}

	@Cacheable(value = "mfSipDetailsCache", key = "#customerId + '_' + #mobileNumber + '_' + #portfolioSipId")
	public List<Object[]> getCachedMfSIPDetails(Long customerId, String mobileNumber, String portfolioSipId) {
		return pfSipMfListOfFundsRepository.findAmountAndQuantityByMF(String.valueOf(customerId), mobileNumber,
				portfolioSipId, "mutualFunds");
	}

	private SIPType processDGSIPDetails(List<Object[]> dgSIPDetails) throws Exception {
		SIPType sIPType = new SIPType();
		sIPType.setTypeOfSIP("digiGold");
		List<Item> items = new ArrayList<>(dgSIPDetails.size());
		for (Object[] row : dgSIPDetails) {
			String amount = String.valueOf(row[0]);
			String quantity = String.valueOf(row[1]);
			String name = String.valueOf(row[2]);

			Item item = new Item();
			item.setName(name);
			item.setAmount(amount);
			item.setCurrentPrice(getHistoricalGoldPrice());
			item.setQuantity(quantity);
			item.setRating("");
			items.add(item);
		}
		sIPType.setListOfItems(items);
		return sIPType;
	}

	@Cacheable(value = "dgSipDetailsCache", key = "#customerId + '_' + #mobileNumber + '_' + #portfolioSipId")
	public List<Object[]> getCachedDgSIPDetails(Long customerId, String mobileNumber, String portfolioSipId) {
		return pfSipMfListOfFundsRepository.findAmountAndQuantityByDG(String.valueOf(customerId),mobileNumber,portfolioSipId);
	}

	private SIPType processSTSIPDetails(List<Object[]> stSIPDetails) throws IOException {
		SIPType sIPType = new SIPType();
		sIPType.setTypeOfSIP("stocks");
		List<Item> items = new ArrayList<>(stSIPDetails.size());
		for (Object[] row : stSIPDetails) {
			String amount = String.valueOf(row[0]);
			String quantity = String.valueOf(row[1]);
			String name = String.valueOf(row[2]);

			Item item = new Item();
			item.setName(name);
			item.setAmount(amount);
			item.setCurrentPrice("");
			item.setQuantity(quantity);
			item.setRating("");
			items.add(item);
		}
		sIPType.setListOfItems(items);
		return sIPType;
	}

	@Cacheable(value = "stSipDetailsCache", key = "#customerId + '_' + #mobileNumber + '_' + #portfolioSipId")
	public List<Object[]> getCachedStSIPDetails(Long customerId, String mobileNumber, String portfolioSipId) {
		return pfSipMfListOfFundsRepository.findAmountAndQuantityByST(String.valueOf(customerId),mobileNumber, portfolioSipId);
	}

	public SIPType createEmptySIPType(String sipType) {
		List<Item> items = new ArrayList<>();
		SIPType sIPType = new SIPType();
		sIPType.setTypeOfSIP(sipType);
		items = new ArrayList<>();
		Item item = new Item();
		item.setName("");
		item.setAmount("0.00");
		item.setCurrentPrice("");
		item.setQuantity("0");
		item.setRating("");
		items.add(item);
		sIPType.setListOfItems(items);

		return sIPType;
	}

	public ListofSIPsBasedonYear fetchListofSIPsBasedonYear(FetchListofSIPsBasedonYearReq request) {
		List<SIPTypes> sipDetails = new ArrayList<>();
		List<Items> items = new ArrayList<>();
		ListofSIPsBasedonYear returnlistOfSIPs = new ListofSIPsBasedonYear();
		try {
			List<Object[]> mfSIPDetails = pfSipTransStatusRepository.findListOfMF(request.getCustomerID(),
					request.getMobileNumber(), request.getPortfolioSIPID(), request.getYear(), "mutualFunds");
			List<Object[]> dgSIPDetails = pfSipTransStatusRepository.findListOfDG(request.getCustomerID(),
					request.getMobileNumber(), request.getPortfolioSIPID(), request.getYear(), "digiGold");
			List<Object[]> stockSIPDetails = pfSipTransStatusRepository.findListOfST(request.getCustomerID(),
					request.getMobileNumber(), request.getPortfolioSIPID(), request.getYear(), "stocks");

			// Initialize the SIP type list
			List<SIPTypes> sIPTypes = new ArrayList<>();

			// Process mutualFunds
			if (!mfSIPDetails.isEmpty()) {
				SIPTypes sIPType = new SIPTypes();
				sIPType.setTypeOfSIP("mutualFunds");
				items = new ArrayList<>();

				for (Object[] row : mfSIPDetails) {
					String amount = String.valueOf(row[0]);
					String quantity = String.valueOf(row[1]);
					String name = String.valueOf(row[3]);
					String status = String.valueOf(row[4]);
					Items item = new Items();
					item.setStatus(status);
					item.setName(name);
					item.setAmount(amount);
					item.setCurrentPrice("");
					item.setQuantity(quantity);
				}
				sIPType.setListOfItems(items);
				sIPTypes.add(sIPType);
			} else {
				SIPTypes sIPType = new SIPTypes();
				sIPType.setTypeOfSIP("mutualFunds");
				items = new ArrayList<>();
				Items item = new Items();
				item.setStatus("");
				item.setName("");
				item.setAmount("0.00");
				item.setCurrentPrice("0");
				item.setQuantity("0");
				items.add(item);
				sIPType.setListOfItems(items);
				sIPTypes.add(sIPType);
			}

			// Process digiGold
			if (!dgSIPDetails.isEmpty()) {
				SIPTypes sIPType = new SIPTypes();
				sIPType.setTypeOfSIP("digiGold");
				items = new ArrayList<>();

				for (Object[] row : dgSIPDetails) {
					String amount = String.valueOf(row[0]);
					String quantity = String.valueOf(row[1]);
					String name = String.valueOf(row[3]);
					String status = String.valueOf(row[4]);
					Items item = new Items();
					item.setStatus(status);
					item.setName(name);
					item.setAmount(amount);
					item.setCurrentPrice("");
					item.setQuantity(quantity);
				}
				sIPType.setListOfItems(items);
				sIPTypes.add(sIPType);
			} else {
				SIPTypes sIPType = new SIPTypes();
				sIPType.setTypeOfSIP("digiGold");
				items = new ArrayList<>();
				Items item = new Items();
				item.setStatus("");
				item.setName("");
				item.setAmount("0.00");
				item.setCurrentPrice("0");
				item.setQuantity("0");
				items.add(item);
				sIPType.setListOfItems(items);
				sIPTypes.add(sIPType);
			}

			// Process stocks
			if (!stockSIPDetails.isEmpty()) {
				SIPTypes sIPType = new SIPTypes();
				sIPType.setTypeOfSIP("digiGold");
				items = new ArrayList<>();

				for (Object[] row : stockSIPDetails) {
					String amount = String.valueOf(row[0]);
					String quantity = String.valueOf(row[1]);
					String name = String.valueOf(row[3]);
					String status = String.valueOf(row[4]);
					Items item = new Items();
					item.setStatus(status);
					item.setName(name);
					item.setAmount(amount);
					item.setCurrentPrice("");
					item.setQuantity(quantity);
				}
				sIPType.setListOfItems(items);
				sIPTypes.add(sIPType);
			} else {
				SIPTypes sIPType = new SIPTypes();
				sIPType.setTypeOfSIP("stocks");
				items = new ArrayList<>();
				Items item = new Items();
				item.setStatus("");
				item.setName("");
				item.setAmount("0.00");
				item.setCurrentPrice("0");
				item.setQuantity("0");
				items.add(item);
				sIPType.setListOfItems(items);
				sIPTypes.add(sIPType);
			}

			returnlistOfSIPs.setListOfSIPs(sIPTypes);
			return returnlistOfSIPs;
		} catch (Exception e) {
			log.info("Exception in fetchListofSIPsBasedonYear: " + e.getMessage());
			CommonUtil.savePfApiStatus(null, "fetchListofSIPsBasedonYear", request.toString(), e.getMessage(), SYSTEM);
			throw new InternalException("2006");
		}

	}

	public String getSchemeWiseCurrentPrice(String investment_id) {
		ResponseEntity<?> apiResponse = null;
		SchemeWiseReturnsRequest apiRequest = new SchemeWiseReturnsRequest();
		SchemeWiseReturns schemeWiseReturns = new SchemeWiseReturns();
		apiRequest.setMfInvestmentAccount(investment_id);
		try {
			HttpHeaders requestHeaders = tokenService.getRequestHttpHeader();
			String resquestJsonObject = objectMapper.writeValueAsString(apiRequest);
			HttpEntity<?> requestEntity = new HttpEntity<>(resquestJsonObject, requestHeaders);

			apiResponse = restTemplate.postForEntity(getSchemeWiseReturnsUrl, requestEntity, String.class);
			CommonUtil.savePfApiStatus(getSchemeWiseReturnsUrl, "getSchemeWiseCurrentPrice", resquestJsonObject,
					apiResponse.getBody().toString(), SYSTEM);
			return apiResponse.getBody().toString();
		} catch (HttpServerErrorException ex) {
			log.info("error in getSchemeWiseCurrentPrice :" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(getSchemeWiseReturnsUrl, "getSchemeWiseCurrentPrice", apiRequest.toString(),
					ex.getMessage(), SYSTEM);
			throw new ExternalException(ex);
		} catch (HttpClientErrorException ex) {
			log.info("error in getSchemeWiseCurrentPrice :" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(getSchemeWiseReturnsUrl, "getSchemeWiseCurrentPrice", apiRequest.toString(),
					ex.getMessage(), SYSTEM);
			throw new ExternalException(ex);
		} catch (Exception e) {
			log.info("Unable to get SchemeWiseCurrentPrice : " + apiRequest);
			log.info("Exception in getSchemeWiseCurrentPrice: " + e.getMessage());
			CommonUtil.savePfApiStatus(getSchemeWiseReturnsUrl, "getSchemeWiseCurrentPrice", apiRequest.toString(),
					e.getMessage(), SYSTEM);
			throw new InternalException("2007");
		}
	}

	public CreateMFPurchasePlansResponse fetchMFPurchasePlans(String fetchMFSIPPlan) throws Exception {
		log.info("Fetch MF Purchase Plan");
		ResponseEntity<CreateMFPurchasePlansResponse> apiResponse = null;
		FetchMFPurchasePlan fetchMFPurchasePlan = new FetchMFPurchasePlan();
		fetchMFPurchasePlan.setId(fetchMFSIPPlan);

		try {

			HttpHeaders httpHeaders = tokenService.getRequestHttpHeader();
			HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
			apiResponse = restTemplate.exchange(fetchMFPurchasePlanUrl + fetchMFPurchasePlan.getId(), HttpMethod.GET,
					httpEntity, CreateMFPurchasePlansResponse.class);
			log.debug("Response: " + apiResponse);
			CommonUtil.savePfApiStatus(fetchMFPurchasePlanUrl, "fetchMFPurchasePlans", fetchMFPurchasePlan.getId(),
					apiResponse.getBody().toString(), SYSTEM);
			return apiResponse.getBody();

		} catch (HttpServerErrorException ex) {
			log.info("HttpServerErrorException in fetchMFPurchasePlans :" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(fetchMFPurchasePlanUrl, "fetchMFPurchasePlans", fetchMFPurchasePlan.getId(),
					ex.getMessage(), SYSTEM);
			throw new ExternalException(ex);
		} catch (HttpClientErrorException ex) {
			log.info("HttpClientErrorException in fetchMFPurchasePlans :" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(fetchMFPurchasePlanUrl, "fetchMFPurchasePlans", fetchMFPurchasePlan.getId(),
					ex.getMessage(), SYSTEM);
			throw new ExternalException(ex);
		} catch (Exception ex) {
			CommonUtil.savePfApiStatus(fetchMFPurchasePlanUrl, "fetchMFPurchasePlans", fetchMFPurchasePlan.getId(),
					ex.getMessage(), SYSTEM);
			throw new InternalException("2008");
		}
	}

	public IsinCategoryDetailsResponse getIsinCategoryDetails(IsinCategoryDetails request) throws Exception {
		log.info("Getting Category details on ISIN code");
		IsinCategoryDetailsResponse response = null;
		IsinCategoryDetailsRequest CategoryDetailsRequest = new IsinCategoryDetailsRequest();
		String requestString = request.toString();
		try {
			modelMapper.map(request, CategoryDetailsRequest);
			log.debug("Category details on ISIN code Request - " + request);
			String requestObject = objectMapper.writeValueAsString(CategoryDetailsRequest);
			HttpHeaders httpHeaders = tokenService.getRequestHttpHeader();
			log.info("Getting Category details on ISIN code");
			HttpEntity<?> httpEntity = new HttpEntity<>(requestObject, httpHeaders);
			response = restTemplate.postForObject(categoryDetailsUrl, httpEntity, IsinCategoryDetailsResponse.class);
			log.debug("Category details on ISIN code Response: " + response);
			CommonUtil.savePfApiStatus(categoryDetailsUrl, "getIsinCategoryDetails", requestString, response.toString(),
					SYSTEM);
			return response;
		} catch (HttpClientErrorException ex) {
			log.info("Error in Category details on ISIN code API:" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(categoryDetailsUrl, "getIsinCategoryDetails", requestString, ex.getResponseBodyAsString(),
					SYSTEM);
			throw new ExternalException(ex);
		} catch (HttpServerErrorException ex) {
			log.info("Error in Category details on ISIN code API:" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(categoryDetailsUrl, "getIsinCategoryDetails", requestString, ex.getMessage(),
					SYSTEM);
			throw new ExternalException(ex);
		} catch (Exception ex) {
			log.info("Error in Category details on ISIN codeAPI : " + ex.getMessage());
			CommonUtil.savePfApiStatus(categoryDetailsUrl, "getIsinCategoryDetails", requestString, ex.getMessage(),
					SYSTEM);
			throw new InternalException("2009");

		}
	}

	public String getHistoricalGoldPrice() throws Exception {
		Double latestAmount = 0.00;
		GoldHistoricalPriceRequest goldHistoricalPriceRequest = new GoldHistoricalPriceRequest();
		String requestStr = goldHistoricalPriceRequest.toString();
		try {
			goldHistoricalPriceRequest.setTimeFrame("1Y");
			HttpHeaders headers = tokenService.getRequestHttpHeader();
			String request = gson.toJson(goldHistoricalPriceRequest);
			HttpEntity<String> httpEntity = new HttpEntity<>(request, headers);
			ResponseEntity<GoldHistoricalPriceResponse[]> apiResponse = restTemplate
					.postForEntity(historicalGoldPriceURL, httpEntity, GoldHistoricalPriceResponse[].class);

			GoldHistoricalPriceResponse[] responses = apiResponse.getBody();

			if (responses != null && responses.length > 0) {
				latestAmount = responses[responses.length - 1].getBuy_pretax();
			}
			CommonUtil.savePfApiStatus(historicalGoldPriceURL, "getHistoricalGoldPrice", requestStr,
					String.valueOf(apiResponse.getBody()), SYSTEM);

			return String.valueOf(latestAmount);
		} catch (HttpServerErrorException ex) {
			log.info("HttpServerErrorException in getHistoricalGoldPrice :" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(historicalGoldPriceURL, "getHistoricalGoldPrice", requestStr, ex.getResponseBodyAsString(),
					SYSTEM);
			throw new ExternalException(ex);
		} catch (HttpClientErrorException ex) {
			log.info("HttpClientErrorException in getHistoricalGoldPrice :" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(historicalGoldPriceURL, "getHistoricalGoldPrice", requestStr, ex.getResponseBodyAsString(),
					SYSTEM);
			throw new ExternalException(ex);
		} catch (Exception e) {
			log.info("Exception in : getHistoricalGoldPrice {}", e.getMessage());
			CommonUtil.savePfApiStatus(historicalGoldPriceURL, "getHistoricalGoldPrice", requestStr, e.getMessage(),
					SYSTEM);
			throw new InternalException("2010");

		}
	}

}
