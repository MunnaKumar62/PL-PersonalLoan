package com.abc.portfolio.sip.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@Entity
@Table(name = "t_pf_sip_trans_status")
@ToString
public class PfSipTransStatus implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;

	@Column(name = "stock_SIP_ID")
	private String stockSipId;

	@Column(name = "stock_SIP_Status")
	private String stockSipStatus;

	@Column(name = "mf_SIP_ID")
	private String mfSipId;

	@Column(name = "mf_Status")
	private String mfStatus;

	@Column(name = "DG_SIP_ID")
	private String dgSipId;

	@Column(name = "DG_SIP_status")
	private String dgSipStatus;

	@Column(name = "customerID")
	private Long customerId;

	@Column(name = "mobno")
	private String mobno;

	@Column(name = "pf_SIP_ID")
	private String pfSipId;

	@Column(name = "SIPType")
	private String sipType;

	@Column(name = "pfSIP_planname")
	private String pfSIPPlanname;

	// Getters and Setters
	public Long getSno() {
		return sno;
	}

	public void setSno(Long sno) {
		this.sno = sno;
	}

	public String getStockSipId() {
		return stockSipId;
	}

	public void setStockSipId(String stockSipId) {
		this.stockSipId = stockSipId;
	}

	public String getStockSipStatus() {
		return stockSipStatus;
	}

	public void setStockSipStatus(String stockSipStatus) {
		this.stockSipStatus = stockSipStatus;
	}

	public String getMfSipId() {
		return mfSipId;
	}

	public void setMfSipId(String mfSipId) {
		this.mfSipId = mfSipId;
	}

	public String getMfStatus() {
		return mfStatus;
	}

	public void setMfStatus(String mfStatus) {
		this.mfStatus = mfStatus;
	}

	public String getDgSipId() {
		return dgSipId;
	}

	public void setDgSipId(String dgSipId) {
		this.dgSipId = dgSipId;
	}

	public String getDgSipStatus() {
		return dgSipStatus;
	}

	public void setDgSipStatus(String dgSipStatus) {
		this.dgSipStatus = dgSipStatus;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getMobno() {
		return mobno;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}

	public String getPfSipId() {
		return pfSipId;
	}

	public void setPfSipId(String pfSipId) {
		this.pfSipId = pfSipId;
	}

	public String getSipType() {
		return sipType;
	}

	public void setSipType(String sipType) {
		this.sipType = sipType;
	}

	
	
	@Column(name = "created_by", length = 45)
	private String createdBy;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modified_by", length = 45)
	private String modifiedBy;

	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;
}
