package com.abc.portfolio.sip.request;

import lombok.*;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GoalCalculatorRequest {
	
    private Long goalAmount;
    private Integer timeHorizon;
    private Double expectedRor;
}
