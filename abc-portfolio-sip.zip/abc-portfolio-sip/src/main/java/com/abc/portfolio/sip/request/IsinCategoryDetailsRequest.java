package com.abc.portfolio.sip.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IsinCategoryDetailsRequest {
	
	@JsonProperty("isin_code")
	private String isinCode;


}
