package com.abc.portfolio.sip.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreateMFPurchasePlansResponse {
	private String object;
	private String id;
	private String state;
	private String mf_investment_account;
	private String folio_number;
	private Boolean systematic;
	private String frequency;
	private String scheme;
	private Boolean auto_generate_installments;
	private Integer installment_day;
	private String start_date;
	private String end_date;
	private String requested_activation_date;
	private Integer number_of_installments;
	private String next_installment_date;
	private String previous_installment_date;
	private Integer remaining_installments;
	private Double amount;
	private String payment_method;
	private String payment_source;
	private String purpose;
	private String source_ref_id;
	private String euin;
	private String partner;
	private String created_at;
	private String activated_at;
	private String cancelled_at;
	private String completed_at;
	private String failed_at;
	private String cancellation_scheduled_on;
	private String reason;
	private String gateway;
	private String user_ip;
	private String server_ip;
	private String initiated_by;
	private String initiated_via;
//	private String productName;
	//private Consent consent;
	private String cancellation_code;
	private boolean auto_cancelled;

}