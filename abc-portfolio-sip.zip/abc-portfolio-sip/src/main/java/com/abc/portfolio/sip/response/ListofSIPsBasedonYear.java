package com.abc.portfolio.sip.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ListofSIPsBasedonYear {
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<SIPTypes> listOfSIPs;
}
