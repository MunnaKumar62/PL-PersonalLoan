package com.abc.portfolio.sip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.PfSipTransStatus;

@Repository
public interface PfSipTransStatusRepository extends JpaRepository<PfSipTransStatus, Long> {
	
	/*
	@Query(value = "SELECT f.amount, f.quantity,f.name,t.mf_status " + "FROM t_pf_sip_mf_list_of_funds f "
			+ "JOIN t_pf_sip_trans_status t ON f.mf_SIP_ID = t.mf_SIP_ID "
			+ "WHERE t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType AND YEAR(t.created_date) =:year", nativeQuery = true)
	List<Object[]> findListOfMF(@Param("customerId") String customerId, @Param("mobileNumber") String mobileNumber,
			@Param("pfSipId") String pfSipId, @Param("sipType") String sipType, @Param("year") String year);

	@Query(value = "SELECT f.amount, f.quantity,f.name,t.DG_SIP_status " + "FROM t_pf_sip_mf_list_of_funds f "
			+ "JOIN t_pf_sip_trans_status t ON f.dg_SIP_ID = t.dg_SIP_ID "
			+ "WHERE t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType AND YEAR(t.created_date) =:year", nativeQuery = true)
	List<Object[]> findListOfDG(@Param("customerId") String customerId, @Param("mobileNumber") String mobileNumber,
			@Param("pfSipId") String pfSipId, @Param("sipType") String sipType, @Param("year") String year);

	@Query(value = "SELECT f.amount, f.quantity,f.name,t.stock_SIP_Status " + "FROM t_pf_sip_mf_list_of_funds f "
			+ "JOIN t_pf_sip_trans_status t ON f.stock_SIP_ID = t.stock_SIP_ID "
			+ "WHERE t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType AND YEAR(t.created_date) =:year", nativeQuery = true)
	List<Object[]> findListOfST(@Param("customerId") String customerId, @Param("mobileNumber") String mobileNumber,
			@Param("pfSipId") String pfSipId, @Param("sipType") String sipType, @Param("year") String year);

	*/
	
	
	@Query(value = "SELECT mf.invest_amount AS investAmount,'0' as quantity,'' as name,t.mf_status "
			+ "FROM t_pf_sip_trans_status t, t_mf_purchase_plan_details mf "
			+ "WHERE t.mf_SIP_ID = mf.partner_investment_account_id AND t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType AND YEAR(t.created_date) =:year and mf.is_portfolioSIP='1'", nativeQuery = true)
	List<Object[]> findListOfMF(@Param("customerId") String customerId, @Param("mobileNumber") String mobileNumber,
			@Param("pfSipId") String pfSipId, @Param("sipType") String sipType, @Param("year") String year);

	@Query(value = "SELECT dg.total_amount AS totalAmount,dg.quantity AS quantity, dg.sip_name AS sipName,t.DG_SIP_status "
			+ "FROM t_pf_sip_trans_status t, t_digigold_sip_details dg "
			+ "WHERE t.DG_SIP_ID = dg.customer_ref_no and t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType AND YEAR(t.created_date) =:year and dg.is_portfolioSIP='1'", nativeQuery = true)
	List<Object[]> findListOfDG(@Param("customerId") String customerId, @Param("mobileNumber") String mobileNumber,
			@Param("pfSipId") String pfSipId, @Param("sipType") String sipType, @Param("year") String year);

	@Query(value = "SELECT st.amount AS amount,st.quantity AS quantity,st.basket_name AS basketName,t.stock_SIP_Status "
			+ "FROM t_pf_sip_trans_status t, t_demat_sip_stock st "
			+ "WHERE t.stock_SIP_ID = st.sip_id and t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType AND YEAR(t.created_date) =:year and st.is_portfolioSIP='1'", nativeQuery = true)
	List<Object[]> findListOfST(@Param("customerId") String customerId,
			@Param("mobileNumber") String mobileNumber, @Param("pfSipId") String pfSipId,
			@Param("sipType") String sipType, @Param("year") String year);

}
