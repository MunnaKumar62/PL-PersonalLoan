package com.abc.portfolio.sip.response;

import lombok.Data;

@Data
public class FetchMFPurchasePlan {
	
    private Long customerId;
	private String journeyId;
	private String profileId;
	private String id;

}
