package com.abc.portfolio.sip.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.MfPurchasePlanDetails;

@Repository
public interface MfPurchasePlanDetailsRepository extends JpaRepository<MfPurchasePlanDetails, Long> {
    // You can add custom query methods if needed
}
