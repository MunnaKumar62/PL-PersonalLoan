package com.abc.portfolio.sip;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.client.RestTemplate;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@Configuration
@ComponentScan(basePackages = "com.abc.portfolio.sip")
@EnableJpaRepositories(basePackages = "com.abc.portfolio.sip.repo")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@OpenAPIDefinition(servers = {
		@Server(url = "${swagger.default.server.url}", description = "Default Server URL") }, info = @Info(title = "Portfolio Sip Service"))

public class AbcPortfolioSipApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcPortfolioSipApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}
