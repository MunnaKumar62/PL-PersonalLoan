package com.abc.portfolio.sip.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvestedSchemes {
	private String isin;
	private String schemeName;
	private String planType;
	private String investmentOption;
	private String asOn;
	private Double nav;
	private Double investedAmount;
	private Double currentValue;
	private Double unrealizedGain;
	private Double absoluteReturn;
	private Double averageBuyingValue;
	private Double units;
	private Double xirr;
	private String schemeType;
	private boolean isSIP = Boolean.FALSE;
	private String lastInstallmentDate;
	private String nextInstallmentDate;
	private String folioNo;
}
