package com.abc.portfolio.sip.controller;

import java.util.List;
import java.util.Objects;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.portfolio.sip.common.Constants;
import com.abc.portfolio.sip.entity.PfSipTransStatus;
import com.abc.portfolio.sip.request.CalculatorRequest;
import com.abc.portfolio.sip.request.FetchListofSIPsBasedonYearReq;
import com.abc.portfolio.sip.request.FetchPortfolioSIPdetailRequest;
import com.abc.portfolio.sip.request.FetchpanandemailRequest;
import com.abc.portfolio.sip.request.GoalCalculatorRequest;
import com.abc.portfolio.sip.request.SIPCalculatorRequest;
import com.abc.portfolio.sip.response.CalculateData;
import com.abc.portfolio.sip.response.CalculatorResponse;
import com.abc.portfolio.sip.response.FetchpanandemailResponse;
import com.abc.portfolio.sip.response.GoalCalculatorResponse;
import com.abc.portfolio.sip.response.ListOfSIPs;
import com.abc.portfolio.sip.response.ListofSIPsBasedonYear;
import com.abc.portfolio.sip.response.SIPCalculatorResponse;
import com.abc.portfolio.sip.response.SipResponse;
import com.abc.portfolio.sip.service.PortfolioSipService;
import com.abc.portfolio.sip.util.CommonUtil;
import com.abc.portfolio.sip.util.SuccessMessage;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@Tag(name = "abc-portfolio-sip-Controller", description = "abc-portfolio-sip-Controller APIs")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api/v1")
public class PortfolioSipController {

	private static final String SYSTEM = "SYSTEM";

	@Autowired
	Environment env;

	private final PortfolioSipService portfolioSipService;
	

	@Autowired
	public PortfolioSipController(PortfolioSipService portfolioSipService) {
		this.portfolioSipService = portfolioSipService;
	}

	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Data Fetched."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@GetMapping("/fetchpanandemail")
	public ResponseEntity<?> fetchpanandemail(@RequestBody FetchpanandemailRequest request) {
		log.info("Start of fetchpanandemail  Service");

		FetchpanandemailResponse response = portfolioSipService.fetchpanandemail(request);
		SuccessMessage successMessage = CommonUtil.getSuccessResponse("200", Constants.FETCH_PANANDEMAIL_SUCCESS,
				response);
		log.info("End of fetchpanandemail  Service");
		String responseStr = Objects.nonNull(successMessage) ? successMessage.toString(): "";
		CommonUtil.savePfApiStatus(null, "fetchpanandemail", request.toString(),
				responseStr, SYSTEM);
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Data Fetched."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@GetMapping("/sipgoalcalculator")
	public ResponseEntity<Object> sipgoalcalculator(@RequestBody CalculatorRequest calculatorRequest) {
		GoalCalculatorRequest request = new GoalCalculatorRequest();
		request.setTimeHorizon(Integer.parseInt(calculatorRequest.getYears()));
		request.setGoalAmount(Long.parseLong(calculatorRequest.getAmount()));
		request.setExpectedRor(Double.parseDouble(calculatorRequest.getRoi()));
		log.debug("Goal Calculator Request - " + request);
		GoalCalculatorResponse goalCalculatorResponse = portfolioSipService.goalCalculator(request);
		CalculateData calculateData = new CalculateData();
		CalculatorResponse calculatorResponse = new CalculatorResponse();
		if (!goalCalculatorResponse.equals(null)) {
			calculatorResponse.setMonthlySipAmount(goalCalculatorResponse.getSipAmount());
		} else {
			calculateData.setErrorStatus(true);
			calculateData.setErrorMessage("No Data Found");
		}
		calculateData.setCalculatorResponse(calculatorResponse);
		SuccessMessage successResponse = CommonUtil.getSuccessResponse("4205", env.getProperty("4205"), calculateData);
		SipResponse successMessage1 = CommonUtil.getMinSipResponse("Investment-200", calculateData);
		SipResponse successMessage2 = CommonUtil.getMaxSipResponse("Investment-200", calculateData);
		String requestStr = calculatorRequest.toString();
		String successResponseStr = Objects.nonNull(successResponse) ? successResponse.toString(): "";
		if (SipResponse.minSip < 100) {
			log.debug("Goal Calculator Response - " + successMessage1);
			CommonUtil.savePfSaveCalculator(calculatorRequest, successMessage1, null);
			String successMessage1Str = Objects.nonNull(successMessage1) ? successMessage1.toString(): "";
			CommonUtil.savePfApiStatus(null, "sipgoalcalculator", requestStr,
					successMessage1Str, SYSTEM);
			return new ResponseEntity<>(successMessage1, HttpStatus.OK);
		} else if (SipResponse.minSip > 1000000) {
			log.debug("Goal Calculator Response - " + successMessage2);
			CommonUtil.savePfSaveCalculator(calculatorRequest, successMessage2, null);
			String successMessage2Str = Objects.nonNull(successMessage2) ? successMessage2.toString(): "";
			CommonUtil.savePfApiStatus(null, "sipgoalcalculator", requestStr,
					successMessage2Str, SYSTEM);
			return new ResponseEntity<>(successMessage2, HttpStatus.OK);
		} else {
			log.debug("Goal Calculator Response - " + successResponse);
			CommonUtil.savePfApiStatus(null, "sipgoalcalculator", requestStr,
					successResponseStr, SYSTEM);
			CommonUtil.savePfSaveCalculator(calculatorRequest, null, successResponse);
			return new ResponseEntity<>(successResponse, HttpStatus.OK);
		}
	}

	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Data Fetched."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@GetMapping("/sipprofilecalculator")
	public ResponseEntity<?> sipCalculator(@RequestBody CalculatorRequest calculatorRequest) {
		SIPCalculatorRequest request = new SIPCalculatorRequest();
		request.setInvestedPeriod(Integer.parseInt(calculatorRequest.getYears()));
		request.setMonthlyInvestAmt(Long.parseLong(calculatorRequest.getAmount()));
		request.setExpectedAnnualReturns(Double.parseDouble(calculatorRequest.getRoi()));
		int investedPeriod = request.getInvestedPeriod();
		log.debug("SIP Calculator Request - " + request);
		List<SIPCalculatorResponse> sipCalculatorResponse = portfolioSipService.sipCalculator(request);
		JSONArray json = new JSONArray(sipCalculatorResponse);
		log.debug("profile calc response: " + json.toString(4));
		CalculateData calculateData = new CalculateData();
		CalculatorResponse calculatorResponse = new CalculatorResponse();
		if (sipCalculatorResponse.size() > 0) {
			for (SIPCalculatorResponse sip : sipCalculatorResponse) {
				if ((int) sip.getYear() == investedPeriod) {
					calculatorResponse.setMonthlySipAmount(sip.getTotalWealthCreated());
					break;
				}
			}
		} else {
			calculateData.setErrorStatus(true);
			calculateData.setErrorMessage("No Data Found");
		}
		calculateData.setCalculatorResponse(calculatorResponse);
		SuccessMessage successResponse = CommonUtil.getSuccessResponse("4205", env.getProperty("4205"), calculateData);
		log.debug("SIP Calculator Response - " + successResponse);
		String successResponseStr = Objects.nonNull(successResponse) ? successResponse.toString(): "";
		CommonUtil.savePfApiStatus(null, "sipCalculator", calculatorRequest.toString(),
				successResponseStr, SYSTEM);
		CommonUtil.savePfSaveCalculator(calculatorRequest, null, successResponse);
		return new ResponseEntity<>(successResponse, HttpStatus.OK);
	}

	
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Data Fetched."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@PostMapping("/pfItemCompletionStatus")
	public ResponseEntity<?> pfItemCompletionStatus(@RequestBody PfSipTransStatus request) {
		log.info("Start of pfItemCompletionStatus  Service");

		PfSipTransStatus response = portfolioSipService.savepfItemCompletionStatus(request);
		SuccessMessage successMessage = CommonUtil.getSuccessResponse("200", Constants.PF_ITEM_COMPLETION_STATUS,
				response);
		log.info("End of pfItemCompletionStatus  Service");
		String successResponseStr = Objects.nonNull(successMessage) ? successMessage.toString(): "";
		CommonUtil.savePfApiStatus(null, "pfItemCompletionStatus", request.toString(),
				successResponseStr, SYSTEM);
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Data Fetched."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@PostMapping("/fetchPortfolioSIPdetails")
	public ResponseEntity<?> fetchPortfolioSIPdetails(@RequestBody FetchPortfolioSIPdetailRequest request) {
		log.info("Start of fetchPortfolioSIPdetails  Service");

		ListOfSIPs response = portfolioSipService.fetchPortfolioSIPdetails(request);
		SuccessMessage successMessage = CommonUtil.getSuccessResponse("200", Constants.FETCH_LIST_OF_SIPSBASEDONYEAR,
				response);
		String successResponseStr = Objects.nonNull(successMessage) ? successMessage.toString(): "";
		CommonUtil.savePfApiStatus(null, "fetchPortfolioSIPdetails", request.toString(),
				successResponseStr, SYSTEM);
		log.info("End of fetchPortfolioSIPdetails  Service");
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}
	
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully Data Fetched."),
			@ApiResponse(responseCode = "500", description = "Service temporarily unavailable.") })
	@PostMapping("/fetchListofSIPsBasedonYear")
	public ResponseEntity<?> fetchListofSIPsBasedonYear(@RequestBody FetchListofSIPsBasedonYearReq request) {
		log.info("Start of fetchListofSIPsBasedonYear  Service");

		ListofSIPsBasedonYear response = portfolioSipService.fetchListofSIPsBasedonYear(request);
		SuccessMessage successMessage = CommonUtil.getSuccessResponse("200", Constants.FETCH_LIST_OF_SIPSBASEDONYEAR,
				response);
		log.info("End of fetchListofSIPsBasedonYear  Service");
		String successResponseStr = Objects.nonNull(successMessage) ? successMessage.toString(): "";
		CommonUtil.savePfApiStatus(null, "fetchListofSIPsBasedonYear", request.toString(),
				successResponseStr, SYSTEM);
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}

}
