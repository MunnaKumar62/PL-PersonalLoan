package com.abc.portfolio.sip.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CalculateData {

	private boolean errorStatus;
	private String errorMessage;

	private CalculatorResponse calculatorResponse;

}
