package com.abc.portfolio.sip.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "t_pf_sip_mf_list_of_funds")
public class PfSipMfListOfFunds implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long sno;

	@Column(name = "name")
	private String name;

	@Column(name = "amount")
	private Double amount;

	@Column(name = "quantity")
	private Integer quantity;

	@Column(name = "mf_SIP_ID")
	private String mfSipId;

	@Column(name = "pf_SIP_ID")
	private String pfSipId;
	
	@Column(name = "stock_SIP_ID")
	private String stockSipId;
	
	@Column(name = "dg_SIP_ID")
	private String dgSipId;

	@Column(name = "customerID")
	private Long customerId;

	@Column(name = "mobNo")
	private String mobNo;

	// Getters and Setters
	public Long getSno() {
		return sno;
	}

	public void setSno(Long sno) {
		this.sno = sno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getMfSipId() {
		return mfSipId;
	}

	public void setMfSipId(String mfSipId) {
		this.mfSipId = mfSipId;
	}

	public String getPfSipId() {
		return pfSipId;
	}

	public void setPfSipId(String pfSipId) {
		this.pfSipId = pfSipId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	
	@Column(name = "created_by", length = 45)
	private String createdBy;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modified_by", length = 45)
	private String modifiedBy;

	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;
}