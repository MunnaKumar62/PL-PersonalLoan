package com.abc.portfolio.sip.serviceImpl;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.portfolio.sip.common.Constants;
import com.abc.portfolio.sip.exception.ExternalException;
import com.abc.portfolio.sip.exception.InternalException;
import com.abc.portfolio.sip.response.TokenResponse;
import com.abc.portfolio.sip.service.TokenService;
import com.abc.portfolio.sip.util.CommonUtil;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class TokenServiceImpl implements TokenService {

	@Value("${mf.exernal.api.token.url}")
	private String tokenUrl;

	@Value("${mf.exernal.api.token.grant.type}")
	private String grantType;

	@Value("${mf.exernal.api.token.client.id}")
	private String clientId;

	@Value("${mf.exernal.api.token.scope}")
	private String scope;

	@Value("${mf.exernal.api.token.authorization}")
	private String authToken;

	@Autowired
	private RestTemplate restTemplate;

	public HttpHeaders getRequestHttpHeader() throws Exception {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.add(Constants.AUTH_TOKEN, getAccessToken());
		return httpHeaders;

	}

	public String getAccessToken() throws Exception {

		UriComponents builder = UriComponentsBuilder.fromHttpUrl(tokenUrl).queryParam(Constants.CLIENT_ID, clientId)
				.queryParam(Constants.SCOPE, scope).queryParam(Constants.GRANT_TYPE, grantType).build();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add(Constants.AUTHORIZATION, Constants.BASIC + authToken);
		HttpEntity<Object> request = new HttpEntity<>(headers);
		String token = null;
		try {
			ResponseEntity<TokenResponse> apiResponse = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					request, TokenResponse.class);
			if (Objects.nonNull(apiResponse.getBody())) {
				token = apiResponse.getBody().getAccessToken();
			}
		} catch (HttpServerErrorException ex) {
			log.info("HttpServerErrorException in getting Access Token:" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(builder.toUriString(), "getAccessToken", request.toString(),
					ex.getMessage(), "SYSTEM");
			throw new ExternalException(ex);
		} catch (HttpClientErrorException ex) {
			log.info("HttpClientErrorException in getting Access Token:" + ex.getResponseBodyAsString());
			CommonUtil.savePfApiStatus(builder.toUriString(), "getAccessToken", request.toString(),
					ex.getMessage(), "SYSTEM");
			throw new ExternalException(ex);
		} catch (Exception ex) {
			log.info("error in getting Access Token:"+ ex.getMessage());
			throw new InternalException("2017");
			// throw new CustomException(ex.getMessage());
		}
		return token;
	}

}
