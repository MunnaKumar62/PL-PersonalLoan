package com.abc.portfolio.sip.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_mf_purchase_plan_details")
public class MFPurchasePlan {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mf_purchase_plan_id")
	private Long id;

	/*@ManyToOne
	@JoinColumn(name = "customer_id")
	@JsonBackReference
	private Customer customer;*/

	@Column(name = "source_ref_id")
	private String sourceRefId;

	@Column(name = "partner_purchase_plan_id", length = 45)
	private String partnerPurchasePlanId;

	@Column(name = "partner_investment_account_id", length = 45)
	private String partnerInvestmentAccountId;

	@Column(name = "start_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime startDate;

	@Column(name = "end_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime endDate;

	@Column(name = "number_of_installments")
	private Integer numberOfInstallments;

	@Column(name = "next_installment_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime nextInstallmentDate;

	@Column(name = "previous_installment_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime previousInstallmentDate;

	@Column(name = "remaining_inst")
	private Integer remainingInstallments;

	@Column(name = "folio_no", length = 45)
	private String folioNo;

	@Column(name = "state", length = 45)
	private String state;

	@Column(name = "invest_amount")
	private Double investAmount;

	@Column(name = "scheme_isin", length = 45)
	private String schemeIsin;

	@Column(name = "initated_by", length = 45)
	private String initatedBy;

	@Column(name = "initated_via", length = 45)
	private String initatedVia;

	@Column(name = "purchase_reason", length = 45)
	private String purchaseReason;

	@Column(name = "euin", length = 45)
	private String euin;

	@Column(name = "gateway", length = 45)
	private String gateway;

	@Column(name = "payment_mandate_id")
	private Long emandateId;

	@Column(name = "partner_id", length = 45)
	private String partnerId;

	@Column(name = "systematic")
	private Boolean systematic;

	@Column(name = "frequency")
	private String frequency;

	@Column(name = "auto_generate_installments")
	private Boolean autoGenerateInstallments;

	@Column(name = "installment_day")
	private Integer installmentDay;

	@Column(name = "payment_method")
	private String paymentMethod;

	@Column(name = "purpose")
	private String purpose;

	@Column(name = "plan_created_at")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime purchaseCreatedAt;

	@Column(name = "plan_activated_at")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime activatedAt;

	@Column(name = "plan_cancelled_at")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime cancelledAt;

	@Column(name = "plan_completed_at")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime completedAt;

	@Column(name = "plan_failed_at")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime purchaseFailedAt;

	@Column(name = "cancellation_scheduled_on")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime cancellationScheduledOn;

	@Column(name = "reason")
	private String reason;

	@Column(name = "requested_activation_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime requestedActivationDate;

	@Column(name = "cancellation_code")
	private Long cancellationCode;

	@Column(name = "purchase_consent")
	private String purchaseConsent;

	@Column(name = "purchase_consent_date")
	private LocalDateTime purchaseConsentDate;

	@Column(name = "plan_cancellation_consent")
	private String planCancellationConsent;

	@Column(name = "plan_cancellation_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime planCancellationDatetime;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;

	@Column(name = "created_by", length = 45)
	private String createdBy;

	@Column(name = "modified_by", length = 45)
	private String modifiedBy;

	@Column(name = "active")
	private Boolean active;

}
