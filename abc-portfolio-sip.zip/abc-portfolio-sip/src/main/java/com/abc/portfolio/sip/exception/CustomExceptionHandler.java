/**
 * Author: Vijayan L
 * Date: Aug 05, 2024
 * 
 */
package com.abc.portfolio.sip.exception;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.log4j.Log4j2;

@ControllerAdvice
@Log4j2
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
	
	@Value("${spring.application.name}")
	private String sourceName;

	@Autowired
	private Message message;

	@Value("${api.service.code}")
	private String serviceCode;

	@Value("${external.errorcode.prefix}")
	private String externalErrorCodePrefix;

	@Value("${internal.errorcode.prefix}")
	private String internalErrorCodePrefix;
	
	private static final String TECHNICAL_ERROR = "Technical Error";
	
	private static final String BUSINESS_ERROR = "Business Error";
	
	private static final String CLIENT_PREFIX = "C";
	
	private static final String SERVER_PREFIX = "S";

	@ResponseStatus(HttpStatus.UNAUTHORIZED) // 401
	@ExceptionHandler(HttpClientErrorException.Unauthorized.class)
	public @ResponseBody ExceptionResponse handleUnAuthorizedException(HttpClientErrorException.Unauthorized exception, HttpServletRequest request) {
		return buildResponseForHttpError(exception, CLIENT_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.FORBIDDEN) // 403
	@ExceptionHandler(HttpClientErrorException.Forbidden.class)
	public @ResponseBody ExceptionResponse handleForbiddenException(HttpClientErrorException.Forbidden exception, HttpServletRequest request) {
		return buildResponseForHttpError(exception, CLIENT_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.NOT_FOUND) // 404
	@ExceptionHandler(HttpClientErrorException.NotFound.class)
	public @ResponseBody ExceptionResponse handleNotFoundException(HttpClientErrorException.NotFound exception, HttpServletRequest request) {
		return buildResponseForHttpError(exception, CLIENT_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST) // 4xx
	@ExceptionHandler(HttpClientErrorException.class)
	public @ResponseBody ExceptionResponse handleClientErrorException(HttpClientErrorException exception, HttpServletRequest request) {
		return buildResponseForHttpError(exception, CLIENT_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.BAD_GATEWAY) // 502
	@ExceptionHandler(HttpServerErrorException.BadGateway.class)
	public @ResponseBody ExceptionResponse handleBadGatewayException(HttpServerErrorException.BadGateway exception,
			HttpServletRequest request) {
		return buildResponseForHttpError(exception, SERVER_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.GATEWAY_TIMEOUT) // 504
	@ExceptionHandler(HttpServerErrorException.GatewayTimeout.class)
	public @ResponseBody ExceptionResponse handleGatewayTimeoutException(HttpServerErrorException.GatewayTimeout exception,
			HttpServletRequest request) {
		return buildResponseForHttpError(exception, SERVER_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // 5xx
	@ExceptionHandler(HttpServerErrorException.class)
	public @ResponseBody ExceptionResponse handleHttpServerErrorException(HttpServerErrorException exception,
			HttpServletRequest request) {
		return buildResponseForHttpError(exception, SERVER_PREFIX);
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // All Other Technical errors 500
	@ExceptionHandler(Exception.class)
	public @ResponseBody ExceptionResponse handleAllOtherExceptions(Exception exception, HttpServletRequest request) {
		return buildResponseForOtherError(exception);
	}
	
	@ResponseStatus(HttpStatus.PARTIAL_CONTENT) //206
	@ExceptionHandler(BusinessException.class)
	public @ResponseBody ExceptionResponse handleBusinessException(BusinessException ex) {
		return buildResponseForBusinessError(ex);
	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // 500
	@ExceptionHandler(InternalException.class)
	public @ResponseBody ExceptionResponse handleInternalException(InternalException ex) {
		return buildResponseForInternalError(ex);
	}
	
	private ExceptionResponse buildResponseForHttpError(HttpStatusCodeException ex, String erPrefix) {
		
		int httpStatusCode = ex.getStatusCode().value();
		String errorCode = erPrefix + httpStatusCode;
		String eCode = serviceCode + "-" + externalErrorCodePrefix + "-" + errorCode;
		String errorMessage = ex.getMessage();
		String fullErrorMessage = errorCode + " : " + errorMessage;
		 
		log.info("HttpStatusCodeException;" + ex + "; statusCode=" + ex.getStatusCode().value()
				+ "; response =" + ex.getResponseBodyAsString());
		log.info("HTTP Error : "+fullErrorMessage);
		
		return ExceptionResponse.builder().code(httpStatusCode).reason(ex.getResponseBodyAsString()).errorCode(eCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(TECHNICAL_ERROR).build();
		
	}
	
	private ExceptionResponse buildResponseForBusinessError(BusinessException ex) {
		
		//Exception source = ex.getSourceException();
		String errorCode = serviceCode + "-" + "BE" + "-" + ex.getErrorCode();
		String errorMessage = message.getMessage(ex.getErrorCode());
		String fullErrorMessage = errorCode + ": " + errorMessage;
		//String reason = (source != null ? source.getMessage() : errorMessage);
		
		log.info("BusinessException;" + ex + "; statusCode=" + ex.getErrorCode()
		+ "; message =" + fullErrorMessage);
		log.error("Business Error :"+errorMessage);
		
		return ExceptionResponse.builder().code(206).reason(errorMessage).errorCode(errorCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(BUSINESS_ERROR ).build();
	}
	
	private ExceptionResponse buildResponseForInternalError(InternalException ex) {
		ex.setErrorCode("500");
		String errorCode = serviceCode + "-" + internalErrorCodePrefix + "-" + ex.getErrorCode();
		String errorMessage = message.getMessage(ex.getErrorCode());
		
		String fullErrorMessage = errorCode + ": " + errorMessage;
		//String reason = (source != null ? source.getMessage() : errorMessage);
		
		log.info("InternalException;" + ex + "; statusCode=" + ex.getErrorCode()
		+ "; message =" + fullErrorMessage);
		log.error("Internal Error :"+errorMessage);
		
		return ExceptionResponse.builder().code(500).reason(errorMessage).errorCode(errorCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(TECHNICAL_ERROR ).build();
	}
	
	private ExceptionResponse buildResponseForOtherError(Exception ex) {
		
		String eCode = "S500";
		String errorCode = serviceCode + "-" + internalErrorCodePrefix + "-" + eCode;
		String errorMessage = message.getMessage("S500");
		String fullErrorMessage = errorCode + ": " + errorMessage;
		String reason = (ex != null ? ex.getMessage() : errorMessage);
		
		log.info("InternalException;" + ex + "; statusCode=" + eCode
		+ "; message =" + fullErrorMessage);
		log.error("Internal Error :"+reason);
		
		return ExceptionResponse.builder().code(500).reason(reason).errorCode(errorCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(TECHNICAL_ERROR ).build();
	}
}
