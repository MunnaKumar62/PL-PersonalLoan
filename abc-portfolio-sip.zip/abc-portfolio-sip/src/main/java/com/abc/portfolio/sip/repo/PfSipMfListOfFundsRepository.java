package com.abc.portfolio.sip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.PfSipMfListOfFunds;

@Repository
public interface PfSipMfListOfFundsRepository extends JpaRepository<PfSipMfListOfFunds, Long> {

	/*
	 * @Query(value =
	 * "SELECT mf.invest_amount AS investAmount,'0' as quantity,'' as name,mf.partner_investment_account_id "
	 * + "FROM t_pf_sip_trans_status t, t_mf_purchase_plan_details mf " +
	 * "WHERE t.mf_SIP_ID = mf.partner_investment_account_id AND t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType and mf.is_portfolioSIP='1'"
	 * , nativeQuery = true) List<Object[]>
	 * findAmountAndQuantityByMF(@Param("customerId") String customerId,
	 * 
	 * @Param("mobileNumber") String mobileNumber, @Param("pfSipId") String pfSipId,
	 * 
	 * @Param("sipType") String sipType);
	 */

	@Query(value = "SELECT  distinct mf.partner_investment_account_id,mf.scheme_isin "
			+ "FROM t_pf_sip_trans_status t, t_mf_purchase_plan_details mf "
			+ "WHERE t.mf_SIP_ID = mf.partner_investment_account_id AND t.customerID=:customerId and t.mobno=:mobileNumber and t.pf_SIP_ID=:pfSipId and t.SIPType = :sipType and state='active' and mf.is_portfolioSIP='1'", nativeQuery = true)
	List<Object[]> findAmountAndQuantityByMF(@Param("customerId") String customerId,
			@Param("mobileNumber") String mobileNumber, @Param("pfSipId") String pfSipId,
			@Param("sipType") String sipType);

	@Query(value = "SELECT distinct dg.total_amount AS totalAmount,dg.quantity AS quantity, dg.sip_name AS sipName "
			+ "FROM t_pf_sip_trans_status t, t_digigold_sip_details dg "
			+ "WHERE t.DG_SIP_ID = dg.customer_ref_no and t.customerID=:customerId AND t.mobno =:mobileNumber and t.pf_SIP_ID=:pfSipId and sip_status='Order Created' and dg.is_portfolioSIP='1'", nativeQuery = true)
	List<Object[]> findAmountAndQuantityByDG(@Param("customerId") String customerId,
			@Param("mobileNumber") String mobileNumber, @Param("pfSipId") String pfSipId);

	@Query(value = "SELECT st.amount AS amount,st.quantity AS quantity,st.basket_name AS basketName "
			+ "FROM t_pf_sip_trans_status t, t_demat_sip_stock st "
			+ "WHERE t.customerID = st.customer_id and t.stock_SIP_ID = st.sip_id and t.customerID=:customerId AND t.mobno =:mobileNumber and t.pf_SIP_ID=:pfSipId and st.is_portfolioSIP='1'", nativeQuery = true)
	List<Object[]> findAmountAndQuantityByST(@Param("customerId") String customerId,
			@Param("mobileNumber") String mobileNumber, @Param("pfSipId") String pfSipId);

}
