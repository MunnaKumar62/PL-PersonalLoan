package com.abc.portfolio.sip.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginResponse {

	private String authToken;
}
