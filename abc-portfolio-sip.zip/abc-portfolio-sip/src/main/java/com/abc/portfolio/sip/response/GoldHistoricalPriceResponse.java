/**
 * Author: yamini.p
 * Date: 27-Jun-2024
 * ModifiedBy: yamini.p
 */
package com.abc.portfolio.sip.response;

import lombok.Data;

/**
 * 
 */
@Data
public class GoldHistoricalPriceResponse {
	

   private Double buy_pretax;
   private String date_time;
   
}
