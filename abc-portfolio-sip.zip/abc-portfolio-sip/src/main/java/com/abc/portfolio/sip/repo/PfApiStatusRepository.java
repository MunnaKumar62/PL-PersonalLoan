package com.abc.portfolio.sip.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.PfApiStatus;

@Repository
public interface PfApiStatusRepository extends JpaRepository<PfApiStatus, Long>{

}
