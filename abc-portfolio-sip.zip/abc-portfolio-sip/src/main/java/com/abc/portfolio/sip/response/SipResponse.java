package com.abc.portfolio.sip.response;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SipResponse {
	public static long minSip = 0;

	private String message;
	private String status;
	private String code;
	private LocalDateTime timestamp;
	private Object data;
}
