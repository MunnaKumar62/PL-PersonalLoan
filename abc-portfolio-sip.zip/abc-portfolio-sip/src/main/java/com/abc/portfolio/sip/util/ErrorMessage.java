package com.abc.portfolio.sip.util;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorMessage {

	private LocalDateTime timestamp;
	private String status;
	private int code;
	private String message;

	public ErrorMessage(String message) {
		super();
		this.message = message;
	}
}
