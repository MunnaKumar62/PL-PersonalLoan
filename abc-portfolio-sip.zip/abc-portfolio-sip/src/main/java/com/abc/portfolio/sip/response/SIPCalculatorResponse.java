package com.abc.portfolio.sip.response;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SIPCalculatorResponse {
	private long  totalWealthCreated;
	private long totalMoneyYouInvested;
	private long expectedWealthGain;
	private long year;
	
}
