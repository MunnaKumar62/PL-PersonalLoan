package com.abc.portfolio.sip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.MfPersonalDetails;

@Repository
public interface MfPersonalDetailsRepository extends JpaRepository<MfPersonalDetails, Long> {

	@Query(value = "SELECT p.pannumber, p.emailid FROM t_mf_personal_details p WHERE p.customer_id = :customerId AND p.mobilenumber = :mobileNumber", nativeQuery = true)
    List<Object[]> findPanNumberAndEmailIdByCustomerIdAndMobileNumber(@Param("customerId") Long customerId,
                                                                      @Param("mobileNumber") String mobileNumber);
}