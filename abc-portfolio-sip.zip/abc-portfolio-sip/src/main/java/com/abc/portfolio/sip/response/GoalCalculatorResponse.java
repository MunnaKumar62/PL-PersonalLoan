package com.abc.portfolio.sip.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GoalCalculatorResponse {

    private double sipAmount;
    private double needToInvest;
}
