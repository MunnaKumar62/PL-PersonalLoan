package com.abc.portfolio.sip.exception;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InternalErrorMessage {

	private Integer code;
	private String reason;
	private String errorCode;
	private String errorMessage;
	private String message;

}
