package com.abc.portfolio.sip.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class SIPType {
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String typeOfSIP;
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<Item> listOfItems;

}
