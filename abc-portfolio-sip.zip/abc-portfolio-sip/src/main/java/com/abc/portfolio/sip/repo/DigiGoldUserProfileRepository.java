package com.abc.portfolio.sip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.DigiGoldUserProfileEntity;

@Repository
public interface DigiGoldUserProfileRepository extends JpaRepository<DigiGoldUserProfileEntity, Long> {

	@Query(value = "select pannumber,emp_referral_email from t_digigold_user_profile where customer_id=:customerId and mobile_number=:mobileNumber", nativeQuery = true)
	List<Object[]> findPanNumberAndEmailIdByCustomerIdAndMobileNumber(@Param("customerId") Long customerId,
			@Param("mobileNumber") String mobileNumber);

}
