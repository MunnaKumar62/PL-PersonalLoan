package com.abc.portfolio.sip.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "t_mf_purchase_plan_details")
public class MfPurchasePlanDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mf_purchase_plan_id")
    private Long mfPurchasePlanId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "source_ref_id")
    private String sourceRefId;

    @Column(name = "partner_purchase_plan_id")
    private String partnerPurchasePlanId;

    @Column(name = "partner_investment_account_id")
    private String partnerInvestmentAccountId;

    @Column(name = "start_date")
    private LocalDateTime startDate;

    @Column(name = "end_date")
    private LocalDateTime endDate;

    @Column(name = "number_of_installments")
    private Integer numberOfInstallments;

    @Column(name = "next_installment_date")
    private LocalDateTime nextInstallmentDate;

    @Column(name = "previous_installment_date")
    private LocalDateTime previousInstallmentDate;

    @Column(name = "remaining_inst")
    private Integer remainingInst;

    @Column(name = "folio_no")
    private String folioNo;

    @Column(name = "state")
    private String state;

    @Column(name = "invest_amount")
    private Double investAmount;

    @Column(name = "scheme_isin")
    private String schemeIsin;

    @Column(name = "initated_by")
    private String initiatedBy;

    @Column(name = "initated_via")
    private String initiatedVia;

    @Column(name = "purchase_reason")
    private String purchaseReason;

    @Column(name = "euin")
    private String euin;

    @Column(name = "gateway")
    private String gateway;

    @Column(name = "payment_mandate_id")
    private Long paymentMandateId;

    @Column(name = "partner_id")
    private String partnerId;

    @Column(name = "systematic")
    private Boolean systematic;

    @Column(name = "frequency")
    private String frequency;

    @Column(name = "auto_generate_installments")
    private Boolean autoGenerateInstallments;

    @Column(name = "installment_day")
    private Integer installmentDay;

    @Column(name = "payment_method")
    private String paymentMethod;

    @Column(name = "purpose")
    private String purpose;

    @Column(name = "plan_created_at")
    private LocalDateTime planCreatedAt;

    @Column(name = "plan_activated_at")
    private LocalDateTime planActivatedAt;

    @Column(name = "plan_cancelled_at")
    private LocalDateTime planCancelledAt;

    @Column(name = "plan_completed_at")
    private LocalDateTime planCompletedAt;

    @Column(name = "plan_failed_at")
    private LocalDateTime planFailedAt;

    @Column(name = "cancellation_scheduled_on")
    private LocalDateTime cancellationScheduledOn;

    @Column(name = "reason")
    private String reason;

    @Column(name = "requested_activation_date")
    private LocalDateTime requestedActivationDate;

    @Column(name = "purchase_consent")
    private String purchaseConsent;

    @Column(name = "purchase_consent_date")
    private LocalDateTime purchaseConsentDate;

    @Column(name = "plan_cancellation_consent")
    private String planCancellationConsent;

    @Column(name = "plan_cancellation_datetime")
    private LocalDateTime planCancellationDatetime;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "cancellation_code")
    private Long cancellationCode;
    
    @Column(name="is_portfolioSIP")
	private String isPortfolioSIP;
}