package com.abc.portfolio.sip.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = 4087930070289795747L;

	private String errorCode;
	private String errorMessage;
	private Integer code;
	private String reason;
	
	

	public BusinessException() {
		super();
	}

	public BusinessException(Throwable cause) {
		super(cause);
	}
	
	public BusinessException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}
	
	public BusinessException(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public BusinessException(String errorCode, String errorMessage, Integer code, String reason) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.code = code;
		this.reason = reason;
	}

	

}
