package com.abc.portfolio.sip.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.DigigoldSipDetails;

@Repository
public interface DigigoldSipDetailsRepository extends JpaRepository<DigigoldSipDetails, Long> {
	// You can add custom query methods if needed
}
