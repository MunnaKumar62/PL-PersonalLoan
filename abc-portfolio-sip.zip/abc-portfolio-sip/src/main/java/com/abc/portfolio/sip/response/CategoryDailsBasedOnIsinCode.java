package com.abc.portfolio.sip.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CategoryDailsBasedOnIsinCode {

	@JsonProperty("basic_name")
	private String basicName;

	@JsonProperty("fund_name")
	private String fundName;

	@JsonProperty("category_id")
	private Integer categoryId;

	@JsonProperty("category_name")
	private String categoryName;

	@JsonProperty("isin_code")
	private String isinCode;

	@JsonProperty("primary_category_name")
	private String primaryCategoryName;
	
	private Double nav;
	
	@JsonProperty("nav_date")
	private String navDate;
	
	@JsonProperty("plan_id")
	private String planId;
	
	@JsonProperty("plan_name")
	private String planName;
	
	@JsonProperty("scheme_name")
	private String schemeName;
	
}
