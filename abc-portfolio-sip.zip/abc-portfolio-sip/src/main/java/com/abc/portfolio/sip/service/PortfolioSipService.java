package com.abc.portfolio.sip.service;

import java.util.List;

import com.abc.portfolio.sip.entity.PfSipTransStatus;
import com.abc.portfolio.sip.request.FetchListofSIPsBasedonYearReq;
import com.abc.portfolio.sip.request.FetchPortfolioSIPdetailRequest;
import com.abc.portfolio.sip.request.FetchpanandemailRequest;
import com.abc.portfolio.sip.request.GoalCalculatorRequest;
import com.abc.portfolio.sip.request.SIPCalculatorRequest;
import com.abc.portfolio.sip.response.FetchpanandemailResponse;
import com.abc.portfolio.sip.response.GoalCalculatorResponse;
import com.abc.portfolio.sip.response.ListOfSIPs;
import com.abc.portfolio.sip.response.ListofSIPsBasedonYear;
import com.abc.portfolio.sip.response.SIPCalculatorResponse;

public interface PortfolioSipService {

	public FetchpanandemailResponse fetchpanandemail(FetchpanandemailRequest request);

	public GoalCalculatorResponse goalCalculator(GoalCalculatorRequest request);

	public List<SIPCalculatorResponse> sipCalculator(SIPCalculatorRequest request);

	public PfSipTransStatus savepfItemCompletionStatus(PfSipTransStatus request);

	public ListOfSIPs fetchPortfolioSIPdetails(FetchPortfolioSIPdetailRequest request);

	public ListofSIPsBasedonYear fetchListofSIPsBasedonYear(FetchListofSIPsBasedonYearReq request);
}
