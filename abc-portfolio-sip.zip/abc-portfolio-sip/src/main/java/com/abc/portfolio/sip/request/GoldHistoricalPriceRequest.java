/**
 * Author: yamini.p
 * Date: 27-Jun-2024
 * ModifiedBy: yamini.p
 */
package com.abc.portfolio.sip.request;

import lombok.Data;

/**
 * 
 */
@Data
public class GoldHistoricalPriceRequest {
	private String timeFrame;
}
