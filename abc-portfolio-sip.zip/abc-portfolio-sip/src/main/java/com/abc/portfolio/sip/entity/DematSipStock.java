package com.abc.portfolio.sip.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "t_demat_sip_stock")
public class DematSipStock {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "account_id")
	private String accountId;

	@Column(name = "amount")
	private Double amount;

	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "mobile_number")
	private String mobileNumber;

	@Column(name = "request_date")
	private String requestDate;

	@Column(name = "start_date")
	private String startDate;

	@Column(name = "total_sip_amount")
	private Double totalSipAmount;

	@Column(name = "transacton_id", nullable = false, unique = true)
	private String transactonId;

	@Column(name = "action")
	private String action;

	@Column(name = "basket_id")
	private String basketId;

	@Column(name = "basket_name")
	private String basketName;

	@Column(name = "exchange_seg")
	private String exchangeSeg;

	@Column(name = "frequency")
	private String frequency;

	@Column(name = "investby")
	private String investBy;

	@Column(name = "order_type")
	private String orderType;

	@Column(name = "price_from")
	private String priceFrom;

	@Column(name = "product_type")
	private String productType;

	@Column(name = "status")
	private String status;

	@Column(name = "stock_code")
	private String stockCode;

	@Column(name = "is_abml_recomended")
	private Boolean isAbmlRecomended;

	@Column(name = "purpose")
	private String purpose;

	@Column(name = "quantity")
	private Integer quantity;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;

	@Column(name = "is_custombasket")
	private Boolean isCustomBasket;

	@Column(name = "is_paused_status")
	private Boolean isPausedStatus;

	@Column(name = "is_unpaused_status")
	private Boolean isUnpausedStatus;

	@Column(name = "sip_id")
	private String sipId;

	@Column(name = "is_modified_status")
	private Boolean isModifiedStatus;

	@Column(name = "sector_name")
	private String sectorName;
	
	@Column(name="is_portfolioSIP")
	private String isPortfolioSIP;

}
