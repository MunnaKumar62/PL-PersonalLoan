package com.abc.portfolio.sip.util;

import java.time.LocalDateTime;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.abc.portfolio.sip.entity.PfApiStatus;
import com.abc.portfolio.sip.entity.PfSaveCalculator;
import com.abc.portfolio.sip.exception.ExternalErrorMessage;
import com.abc.portfolio.sip.exception.InternalErrorMessage;
import com.abc.portfolio.sip.repo.PfApiStatusRepository;
import com.abc.portfolio.sip.repo.PfSaveCalculatorRepository;
import com.abc.portfolio.sip.request.CalculatorRequest;
import com.abc.portfolio.sip.response.SipResponse;

@Component
public class CommonUtil {

	@Value("${spring.application.name}")
	private static String applicationName;
	
	private static PfSaveCalculatorRepository pfSaveCalculatorRepository;
	
	private static PfApiStatusRepository pfApiStatusRepository;
	
	@Autowired
	public CommonUtil(PfSaveCalculatorRepository pfSaveCalculatorRepository, PfApiStatusRepository pfApiStatusRepository) {
		CommonUtil.pfSaveCalculatorRepository = pfSaveCalculatorRepository;
		CommonUtil.pfApiStatusRepository= pfApiStatusRepository;
	}
	
	public static SuccessMessage getSuccessResponse(String code, String message, Object data) {
		SuccessMessage successResponse = new SuccessMessage();
		successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus("success");
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}

	public static ErrorMessage getErrorMessage(int code, String message) {
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setTimestamp(LocalDateTime.now());
		errorMessage.setStatus("error");
		errorMessage.setCode(code);
		errorMessage.setMessage(message);
		return errorMessage;
	}

	public static InternalErrorMessage getInternalErrorMessage(int code, String reason, String errorCode,
			String errorMsg, String message) {
		InternalErrorMessage errorMessage = new InternalErrorMessage();
		errorMessage.setCode(code);
		errorMessage.setReason(reason);
		errorMessage.setErrorCode(errorCode);
		errorMessage.setErrorMessage(errorMsg);
		errorMessage.setMessage(errorCode + ": " + errorMsg);
		return errorMessage;
	}

	public static ExternalErrorMessage getExternalErrorMessage(int code, String reason, String errorCode,
			String errorMsg, String message) {
		ExternalErrorMessage errorMessage = new ExternalErrorMessage();
		errorMessage.setCode(code);
		errorMessage.setReason(reason);
		errorMessage.setErrorCode(errorCode);
		errorMessage.setErrorMessage(errorMsg);
		errorMessage.setMessage(message);
		return errorMessage;
	}

	public static SipResponse getMinSipResponse(String code, Object data) {
		SipResponse sipResponse = new SipResponse();
		sipResponse.setCode(code);
		sipResponse.setStatus("success");
		sipResponse.setTimestamp(LocalDateTime.now());
		sipResponse.setMessage("Minimum SIP is 100");
		sipResponse.setData(data);
		return sipResponse;
	}

	public static SipResponse getMaxSipResponse(String code, Object data) {
		SipResponse sipResponse = new SipResponse();
		sipResponse.setCode(code);
		sipResponse.setStatus("success");
		sipResponse.setTimestamp(LocalDateTime.now());
		sipResponse.setMessage("Maximum SIP must be between 100 to 10,00,000");
		sipResponse.setData(data);
		return sipResponse;
	}
		
	public static void savePfSaveCalculator(CalculatorRequest calculatorRequest, SipResponse sipResponse, SuccessMessage successMessage) {
		PfSaveCalculator pfSaveCalculator = new PfSaveCalculator();
		Long customerId = calculatorRequest.getCustomerId();
		String profileSipId = calculatorRequest.getPortfolioSipId();
		pfSaveCalculator.setCustomerId(customerId);
		pfSaveCalculator.setPfSipId(profileSipId);
		pfSaveCalculator.setRequestPayload(calculatorRequest.toString());
		pfSaveCalculator.setResponsePayload(Objects.nonNull(sipResponse) 
				? sipResponse.toString() 
				: successMessage.toString());
		pfSaveCalculator.setCreatedBy(String.valueOf(customerId));
		pfSaveCalculator.setCreatedDate(LocalDateTime.now());
		pfSaveCalculator.setModifiedBy(String.valueOf(customerId));
		pfSaveCalculator.setModifiedDate(LocalDateTime.now());
		pfSaveCalculatorRepository.save(pfSaveCalculator);
	}
	
	public static void savePfApiStatus(String apiUrl, String methodName, 
			String request, String response, String createdBy) {
		LocalDateTime currentDateTime = LocalDateTime.now();
		PfApiStatus pfApiStatus = new PfApiStatus();
		if (StringUtils.isNotBlank(apiUrl)) {
			pfApiStatus.setApiUrl(apiUrl);
		}
		pfApiStatus.setRequest(request);
		if (StringUtils.isNotBlank(methodName)) {
			pfApiStatus.setMethodName(methodName);
		}
		pfApiStatus.setResponse(response);
		pfApiStatus.setCreatedDate(currentDateTime);
		if (StringUtils.isNotBlank(createdBy)) {
			pfApiStatus.setModifiedBy(createdBy);
			pfApiStatus.setCreatedBy(createdBy);
		}
		pfApiStatus.setModifiedDate(currentDateTime);
		pfApiStatusRepository.save(pfApiStatus);
	}


}
