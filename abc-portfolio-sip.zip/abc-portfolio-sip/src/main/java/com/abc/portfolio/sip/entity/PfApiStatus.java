package com.abc.portfolio.sip.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "t_pf_api_status")
public class PfApiStatus implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pf_api_id")
	private Long pfApiId;

	@Column(name = "method_name")
	private String methodName;

	@Column(name = "api_url")
	private String apiUrl;

	@Column(name = "request", columnDefinition = "MEDIUMTEXT")
	private String request;

	@Column(name = "response", columnDefinition = "MEDIUMTEXT")
	private String response;

	@Column(name = "status")
	private String status;
	
	@Column(name = "created_by", length = 45)
	private String createdBy;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modified_by", length = 45)
	private String modifiedBy;

	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;



}
