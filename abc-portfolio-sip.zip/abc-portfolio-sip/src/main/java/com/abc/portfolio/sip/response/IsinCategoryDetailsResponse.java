package com.abc.portfolio.sip.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class IsinCategoryDetailsResponse {
	@JsonProperty("cat_details_based_on_isin_code")
	List<CategoryDailsBasedOnIsinCode> CatDailsBasedOnIsinCode;

}
