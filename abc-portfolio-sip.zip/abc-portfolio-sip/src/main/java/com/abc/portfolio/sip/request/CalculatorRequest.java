package com.abc.portfolio.sip.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CalculatorRequest {

	private String amount;
	private String years;
	private String roi;
	private Long customerId;
	private String portfolioSipId;

}
