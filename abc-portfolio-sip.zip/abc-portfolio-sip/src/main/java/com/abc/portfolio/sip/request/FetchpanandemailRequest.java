package com.abc.portfolio.sip.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@ToString
public class FetchpanandemailRequest {

	String customerID;
	String mobileNo;
}
