package com.abc.portfolio.sip.service;

import org.springframework.http.HttpHeaders;

public interface TokenService {
	public HttpHeaders getRequestHttpHeader() throws Exception;
}
