package com.abc.portfolio.sip.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "t_digigold_sip_details")
public class DigigoldSipDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sip_details_id")
	private Long sipDetailsId;

	@Column(name = "customer_id", nullable = false)
	private Long customerId;

	@Column(name = "customer_ref_no")
	private String customerRefNo;

	@Column(name = "dg_customer_ref_no")
	private String dgCustomerRefNo;

	@Column(name = "mmtc_customer_id")
	private String mmtcCustomerId;

	@Column(name = "name")
	private String name;

	@Column(name = "mobile_number", nullable = false)
	private String mobileNumber;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "quote_id")
	private String quoteId;

	@Column(name = "metal_type")
	private String metalType;

	@Column(name = "quantity")
	private Double quantity;

	@Column(name = "total_amount")
	private Double totalAmount;

	@Column(name = "payment_method")
	private String paymentMethod;

	@Column(name = "payment_date")
	private String paymentDate;

	@Column(name = "emandate_id")
	private String emandateId;

	@Column(name = "sip_name")
	private String sipName;

	@Column(name = "sip_id", nullable = false, unique = true)
	private String sipId;

	@Column(name = "sip_period")
	private String sipPeriod;

	@Column(name = "frequency")
	private String frequency;

	@Column(name = "sip_start_date")
	private String sipStartDate;

	@Column(name = "sip_end_date")
	private String sipEndDate;

	@Column(name = "is_paused")
	private Boolean isPaused;

	@Column(name = "pause_count")
	private Integer pauseCount;

	@Column(name = "pause_start_date")
	private String pauseStartDate;

	@Column(name = "pause_end_date")
	private String pauseEndDate;

	@Column(name = "total_sip_count")
	private Integer totalSipCount;

	@Column(name = "success_sip_count")
	private Integer successSipCount;

	@Column(name = "sip_status")
	private String sipStatus;

	@Column(name = "sip_active")
	private Boolean sipActive;

	@Column(name = "created_date")
	private LocalDateTime createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_date")
	private LocalDateTime modifiedDate;

	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name="is_portfolioSIP")
	private String isPortfolioSIP;

}
