package com.abc.portfolio.sip.response;

import java.time.LocalDate;

import lombok.Data;

@Data
public class ReturnsRequest {

    private Long customerId;
    private String profileId;
    private String journeyId;
    private String mfInvestmentAccount;
    private LocalDate tradedOnTo;

}
