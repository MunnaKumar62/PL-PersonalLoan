package com.abc.portfolio.sip.coffeine;

public class CaffeineConstant {

    private CaffeineConstant(){}

    public static final int EXPIRE_AFTER_WRITE_DURATION_IN_MINUTES = 20;
    public static final String AUTH_TOKEN_CACHE = "digigold_auth_token_cache";
    public static final String AUTH_TOKEN_CACHE_KEY = "digigold_auth_token";
}
