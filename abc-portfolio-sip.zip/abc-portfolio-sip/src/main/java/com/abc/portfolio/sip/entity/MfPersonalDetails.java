package com.abc.portfolio.sip.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
@Entity
@Table(name = "t_mf_personal_details")
public class MfPersonalDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "investor_personal_detailid")
	private Long id;

	@Column(name = "partner_profile_id")
	private String partnerProfileId;

	@Column(name = "customer_id")
	private Long customerId;

	@Column(name = "pannumber")
	private String panNumber;

	@Column(name = "dob")
	private Date dob;

	@Column(name = "emailid")
	private String emailId;

	@Column(name = "email_belongs_to")
	private String emailBelongsTo;

	@Column(name = "mobile_belongs_to")
	private String mobileBelongsTo;

	@Column(name = "fullname")
	private String fullName;

	@Column(name = "gender")
	private String gender;

	@Column(name = "country_ofbirth")
	private String countryOfBirth;

	@Column(name = "is_politically_exposed")
	private Boolean isPoliticallyExposed;

	@Column(name = "residential_status")
	private String residentialStatus;

	@Column(name = "maritial_status")
	private String maritalStatus;

	@Column(name = "father_name")
	private String fatherName;

	@Column(name = "spouse_name")
	private String spouseName;

	@Column(name = "mother_name")
	private String motherName;

	@Column(name = "mobilenumber")
	private String mobileNumber;

	@Column(name = "partner_email_id")
	private String partnerEmailId;

	@Column(name = "partner_mobile_id")
	private String partnerMobileId;

	@Column(name = "is_resident_taxpayer")
	private Boolean isResidentTaxpayer;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;
}
