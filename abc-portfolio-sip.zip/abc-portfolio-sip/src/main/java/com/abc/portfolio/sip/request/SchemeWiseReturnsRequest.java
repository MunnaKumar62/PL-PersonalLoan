package com.abc.portfolio.sip.request;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SchemeWiseReturnsRequest {

	@JsonProperty("mf_investment_account")
	private String mfInvestmentAccount;

	@JsonProperty("traded_on_to")
	private LocalDate tradedOnTo;

}
