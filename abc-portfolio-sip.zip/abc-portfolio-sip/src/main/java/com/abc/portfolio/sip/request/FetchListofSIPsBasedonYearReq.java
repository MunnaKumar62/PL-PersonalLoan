package com.abc.portfolio.sip.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
public class FetchListofSIPsBasedonYearReq {
	String customerID;
	String mobileNumber;
	String portfolioSIPID;
	String year;

}
