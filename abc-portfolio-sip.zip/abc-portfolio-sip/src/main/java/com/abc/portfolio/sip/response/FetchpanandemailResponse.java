package com.abc.portfolio.sip.response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
@Setter
@Getter
@ToString
public class FetchpanandemailResponse {

	String pan;
	String email;
}
