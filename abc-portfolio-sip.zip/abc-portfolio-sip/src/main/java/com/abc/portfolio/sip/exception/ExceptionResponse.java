package com.abc.portfolio.sip.exception;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
public class ExceptionResponse<T> {
    private final int code;
    private final String reason;
    private T data;
    private String errorCode;
    private String errorMessage;
    private String message;
    private String errorType;
}
