package com.abc.portfolio.sip.entity;

import static com.abc.portfolio.sip.common.Constants.USER_ABCD;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "t_digigold_user_profile")
public class DigiGoldUserProfileEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "digigoldUserProfileId")
	private long id;

	@Column(name = "mobileNumber")
	private String mobileNumber;

	@Column(name = "fullName")
	private String fullName;

	@Column(name = "partnerId")
	private String partnerId;

	@Column(name = "customerRefNo")
	private String customerRefNo;

	@Column(name = "dgCustomerRefNo")
	private String dgCustomerRefNo;

	@Column(name = "customer_id")
	private Long customerId;

	@Column(name = "created_date")
	private LocalDateTime createdDate = LocalDateTime.now();

	@Column(name = "modified_date")
	private LocalDateTime modifiedDate = LocalDateTime.now();

	@Column(name = "created_by")
	private String createdBy = USER_ABCD;

	@Column(name = "modified_by")
	private String modifiedBy = USER_ABCD;

	@Column(name = "active")
	private int active = 1;

	@Column(name = "pannumber")
	private String pannumber;

	@Column(name = "pan_verification_status")
	private Boolean panVerificationStatus;
}
