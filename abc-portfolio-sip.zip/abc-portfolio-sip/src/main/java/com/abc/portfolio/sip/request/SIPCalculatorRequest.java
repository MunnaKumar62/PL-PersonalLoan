package com.abc.portfolio.sip.request;

import lombok.*;

@Getter
@Data
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SIPCalculatorRequest {
	public long monthlyInvestAmt;
	public double expectedAnnualReturns;
	public int investedPeriod;
}
