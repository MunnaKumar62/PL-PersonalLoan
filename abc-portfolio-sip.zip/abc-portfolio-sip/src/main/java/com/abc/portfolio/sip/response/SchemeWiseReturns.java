package com.abc.portfolio.sip.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SchemeWiseReturns {
	private String partnerInvestmentAccountId;
	List<InvestedSchemes> investedSchemes;
	private double equityPercent;
	private double debtPercent;
	private double liquidPercent;
	private double commoditiesPercent;

}
