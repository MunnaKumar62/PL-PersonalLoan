package com.abc.portfolio.sip.common;

public class Constants {
	public static final String LOCALE_MESSAGE_COUNTRYCODE = "IN";
	public static final String LOCALE_MESSAGE_ENGLISH = "en";
	public static final String LOCALE_MESSAGE_TAMIL = "ta";
	public static final String LOCALE_MESSAGE_HINDI = "hi";
	public static final String SERVER = "S";
	public static final String CLIENT = "C";
	public static final String FETCH_PANANDEMAIL_SUCCESS = "Pan and Eamil Fetche Successfully";
	public static final String PF_ITEM_COMPLETION_STATUS = "Record Saved Successfully";
	public static final String FETCH_LIST_OF_SIPSBASEDONYEAR = "Fetched Record Successfully";
	public static final String USER_ABCD = "ABCD";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BASIC = "Basic ";
	public static final String AUTH_TOKEN = "auth-token";
	public static final String CLIENT_ID = "client_id";
	public static final String SCOPE = "scope";
	public static final String GRANT_TYPE = "grant_type";
}
