package com.abc.portfolio.sip.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IsinCategoryDetails {
	private String customerId;
	private String isinCode;


}
