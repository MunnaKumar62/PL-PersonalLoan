package com.abc.portfolio.sip.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Data
@JsonInclude(JsonInclude.Include.ALWAYS)
public class Items {
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String status;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String name;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currentPrice;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String quantity;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String amount;
}
