package com.abc.portfolio.sip.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.portfolio.sip.entity.PfSaveCalculator;

@Repository
public interface PfSaveCalculatorRepository extends JpaRepository<PfSaveCalculator, Long> {
    // Custom query methods can be added here if needed
}
