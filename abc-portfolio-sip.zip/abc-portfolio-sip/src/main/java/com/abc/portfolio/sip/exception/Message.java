package com.abc.portfolio.sip.exception;

import java.util.Objects;
import java.util.ResourceBundle;

import org.springframework.stereotype.Component;

import com.abc.portfolio.sip.common.Constants;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class Message {

	private String defaultLocale = Constants.LOCALE_MESSAGE_ENGLISH;
	private String defaultCountryCode = Constants.LOCALE_MESSAGE_COUNTRYCODE;

	public String getMessage(String messageKey) {
		String messageValue = null;
		try {
			ResourceBundle bundle = ResourceBundle
					.getBundle("messages" + "_" + defaultLocale + "_" + defaultCountryCode);
			messageValue = bundle.getString(messageKey);
		} catch (Exception e) {
			log.error("getMessage: {}", e.getMessage());
		}
		return null != messageValue ? messageValue : messageKey;
	}

	public String getMessage(String messageKey, String locale, String countryCode) {
		String messageValue = null;
		locale = (Objects.nonNull(locale)) ? locale : defaultLocale;
		countryCode = (Objects.nonNull(countryCode)) ? countryCode : defaultCountryCode;
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("messages" + "_" + locale + "_" + countryCode);
			messageValue = bundle.getString(messageKey);
		} catch (Exception e) {
			log.error("getMessage: {}", e.getMessage());
		}
		return null != messageValue ? messageValue : messageKey;
	}

}
