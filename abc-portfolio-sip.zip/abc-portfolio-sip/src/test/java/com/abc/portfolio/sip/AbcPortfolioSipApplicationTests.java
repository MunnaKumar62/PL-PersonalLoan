package com.abc.portfolio.sip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcPortfolioSipApplicationTests {

	@Test
	void contextLoads() {
	}

}
