package com.abc.rewards;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlRewardsApplicationTests {

	@Test
	void contextLoads() {
	}

}
