package com.abc.rewards.constants;

import com.abc.rewards.exception.ExternalException;
import com.abc.rewards.exception.PartnerError;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

@Slf4j
@Component
public class CommonUtills {

    @Autowired
    private ObjectMapper objectMapper;


    public void handleHttpClientError(HttpStatusCodeException ex, String apiName) throws Exception {
        log.info("handleHttpClientError()-apiName=" + apiName + "; statusCode=" + ex.getStatusCode().value()
                + "; response =" + ex.getResponseBodyAsString());
        PartnerError partnerError = null;
        String errorMessage = null;
        String reason = null;
        int httpStatusCode = ex.getStatusCode().value();
        if (ex.getResponseBodyAsString() != null && !ex.getResponseBodyAsString().isEmpty()) {
            try {
                partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
                errorMessage = partnerError.getError() != null ? partnerError.getError().getMessage() : null;
            } catch (JsonProcessingException e) {
                errorMessage = "Error processing JSON response from the client";
                reason = ex.getStatusText();
                log.error("Error processing JSON response from client: " + ex.getResponseBodyAsString(), e);
            }
        } else {
            errorMessage = "Empty or null response from the client";
            log.error("Empty or null response received from client API: " + apiName);
        }
        if (partnerError != null && partnerError.getError() != null && partnerError.getError().getStatus() != null
                && partnerError.getError().getMessage() != null) {
            throw new ExternalException("C" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
                    partnerError.getError().getStatus(), partnerError.getError().getMessage());
        } else if(null!=partnerError.getMessage()) {
        	errorMessage = partnerError.getMessage();
            throw new ExternalException("C" + httpStatusCode, errorMessage ,
                    500, reason);
        }
    }

    public void handleHttpServerError(HttpStatusCodeException ex, String apiName) throws Exception {
        log.info("handleHttpServerError() - apiName=" + apiName + "; statusCode=" + ex.getStatusCode().value()
                + "; response =" + ex.getResponseBodyAsString());
        PartnerError partnerError = null;
        String errorMessage = null;
        String reason = null;
        int httpStatusCode = ex.getStatusCode().value();
        if (ex.getResponseBodyAsString() != null && !ex.getResponseBodyAsString().isEmpty()) {
            try {
                partnerError = objectMapper.readValue(ex.getResponseBodyAsString(), PartnerError.class);
                errorMessage = partnerError.getError() != null ? partnerError.getError().getMessage() : null;
            } catch (JsonProcessingException e) {
                errorMessage = "Error processing JSON response from the server";
                reason = ex.getStatusText();
                log.error("Error processing JSON response from server: " + ex.getResponseBodyAsString(), e);
            }
        } else {
            errorMessage = "Empty or null response from the server";
            log.error("Empty or null response received from server for API: " + apiName);
        }
        if (partnerError != null && partnerError.getError() != null && partnerError.getError().getStatus() != null
                && partnerError.getError().getMessage() != null) {
            throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
                    partnerError.getError().getStatus(), partnerError.getError().getMessage());
        } else {
            throw new ExternalException("S" + httpStatusCode, errorMessage != null ? errorMessage : "Unknown error",
                    500, reason);
        }
    }

}
