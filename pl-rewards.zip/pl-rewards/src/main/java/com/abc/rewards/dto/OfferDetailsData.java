package com.abc.rewards.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OfferDetailsData {

	
    @JsonProperty("Id") 
    public String id;
    @JsonProperty("ProviderDetailsId") 
    public Object providerDetailsId;
    @JsonProperty("LanguageMasterId") 
    public Object languageMasterId;
    @JsonProperty("SourceMasterId") 
    public Object sourceMasterId;
    @JsonProperty("Source") 
    public String source;
    @JsonProperty("ProviderCode") 
    public Object providerCode;
    @JsonProperty("SKU") 
    public String sKU;
    @JsonProperty("Name") 
    public String name;
    @JsonProperty("Code") 
    public String code;
    @JsonProperty("Type") 
    public String type;
    @JsonProperty("OfferType") 
    public String offerType;
    @JsonProperty("ShortDescription") 
    public String shortDescription;
    @JsonProperty("FullDescription") 
    public String fullDescription;
    @JsonProperty("Discount") 
    public double discount;
    @JsonProperty("DiscountType") 
    public String discountType;
    @JsonProperty("StartDate") 
    public String startDate;
    @JsonProperty("EndDate") 
    public String endDate;
    @JsonProperty("BrandId") 
    public String brandId;
    @JsonProperty("BrandName") 
    public String brandName;
    @JsonProperty("BrandDescription") 
    public Object brandDescription;
    @JsonProperty("BrandURL") 
    public Object brandURL;
    @JsonProperty("BrandLogoURL") 
    public Object brandLogoURL;
    @JsonProperty("CategoryId") 
    public Object categoryId;
    @JsonProperty("CategoryName") 
    public Object categoryName;
    @JsonProperty("IsMultiUse") 
    public boolean isMultiUse;
    @JsonProperty("IsInternational") 
    public boolean isInternational;
    @JsonProperty("DisplayStartDate") 
    public String displayStartDate;
    @JsonProperty("DisplayEndDate") 
    public String displayEndDate;
    @JsonProperty("IsLRConsumable") 
    public boolean isLRConsumable;
    @JsonProperty("MaxDiscountPerTransaction") 
    public double maxDiscountPerTransaction;
    @JsonProperty("MaxDiscountPerCustomer") 
    public Object maxDiscountPerCustomer;
    @JsonProperty("MaxUsage") 
    public int maxUsage;
    @JsonProperty("MaxUsagePerCustomer") 
    public int maxUsagePerCustomer;
    @JsonProperty("TotalOfferAmount") 
    public double totalOfferAmount;
    @JsonProperty("TnC") 
    public String tnC;
    @JsonProperty("OnlineUrl") 
    public String onlineUrl;
    @JsonProperty("IsOnline") 
    public boolean isOnline;
    @JsonProperty("Comments") 
    public Object comments;
    @JsonProperty("OperationType") 
    public Object operationType;
    @JsonProperty("Status") 
    public Object status;
    @JsonProperty("IsCoupon") 
    public boolean isCoupon;
    @JsonProperty("IsAutoGeneration") 
    public boolean isAutoGeneration;
    @JsonProperty("MinLength") 
    public int minLength;
    @JsonProperty("Prefix") 
    public Object prefix;
    @JsonProperty("Postfix") 
    public Object postfix;
    @JsonProperty("ExpiryDuration") 
    public int expiryDuration;
    @JsonProperty("MaxCouponCount") 
    public int maxCouponCount;
    @JsonProperty("Denomination") 
    public double denomination;
    @JsonProperty("AvailableCouponCount") 
    public int availableCouponCount;
    @JsonProperty("IsSellable") 
    public boolean isSellable;
    @JsonProperty("IsCustomAttributes") 
    public boolean isCustomAttributes;
    @JsonProperty("MRP") 
    public Object mRP;
    @JsonProperty("RetailPrice") 
    public double retailPrice;
    @JsonProperty("NetPrice") 
    public Object netPrice;
    @JsonProperty("RetailShippingPrice") 
    public double retailShippingPrice;
    @JsonProperty("RetailPriceInclusive") 
    public double retailPriceInclusive;
    @JsonProperty("Images") 
    public ArrayList<Image> images;
    @JsonProperty("Banners") 
    public ArrayList<OfferDetailsBanner> banners;
    @JsonProperty("CustomAttributes") 
    public Object customAttributes;
    @JsonProperty("Headers") 
    public Headers headers;
    @JsonProperty("Coupons") 
    public Object coupons;
    @JsonProperty("Stores") 
    public Object stores;
    @JsonProperty("OfferCategories") 
    public ArrayList<OfferCategory> offerCategories;
    @JsonProperty("RuleIds") 
    public Object ruleIds;
    @JsonProperty("Message") 
    public Object message;
    @JsonProperty("RedemptionSteps") 
    public String redemptionSteps;
    @JsonProperty("IncentiveType") 
    public Object incentiveType;
    @JsonProperty("IncentiveValue") 
    public double incentiveValue;
    @JsonProperty("MinDiscount") 
    public double minDiscount;
    @JsonProperty("MaxDiscount") 
    public double maxDiscount;
    @JsonProperty("BrandDetails") 
    public BrandDetails brandDetails;

}


class Headers{
    @JsonProperty("Header1") 
    public String header1;
}
