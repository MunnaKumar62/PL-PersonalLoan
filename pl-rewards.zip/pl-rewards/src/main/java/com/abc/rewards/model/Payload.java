package com.abc.rewards.model;

import lombok.Data;

@Data
public class Payload {

	private String balance;
	
	private Float amount;
	
	private String currency;

	private Object currencyIdentifier;

	private Float rate;

	private Integer inTransit;

	private String totalAccrualTillDate;

	private Integer totalTransactionCountTillDate;

	private Integer totalExpired;

	private Integer totalRedeemed;

	private Object totalReversed;

	private Object upComingExpiry;

	private Object expiryDate;

	private TotalRedeemable totalRedeemable;

	private TotalFutureRedeemeable totalFutureRedeemeable;

	private TotalProvisionalPoints totalProvisionalPoints;

	public Boolean thresholdAcquired;

	public String uniqueCustomerID;

	public String totalAvailablePoints;

	public String kind;

	public Integer transferPoint;

}
