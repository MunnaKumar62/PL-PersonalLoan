package com.abc.rewards.constants;

public interface Constants {

	public static final String NONCE_PREFIX = "d9e3b0";
	public static final String SHA_256 = "SHA-256";
	public static final String HMAC_SHA256 = "hmacSHA256";
	public static final String UTF_8 = "UTF-8";
	public static final String METHOD_POST = "POST";
	public static final String METHOD_GET = "GET";
	public static int MAC_BIT_SIZE = 128;
	public static int NONCE_BIT_SIZE = 256;
	public static int KEY_BIT_SIZE = 256;

	public static final String ALL = "*";
	public static final String SLASH = "/";
	public static final String API = "/api";
	public static final String ONE_APP_ABC = "/oneappabc";
	public static final String ADITYA_BIRLA = "/adityabirla";
	public static final String PERSONAL_LOAN = "/personalloan";
	public static final String REWARDS = "/rewards";
	public static final String VERSION = Constants.SLASH + "${pl.url.version}";
	
	public static final String GET_ALL_CATEGORIES = "Get All Categories";
	public static final String GET_OFFER_BY_CATEGORIES = "Get Offer by Categories";
	public static final String GET_AVAILABLE_QUANTITIES_EXCEPTION = "Get Available Quantities Exception";
	public static final String GET_AVAILABLE_QUANTITIES = "Get Available Quantities";
	public static final String GET_MEMBER_OFFERS_EXCEPTION = "Get Member Offer Exception";
	public static final String GET_MEMBER_OFFERS = "Get Member Offer";
	public static final String GET_OFFERS_BY_CATEGORY = "Get Offer by Category";
	public static final String GET_ALL_CATEGORIES_EXCEPTION = "Get All Categories Exception";
	public static final String AVAIL_COUPON_EXCEPTION = "Avil Coupon Exception";
	public static final String AVAIL_COUPON = "Avil Coupon";
	public static final String GET_OFFERS = "Get Offers";
	public static final String GET_OFFER_EXCEPTION = "Get Offers Exception";
	public static final String GET_OFFERS_BY_CATEGORY_EXCEPTION = "Get Offers By Categories Exception";
	public static final String EXTERNAL_API_EXCEPTION = "Unable to connect with partner service. Please try again later.";
	public static final String SUCCESS = "SUCCESS";
	public static final String ERROR = "ERROR";
	public static final String LOCALE_MESSAGE_COUNTRYCODE = "IN";
	public static final String LOCALE_MESSAGE_ENGLISH = "en";
	public static final String ERROR_TYPE_BUSINESS = "Business Error";
	public static final String ERROR_TYPE_TECHNICAL = "Technical Error";
	public static final String REFERREL_DETAILS = "Referred Details";
	public static final String REFERREL_DETAILS_EXCEPTION = "Referred Details Exception";
	public static final String KINDWISE_BALANCE = "Kindwise Balance Details";
	public static final String KINDWISE_BALANCE_EXCEPTION = "Kindwise Balance Exception";
	public static final String USER_DETAILS = "User Details";
	public static final String USER_DETAILS_EXCEPTION = "User Details Exception";

}
