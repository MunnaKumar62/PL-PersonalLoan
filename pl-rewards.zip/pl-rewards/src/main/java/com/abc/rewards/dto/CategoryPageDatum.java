package com.abc.rewards.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CategoryPageDatum {

    @JsonProperty("Id") 
    public String id;
    @JsonProperty("Name") 
    public String name;
    @JsonProperty("SKU") 
    public String sKU;
    @JsonProperty("Code") 
    public String code;
    @JsonProperty("Description") 
    public String description;
    @JsonProperty("ParentCategoryId") 
    public Object parentCategoryId;
    @JsonProperty("ParentCategoryName") 
    public Object parentCategoryName;
    @JsonProperty("DisplayOrder") 
    public int displayOrder;
    @JsonProperty("MetaKeywords") 
    public Object metaKeywords;
    @JsonProperty("MetaDescription") 
    public Object metaDescription;
    @JsonProperty("MetaTitle") 
    public Object metaTitle;
    @JsonProperty("BannerUrl") 
    public Object bannerUrl;
    @JsonProperty("ProviderCode") 
    public String providerCode;
    @JsonProperty("Images") 
    public ArrayList<Image> images;
    @JsonProperty("Banners") 
    public ArrayList<Object> banners;
    @JsonProperty("SubCategories") 
    public ArrayList<Object> subCategories;
    @JsonProperty("Offers") 
    public Object offers;

}
