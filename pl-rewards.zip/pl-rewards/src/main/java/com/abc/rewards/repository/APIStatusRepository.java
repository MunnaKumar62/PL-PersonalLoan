package com.abc.rewards.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.abc.rewards.entity.ApiStatus;



public interface APIStatusRepository extends JpaRepository<ApiStatus, Integer>,JpaSpecificationExecutor<ApiStatus> {
	
	ApiStatus findByApiName(String apiName);
	
	ApiStatus findByApiNameAndCustomerIdAndAccountId(String apiName,int customerId,String accountId);

}
