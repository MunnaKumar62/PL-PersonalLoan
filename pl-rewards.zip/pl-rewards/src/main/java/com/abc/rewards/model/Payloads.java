package com.abc.rewards.model;

import lombok.Data;

@Data
public class Payloads {

	public Integer directReferralCount;

	public Integer inDirectReferralCount;

	public Double inDirectCashBackSum;

	public Double directCashBackSum;

	public Double direct1StTransactionCount;

	public Double indirect1StTransactionCount;

	public String DirectPotentialReferralCount;

	public String IndirectPotentialCashbackSum;

	public String IndirectPotentialReferralCount;

	public String DirectPotentialCashbackSum;
	

}
