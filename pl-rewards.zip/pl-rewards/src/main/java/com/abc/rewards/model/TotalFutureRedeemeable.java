package com.abc.rewards.model;

import lombok.Data;

@Data
public class TotalFutureRedeemeable {
	
    private Integer totalBankPoints;
	
	private Integer totalMerchantPoints;

}
