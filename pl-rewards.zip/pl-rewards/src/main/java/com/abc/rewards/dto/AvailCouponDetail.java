package com.abc.rewards.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AvailCouponDetail {
	
    @JsonProperty("Expiry") 
    public String expiry;
    @JsonProperty("CouponId") 
    public String couponId;
    @JsonProperty("CouponCode") 
    public String couponCode;
    @JsonProperty("RequestId") 
    public String requestId;
    @JsonProperty("AvailedDate") 
    public String availedDate;
    @JsonProperty("CustomerUniqueId") 
    public String customerUniqueId;

}
