package com.abc.rewards.exception;

import lombok.Data;

import java.util.List;

@Data
public class ErrorDetail {
    private Integer status;
    private String code;
    private String message;
    private List<ErrorItem> errors;
}
