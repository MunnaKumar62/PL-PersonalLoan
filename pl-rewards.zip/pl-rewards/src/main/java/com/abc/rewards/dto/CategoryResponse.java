package com.abc.rewards.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CategoryResponse {

	
    @JsonProperty("Code") 
    public int code;
    @JsonProperty("Message") 
    public String message;
    @JsonProperty("Success") 
    public boolean success;
    @JsonProperty("Data") 
    public Data data;
    @JsonProperty("FailureReasons") 
    public ArrayList<FailureReason> failureReasons;
}
