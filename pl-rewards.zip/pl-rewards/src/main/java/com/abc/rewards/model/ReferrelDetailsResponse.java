package com.abc.rewards.model;

import lombok.Data;

@Data
public class ReferrelDetailsResponse {
	
	private Integer responseCode;
	
	private String message;
	
	private Payloads payload;
	
	private Object errors;
}
