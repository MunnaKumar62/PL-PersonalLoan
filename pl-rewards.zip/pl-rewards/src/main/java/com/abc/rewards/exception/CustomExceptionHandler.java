package com.abc.rewards.exception;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.abc.rewards.constants.Constants;
import com.abc.rewards.constants.Message;
import com.abc.rewards.dto.ErrorResponseVO;
import com.abc.rewards.dto.Errors;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@ControllerAdvice
@Log4j2
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
	@Value("${spring.application.name}")
	private String sourceName;
	
	@Autowired
	private Message message;
	
	@Value("${api.service.code}")
	private String serviceCode;
	
	@Value("${external.errorcode.prefix}")
	private String externalErrorCodePrefix;

	@Value("${internal.errorcode.prefix}")
	private String internalErrorCodePrefix;

	@ExceptionHandler(Exception.class)
	protected ResponseEntity<Errors> handleOtpServiceException(Exception ex) {

		Errors errors = new Errors();
		List<ErrorResponseVO> errorList = new ArrayList<>();
		String errorMessage = ex.getMessage();
		getErrorList(HttpStatus.INTERNAL_SERVER_ERROR.value(), errorMessage, 1000, errorList);
		errors.setErrors(errorList);
		return new ResponseEntity<>(errors, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(CustomException.class)
	protected ResponseEntity<Errors> handleOtpServiceException(CustomException ex) {

		Errors errors = new Errors();
		List<ErrorResponseVO> errorList = new ArrayList<>();
		getErrorList(ex.getStatusCode(), ex.getMessage(), ex.getStatusCode(), errorList);
		errors.setErrors(errorList);
		return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}

	private void getErrorList(int statusCode, String message, int errorCode, List<ErrorResponseVO> errorList) {
		ErrorResponseVO res = new ErrorResponseVO();
		res.setStatus(statusCode);
		res.setMessage(message);
		res.setErrorCode(errorCode);
		res.setSource(sourceName);
		errorList.add(res);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		Errors errors = new Errors();
		List<ErrorResponseVO> errorList = new ArrayList<>();
		ex.getAllErrors().forEach(error -> {
			getErrorList(ex.getStatusCode().value(), error.getDefaultMessage(), 1099, errorList);
		});
		errors.setErrors(errorList);
		return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(HttpStatus.PARTIAL_CONTENT)
	@ExceptionHandler(ExternalException.class)
	public @ResponseBody ExceptionResponse handleExternalException(ExternalException ex) {
		System.err.println("message: " + message);
		String errorCode = serviceCode + "-" + externalErrorCodePrefix + "-" + ex.getErrorCode();
		String errorMessage = ex.getErrorMessage();
		String fullErrorMessage = errorCode + " : " + errorMessage;
		log.error("External Error : " + fullErrorMessage);
		return ExceptionResponse.builder().code(ex.getCode()).reason(ex.getReason()).errorCode(errorCode)
				.errorMessage(errorMessage).message(errorCode + ": " + errorMessage)
				.errorType(Constants.ERROR_TYPE_TECHNICAL).build();
	}

	@ResponseStatus(HttpStatus.PARTIAL_CONTENT)
	@ExceptionHandler(InternalException.class)
	public @ResponseBody ExceptionResponse handleInternalException(InternalException ex) {
		String errorCode = serviceCode + "-" + internalErrorCodePrefix + "-" + ex.getErrorCode();
		String errorMessage = message.getMessage(ex.getErrorCode());
		log.info(errorMessage);
		String errorType;
		String[] errorMessageParts = errorMessage.split("-");
		if (errorMessageParts.length > 1) {
			errorType = errorMessageParts[0].equalsIgnoreCase("BE") ? Constants.ERROR_TYPE_BUSINESS
					: Constants.ERROR_TYPE_TECHNICAL;
			errorMessage = errorMessageParts[1];
		} else {
			errorType = Constants.ERROR_TYPE_TECHNICAL;
		}
		log.info(errorMessageParts[0]);
		String fullErrorMessage = errorCode + " : " + errorMessage;
		log.error("Internal Error : " + fullErrorMessage);
		return ExceptionResponse.builder().code(ex.getCode()).reason(ex.getReason()).errorCode(errorCode)
				.errorMessage(errorMessage).message(fullErrorMessage).errorType(errorType).build();
	}
}
