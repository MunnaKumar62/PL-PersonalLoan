package com.abc.rewards.entity;
import java.util.Date;

import org.hibernate.annotations.CurrentTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Table(name="t_pl_apistatus")
public class ApiStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="apistatus_id")
    private Integer id;

    @Column(name="apiname")
    private String apiName;

    @Column(name="customerid")
    private int customerId;

    @Column(name="accountid")
    private String accountId;

    @Column(name="request_json")
    private String requestJson;

    @Column(name="response_json")
    private String responseJson;

    @Column(name="requestid")
    private String requestId;

    @Column(name="profileid")
    private String profileId;

    @Column(name="transactionid")
    private String transactionId;

    @Column(name="journey")
    private String journey;

    @Column(name="loanpurpose")
    private String loanPurpose;

    @Column(name="gcsreqjsonpath")
    private String gcsReqJsonPath;

    @Column(name="gcsrespjsonpath")
    private String gcsRespJsonPath;

    @Column(name="httpstatuscode")
    private int httpStatusCode;

    @Column(name="status")
    private String status;

    @Column(name="createddate")
    @CurrentTimestamp
    private Date createdDate;

    @Column(name="modifieddate")
    @UpdateTimestamp
    private Date modifiedDate;

    @Column(name="active")
    private String active;

    @Column(name="created_by")
    private String createdBy;

    @Column(name="created_date")
    @CurrentTimestamp
    private Date created_Date;

    @Column(name="modified_by")
    private String modifiedBy;

    @Column(name="modified_date")
    @UpdateTimestamp
    private Date modified_Date;

}
