package com.abc.rewards.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.abc.rewards.entity.RewardsCoupons;

public interface RewardsCouponsRepository extends JpaRepository<RewardsCoupons, Long>{

}
