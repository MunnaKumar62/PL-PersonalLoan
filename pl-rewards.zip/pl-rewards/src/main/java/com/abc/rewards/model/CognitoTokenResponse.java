package com.abc.rewards.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CognitoTokenResponse {
	
	  @JsonProperty("access_token")
	  private String accessToken;
	  
	  @JsonProperty("token_type")
	  private String tokenType;
	  
	  @JsonProperty("expires_in")
	  private String expiresIn;	

}
