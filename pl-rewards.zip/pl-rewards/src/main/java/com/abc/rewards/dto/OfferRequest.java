package com.abc.rewards.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OfferRequest {

	
    @JsonProperty("CustomerUniqueId") 
    public String customerUniqueId;
    @JsonProperty("OfferId") 
    public String offerId;
    @JsonProperty("RequestId") 
    public String requestId;
    @JsonProperty("Quantity") 
    public String quantity;
}
