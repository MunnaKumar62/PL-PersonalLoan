package com.abc.rewards.exception;

import lombok.Data;

@Data
public class ErrorItem
{
    private String field;
    private String message;

}
