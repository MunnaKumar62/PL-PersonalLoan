package com.abc.rewards.model;

import lombok.Data;

@Data
public class TotalProvisionalPoints {
	
    private Integer totalBankPoints;
	
	private Integer totalMerchantPoints;

}
