package com.abc.rewards;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESFastEngine;
import org.bouncycastle.crypto.modes.GCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.KeyParameter;


public class LoyaltyAPIs{

    private static int MAC_BIT_SIZE = 128;
    private static int NONCE_BIT_SIZE = 256;
    private static int KEY_BIT_SIZE = 256;

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private static String CLIENT_ID = "399";
	private static String CLIENT_KEY = "5c94984c-39d7-4aqe-a11b-414d1ffc4f52";
	private static String CLIENT_SECRET = "3975033525D44FB2AD39C7625C94D1A7";
	private static String CLIENT_ENCRYPTION_KEY = "77F0A1F95F964EBA9C2531A26E1D9DD1";

	private static final String TOKEN_URL ="https://authuat.loylty.com/token";
    private static final String BASE_URL ="https://uatofrb9.loylty.com/";
    private static final String NONCE_PREFIX = "d9e3b0";

    private static final String GET_ALL_CATEGORIES_API_ENDPOINT ="eliteoffers/Categories";
    private static final String GET_OFFERS_BY_CATEGORU_SKU_API_ENDPOINT ="eliteoffers/offers?request.pageIndex=1&request.pageSize=9&request.categorySKU=Wedding";
    private static final String GET_OFFERS_DETAILS_BY_SKU_API_ENDPOINT ="eliteoffers/offers/SKU/Jewellery";
    private static final String AVAIL_API_ENDPOINT ="Coupon/Avail";
    private static final String MEMBER_OFFERS_API_ENDPOINT ="EliteOffers/Customer/Offers";
    private static final String AVAILABLE_QUANTITY_API_ENDPOINT ="Coupon/AvailableQuantity";

    private static final String SHA_256 = "SHA-256";
    private static final String HMAC_SHA256 = "hmacSHA256";
    private static final String UTF_8 = "UTF-8";

    private static final String METHOD_POST = "POST";
    private static final String METHOD_GET = "GET";

    public static void main(String args[]){

        try {

//        	Request Token
 //      	requestToken();
        	
//        	Get All Catgeories API
    //    	getAllCategories();
        	
//        	Get offers by category SKU API
//        	getOffersByCategorySKU();
        	
//        	Get Offer Details by SKU API
//        	getOfferDetailsBYSKU();
            
//          calling avail coupon API
//       	availAPI();
            
//          calling MemberOffers API
//          memberOffers();
        	
//        	Available quantity
//        	availableQuantity();
        	
//        	Decrypt Response Body
        	byte[] key = CLIENT_ENCRYPTION_KEY.getBytes();
        	
//        	pass encrypted reponse body
        	String encryptedText = "JaTkUTTZZYbOhCju49D+Bmmt25Rqd0/g6b6gTc8tU0p1Nh14nCnl/VToSlc5tVIZT7/PMSddkOKCxcg5PfTfw0W6MPuOA/LrDnXJMJzHt5INQKI477IkJ4pvrkEN3kIg8SI2Ze9arQ==";
        	
        	decrypt(encryptedText, key);
            
            
        	//decryptOnly(encryptedText);

            System.out.println("Success Execution");

        } catch(Exception e) {
        	e.printStackTrace();
        }
    }
    
//    Token Generation API  
    public static void requestToken() throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException{
    	
    	String methodType = METHOD_POST;
        String reqURL = TOKEN_URL;
        String reqBody = "";
    	
      //generate timstamp and nonce
        Instant instant = Instant.now();
		long timeStampMillis = instant.toEpochMilli();
		String timestamp = Long.toString(timeStampMillis);
        String nonce = NONCE_PREFIX + timestamp;

       String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

        System.out.println("Sign Auth :"+signAuth );
    }
    
//	 Get All Categories API
    public static void getAllCategories() throws InvalidKeyException, NoSuchAlgorithmException, 		IllegalStateException, InvalidCipherTextException, IOException{

       String methodType = METHOD_GET;
       String reqURL = BASE_URL + GET_ALL_CATEGORIES_API_ENDPOINT;
       String reqBody = "";
       
       Instant instant = Instant.now();
     		long timeStampMillis = instant.toEpochMilli();
     		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

       String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

       System.out.println("Sign Auth :" + signAuth);
//
//       String encryptedRequestBody = encrypt(reqBody, CLIENT_ENCRYPTION_KEY.getBytes());
//       System.out.println("Encrypted Request Body :" + encryptedRequestBody);

   }
   
   
//	 Get Offer Details by SKU
   	public static void getOfferDetailsBYSKU() throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException{

     String methodType = METHOD_GET;
     String reqURL = BASE_URL + GET_OFFERS_DETAILS_BY_SKU_API_ENDPOINT;
     String reqBody = "";
     
     Instant instant = Instant.now();
   		long timeStampMillis = instant.toEpochMilli();
   		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

     String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

     System.out.println("Sign Auth :" + signAuth);

   	}
   	
//	 Get offers by category SKU
  	public static void getOffersByCategorySKU() throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException{

    String methodType = METHOD_GET;
    String reqURL = BASE_URL + GET_OFFERS_BY_CATEGORU_SKU_API_ENDPOINT;
    String reqBody = "";
    
    Instant instant = Instant.now();
  		long timeStampMillis = instant.toEpochMilli();
  		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

    String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

    System.out.println("Sign Auth :" + signAuth);

  	}
    
    
    
//	 Avail Coupon API
   	public static void availAPI() throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException{

        String methodType = METHOD_POST;
        String reqURL = BASE_URL + AVAIL_API_ENDPOINT;

        //getAvailRequestBody(String customerUniqueId, String offerId, String requestId)
        String reqBody = getAvailRequestBody("ABCD_1234", "091b950d-5c54-4a22-b657-5b0cff19f556", "ABCD_12345");
        
        Instant instant = Instant.now();
      		long timeStampMillis = instant.toEpochMilli();
      		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

        String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

        System.out.println("Sign Auth :" + signAuth);

        String encryptedRequestBody = encrypt(reqBody, CLIENT_ENCRYPTION_KEY.getBytes());
        System.out.println("Encrypted Request Body :" + encryptedRequestBody);

    }


    public static String getAvailRequestBody(String customerUniqueId, String offerId, String requestId){

        String requestBody = "{\"CustomerUniqueId\":\"" + customerUniqueId + "\"," + 
                            "\"OfferId\":\"" + offerId + "\"," + 
                            "\"RequestId\":\"" + requestId + "\"}";
        return requestBody;

    }
    
    
//    MEMBER OFFERS SIGN AUTH AND ENC REQ BODY     
    public static void memberOffers() throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException{

        String methodType = METHOD_POST;
        String reqURL = BASE_URL + MEMBER_OFFERS_API_ENDPOINT;

        //getAvailRequestBody(String customerUniqueId, String offerId, String requestId)
        String reqBody = getAvailRequestBody("9867639932", "10", "1");
        System.out.println("String RequestBody:   "+reqBody);

      //generate timstamp and nonce
        Instant instant = Instant.now();
		long timeStampMillis = instant.toEpochMilli();
		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

        String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

        System.out.println("Sign Auth :" + signAuth);

        String encryptedRequestBody = encrypt(reqBody, CLIENT_ENCRYPTION_KEY.getBytes());
        System.out.println("Encrypted Request Body :" + encryptedRequestBody);

    }
    
//  encode request body for Member Offer API  
    public static String getMemberOffersRequestBody(String customerUniqueId, String pageSize, String pageIndex){

        String requestBody = "{\"CustomerUniqueId\":\"" + customerUniqueId + "\"," + 
                            "\"PageSize\":\"" + pageSize + "\"," + 
                            "\"PageIndex\":\"" + pageIndex + "\"}";
        return requestBody;

    }
    
    
//	 Available Quantity
 	public static void availableQuantity() throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException{

   String methodType = METHOD_POST;
   String reqURL = BASE_URL + AVAILABLE_QUANTITY_API_ENDPOINT;
   String reqBody = "";
   
   Instant instant = Instant.now();
 		long timeStampMillis = instant.toEpochMilli();
 		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

   String signAuth = getSignAuth(CLIENT_ID, methodType, reqURL, reqBody, nonce, timestamp);

   System.out.println("Sign Auth :" + signAuth);
   
   String encryptedRequestBody = encrypt(reqBody, CLIENT_ENCRYPTION_KEY.getBytes());
   System.out.println("Encrypted Request Body :" + encryptedRequestBody);


 	}
    
    
//	sign auth generation
    public static String getSignAuth(String clientId, String method, String requestURL, String requestBody, String nonce, String timestamp) throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException{

        //encode the requestURL
    	System.out.println("Req URL:  "+requestURL);
        String encodedURL = URLEncoder.encode(requestURL, StandardCharsets.UTF_8.toString()).toLowerCase();

        //If requestBody is NOT empty, base64 encode
        String encodedHashedBody = "";
        if (!requestBody.isEmpty()) {
			encodedHashedBody = getEncodedHashedValue(requestBody);
		}

        //assemble raw HMAC Value as per the Loyalty documentation 
        String rawHMACValue = clientId + "|" + method + "|" + encodedURL + "|" + nonce + "|" + timestamp + "|" + encodedHashedBody;

        //get HMAC signature from the raw HMAC Value 
        String signature = getHMACSignature(rawHMACValue);

        //sign_auth = client_Key + ":" + signature + ":" + nounce + ":" + timeStampMillis;
        String signAuth = CLIENT_KEY + ":" +  signature + ":" + nonce + ":" + timestamp ;
        
        return signAuth;

    }

    public static String getEncodedHashedValue(String baseString) throws NoSuchAlgorithmException, UnsupportedEncodingException{

        String encodedHashedValue = "";

        MessageDigest digest = MessageDigest.getInstance(SHA_256);
        byte[] hash = digest.digest(baseString.getBytes(UTF_8)); /* recommended to use ASCII encoding here */
        encodedHashedValue = java.util.Base64.getEncoder().encodeToString(hash);
        
        return encodedHashedValue;

    }

    public static String getHMACSignature(String rawHMAC) throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException{
        //Generate HMAC-SHA256 & Encode using Base64
		Mac sha256 = Mac.getInstance(HMAC_SHA256);
		SecretKeySpec secretKey = new SecretKeySpec(CLIENT_SECRET.getBytes(UTF_8), HMAC_SHA256);
		sha256.init(secretKey);

		String signature = java.util.Base64.getEncoder().encodeToString(sha256.doFinal(rawHMAC.getBytes(UTF_8)));
        return signature;
		
    }

    public static String encrypt(String plaintext, byte[] key) throws IllegalStateException, InvalidCipherTextException, IOException {
		String encryptedString = null;
		
        byte[] iv = key;
        byte[] plainByte = plaintext.getBytes(UTF_8);

        GCMBlockCipher cipher = new GCMBlockCipher(new AESFastEngine());
        AEADParameters parameters = new AEADParameters(new KeyParameter(key), MAC_BIT_SIZE, iv, null);
        cipher.init(true, parameters);

        byte[] encryptedBytes = new byte[cipher.getOutputSize(plainByte.length)];

        int retlen = cipher.processBytes(plainByte, 0, plainByte.length, encryptedBytes, 0);
        cipher.doFinal(encryptedBytes, retlen);

        ByteArrayOutputStream str = new ByteArrayOutputStream();

        str.write(iv);
        str.write(encryptedBytes);

        encryptedString = java.util.Base64.getEncoder().encodeToString(str.toByteArray());
//        System.out.println("encrypted String : "+encryptedString);
        return encryptedString;


	}
	
	
	public static String decrypt(String encryptedText, byte[] key) {
		String decrString = "";
		try {
			byte[] encryptedBytes = java.util.Base64.getDecoder().decode(encryptedText);
			byte[] iv = Arrays.copyOfRange(encryptedBytes, 0, NONCE_BIT_SIZE / 8);
			
			GCMBlockCipher cipher = new GCMBlockCipher(new AESFastEngine());
			AEADParameters parameters = new AEADParameters(new KeyParameter(key), MAC_BIT_SIZE, iv, null);
			cipher.init(false, parameters);
			byte[] cipherText = Arrays.copyOfRange(encryptedBytes, NONCE_BIT_SIZE / 8, encryptedBytes.length); 

			byte[] plainByte = new byte[cipher.getOutputSize(cipherText.length)];

			int retlen = cipher.processBytes(cipherText, 0, cipherText.length, plainByte, 0);
			cipher.doFinal(plainByte, retlen);

			decrString = new String(plainByte, Charset.forName("UTF-8"));
			System.out.println("Decrypted Response : \n"+decrString);
			return decrString;

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return decrString;
	}
	
	public static void decryptOnly(String encryptedTxt) {
		byte[] encryptedBytes = Base64.getDecoder().decode(encryptedTxt);
		System.out.println("after decode ::");
	}

}