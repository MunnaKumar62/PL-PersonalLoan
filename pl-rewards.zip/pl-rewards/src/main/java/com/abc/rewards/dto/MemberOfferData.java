package com.abc.rewards.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MemberOfferData {

	 @JsonProperty("PageData") 
	    public ArrayList<MemberOfferPageDatum> pageData;
	    @JsonProperty("TotalRecords") 
	    public int totalRecords;
	    @JsonProperty("PreviousIndex") 
	    public Object previousIndex;
	    @JsonProperty("NextIndex") 
	    public Object nextIndex;
}
