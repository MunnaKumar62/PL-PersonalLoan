package com.abc.rewards.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "t_pl_rewards_coupon")
public class RewardsCoupons {

	private static final long serialVersionUID = -13671323230763931L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "reward_id")
	private long rewardId;

	@Column(name = "account_id")
	private String accountId;

	@Column(name = "loan_account_no")
	private String loanAccountNo;

	@Column(name = "request_id")
	private String requestId;

	@Column(name = "offer_id")
	private String offerId;

	@Column(name = "data_id")
	private String dataId;

	@Column(name = "data_name")
	private String dataName;

	@Column(name = "SKU")
	private String sku;

	@Column(name = "short_desc")
	private String shortDesc;

	@Column(name = "image_path")
	private String imagePath;

	@Column(name = "brand_id")
	private String brandId;

	@Column(name = "brand_name")
	private String brandName;

	@Column(name = "coupon_expiry")
	private String couponExpiry;

	@Column(name = "coupon_id")
	private String couponId;

	@Column(name = "coupon_code")
	private String couponCode;

	@Column(name = "availed_date")
	private String availedDate;

	@Column(name = "customer_unique_id")
	private String customerUniqueId;

	@Column(name = "start_date")
	private String startDate;

	@Column(name = "end_date")
	private String endDate;

}
