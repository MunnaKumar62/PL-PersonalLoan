package com.abc.rewards.controller;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.abc.rewards.constants.Constants;
import com.abc.rewards.dto.AvailCouponResponse;
import com.abc.rewards.dto.AvailableQuantityResponse;
import com.abc.rewards.dto.CategoryResponse;
import com.abc.rewards.dto.MemberOffersResponse;
import com.abc.rewards.dto.OfferDetailsResponse;
import com.abc.rewards.dto.OfferRequest;
import com.abc.rewards.dto.OfferResponse;
import com.abc.rewards.dto.RequestTokenOutput;
import com.abc.rewards.model.KindWiseBalanceResponse;
import com.abc.rewards.model.ReferrelDetailsResponse;
import com.abc.rewards.service.RewardsService;
import com.abc.rewards.service.TokenService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.RequiredArgsConstructor;

@RestController
@CrossOrigin(origins = Constants.ALL, allowedHeaders = Constants.ALL)
@RequestMapping(Constants.API + Constants.ONE_APP_ABC + Constants.ADITYA_BIRLA + Constants.API + Constants.VERSION
		+ Constants.PERSONAL_LOAN + Constants.REWARDS)
@RequiredArgsConstructor
public class CustomerController {

	@Autowired
	private final RewardsService rewardsService;

	@Autowired
	private final TokenService tokenService;
	
	@Value("${pl.rewards.client_key}")
	private String clientKey;
	
	@Value("${pl.rewards.client_encryption_key}")
	private String clientEncryptionKey;
	
	@Value("${pl.rewards.client_secret}")
	private String tokenClientSecret;
	
	private static final String NONCE_PREFIX = "d9e3b0";
	
	/**
	 * Retrieves a list of categories from the server based on the provided pagination parameters.
	 *
	 * @param pageIndex The index of the page to retrieve (starting from 0).
	 * @param pageSize  The size of each page (number of categories per page).
	 * @return A {@link CategoryResponse} object containing the retrieved categories.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
	@GetMapping("/categories")
	public CategoryResponse getAllCategories(@RequestParam int pageIndex, @RequestParam int pageSize) throws Exception {
		return rewardsService.getAllCategories(pageIndex,pageSize);
	}

	/**
	 * Retrieves offers belonging to a specific category from the server based on the provided pagination parameters.
	 *
	 * @param pageIndex The index of the page to retrieve (starting from 0).
	 * @param pageSize  The size of each page (number of offers per page).
	 * @param category  The SKU (Stock Keeping Unit) of the category for which offers are retrieved.
	 * @return An {@link OfferResponse} object containing the retrieved offers.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
	@GetMapping("/offers")
	public OfferResponse getOffersByCategory(@RequestParam int pageIndex, @RequestParam int pageSize, @RequestParam String category) throws Exception {
		return rewardsService.getOffersByCategory(pageIndex,pageSize,category);
	}

	/**
	 * Retrieves offer details for a specific category from the server.
	 *
	 * @param category The category identifier for which offer details are retrieved.
	 * @return An {@link OfferDetailsResponse} object containing the details of offers for the specified category.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
	@GetMapping("/offerdetails/{category}")
	public OfferDetailsResponse getOfferDetailsByCategory(@PathVariable String category) throws Exception {
		return rewardsService.getOfferDetailsByCategory(category);
	}
	
	/**
	 * Retrieves member-specific offers from the server based on the provided pagination parameters and request details.
	 *
	 * @param pageIndex The index of the page to retrieve (starting from 0).
	 * @param pageSize  The size of each page (number of offers per page).
	 * @param request   An {@link OfferRequest} object containing details necessary for fetching member offers.
	 * @return A {@link MemberOffersResponse} object containing member-specific offers.
	 * @throws Exception If there's an issue with the HTTP request or response, or if the input request is empty.
	 */
	@PostMapping("/memberoffers")
	public MemberOffersResponse getMemberOffers(@RequestParam int pageIndex, @RequestParam int pageSize, @RequestBody OfferRequest request) throws Exception {
		return rewardsService.getMemberOffers(pageIndex, pageSize, request);
	}
	
	/**
	 * Attempts to avail a coupon for a specific offer request.
	 *
	 * @param request An {@link OfferRequest} object containing details necessary to avail the coupon.
	 * @return An {@link AvailCouponResponse} object containing the response from availing the coupon.
	 * @throws Exception If there's an issue with the HTTP request or response, or if the input request is empty.
	 */
	@PostMapping("/availcoupon")
	public AvailCouponResponse availCoupon(@RequestBody OfferRequest request) throws Exception {
		return rewardsService.availCoupon(request);
	}
	
	/**
	 * Retrieves available quantity information based on the provided parameters and request details.
	 *
	 * @param pageIndex The index of the page to retrieve (starting from 0), used if {@code request} is null.
	 * @param pageSize  The size of each page (number of items per page), used if {@code request} is null.
	 * @param request   An {@link OfferRequest} object containing details necessary for fetching available quantities.
	 *                  If {@code null}, default query parameters are used to retrieve general quantity information.
	 * @return An {@link AvailableQuantityResponse} object containing available quantity information.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
		@PostMapping("/availableQuantity")
	public AvailableQuantityResponse getAvailableQuantity(@RequestParam int pageIndex, @RequestParam int pageSize, @RequestBody OfferRequest request) throws Exception {
		return rewardsService.getAvailableQuantity(pageIndex, pageSize, request);
	}
	/**
	 * Retrieves a request token using the provided parameters and authentication headers.
	 * The client key used for authentication.
	 * clientEncryptionKey The client encryption key used for decrypting the response.
	 * TokenClientSecret The client secret used for signing the request.
	 * 
	 * @return A {@link RequestTokenOutput} object containing the retrieved request token and related data.
	 */
	@GetMapping("/requestToken")
	public RequestTokenOutput getRequestToken() throws JsonMappingException, InvalidKeyException,
			JsonProcessingException, UnsupportedEncodingException, NoSuchAlgorithmException {
		return tokenService.getRequestToken(clientKey, clientEncryptionKey,tokenClientSecret, NONCE_PREFIX );
	}
	
	/**
	 * Retrieves user details from the server based on the provided customer ID.
	 *
	 * @param custId The customer ID for whom the details are requested.
	 * @return An {@link Object} containing the retrieved user details.
	 * @throws Exception If there's an issue with the HTTP request or response.
	 */
	@PostMapping("/userdetails/{custId}")
	public Object getUserDetails(@PathVariable String custId) throws Exception {
		return rewardsService.getUserDetails(custId);
	}

	/**
	 * Retrieves the KindWiseBalanceResponse from the server based on the providedaccount ID.
	 * @param accountid The account ID for which the KindWiseBalanceResponse is requested.
	 * @return A {@link KindWiseBalanceResponse} object containing the retrieved balance details.
	 * @throws Exception If there's an issue with the HTTP request or response, or during decryption.
	 */
	@GetMapping("/kindwisebalance/{accountid}")
	public KindWiseBalanceResponse  kindwisebalance(@PathVariable String accountid)throws Exception  {
		return rewardsService.kindwisebalance(accountid);
	}
	
	/**
	 * Retrieves referral details from the server based on the provided account ID.
	 *
	 * @param accountid The account ID for which referral details are requested.
	 * @return A {@link ReferrelDetailsResponse} object containing the retrieved referral details.
	 * @throws Exception If there's an issue with the HTTP request or response, or during decryption.
	 */
	@GetMapping("/getreferraldetails/{accountid}")
	public ReferrelDetailsResponse  referrelDetails(@PathVariable String accountid)throws Exception {
		return rewardsService.referrelDetails(accountid);
	}
}
