package com.abc.rewards.model;

import lombok.Data;

@Data
public class TotalRedeemable {
	
	private Integer totalBankPoints;
	
	private Integer totalMerchantPoints;

}
