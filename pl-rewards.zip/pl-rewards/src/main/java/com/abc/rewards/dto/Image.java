package com.abc.rewards.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Image {

    @JsonProperty("Id") 
    public String id;
    @JsonProperty("Path") 
    public String path;
    @JsonProperty("Width") 
    public int width;
    @JsonProperty("Height") 
    public int height;
    @JsonProperty("Alt") 
    public String alt;
    @JsonProperty("DisplayOrder") 
    public int displayOrder;
    @JsonProperty("ImageType") 
    public String imageType;

}
