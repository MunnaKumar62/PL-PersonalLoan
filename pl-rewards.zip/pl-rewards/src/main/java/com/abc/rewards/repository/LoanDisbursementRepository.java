package com.abc.rewards.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.abc.rewards.entity.LoanDisbursementDetails;



public interface LoanDisbursementRepository extends JpaRepository<LoanDisbursementDetails, Long>{

	@Query(value = "SELECT * FROM t_pl_loan_offer_details WHERE loan_no = :loanNo ORDER BY loan_offer_id DESC LIMIT 1",nativeQuery = true)
	public Optional<LoanDisbursementDetails> getLoanDisbursementDetailsByUniqueId(@Param("loanNo") String loanNo);

	
}
