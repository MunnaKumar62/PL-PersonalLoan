package com.abc.rewards.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Coupondetails {
	
	@JsonProperty("Expiry") 
    public String expiry;
    @JsonProperty("CouponCode") 
    public String couponCode;
    @JsonProperty("CustomerUniqueId") 
    public String customerUniqueId;
    @JsonProperty("CouponId") 
    public String couponId;
    @JsonProperty("RequestId") 
    public String requestId;
    @JsonProperty("AvailedDate") 
    public Date availedDate;

}
