package com.abc.rewards.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AvailCouponDatum {

	    @JsonProperty("Id") 
	    public String id;
	    @JsonProperty("Name") 
	    public String name;
	    @JsonProperty("SKU") 
	    public String sKU;
	    @JsonProperty("Type") 
	    public String type;
	    @JsonProperty("ShortDescription") 
	    public String shortDescription;
	    @JsonProperty("DiscountType") 
	    public String discountType;
	    @JsonProperty("Discount") 
	    public int discount;
	    @JsonProperty("StartDate") 
	    public String startDate;
	    @JsonProperty("EndDate") 
	    public String endDate;
	    @JsonProperty("DisplayStartDate") 
	    public String displayStartDate;
	    @JsonProperty("DisplayEndDate") 
	    public String displayEndDate;
	    @JsonProperty("BrandDetails") 
	    public BrandDetails brandDetails;
	    @JsonProperty("DisplayOrder") 
	    public int displayOrder;
	    @JsonProperty("Images") 
	    public ArrayList<Image> images;
	    @JsonProperty("IsSellable") 
	    public boolean isSellable;
	    @JsonProperty("MRP") 
	    public Object mRP;
	    @JsonProperty("NetPrice") 
	    public Object netPrice;
	    @JsonProperty("RetailPrice") 
	    public double retailPrice;
	    @JsonProperty("RetailShippingPrice") 
	    public double retailShippingPrice;
	    @JsonProperty("RetailPriceInclusive") 
	    public double retailPriceInclusive;
	    @JsonProperty("IsOnline") 
	    public boolean isOnline;
	    @JsonProperty("IsCoupon") 
	    public boolean isCoupon;
	    @JsonProperty("OnlineUrl") 
	    public String onlineUrl;
	    @JsonProperty("coupondetails") 
	    public AvailCouponDetail couponDetails;
	    @JsonProperty("ProgramId") 
	    public Object programId;
}
