package com.abc.rewards.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Optional;

import org.bouncycastle.crypto.InvalidCipherTextException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import com.abc.rewards.constants.CommonUtills;
import com.abc.rewards.constants.Constants;
import com.abc.rewards.dto.AvailCouponResponse;
import com.abc.rewards.dto.AvailableQuantityResponse;
import com.abc.rewards.dto.CategoryResponse;
import com.abc.rewards.dto.FailureReason;
import com.abc.rewards.dto.Image;
import com.abc.rewards.dto.MemberOffersResponse;
import com.abc.rewards.dto.OfferDetailsResponse;
import com.abc.rewards.dto.OfferRequest;
import com.abc.rewards.dto.OfferResponse;
import com.abc.rewards.dto.RequestTokenData;
import com.abc.rewards.dto.RequestTokenOutput;
import com.abc.rewards.entity.ApiStatus;
import com.abc.rewards.entity.LoanDisbursementDetails;
import com.abc.rewards.entity.RewardsCoupons;
import com.abc.rewards.exception.CustomException;
import com.abc.rewards.exception.InternalException;
import com.abc.rewards.model.KindWiseBalanceResponse;
import com.abc.rewards.model.ReferrelDetailsResponse;
import com.abc.rewards.repository.APIStatusRepository;
import com.abc.rewards.repository.LoanDisbursementRepository;
import com.abc.rewards.repository.RewardsCouponsRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class RewardsService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private RewardsCouponsRepository rewardsCouponsRepository;

	@Autowired
	private APIStatusRepository apiStatusRepository;

	@Value("${pl.rewards.categories.url}")
	private String getCategoriesUrl;

	@Value("${pl.rewards.categories.signauth.url}")
	private String categorySignAuthUrl;

	@Value("${pl.rewards.offers.url}")
	private String getOffersUrl;

	@Value("${pl.rewards.offers.signauth.url}")
	private String offerSignAuthUrl;

	@Value("${pl.rewards.offerdetails.url}")
	private String getOfferDetailsUrl;

	@Value("${pl.rewards.offerdetails.signauth.url}")
	private String offerDetailsSignAuthUrl;

	@Value("${pl.rewards.memberoffers.url}")
	private String memberOffersUrl;

	@Value("${pl.rewards.memberoffers.signauth.url}")
	private String memberOffersSignAuthUrl;

	@Value("${pl.rewards.availablequantity.url}")
	private String availableQuantityUrl;

	@Value("${pl.rewards.availablequantity.signauth.url}")
	private String availableQuantitySignAuthUrl;

	@Value("${pl.rewards.availcoupon.url}")
	private String availCouponUrl;

	@Value("${pl.rewards.availcoupon.signauth.url}")
	private String availCouponSignAuthUrl;
	
	@Value("${pl.rewards.client_key}")
	private String clientKey;
	
	@Value("${pl.rewards.userdetails.signauth.url}")
	private String userdetailsSignauthUrl;
	
	@Value("${pl.rewards.userdetails.url}")
	private String userDetailsUrl;

	@Value("${pl.rewards.categories.userip}")
	private String userIp;

	@Value("${pl.rewards.client_id}")
	private String clientId;
	
	@Value("${pl.rewards.userclientid}")
	private String userClientId;
	
	@Value("${pl.rewards.userclientkey}")
	private String userClientKey;
	
	@Value("${pl.rewards.userclientencryptionkey}")
	private String userClientEncryptionKey;

	@Value("${pl.rewards.client_encryption_key}")
	private String clientEncryptionKey;
	
	@Value("${pl.rewards.client_secret}")
	private String tokenClientSecret;
	
	@Value("${pl.rewards.usertokenclientsecret}")
	private String userTokenClientSecret;
	
	@Value("${pl.rewards.usernonceprefix}")
	private String usernoncePrefix;
	
	@Value("${pl.rewards.kindwisebalance.url}")
	private String kindwisebalanceurl;
	
	@Value("${pl.rewards.kindwisebalanceiv.url}")
	private String kindwisebalanceiv;
	
	@Value("${pl.rewards.kindwisebalancekey.url}")
	private String kindwisebalancekey;
	
	@Value("${pl.rewards.referraldetails.url}")
	private String referrelDetailsurl;

	private static final String NONCE_PREFIX = "d9e3b0";
	
	private static final String METHOD_GET = "GET";

	private static final String METHOD_POST = "POST";

	@Autowired
	LoanDisbursementRepository loanDisbursementRepository;
	
	@Autowired
	CommonUtills commonUtil;

	/**
	 * 
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 * @throws Exception 
	 */
	public CategoryResponse getAllCategories(int pageIndex, int pageSize) throws Exception {
		CategoryResponse response = new CategoryResponse();
		ArrayList<FailureReason> list = new ArrayList<>();
		HttpEntity request = null;
		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(getCategoriesUrl)
					.queryParam("request.pageIndex", pageIndex).queryParam("request.pageSize", pageSize).build();

			HttpHeaders headers = getHttpHeaders(METHOD_GET, clientId, categorySignAuthUrl, "");

		    request = new HttpEntity(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					request, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), clientEncryptionKey.getBytes());
			System.out.println("decrypted ::" + decrypted);
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, CategoryResponse.class);

			saveRequest(request, response, "GET_CATEGORIES", "", "", "SUCCESS");

		} catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			saveRequest(request, response, "GET_CATEGORIES", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.GET_ALL_CATEGORIES);
		}
		catch (HttpServerErrorException ex) {
			log.error(Constants.GET_ALL_CATEGORIES_EXCEPTION);
			saveRequest(request, response, "GET_CATEGORIES", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.GET_ALL_CATEGORIES);
		}catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeyException e) {
			FailureReason obj = getFailureReasonObj(500, "Sign Auth Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
		} catch (JsonProcessingException e) {
			FailureReason obj = getFailureReasonObj(500, "Token Generation Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
		} catch (Exception e) {
			if (e.getMessage().contains(":")) {
				int i1 = e.getMessage().indexOf("\"");
				int i2 = e.getMessage().lastIndexOf("\"");

				String msg = e.getMessage().substring(i1 + 1, i2);
				String errorResponse = TokenService.decrypt(msg, clientEncryptionKey.getBytes());
				ObjectMapper mapper = new ObjectMapper();
				try {
					response = mapper.readValue(errorResponse, CategoryResponse.class);
				} catch (JsonMappingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				} catch (JsonProcessingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				}
			} else {
				FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
				list.add(obj);
				response.setCode(500);
			}
		}
		response.setFailureReasons(list);
		return response;
	}

	public FailureReason getFailureReasonObj(int code, String error, String msg) {
		FailureReason failure = new FailureReason();
		failure.setCode(500);
		failure.setError(error);
		failure.setMessage(msg);
		return failure;
	}

	/**
	 * 
	 * @param methodType
	 * @param clientId
	 * @param url
	 * @param reqBody
	 * @return
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws IOException 
	 * @throws InvalidCipherTextException 
	 * @throws IllegalStateException 
	 */
	public HttpHeaders getHttpHeaders(String methodType, String clientId, String url, String reqBody)
			throws InvalidKeyException, NoSuchAlgorithmException, IllegalStateException, InvalidCipherTextException, IOException {

		Instant instant = Instant.now();
		long timeStampMillis = instant.toEpochMilli();
		String timestamp = Long.toString(timeStampMillis);
		String nonce = NONCE_PREFIX + timestamp;

		String signAuth = tokenService.getSignAuth(clientId, methodType, url, reqBody, nonce, timestamp,clientKey, tokenClientSecret);

		HttpHeaders headers = new HttpHeaders();
		RequestTokenOutput requestTokenOutput = tokenService.getRequestToken(clientKey, clientEncryptionKey,tokenClientSecret, NONCE_PREFIX);
		RequestTokenData requestTokenData = requestTokenOutput.getData();
		if (requestTokenData.getAccess_token() != null) {
			String auth = "Bearer " + requestTokenData.getAccess_token();
			String token = requestTokenData.getAuthToken();
			headers.add("Authorization", auth);
			headers.add("auth-token", token);
			log.info("[RewardsService][getHttpHeaders]Authorization: "+auth);
			log.info("[RewardsService][getHttpHeaders]auth-token: "+token);
		}

		headers.add("UserIp", userIp);
		headers.add("client_id", clientId);
		headers.add("sign_auth", signAuth);
		
		log.info("[RewardsService][getHttpHeaders]UserIp: "+ userIp);
		log.info("[RewardsService][getHttpHeaders]client_id: "+ clientId);
		log.info("[RewardsService][getHttpHeaders]sign_auth: "+ signAuth);
		
		return headers;
	}

	public OfferResponse getOffersByCategory(int pageIndex, int pageSize, String category) throws Exception {
		OfferResponse response = new OfferResponse();
		HttpEntity request=null;
		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(getOffersUrl)
					.queryParam("request.pageIndex", pageIndex).queryParam("request.pageSize", pageSize)
					.queryParam("request.categorySKU", category).build();

			UriComponents signAuthBuilder = UriComponentsBuilder.fromHttpUrl(offerSignAuthUrl)
					.queryParam("request.pageIndex", pageIndex).queryParam("request.pageSize", pageSize)
					.queryParam("request.categorySKU", category).build();

			HttpHeaders headers = getHttpHeaders(METHOD_GET, clientId, signAuthBuilder.toUriString(), "");

			request = new HttpEntity(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					request, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), clientEncryptionKey.getBytes());
			System.out.println("Decrypted ::" + decrypted);
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, OfferResponse.class);

			saveRequest(request, response, "GET_OFFERS", "", "", "SUCCESS");

		} 
		catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			saveRequest(request, response, "GET_OFFERS", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.GET_OFFERS);
		} catch (HttpServerErrorException ex) {
			log.error(Constants.GET_OFFER_EXCEPTION);
			saveRequest(request, response, "GET_OFFERS", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.GET_OFFERS);
		} catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeyException e) {
			FailureReason obj = getFailureReasonObj(500, "Sign Auth Failure", e.getMessage());
			response.setCode(500);
			response.setFailureReasons(obj);
		} catch (JsonProcessingException e) {
			FailureReason obj = getFailureReasonObj(500, "Token Generation Failure", e.getMessage());
			response.setCode(500);
			response.setFailureReasons(obj);
		} catch (Exception e) {
			if (e.getMessage().contains(":")) {
				int i1 = e.getMessage().indexOf("\"");
				int i2 = e.getMessage().lastIndexOf("\"");

				String msg = e.getMessage().substring(i1 + 1, i2);
				String errorResponse = TokenService.decrypt(msg, clientEncryptionKey.getBytes());
				ObjectMapper mapper = new ObjectMapper();
				try {
					response = mapper.readValue(errorResponse, OfferResponse.class);
				} catch (JsonMappingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					response.setCode(500);
					response.setFailureReasons(obj);
				} catch (JsonProcessingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					response.setCode(500);
					response.setFailureReasons(obj);
				}
			} else {
				FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
				response.setCode(500);
				response.setFailureReasons(obj);
			}
		}
		return response;
	}

	/**
	 * 
	 * @param category
	 * @return
	 * @throws Exception 
	 */
	public OfferDetailsResponse getOfferDetailsByCategory(String category) throws Exception {
		OfferDetailsResponse response = new OfferDetailsResponse();
		ArrayList<FailureReason> list = new ArrayList<>();
		HttpEntity request=null;
		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(getOfferDetailsUrl).path(category).build();

			UriComponents signAuthBuilder = UriComponentsBuilder.fromHttpUrl(offerDetailsSignAuthUrl).path(category)
					.build();

			HttpHeaders headers = getHttpHeaders(METHOD_GET, clientId, signAuthBuilder.toUriString(), "");

			request = new HttpEntity(headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					request, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), clientEncryptionKey.getBytes());
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, OfferDetailsResponse.class);

			saveRequest(request, response, "GET_OFFERS_BY_CATEGORY", "", "", "SUCCESS");

		}  catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			saveRequest(request, response, "GET_OFFERS_BY_CATEGORY", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.GET_OFFERS_BY_CATEGORY);
		}
		catch (HttpServerErrorException ex) {
			log.error(Constants.GET_OFFERS_BY_CATEGORY_EXCEPTION);
			saveRequest(request, response, "GET_OFFERS_BY_CATEGORY", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.GET_OFFERS_BY_CATEGORY);
		} catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeyException e) {
			FailureReason obj = getFailureReasonObj(500, "Sign Auth Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
		} catch (JsonProcessingException e) {
			FailureReason obj = getFailureReasonObj(500, "Token Generation Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
		} catch (Exception e) {
			if (e.getMessage().contains(":")) {
				int i1 = e.getMessage().indexOf("\"");
				int i2 = e.getMessage().lastIndexOf("\"");

				String msg = e.getMessage().substring(i1 + 1, i2);
				String errorResponse = TokenService.decrypt(msg, clientEncryptionKey.getBytes());
				ObjectMapper mapper = new ObjectMapper();
				try {
					response = mapper.readValue(errorResponse, OfferDetailsResponse.class);
				} catch (JsonMappingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				} catch (JsonProcessingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				}
			} else {
				FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
				list.add(obj);
				response.setCode(500);
			}
		}
		return response;
	}

	/**
	 * 
	 * @param customerUniqueId
	 * @param offerId
	 * @param requestId
	 * @return
	 */
	public static String getAvailRequestBody(String customerUniqueId, String offerId, String requestId) {

		String requestBody = "{\"CustomerUniqueId\":\"" + customerUniqueId + "\"," + "\"OfferId\":\"" + offerId + "\","
				+ "\"RequestId\":\"" + requestId + "\"}";
		System.out.println("Request Body ::" + requestBody);
		return requestBody;

	}

	/**
	 * 
	 * @param pageIndex
	 * @param pageSize
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	public MemberOffersResponse getMemberOffers(int pageIndex, int pageSize, OfferRequest request) throws Exception {
		MemberOffersResponse response = new MemberOffersResponse();
		ArrayList<FailureReason> list = new ArrayList<>();
		try {
			if (request == null) {
				throw new Exception("Input is Empty!");
			}
			String requestBody = getAvailRequestBody("", "", "");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(memberOffersUrl)
					.queryParam("request.pageIndex", pageIndex).queryParam("request.pageSize", pageSize).build();
			requestBody = getAvailRequestBody(request.getCustomerUniqueId(), request.getOfferId(),
					request.getRequestId());

			HttpHeaders headers = getHttpHeaders(METHOD_POST, clientId, memberOffersSignAuthUrl, requestBody);

			String encryptedRequestBody = tokenService.encrypt(requestBody, clientEncryptionKey.getBytes());

			HttpEntity httpRequest = new HttpEntity(encryptedRequestBody, headers);

			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					httpRequest, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), clientEncryptionKey.getBytes());
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, MemberOffersResponse.class);

			saveRequest(request, response, "GET_MEMBER_OFFERS", "", "", "SUCCESS");

		}  catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			saveRequest(request, response, "GET_MEMBER_OFFERS", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.GET_MEMBER_OFFERS);
		}
		catch (HttpServerErrorException ex) {
			log.error(Constants.GET_MEMBER_OFFERS_EXCEPTION);
			saveRequest(request, response, "GET_MEMBER_OFFERS", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.GET_MEMBER_OFFERS);
		} catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeyException e) {
			FailureReason obj = getFailureReasonObj(500, "Sign Auth Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
			saveRequest(request, response, "GET_MEMBER_OFFERS", "", "", Constants.ERROR);
		} catch (JsonProcessingException e) {
			FailureReason obj = getFailureReasonObj(500, "Token Generation Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
			saveRequest(request, response, "GET_MEMBER_OFFERS", "", "", Constants.ERROR);
		} catch (Exception e) {
			if (e.getMessage().contains(":")) {
				int i1 = e.getMessage().indexOf("\"");
				int i2 = e.getMessage().lastIndexOf("\"");

				String msg = e.getMessage().substring(i1 + 1, i2);
				String errorResponse = TokenService.decrypt(msg, clientEncryptionKey.getBytes());
				ObjectMapper mapper = new ObjectMapper();
				try {
					response = mapper.readValue(errorResponse, MemberOffersResponse.class);
				} catch (JsonMappingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				} catch (JsonProcessingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				}
			} else {
				FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
				list.add(obj);
				response.setCode(500);
			}
			saveRequest(request, response, "GET_MEMBER_OFFERS", "", "", Constants.ERROR);
		}
		response.setFailureReasons(list);
		return response;
	}

	/**
	 * 
	 * @param pageIndex
	 * @param pageSize
	 * @param request
	 * @return
	 * @throws Exception 
	 */
	public AvailableQuantityResponse getAvailableQuantity(int pageIndex, int pageSize, OfferRequest request) throws Exception {
		AvailableQuantityResponse response = new AvailableQuantityResponse();
		ArrayList<FailureReason> list = new ArrayList<>();
		try {
			String requestBody = getAvailRequestBody("", "", "");
			UriComponents builder = null;
			if (request != null) {
				builder = UriComponentsBuilder.fromHttpUrl(availableQuantityUrl).build();

				requestBody = getAvailRequestBody(request.getCustomerUniqueId(), request.getOfferId(),
						request.getRequestId());

			} else {
				builder = UriComponentsBuilder.fromHttpUrl(memberOffersUrl).queryParam("request.pageIndex", pageIndex)
						.queryParam("request.pageSize", pageSize).build();
			}

			HttpHeaders headers = getHttpHeaders(METHOD_POST, clientId, availableQuantitySignAuthUrl, requestBody);

			String encryptedRequestBody = tokenService.encrypt(requestBody, clientEncryptionKey.getBytes());

			HttpEntity httpRequest = new HttpEntity(encryptedRequestBody, headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					httpRequest, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), clientEncryptionKey.getBytes());
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, AvailableQuantityResponse.class);

			saveRequest(request, response, "GET_AVAILABLE_QUANTITIES", "", "", "SUCCESS");

		} catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			saveRequest(request, response, "GET_AVAILABLE_QUANTITIES", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.GET_AVAILABLE_QUANTITIES);
		} catch (HttpServerErrorException ex) {
			log.error(Constants.GET_AVAILABLE_QUANTITIES_EXCEPTION);
			saveRequest(request, response, "GET_AVAILABLE_QUANTITIES", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.GET_AVAILABLE_QUANTITIES);
		} catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeyException e) {
			FailureReason obj = getFailureReasonObj(500, "Sign Auth Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
			saveRequest(request, response, "GET_AVAILABLE_QUANTITIES", "", "", Constants.ERROR);
		} catch (JsonProcessingException e) {
			FailureReason obj = getFailureReasonObj(500, "Token Generation Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
			saveRequest(request, response, "GET_AVAILABLE_QUANTITIES", "", "", Constants.ERROR);
		} catch (Exception e) {
			if (e.getMessage().contains(":")) {
				int i1 = e.getMessage().indexOf("\"");
				int i2 = e.getMessage().lastIndexOf("\"");

				String msg = e.getMessage().substring(i1 + 1, i2);
				String errorResponse = TokenService.decrypt(msg, clientEncryptionKey.getBytes());
				ObjectMapper mapper = new ObjectMapper();
				try {
					response = mapper.readValue(errorResponse, AvailableQuantityResponse.class);
				} catch (JsonMappingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				} catch (JsonProcessingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				}
			} else {
				FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
				list.add(obj);
				response.setCode(500);
			}
			saveRequest(request, response, "GET_AVAILABLE_QUANTITIES", "", "", Constants.ERROR);
		}
		response.setFailureReasons(list);
		return response;
	}

	public AvailCouponResponse availCoupon(OfferRequest request)throws Exception {
		AvailCouponResponse response = new AvailCouponResponse();

		ArrayList<FailureReason> list = new ArrayList<>();
		try {
			if (request == null) {
				throw new Exception("Input is Empty!");
			}
			String requestBody = getAvailRequestBody("", "", "");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(availCouponUrl).build();
			requestBody = getAvailRequestBody(request.getCustomerUniqueId(), request.getOfferId(),
					request.getRequestId());

			HttpHeaders headers = getHttpHeaders(METHOD_POST, clientId, availCouponSignAuthUrl, requestBody);

			String encryptedRequestBody = tokenService.encrypt(requestBody, clientEncryptionKey.getBytes());

			HttpEntity httpRequest = new HttpEntity(encryptedRequestBody, headers);

			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					httpRequest, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), clientEncryptionKey.getBytes());
			log.info("[availCoupon]decrypted Response: " + decrypted);

			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, AvailCouponResponse.class);
			response.getData().brandDetails.getId();

			//save rewards avail coupons
			if (null != response && null != response.getData()) {
				RewardsCoupons rewardsCoupons = new RewardsCoupons();
				rewardsCoupons.setBrandId(response.getData().brandDetails.id);
				rewardsCoupons.setBrandName(response.getData().brandDetails.name);
				rewardsCoupons.setCouponCode(response.getData().getCouponDetails().getCouponCode());
				rewardsCoupons.setCouponId(response.getData().getCouponDetails().getCouponId());
				rewardsCoupons.setCouponExpiry(response.getData().getCouponDetails().getExpiry());
				rewardsCoupons.setCustomerUniqueId(request.getCustomerUniqueId());
				rewardsCoupons.setAvailedDate(response.getData().getCouponDetails().getAvailedDate());
				rewardsCoupons.setDataId(response.getData().getId());
				rewardsCoupons.setDataName(response.getData().getName());
				rewardsCoupons.setEndDate(response.getData().getEndDate());
				for (Image rewardsCoupon : response.getData().getImages()) {
					rewardsCoupons.setImagePath(rewardsCoupon.getPath());
				}
				rewardsCoupons.setLoanAccountNo(request.getCustomerUniqueId());
				rewardsCoupons.setStartDate(response.getData().getStartDate());
				rewardsCoupons.setSku(response.getData().getSKU());
				rewardsCoupons.setShortDesc(response.getData().getShortDescription());
				rewardsCoupons.setRequestId(request.getRequestId());
				rewardsCoupons.setOfferId(request.getOfferId());
				rewardsCouponsRepository.save(rewardsCoupons);
			}
			saveRequest(request, response, "AVAIL_COUPON", "", "", "SUCCESS");

			if (response.isSuccess()) {

				Optional<LoanDisbursementDetails> loanDisbursementDetails = loanDisbursementRepository
						.getLoanDisbursementDetailsByUniqueId(request.getCustomerUniqueId());
				if(loanDisbursementDetails.isPresent()) {
					LoanDisbursementDetails details = loanDisbursementDetails.get();
					details.setIsAvailCoupons(Boolean.TRUE);
					loanDisbursementRepository.save(details);
				}
			}

		}   catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			saveRequest(request, response, "AVAIL_COUPON", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.AVAIL_COUPON);
		}
		catch (HttpServerErrorException ex) {
			log.error(Constants.AVAIL_COUPON_EXCEPTION);
			saveRequest(request, response, "AVAIL_COUPON", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.AVAIL_COUPON);
		}catch (NoSuchAlgorithmException | InvalidKeyException e) {
			FailureReason obj = getFailureReasonObj(500, "Sign Auth Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
		} catch (JsonProcessingException e) {
			FailureReason obj = getFailureReasonObj(500, "Token Generation Failure", e.getMessage());
			list.add(obj);
			response.setCode(500);
		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage().contains(":")) {
				int i1 = e.getMessage().indexOf("\"");
				int i2 = e.getMessage().lastIndexOf("\"");

				String msg = e.getMessage().substring(i1 + 1, i2);
				String errorResponse = TokenService.decrypt(msg, clientEncryptionKey.getBytes());
				ObjectMapper mapper = new ObjectMapper();
				try {
					response = mapper.readValue(errorResponse, AvailCouponResponse.class);
				} catch (JsonMappingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				} catch (JsonProcessingException e1) {
					FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
					list.add(obj);
					response.setCode(500);
				}
			} else {
				FailureReason obj = getFailureReasonObj(500, "Exception In Avail Coupon", e.getMessage());
				list.add(obj);
				response.setCode(500);
			}
			saveRequest(request, response, "AVAIL_COUPON", "", "", Constants.ERROR);

		}
		response.setFailureReasons(list);
		return response;
	}

	public ApiStatus saveRequest(Object callBackRequest, Object callbackResponse, String apiName, String accountId,
			String transactionId, String status) {
		String jsonObject = null, jsonObjectResponse = null;
		try {
			jsonObject = objectMapper.writeValueAsString(callBackRequest);
			jsonObjectResponse = objectMapper.writeValueAsString(callbackResponse);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ApiStatus apiStatusRequest = ApiStatus.builder().apiName(apiName).accountId(accountId)
				.transactionId(transactionId).journey("PL").requestJson(jsonObject).responseJson(jsonObjectResponse)
				.status(status).build();
		ApiStatus apiStatus = apiStatusRepository.save(apiStatusRequest);
		System.out.println("saved to api status.." + apiStatus.getId());
		return apiStatus;
	}

	public Object getUserDetails(String custId) throws Exception {
		Object response = null;
		try {
			HttpHeaders headers = getUserHttpHeaders(METHOD_POST, userClientId, userdetailsSignauthUrl+custId, "");
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(userDetailsUrl).path(custId).build();
			HttpEntity<String> httpRequest = new HttpEntity<>("", headers);
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
					httpRequest, String.class);

			String decrypted = TokenService.decrypt(responseEntity.getBody(), userClientEncryptionKey.getBytes());
			log.info("[getUserDetails]decrypted Response: " + decrypted);
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(decrypted, Object.class);

			// saveRequest("", response, "USER_DETAILS", "", "", "SUCCESS");

		}   catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
//			 saveRequest("", response, "USER_DETAILS", "", "", Constants.ERROR);
			commonUtil.handleHttpClientError(ex, Constants.USER_DETAILS);
		}
		catch (HttpServerErrorException ex) {
			log.error(Constants.USER_DETAILS_EXCEPTION);
			// saveRequest("", response, "USER_DETAILS", "", "", Constants.ERROR);
			commonUtil.handleHttpServerError(ex, Constants.USER_DETAILS);
		}catch (Exception e) {
			throw new CustomException(HttpStatus.BAD_REQUEST.value(), e.getMessage());
		}
		return response;
	}

	public HttpHeaders getUserHttpHeaders(String methodType, String clientId, String url, String reqBody)
			throws Exception {

		Instant instant = Instant.now();
		long timeStampMillis = instant.toEpochMilli();
		String timestamp = Long.toString(timeStampMillis);
		String nonce = usernoncePrefix + timestamp;

		String signAuth = tokenService.getSignAuth(clientId, methodType, url, reqBody, nonce, timestamp, userClientKey,
				userTokenClientSecret);
		log.info("[getUserHttpHeaders]signAuth: " + signAuth);
		HttpHeaders headers = new HttpHeaders();
		RequestTokenOutput requestTokenOutput = tokenService.getRequestToken(userClientKey, userClientEncryptionKey,
				userTokenClientSecret, usernoncePrefix);
		RequestTokenData requestTokenData = requestTokenOutput.getData();
	
		if (requestTokenData.getAccess_token() != null) {
			String auth = "Bearer " + requestTokenData.getAccess_token();
			String token = requestTokenData.getAuthToken();
			headers.add("Authorization", auth);
			headers.add("auth-token", token);
			log.info("[RewardsService][getHttpHeaders]Authorization: "+auth);
			log.info("[RewardsService][getHttpHeaders]auth-token: "+token);
		}

		headers.add("UserIp", userIp);
		headers.add("client_id", clientId);
		headers.add("sign_auth", signAuth);
		
		log.info("[RewardsService][getHttpHeaders]UserIp: "+userIp);
		log.info("[RewardsService][getHttpHeaders]client_id: "+clientId);
		log.info("[RewardsService][getHttpHeaders]sign_auth: "+signAuth);

		return headers;
	}
	
	public KindWiseBalanceResponse kindwisebalance(String accountid) throws Exception {

		KindWiseBalanceResponse balance = null;
		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(kindwisebalanceurl).path(accountid).build();
           
			HttpHeaders headers = new HttpHeaders();

			headers = tokenService.getRequestHeaders(tokenService.getCognitoToken());

			HttpEntity request = new HttpEntity<>(headers);
			log.info(request);
			
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					request, String.class);

			String response = responseEntity.getBody();
			log.info("Encrypted Text:" + response);

			String decrypted = tokenService.decryption(response, kindwisebalanceiv, kindwisebalancekey);
			ObjectMapper mapper = new ObjectMapper();
			balance = mapper.readValue(decrypted, KindWiseBalanceResponse.class);
		} catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			commonUtil.handleHttpClientError(ex, Constants.KINDWISE_BALANCE);
		} catch (HttpServerErrorException ex) {
			log.error(Constants.KINDWISE_BALANCE_EXCEPTION);
			commonUtil.handleHttpServerError(ex, Constants.KINDWISE_BALANCE);
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return balance;

	}
	
	public ReferrelDetailsResponse referrelDetails(String accountid) throws Exception {

		ReferrelDetailsResponse balance = null;
		try {
			UriComponents builder = UriComponentsBuilder.fromHttpUrl(referrelDetailsurl).path(accountid).build();
           
			HttpHeaders headers = new HttpHeaders();

			headers = tokenService.getRequestHeaders(tokenService.getCognitoToken());

			HttpEntity request = new HttpEntity<>(headers);
			
			log.info(request);
			
			ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
					request, String.class);

			String response = responseEntity.getBody();
			log.info("Encrypted Text:" + response);

			String decrypted = tokenService.decryption(response,kindwisebalanceiv,kindwisebalancekey);
			
			ObjectMapper mapper = new ObjectMapper();
			
			balance = mapper.readValue(decrypted, ReferrelDetailsResponse.class);
			
			log.info("Decrypted Text");
		}  catch (HttpClientErrorException ex) {
			log.error(ex.getResponseBodyAsString());
			commonUtil.handleHttpClientError(ex, Constants.REFERREL_DETAILS);
		}
		catch (HttpServerErrorException ex) {
			log.error(Constants.REFERREL_DETAILS_EXCEPTION);
			commonUtil.handleHttpServerError(ex, Constants.REFERREL_DETAILS);
		}
		catch (Exception ex) {
			log.error(Constants.REFERREL_DETAILS_EXCEPTION);
			throw new InternalException("1000");
		}
		return balance;

	}

}
