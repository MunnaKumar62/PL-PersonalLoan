package com.abc.rewards.dto;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OfferPageDatum {

    @JsonProperty("Id") 
    public String id;
    @JsonProperty("Name") 
    public String name;
    @JsonProperty("SKU") 
    public String sKU;
    @JsonProperty("Source") 
    public String source;
    @JsonProperty("Type") 
    public String type;
    @JsonProperty("ShortDescription") 
    public String shortDescription;
    @JsonProperty("DiscountType") 
    public String discountType;
    @JsonProperty("Discount") 
    public double discount;
    @JsonProperty("StartDate") 
    public String startDate;
    @JsonProperty("EndDate") 
    public String endDate;
    @JsonProperty("DisplayStartDate") 
    public String displayStartDate;
    @JsonProperty("DisplayEndDate") 
    public String displayEndDate;
    @JsonProperty("BrandDetails") 
    public BrandDetails brandDetails;
    @JsonProperty("CategoryId") 
    public Object categoryId;
    @JsonProperty("CategoryName") 
    public Object categoryName;
    @JsonProperty("CategorySKU") 
    public Object categorySKU;
    @JsonProperty("DisplayOrder") 
    public int displayOrder;
    @JsonProperty("IsFeaturedOffer") 
    public boolean isFeaturedOffer;
    @JsonProperty("FeaturedOfferDisplayOrder") 
    public int featuredOfferDisplayOrder;
    @JsonProperty("IsHomePageOffer") 
    public boolean isHomePageOffer;
    @JsonProperty("HomePageOfferDisplayOrder") 
    public int homePageOfferDisplayOrder;
    @JsonProperty("Images") 
    public ArrayList<Image> images;
    @JsonProperty("IsSellable") 
    public boolean isSellable;
    @JsonProperty("MRP") 
    public Object mRP;
    @JsonProperty("NetPrice") 
    public Object netPrice;
    @JsonProperty("RetailPrice") 
    public double retailPrice;
    @JsonProperty("RetailShippingPrice") 
    public double retailShippingPrice;
    @JsonProperty("RetailPriceInclusive") 
    public double retailPriceInclusive;
    @JsonProperty("IsTrending") 
    public boolean isTrending;
    @JsonProperty("IsOnline") 
    public boolean isOnline;
    @JsonProperty("OnlineUrl") 
    public String onlineUrl;
    @JsonProperty("IsInternational") 
    public boolean isInternational;
    @JsonProperty("Language") 
    public String language;
    @JsonProperty("Distance") 
    public Object distance;
    @JsonProperty("IsPinned") 
    public boolean isPinned;
    @JsonProperty("Latitude") 
    public Object latitude;
    @JsonProperty("Longitude") 
    public Object longitude;
    @JsonProperty("TnC") 
    public String tnC;
    @JsonProperty("StoreDetails") 
    public Object storeDetails;
    @JsonProperty("IncentiveType") 
    public Object incentiveType;
    @JsonProperty("IncentiveValue") 
    public double incentiveValue;
    @JsonProperty("MetaKeywords") 
    public String metaKeywords;
    @JsonProperty("OfferCategories") 
    public ArrayList<OfferCategory> offerCategories;
    @JsonProperty("IsCustomAttributes") 
    public boolean isCustomAttributes;
    @JsonProperty("SourceMasterId") 
    public Object sourceMasterId;
    @JsonProperty("MinDiscount") 
    public double minDiscount;
    @JsonProperty("MaxDiscount") 
    public double maxDiscount;
    @JsonProperty("ProviderCode") 
    public String providerCode;
    @JsonProperty("CardTypes") 
    public Object cardTypes;
    @JsonProperty("CardPaymentTypes") 
    public Object cardPaymentTypes;
    @JsonProperty("RedemptionCountries") 
    public Object redemptionCountries;

    @JsonInclude(value = Include.NON_NULL)
    @JsonProperty("Cities") 
    public Object cities;
}
