package com.abc.rewards.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.engines.AESFastEngine;
import org.bouncycastle.crypto.modes.GCMBlockCipher;
import org.bouncycastle.crypto.params.AEADParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.rewards.constants.Constants;
import com.abc.rewards.dto.RequestTokenOutput;
import com.abc.rewards.model.CognitoTokenResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@RequiredArgsConstructor
public class TokenService {

	@Autowired
	private RestTemplate restTemplate;

	@Value("${pl.rewards.cognitoToken.client_id}")
	private String clientId;

	@Value("${pl.rewards.cognitoToken.scope}")
	private String scope;

	@Value("${pl.rewards.cognitoToken.grant_type}")
	private String grantType;

	@Value("${pl.rewards.cognitoToken.authorization}")
	private String authHeader;

	@Value("${pl.rewards.cognitoToken.url}")
	private String cognitoTokenUrl;

	@Value("${pl.rewards.requestToken.url}")
	private String requestTokenUrl;

	@Value("${pl.rewards.client_id}")
	private String requestTokenClientId;

	@Value("${pl.rewards.client_encryption_key}")
	private String clientEncryptionKey;

	@Value("${pl.rewards.userclientkey}")
	private String userClientKey;
	
	@Value("${pl.rewards.clientencryptionkey}")
	private String userClientEncryptionKey;

	//@Value("${pl.rewards.client_key}")
	//private String clientKey;

	private static final String NONCE_PREFIX = "d9e3b0";

	private static final String SHA_256 = "SHA-256";
	private static final String HMAC_SHA256 = "hmacSHA256";
	private static final String UTF_8 = "UTF-8";

	private static final String METHOD_POST = "POST";
	private static final String METHOD_GET = "GET";

	private static int MAC_BIT_SIZE = 128;
	private static int NONCE_BIT_SIZE = 256;
	private static int KEY_BIT_SIZE = 256;

	public String getCognitoToken() {

		UriComponents builder = UriComponentsBuilder.fromHttpUrl(cognitoTokenUrl).queryParam("client_id", clientId)
				.queryParam("scope", scope).queryParam("grant_type", grantType).build();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", authHeader);

		HttpEntity request = new HttpEntity<>(headers);
		ResponseEntity<CognitoTokenResponse> responseEntity = restTemplate.exchange(builder.toUriString(),
				HttpMethod.POST, request, CognitoTokenResponse.class);

		CognitoTokenResponse response = new CognitoTokenResponse();
		response = (CognitoTokenResponse) responseEntity.getBody();

		return response.getAccessToken();

	}

	public RequestTokenOutput getRequestToken(String clientKey, String clientEncryptionKey,String tokenClientSecret, String nonce) throws InvalidKeyException, UnsupportedEncodingException,
			NoSuchAlgorithmException, JsonMappingException, JsonProcessingException {

		UriComponents builder = UriComponentsBuilder.fromHttpUrl(requestTokenUrl).build();

		HttpHeaders headers = new HttpHeaders();

		String methodType = METHOD_POST;
		String reqBody = "";

		// generate timstamp and nonce Instant instant = Instant.now(); long
		Instant instant = Instant.now();
		long timeStampMillis = instant.toEpochMilli();
		String timestamp = Long.toString(timeStampMillis);

		nonce = nonce + timestamp;

		String signAuth = getSignAuth(requestTokenClientId, methodType, requestTokenUrl, reqBody, nonce, timestamp,clientKey, tokenClientSecret);
		String authToken = getCognitoToken();

		headers.add("sign_auth", signAuth);
		headers.add("client_id", requestTokenClientId);
		headers.add("auth-token", authToken);

		HttpEntity request = new HttpEntity<>(headers);
		ResponseEntity<String> responseEntity = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request,
				String.class);

		RequestTokenOutput output = new RequestTokenOutput();

		String response = responseEntity.getBody();

		String decrypted = decrypt(response, clientEncryptionKey.getBytes());
		ObjectMapper mapper = new ObjectMapper();
		output = mapper.readValue(decrypted, RequestTokenOutput.class);
		output.getData().setAuthToken(authToken);

		return output;

	}

	public String getSignAuth(String clientId, String methodType, String url, String reqBody, String nonce,
			String timestamp , String clientKey, String tokenClientSecret) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException {
		// encode the requestURL
		String encodedURL = URLEncoder.encode(url, StandardCharsets.UTF_8.toString()).toLowerCase();

		// If requestBody is NOT empty, base64 encode
		String encodedHashedBody = "";
		if (!reqBody.isEmpty()) {
			encodedHashedBody = getEncodedHashedValue(reqBody);
		}

		// assemble raw HMAC Value as per the Loyalty documentation
		String rawHMACValue = clientId + "|" + methodType + "|" + encodedURL + "|" + nonce + "|" + timestamp + "|"
				+ encodedHashedBody;

		// get HMAC signature from the raw HMAC Value
		String signature = getHMACSignature(rawHMACValue, tokenClientSecret);

		// sign_auth = client_Key + ":" + signature + ":" + nounce + ":" +
		// timeStampMillis;
		String signAuth = clientKey + ":" + signature + ":" + nonce + ":" + timestamp;

		return signAuth;
	}

	public String getEncodedHashedValue(String baseString)
			throws NoSuchAlgorithmException, UnsupportedEncodingException {

		String encodedHashedValue = "";

		MessageDigest digest = MessageDigest.getInstance(SHA_256);
		byte[] hash = digest.digest(baseString.getBytes(UTF_8)); /* recommended to use ASCII encoding here */
		encodedHashedValue = java.util.Base64.getEncoder().encodeToString(hash);

		return encodedHashedValue;

	}

	public String getHMACSignature(String rawHMAC, String tokenClientSecret)
			throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException {
		// Generate HMAC-SHA256 & Encode using Base64
		Mac sha256 = Mac.getInstance(HMAC_SHA256);
		SecretKeySpec secretKey = new SecretKeySpec(tokenClientSecret.getBytes(UTF_8), HMAC_SHA256);
		sha256.init(secretKey);

		String signature = java.util.Base64.getEncoder().encodeToString(sha256.doFinal(rawHMAC.getBytes(UTF_8)));
		return signature;

	}

	public static String decrypt(String encryptedText, byte[] key) {
		String decrString = "";
		try {
			byte[] encryptedBytes = java.util.Base64.getDecoder().decode(encryptedText);
			byte[] iv = Arrays.copyOfRange(encryptedBytes, 0, NONCE_BIT_SIZE / 8);

			GCMBlockCipher cipher = new GCMBlockCipher(new AESFastEngine());
			AEADParameters parameters = new AEADParameters(new KeyParameter(key), MAC_BIT_SIZE, iv, null);
			cipher.init(false, parameters);
			byte[] cipherText = Arrays.copyOfRange(encryptedBytes, NONCE_BIT_SIZE / 8, encryptedBytes.length);

			byte[] plainByte = new byte[cipher.getOutputSize(cipherText.length)];

			int retlen = cipher.processBytes(cipherText, 0, cipherText.length, plainByte, 0);
			cipher.doFinal(plainByte, retlen);

			decrString = new String(plainByte, Charset.forName("UTF-8"));
			return decrString;

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return decrString;
	}
	
	 public String encrypt(String plaintext, byte[] key) throws IllegalStateException, InvalidCipherTextException, IOException {
			String encryptedString = null;
			
	        byte[] iv = key;
	        byte[] plainByte = plaintext.getBytes(UTF_8);

	        GCMBlockCipher cipher = new GCMBlockCipher(new AESFastEngine());
	        AEADParameters parameters = new AEADParameters(new KeyParameter(key), MAC_BIT_SIZE, iv, null);
	        cipher.init(true, parameters);

	        byte[] encryptedBytes = new byte[cipher.getOutputSize(plainByte.length)];

	        int retlen = cipher.processBytes(plainByte, 0, plainByte.length, encryptedBytes, 0);
	        cipher.doFinal(encryptedBytes, retlen);

	        ByteArrayOutputStream str = new ByteArrayOutputStream();

	        str.write(iv);
	        str.write(encryptedBytes);

	        encryptedString = java.util.Base64.getEncoder().encodeToString(str.toByteArray());
	        return encryptedString;

		}
	 
	 public HttpHeaders getRequestHeaders(String token) {
		 
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("auth-token",token);
 
		return headers;
	}
	 public static String decryption(String strToDecrypt, String iv , String key) {
	        try {
	            byte[] iv16bit = convertValuesInto16Bit(iv);
	            byte[] password32bit = convertValuesInto32Bit(key);

	            IvParameterSpec ivSpec = new IvParameterSpec(iv16bit);
	            SecretKeySpec secretKey = new SecretKeySpec(password32bit, "AES");

	            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
	            return new String(cipher.doFinal(new Base64().decode(strToDecrypt)));
	        } catch (Exception e) {
	            throw new RuntimeException();
	        }
	    }

	    public static byte[] convertValuesInto16Bit(String value){
	        value = hash(value);
	        byte[] byteValues = hexStringToByteArray(value);
	        byte[] value16Bit = Arrays.copyOfRange(byteValues, 0, 16);
	        return value16Bit;
	    }

	    public static byte[] convertValuesInto32Bit(String value){
	        value = hash(value);
	        byte[] byteValues = hexStringToByteArray(value);
	        byte[] value32Bit = Arrays.copyOfRange(byteValues, 0, 32);
	        return value32Bit;
	    }

	    public static byte[] hexStringToByteArray(String s) {
	        return DatatypeConverter.parseHexBinary(s);
	    }

	    public static String hash(String s) {
	        return DigestUtils.sha256Hex(s);
	    }
}
