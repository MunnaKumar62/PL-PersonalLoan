package com.abc.rewards;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;


@SpringBootApplication

@OpenAPIDefinition(servers={@Server(url="${swagger.default.server.url}",
        description="Default Server URL")}, info=@Info(title="PL-Rewards Service"))
public class PlRewardsApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(PlRewardsApplication.class, args);
	}

	
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(PlRewardsApplication.class);
    }


}
