package com.abc.rewards.dto;

import java.util.ArrayList;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MemberOfferPageDatum {
	
	@JsonProperty("Id") 
    public String id;
    @JsonProperty("Name") 
    public String name;
    @JsonProperty("SKU") 
    public String sKU;
    @JsonProperty("Type") 
    public String type;
    @JsonProperty("ShortDescription") 
    public String shortDescription;
    @JsonProperty("DiscountType") 
    public String discountType;
    @JsonProperty("Discount") 
    public double discount;
    @JsonProperty("StartDate") 
    public String startDate;
    @JsonProperty("EndDate") 
    public String endDate;
    @JsonProperty("DisplayStartDate") 
    public String displayStartDate;
    @JsonProperty("DisplayEndDate") 
    public String displayEndDate;
    @JsonProperty("BrandDetails") 
    public BrandDetails brandDetails;
    @JsonProperty("DisplayOrder") 
    public int displayOrder;
    @JsonProperty("Images") 
    public ArrayList<Image> images;
    @JsonProperty("IsSellable") 
    public boolean isSellable;
    @JsonProperty("MRP") 
    public double mRP;
    @JsonProperty("NetPrice") 
    public double netPrice;
    @JsonProperty("RetailPrice") 
    public double retailPrice;
    @JsonProperty("RetailShippingPrice") 
    public double retailShippingPrice;
    @JsonProperty("RetailPriceInclusive") 
    public double retailPriceInclusive;
    @JsonProperty("IsOnline") 
    public boolean isOnline;
    @JsonProperty("OnlineUrl") 
    public Object onlineUrl;
    @JsonProperty("IsCoupon") 
    public boolean isCoupon;
    public Coupondetails coupondetails;
    @JsonProperty("ProgramId") 
    public Object programId;

}
