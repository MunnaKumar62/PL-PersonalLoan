package com.abc.rewards.model;

import java.util.List;

import lombok.Data;

@Data
public class KindWiseBalanceResponse {
	
	private Integer responseCode;
	
	private String message;
	
	private List<Payload> payload;
	
	private Object errors;

}
