package com.abc.rewards.config;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.zalando.problem.ProblemModule;
import org.zalando.problem.validation.ConstraintViolationProblemModule;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@Configuration
public class RewardsConfig {

	
	@Bean
	  public RestTemplate restTemplate() {
	    return new RestTemplateBuilder().build();
	  }

	  @Bean
	  public ObjectMapper objectMapper() {
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	    objectMapper.setSerializationInclusion(Include.NON_NULL);
	    objectMapper.setSerializationInclusion(Include.NON_EMPTY);
	    objectMapper.registerModules(
	    		new ProblemModule(),
	    		new ConstraintViolationProblemModule());
	    objectMapper.registerModule(new JavaTimeModule());
	    return objectMapper;
	  }
}
